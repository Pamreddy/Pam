;(function($, window, document, undefined) {
	$(document).ready(function() {
		var items = $('#rcp_items');
    	var groups = $('#rcp_groups');
		$('#rcp_ingredients').keypress(function(e) {
			var groupsCount = 0;
			var itemsCount = 0;
			var arrayOfItems = $(this).val().split("\n");
			for (var i=0; i<arrayOfItems.length; i++) {
				if (arrayOfItems[i] != '') {
					if (arrayOfItems[i][0] === '-' && arrayOfItems[i][1] === '-') {
						groupsCount += 1;
						groups.text( groupsCount );
					} else {
						itemsCount += 1;
						items.text( itemsCount );
					}
				} else {
					groups.text( groupsCount );
					items.text( itemsCount );
				}
			}
		});
		// $('.rcp-sort-table').sortable({
		// 	items: '.rcp-sort-row',
		// 	handle: '.rcp-sort-icon-holder',
		// 	stop : function (e, ui) {
		// 		rcp_indexes($(ui.item).parents('.rcp-sort-table'));
		// 	}
		// });
		$('.rcp-repeater-actions button').on('click', function(e) {
			e.preventDefault();
			var $this = $(this);
			var action = $this.attr('data-action');
			
			var $rcp_fields_parent_container 	= $this.parents('.rcp-fields-container');
			var $rcp_fields_template_container 	= $rcp_fields_parent_container.find('.rcp-fields-templates');
			var $rcp_fields_live_container 		= $rcp_fields_parent_container.find('.rcp-fields-live');
			
			var to_clone = $this.attr('data-clone');
			
			var $rcp_new_row = $rcp_fields_template_container.find('.' + to_clone).clone();
			$rcp_fields_live_container.append( $rcp_new_row );
			rcp_duplicate_row_init( $rcp_new_row, action );
			$('.rcp-sort-table').each(function () {
				rcp_indexes($(this));
			});
			
		});
		$('.rcp-fields-live').on('click', '.rcp-action-button', function(e) {
			e.preventDefault();
			
			var $this = $(this);
			var action = $this.attr('data-action');
			var $rcp_row = $this.parents('.rcp-fields-row');
			var $rcp_fields_live_container = $this.parents('.rcp-fields-live');

			if(action === 'remove') {
				$rcp_row.remove();
			} else if(action === 'clone') {
				var $rcp_new_row = $rcp_row.clone();
				$rcp_new_row.insertAfter($rcp_row);
				rcp_duplicate_row_init($rcp_new_row, action);
			}
			$('.rcp-sort-table').each(function () {
				rcp_indexes($(this));
			});

		});
	function rcp_duplicate_row_init($rcp_row, action) {
		var row_index = parseInt( $rcp_row.parents('.rcp-fields-live').attr('data-field-index'));
		var row_data_name = $rcp_row.parents('.rcp-fields-live').attr('data-name');
		$rcp_row.find('input[type="text"], select, input[type="hidden"], textarea').each(function() {
			var $this = $(this);
			var rcp_field_name = $this.attr('data-field-name');
			var rcp_field_new_name = row_data_name + '[999]' + rcp_field_name;
			$this.attr( 'name', rcp_field_new_name );
		});
		$rcp_row.parents('.rcp-fields-live').attr('data-field-index', row_index + 1);
	}
	function rcp_indexes($element) {
		var old_index;
		var new_index = 0;
		var match_regex = /\[(\d+)\]/;
		$element.find('[name]').each(function (key, value) {
			var rcp_name_attr = $(this).attr('name');
			var rcp_match_data = rcp_name_attr.match(match_regex);
			if( rcp_match_data ) {
				var input_index = rcp_match_data[1];
				if ( old_index !== input_index ) {
					if( typeof old_index !== 'undefined' ) {
						new_index++;
					}
					old_index = input_index;
				}
				var rcp_field_new_name = rcp_name_attr.replace(match_regex, '[' + new_index + ']');
				$(this).attr( 'name', rcp_field_new_name );
			}
		});
	}
 });
})(jQuery, window, document);
