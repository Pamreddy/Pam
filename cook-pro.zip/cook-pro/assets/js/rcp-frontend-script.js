// Non-strict code...
jQuery(document).ready(function($){
	"use strict";

	  //Recipe Popup
    	$('ul.rcp__share-list .customer.share').on("click", function(e) {
  	$(this).rcp_customerPopup(e);
  	});

  	// ingredient list
  	$('.rcp__ingrdnt-list li').on("click",function(){
  		if ( $(this).hasClass('checked') ) {
  			$(this).removeClass('checked');
  		} else {
  			$(this).addClass('checked');
  		}
  	});

  	// prettyPhoto
  	if ( $.isFunction($.fn.prettyPhoto) ) {
  		$("a[rel^='prettyPhoto']").prettyPhoto({
  			theme: 'pp_default',
  			social_tools: false,
  			deeplinking : false
  		});
  	}

  	// slider
  	if ( $.isFunction($.fn.flexslider) ) {
  		if(typeof rcp_flexslider_args != "undefined") {
  			var slider_navigation = rcp_flexslider_args.slidednav == 'true' ? true : false;
  			$(".flexslider").flexslider({
  				animation: rcp_flexslider_args.slideeffect,
  				controlsContainer: ".flex-container",
  				slideshow: true,
  				slideshowSpeed:rcp_flexslider_args.slidespeed,
  				animationSpeed: 1200,
  				directionNav: slider_navigation,
  				controlNav: false,
  				mousewheel: false,
  				smoothHeight :false,
  				prevText: " ", //String: Set the text for the "previous" directionNav item
  				nextText: " ", //String: Set the text for the "next" directionNav item
  			});
  		}
  	}

  	// User login form
  	$('#rcp_message span.notice').on('click',function(){
  		$("#rcp_message").slideUp("slow");
  	});

  	if ($('.rcp-profile-login').length){
  		$('.rcp-profile-login input[type="submit"]').on('click',function(e) {
  			if ($('.rcp-profile-login input[name="log"]').val() && $('.rcp-profile-login input[name="pwd"]').val()){
  				$('.rcp-profile-login .rcp-custom-error').hide();
  			} else {
  				e.preventDefault();
  				$('.rcp-form-wrap').find('.rcp-custom-error').fadeOut(200).fadeIn(200);
  			}
  		});
  	}
  	if ($('.rcp-profile-forgot').length){
  		$('.rcp-profile-forgot input[type="submit"]').on('click',function(e) {
  			if ($('.rcp-profile-forgot input[name="user_login"]').val()){
  				$('.rcp-profile-forgot .rcp-custom-error').hide();
  			} else {
  				e.preventDefault();
  				$('.rcp-profile-forgot').find('.rcp-custom-error').fadeOut(200).fadeIn(200);
  			}
  		});
  	}

  	$(".rcp__search_box3").hide();
  	$(".rcp__search_advanced").on('click',function () {
  		$(".rcp__search_box3").slideToggle(400, 'swing');
  	});
  	iva_recipe_tabs();

  	// When btn is pressed.
  	$(".rcp-post-status-link").on("click",function(){
  		var $this_link = $(this);
  		var data_url = $(this).attr('data-url');
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data: {
  				action: 'rcp_status_ajax_action',
  				postid: $(this).attr('data-id'),
  			},
  			success: function( data ){
  				document.location = data_url;
  			}
  		});
  		return false;
  	});

  	// Likes
  	$('.rcp-rem-favorite').on('click',function(){
  		var $this_link  = $(this);
  		var data_url    = $(this).attr('data-url');
  		var data_id     = $(this).attr('data-id');
  		var data_userid = $(this).attr('data-userid');
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data: {
  				action: 'rcp_rem_favorite_ajax_action',
  				postid: data_id,
  				userid: data_userid,
  			},
  			success: function( data ){
  				document.location = data_url;
  				$('#rcp-rem-favorite-msg').html(data);
  			}
  		});
  		return false;
  	});

  	$('#rcp-favorite-panel').css('display','none');
  	$('.rcp-post-favorite').on('click', function() {
  		var $favoriteLink = $(this);
  		var $id = $(this).attr('id');
  		if($favoriteLink.hasClass('favorited')) return false;
  		var $sendTheData = {
  			action: 'rcp_favorite_ajax_action',
  			favorite_id: $id,
  		};
  		$.post( rcp_post_favorite_localize.ajaxurl, $sendTheData, function(data){
  			$favoriteLink.find('span').html(data);
  			$favoriteLink.addClass('favorited').attr('title', rcp_post_favorite_localize.youFavoritedit);
  			$favoriteLink.find('span').css({'opacity': 1,'width':'auto'});
  			$('#rcp-favorite-panel').fadeIn().css( 'display','block' );
  		});
  		return false;
  	});

  	// comment form error
  	if ($('.form-submit input[type="submit"]').length){
  		$('.form-submit input[type="submit"]').on('click',function(e) {
  			// not loged in
  			if ($('.comment-respond input[name="author"]').length){
  				if( $('.comment-respond textarea#comment').val()
					// && $('.comment-respond input[name="comment_rating"]').val()
					&& $('.comment-respond input[name="email"]').val()
					&& $('.comment-respond input[name="author"]').val()
				){
  					$('.comment-respond .rcp-comment-error').hide();
  				} else {
  					e.preventDefault();
  					$('.comment-respond .rcp-comment-error').fadeOut(200).fadeIn(200);
  				}
  			}else{
  				// login
  				if( $('.comment-respond textarea#comment').val()
					// && $('.comment-respond input[name="comment_rating"]').val()
				) {
  					$('.comment-respond .rcp-comment-error').hide();
  				} else {
  					e.preventDefault();
  					$('.comment-respond .rcp-comment-error').fadeOut(200).fadeIn(200);
  				}
  			}
  		});
  	}

  	// Search Recipes
  	$(".rcp-by-cat-sh-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				nonce 		  : $this_link.data("nonce"),
  				category      : $this_link.data("categories"),
  				cuisine    	  : $this_link.data("cuisines"),
  				method    	  : $this_link.data("methods"),
  				ingredient    : $this_link.data("ingredients"),
  				action     	  : "rcp_sh_cat_more_ajax",
  				number        : $this_link.data("number"),
  				columns		  : $this_link.data("columns"),
  				offset        : $this_link.closest(".rcp-sh-by-cat-module").find(".rcp-sh-by-cat-post").length,
  				orderby 	  : $this_link.data("orderby"),
  				order 		  : $this_link.data("order"),
  				hide_cooktime	: $this_link.data("hide_cooktime"),
  				hide_difflevel	: $this_link.data("hide_difflevel"),
  				hide_yields		: $this_link.data("hide_yields"),
  				hide_ratings	: $this_link.data("hide_ratings"),
  				display_style	: $this_link.data("display_style"),
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-sh-by-cat-module").find(".rcp-sh-by-cat-module-content").append( data );
  				if ( $(".rcp-sh-by-cat-post").length >= count ) {
  					$this_link.remove();
  				}
  			},
  			complete: function( data ) {
  				$(".rcp-comment-ratings-review").each(function(i) {
  					$(this).nextAll().removeClass("rated");
  					$(this).prevAll().removeClass("rated");
  					var data_count = $(this).attr("data-rated");
  					$(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
  				});
  			}
  		} );
  		return false;
  	});

  	// highest rated
  	$(".rcp-hr-sh-load-more-style a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				nonce 		  : $this_link.data("nonce"),
  				action     	  : "rcp_highest_sh_more_recps_ajax",
  				number        : $this_link.data("number"),
  				columns		  : $this_link.data("columns"),
  				hide_cooktime	: $this_link.data("hide_cooktime"),
  				hide_difflevel	: $this_link.data("hide_difflevel"),
  				hide_yields		: $this_link.data("hide_yields"),
  				hide_ratings	: $this_link.data("hide_ratings"),
  				display_style	: $this_link.data("display_style"),
  				offset        : $this_link.closest(".rcp-highest-rated-sh-module").find(".rcp-highest-rated-post").length,
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-highest-rated-sh-module").find(".rcp-highest-rated-sh-module-content").append( data );
  				if ( $(".rcp-highest-rated-post").length >= count ) {
  					$this_link.remove();
  				}
  			},
  			complete: function( data ) {
  				$(".rcp-comment-ratings-review").each(function(i) {
  					$(this).nextAll().removeClass("rated");
  					$(this).prevAll().removeClass("rated");
  					var data_count = $(this).attr("data-rated");
  					$(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
  				});
  			}
  		} );
  		return false;
  	});

  	// Search Recipes
  	$(".rcp-search-load-more a").on("click",function(){

  		 // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				nonce 		  : $this_link.data("nonce"),
  				search_string : $this_link.data("searchstring"),
  				category      : $this_link.data("categories"),
  				cuisine    	  : $this_link.data("cuisines"),
  				method    	  : $this_link.data("methods"),
  				ingredient    : $this_link.data("ingredients"),
  				action     	  : "rcp_more_search_ajax",
  				number        : $this_link.data("number"),
  				columns		  : $this_link.data("columns"),
  				offset        : $this_link.closest(".rcp-search-module").find(".rcp-search-post").length,
  				orderby 	  : $this_link.data("orderby"),
  				order 		  : $this_link.data("order"),
  				hide_cooktime	: $this_link.data("hide_cooktime"),
  				hide_difflevel	: $this_link.data("hide_difflevel"),
  				hide_yields		: $this_link.data("hide_yields"),
  				hide_ratings	: $this_link.data("hide_ratings"),
  				display_style	: $this_link.data("display_style"),
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-search-module").find(".rcp-search-module-content").append( data );
  				if ( $(".rcp-search-post").length >= count ) {
  					$this_link.remove();
  				}
  			},
  			complete: function( data ) {
  				$(".rcp-comment-ratings-review").each(function(i) {
  					$(this).nextAll().removeClass("rated");
  					$(this).prevAll().removeClass("rated");
  					var data_count = $(this).attr("data-rated");
  					$(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
  				});
  			}
  		} );
  		return false;
  	});

  	// Load More Recent Recipes shortcode
  	$(".rcp-recent-sh-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_recent_sh_more_recps_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				columns	: $this_link.data("columns"),
  				hide_cooktime	: $this_link.data("hide_cooktime"),
  				hide_difflevel	: $this_link.data("hide_difflevel"),
  				hide_yields		: $this_link.data("hide_yields"),
  				hide_ratings	: $this_link.data("hide_ratings"),
  				display_style	: $this_link.data("display_style"),
  				offset  		: $(".rcp-recent-sh-module-content").find(".rcp-recent-sh-post").length
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-recent-sh-module").find(".rcp-recent-sh-module-content").append( data );
  				if( $(".rcp-recent-sh-post").length >= count ) {
  					$this_link.remove();
  				}
  			},
  			complete: function( data ) {
  				$(".rcp-comment-ratings-review").each(function(i) {
  					$(this).nextAll().removeClass("rated");
  					$(this).prevAll().removeClass("rated");
  					var data_count = $(this).attr("data-rated");
  					$(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
  				});
  			}
  		});

  		return false;
  	});

  	// Load more comments
  	$(".rcp-comments-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_more_comments_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				offset  : $this_link.closest(".rcp-comment-module").find(".rcp-comment-post").length,
  				orderby : $this_link.data("orderby"),
  				order 	: $this_link.data("order"),
  				postid	: $this_link.data("postid"),
  			},
  			success: function( data ){

  				$(".rcp-comment-module-content").append( data );
  				if ( $(".rcp-comment-post").length >= count ) {
  					$this_link.remove();
  				}
  			}
  		} );
  		return false;
  	});
  	// Load More Users List
  	$(".rcp-users-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_more_users_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				offset  : $this_link.closest(".rcp-user-list-module").find(".rcp-user-post").length,
  				orderby : $this_link.data("orderby"),
  				order 	: $this_link.data("order")
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-user-list-module").find(".rcp-user-list-module-content").append( data );
  				if ( $(".rcp-user-post").length >= count ) {
  					$this_link.remove();
  				}
  			}
  		} );
  		return false;
  	});
  	// Load More User Recipes
  	$(".rcp-user-rcp-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_user_more_recps_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				user_id : $this_link.data("userid"),
  				offset  : $this_link.closest(".rcp-user-module").find(".rcp-user-post").length,
  				orderby : $this_link.data("orderby"),
  				order 	: $this_link.data("order")
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-user-module").find(".rcp-user-module-content").append( data );
  				if( $(".rcp-user-post").length >= count ) {
  					$this_link.remove();
  				}
  			}
  		} );
  		return false;
  	});

  	// Load More User Reviews
  	$(".rcp-user-review-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_user_more_reviews_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				user_id : $this_link.data("userid"),
  				offset  : $this_link.closest(".rcp-user-review-module").find(".rcp-user-review-post").length,
  				orderby : $this_link.data("orderby"),
  				order 	: $this_link.data("order"),
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-user-review-module").find(".rcp-user-review-module-content").append( data );
  				if( $(".rcp-user-review-post").length >= count ) {
  					$this_link.remove();
  				}
  			},
  			complete: function( data ) {
  				$(".rcp-comment-ratings-review").each(function(i) {
  					$(this).nextAll().removeClass("rated");
  					$(this).prevAll().removeClass("rated");
  					var data_count = $(this).attr("data-rated");
  					$(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
  				});
  			}
  		} );
  		return false;
  	});
  	// Favorites
  	$(".rcp-user-fav-load-more a").on("click",function(){ // When btn is pressed.
  		var $this_link = $(this);
  		var count = $this_link.data("count");
  		$.ajax( {
  			type: "POST",
  			url: rcp_panel.ajaxurl,
  			data:
  			{
  				action  : "rcp_user_more_favorites_ajax",
  				nonce 	: $this_link.data("nonce"),
  				number  : $this_link.data("number"),
  				user_id : $this_link.data("userid"),
  				offset  : $this_link.closest(".rcp-user-fav-module").find(".rcp-user-fav-post").length,
  				orderby : $this_link.data("orderby"),
  				order 	: $this_link.data("order")
  			},
  			success: function( data ){
  				$this_link.closest(".rcp-user-fav-module").find(".rcp-user-fav-module-content").append( data );
  				if( $(".rcp-user-fav-post").length >= count ) {
  					$this_link.remove();
  				}
  			}
  		} );
  		return false;
  	});

  	$('.rcp-comment-ratings a').hover(
  	   // Handles the mouseover
  	   function() {
  		   $(this).prevAll().andSelf().addClass('ratings_over');
  	   },
  	   // Handles the mouseout
  	   function() {
  		   $(this).prevAll().andSelf().removeClass('ratings_over');
  	   }
     );

     $('.rcp-comment-ratings a').bind('click', function() {
          var star = this;
          $(star).prevAll().removeClass('ratings_over');
          $(star).prevAll().andSelf().addClass('ratings_over');
          $(star).nextAll().removeClass('rated');
          $('#comment_rating').val( $(star).attr('data-rated') );
          var data_id =$(star).attr('data-rated');
          $('.rcp-comment-ratings .star_' + data_id).prevAll().andSelf().addClass('rated');
      });

  	$('.rcp-comment-ratings-review').each(function(i) {
          $(this).nextAll().removeClass('rated');
          $(this).prevAll().removeClass('rated');
          var data_count = $(this).attr('data-rated');
          $(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
      });

	  var recipe_num_pages,action,sc_class;

	// recent recipes
	if( $('.rcp-recent-sh-post').length > 0 ) {
		recipe_num_pages = $('.rcp-recent-sh-module-content').attr('data-max_no_pages');
		action = 'rcp_recent_sh_more_recps_ajax';
		sc_class = "rcp-recent-sh-module-content";
		if( $( '#inifiniteLoader' ).length ){
			rcp_scroll_action( recipe_num_pages, action, sc_class );
		}
	}

	// top rated recipes
	if( $('.rcp-highest-rated-post').length > 0 ) {
		recipe_num_pages = $('.rcp-highest-rated-sh-module-content').attr('data-max_no_pages');
		action = 'rcp_highest_sh_more_recps_ajax';
		sc_class = "rcp-highest-rated-sh-module-content";
		if( $( '#inifiniteLoader' ).length ){
			rcp_scroll_action( recipe_num_pages, action, sc_class );
		}
	}

	// search recipes
	if( $('.rcp-search-post').length > 0 ) {
		recipe_num_pages = $('.rcp-search-module-content').attr('data-max_no_pages');
		action = 'rcp_more_search_ajax';
		sc_class = "rcp-search-module-content";
		if( $( '#inifiniteLoader' ).length ){
			rcp_scroll_action( recipe_num_pages, action, sc_class );
		}
	}

	// search categories
	if( $('.rcp-sh-by-cat-post').length  > 0 ) {
		recipe_num_pages = $('.rcp-sh-by-cat-module-content').attr('data-max_no_pages');
		action = 'rcp_sh_cat_more_ajax';
		sc_class = "rcp-sh-by-cat-module-content";
		if( $( '#inifiniteLoader' ).length ){
			rcp_scroll_action( recipe_num_pages, action, sc_class );
		}
	}
});

function iva_recipe_tabs(){

	var rcpTabs = jQuery('.rcp__pane');
 	if (!rcpTabs.find('li.current').length){
		rcpTabs.find('li:first-child').addClass("current");
	 }
	if (rcpTabs.length){
		var activeTab = rcpTabs.find('.current > a').attr('href');
		activeTab = activeTab.split('#');
		activeTab = activeTab[1];
		jQuery('#'+activeTab).show();
	}
	jQuery('.rcp-profile__panes ul.rcp__pane li a').on('click',function (g) {
		var tab = jQuery(this).closest('.rcp-profile__panes'),
			index = jQuery(this).closest('li').index();
		tab.find('ul.rcp__pane > li').removeClass('current');

		jQuery(this).closest('li').addClass('current');

		tab.find('.rcp__pane_content').find('div.pane_content').not('div.pane_content:eq(' + index + ')').slideUp();
		tab.find('.rcp__pane_content').find('div.pane_content:eq(' + index + ')').slideDown();

		g.preventDefault();
	} );
}


function rcp_scroll_action( recipe_num_pages, action , sc_class ){

	if (typeof recipe_num_pages !== typeof undefined && recipe_num_pages !== false) {
		var count = 2;
		var total = recipe_num_pages;
		jQuery(window).scroll(function(){
			if  (jQuery(window).scrollTop() >= (jQuery('.' + sc_class).offset().top) - 100 ) {
				if (count > total){
					return false;
				}else{
					rcp_load_recipes( count, action, sc_class );
				}
				count++;
			}
		});
	}
}


function rcp_load_recipes( pageNumber, action, sc_class ){
	var	hide_cooktime 	= jQuery('.'+ sc_class + '-ajax').attr('data-hide_cooktime');
	var hide_difflevel  = jQuery('.'+ sc_class + '-ajax').attr('data-hide_difflevel');
	var hide_yields 	= jQuery('.'+ sc_class + '-ajax').attr('data-hide_yields');
	var hide_ratings 	= jQuery('.'+ sc_class + '-ajax').attr('data-hide_ratings');
	var hide_author 	= jQuery('.'+ sc_class + '-ajax').attr('data-hide_author');
	var display_style 	= jQuery('.'+ sc_class + '-ajax').attr('data-display_style');
	var limit 			= jQuery('.'+ sc_class + '-ajax').attr('data-limit');
	var columns 		= jQuery('.'+ sc_class + '-ajax').attr('data-columns');
	var scroll_page		= jQuery('.'+ sc_class + '-ajax').attr('data-scroll_page');
	var nonce			= jQuery('.'+ sc_class + '-ajax').attr('data-nonce');

	//
	var orderby			= jQuery('.'+ sc_class ).attr('data-orderby');
	var order			= jQuery('.'+ sc_class ).attr('data-order');
	var category 		= jQuery('.'+ sc_class ).attr('data-categories');
	var cuisine 		= jQuery('.'+ sc_class ).attr('data-cuisines');
	var method 			= jQuery('.'+ sc_class ).attr('data-methods');
	var ingredient 		= jQuery('.'+ sc_class ).attr('data-ingredients');
	var search_string 	= jQuery('.'+ sc_class ).attr('data-searchstring');

	jQuery('#inifiniteLoader').show('10000');
	jQuery.ajax({
		url:rcp_panel.ajaxurl,
		type:'POST',
		data: "action=" + action + "&page_no="+ pageNumber+ '&columns='+ columns+ '&number='+ limit+ '&hide_cooktime='+ hide_cooktime+'&hide_difflevel='+ hide_difflevel+ '&hide_yields='+ hide_yields + '&hide_ratings='+ hide_ratings + '&hide_author='+ hide_author  + '&display_style='+ display_style + '&scroll_page='+ scroll_page+'&nonce='+ nonce + '&category='+ category + '&cuisine='+ cuisine + '&method='+ method + '&ingredient='+ ingredient + '&orderby='+ orderby + '&order='+ order + '&search_string='+ search_string ,
		success: function(html){
			jQuery('#inifiniteLoader').hide('1500');
			jQuery('.' + sc_class ).append(html);    // This will be the div where our content will be loaded
			jQuery(".rcp-comment-ratings-review").each(function(i) {
				jQuery(this).nextAll().removeClass("rated");
				jQuery(this).prevAll().removeClass("rated");
				var data_count = jQuery(this).attr("data-rated");
				jQuery(this).find('.star_' + data_count).prevAll().andSelf().addClass('rated');
			});
		},
	});
	return false;
}


(function ($) {
	/**
	 * jQuery function to prevent default anchor event and take the href * and the title to make a share popup
	 *
	 * @param  {[object]} e           [Mouse event]
	 * @param  {[integer]} intWidth   [Popup width defalut 500]
	 * @param  {[integer]} intHeight  [Popup height defalut 400]
	 * @param  {[boolean]} blnResize  [Is popup resizeabel default true]
	 */
	$.fn.rcp_customerPopup = function (e, intWidth, intHeight, blnResize) {
	  // Prevent default anchor event
	  e.preventDefault();
	  // Set values for window
	  intWidth = intWidth || '500';
	  intHeight = intHeight || '400';
	  strResize = (blnResize ? 'yes' : 'no');
	  // Set title and open popup with focus on it
	  var strTitle = ((typeof this.attr('title') !== 'undefined') ? this.attr('title') : 'Social Share'),
		  strParam = 'width=' + intWidth + ',height=' + intHeight + ',resizable=' + strResize,
		  objWindow = window.open(this.attr('href'), strTitle, strParam).focus();
	};
	// Ingredient Tabs
	$('.rcp__ingrdnt-nutri ul.rcp__ingrdnt_pane').addClass('active').find('> li:eq(0)').addClass('current');
	$('.rcp__ingrdnt-nutri .pane_content:first').show();
	$('.rcp__ingrdnt-nutri ul.rcp__ingrdnt_pane li a').on('click',function (g) {
		var tab = $(this).closest('.rcp__ingrdnt-nutri'),
			index = $(this).closest('li').index();
		tab.find('ul.rcp__ingrdnt_pane > li').removeClass('current');
		$(this).closest('li').addClass('current');
		tab.find('.rcp__pane_content').find('div.pane_content').not('div.pane_content:eq(' + index + ')').slideUp();
		tab.find('.rcp__pane_content').find('div.pane_content:eq(' + index + ')').slideDown();

		g.preventDefault();
	} );
})(jQuery);

// Non-strict code..
