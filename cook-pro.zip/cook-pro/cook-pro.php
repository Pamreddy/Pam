<?php
/**
 * Plugin Name: Cook Pro New
 * Plugin URI: http://www.aivahthemes.com/
 * Description: The Powerful and advanced plugin for listing and managing food recipes.
 * Version: 3.1
 * Author: AivahThemes
 * Author URI: URI: http://themeforest.net/user/AivahThemes
 * Text Domain: cookpro_textdomain
 * Domain Path: /language/
 */
if ( ! class_exists( 'Aivah_Recipe_Class' ) ) {

	class Aivah_Recipe_Class {

		public function __construct() {

			define( 'RECIPE_DIR', plugin_dir_path( __FILE__ ) );
			define( 'RECIPE_URI', plugin_dir_url( __FILE__ ) );

			define( 'RECIPE_INC_DIR', plugin_dir_path( __FILE__ ) . 'includes/' );
			define( 'RECIPE_JS_URI', plugin_dir_url( __FILE__ ) . 'assets/js/' );
			define( 'RECIPE_CSS_URI', plugin_dir_url( __FILE__ ) . 'assets/css/' );
			define( 'RECIPE_IMG_URI', plugin_dir_url( __FILE__ ) . 'assets/images/' );

			$this->recipe_post_type();
			$this->recipe_meta();
			$this->recipe_common();
			$this->recipe_shortcodes();
			$this->recipe_widgets();
			$this->recipe_settings();
		}
		function recipe_meta() {
			require_once( RECIPE_DIR . 'includes/rcp-meta-box.php' );
			require_once( RECIPE_DIR . 'includes/rcp-meta-helper.php' );
		}

		/**
		 * Load custom post types templates
		 * @files testimonials
		 */
		function recipe_post_type() {
		    require_once( RECIPE_DIR . 'post-type/recipe.php' );
		}

		/* Common Files */
		function recipe_common() {
			require_once( RECIPE_INC_DIR . 'rcp-functions.php' );
			require_once( RECIPE_INC_DIR . 'rcp-filters-actions-hooks.php' );
		}
		/* Shortcodes */
		function recipe_shortcodes() {
			require_once( RECIPE_DIR . 'shortcodes/rcp-login-form.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-user-profile.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-submit-form.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-user-list.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-search-recipes.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-recent-recipes.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-featured-chef.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-categories.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-top-rated-recipe.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-top-rated-recipes.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-most-liked-recipe.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-most-fav-recipe.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-most-viewed-recipe.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-top-contributor.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-featured-recipe.php' );
			require_once( RECIPE_DIR . 'shortcodes/rcp-cats.php' );
		}
		function recipe_settings() {
			require_once( RECIPE_DIR . 'settings/rcp-import-export-options.php' );
		}
		/* recipe_widgets */
		function recipe_widgets() {
			require_once( RECIPE_DIR . 'widgets/rcp-author-info.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-recent-posts.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-liked-posts.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-viewed-posts.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-favorite-posts.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-chef-widget.php' );
			require_once( RECIPE_DIR . 'widgets/rcp-top-rated.php' );
		}
	}
	$recipe_obj = new Aivah_Recipe_Class();
}
/**
 * Register and enqueue scripts & styles for short codes
 */
if ( ! function_exists( 'rcp_admin_scripts' ) ) {

	function rcp_admin_scripts() {
		// Styles
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_localize_script('jquery', 'rcp_panel',
			array(
				'plugin_url' => RECIPE_URI,
				'ajaxurl' 	 => admin_url( 'admin-ajax.php' ),
			)
		);
		wp_enqueue_style( 'iva-rcp-fontello' , RECIPE_URI . 'assets/fontello/css/fontello.css', false,true,'all' );
		wp_enqueue_style( 'iva-rcp-admin', RECIPE_URI . 'assets/css/rcp-admin-style.css', false,false,'all' );
		wp_enqueue_script( 'iva-rcp-meta', RECIPE_URI . 'assets/js/rcp-form.js', 'jquery','', true );
		wp_enqueue_script( 'iva-rcp-gallery-meta', RECIPE_URI . 'assets/js/rcp-admin-script.js', 'jquery','',true );

		// Modal
		wp_enqueue_style( 'iva-rcp-modal-component' , RECIPE_URI . 'assets/css/component.css', false,false,'all' );
		wp_enqueue_script( 'iva-rcp-classie',RECIPE_URI . 'assets/js/classie.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'iva-rcp-modalEffects',RECIPE_URI . 'assets/js/modalEffects.js', array( 'jquery' ), '', true );
	}
	add_action( 'admin_enqueue_scripts', 'rcp_admin_scripts' );
}
/**
 * Flex Slider Enqueue Scripts
 */
if ( ! function_exists( 'rcp_flexslider_enqueue_scripts' ) ) {
	add_action( 'rcp_plugin_flexslider','rcp_flexslider_enqueue_scripts' );
	function rcp_flexslider_enqueue_scripts() {
		$fs_slidespeed 	 = get_option( 'rcp_flexslider_speed' ) ? get_option( 'rcp_flexslider_speed' ) : '3000';
		$fs_slideeffect  = get_option( 'rcp_flexslider_effect' ) ? get_option( 'rcp_flexslider_effect' ) : 'fade';
		$fs_slidednav 	 = get_option( 'rcp_flexslider_nav' ) ? get_option( 'rcp_flexslider_nav' ) : 'true';
		$flexslider_args = array(
								'slideeffect' => $fs_slideeffect,
								'slidespeed'  => $fs_slidespeed,
								'slidednav'	  => $fs_slidednav,
							);
		wp_enqueue_script( 'flexslider', RECIPE_URI . 'assets/js/jquery.flexslider-min.js', array( 'jquery' ), '', true );
		wp_localize_script( 'flexslider', 'rcp_flexslider_args', $flexslider_args );
		wp_enqueue_style( 'flexslider-style', RECIPE_URI . 'assets/css/flexslider.css' );
	}
}
/**
 * register and enqueue scripts & styles for short codes
 */

if ( ! function_exists( 'rcp_frontend_scripts' ) ) {
	function rcp_frontend_scripts() {
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_localize_script('jquery', 'rcp_panel',
			array(
				'plugin_url' => RECIPE_URI,
				'ajaxurl' 	 => admin_url( 'admin-ajax.php' ),
			)
		);
		wp_enqueue_style( 'iva-rcp-fontello' , RECIPE_URI . 'assets/fontello/css/fontello.css', false,true,'all' );
		wp_enqueue_style( 'rcp-font-awesome', RECIPE_URI . 'assets/fonts/fontawesome/css/font-awesome.css', array(), false, 'all' );
		wp_enqueue_style( 'rcp-frontend-style', RECIPE_CSS_URI . 'rcp-frontend-style.css', '', true, 'all' );
		wp_enqueue_script( 'rcp-front-js', RECIPE_URI . 'assets/js/rcp-frontend-script.js', 'jquery','', true );
		wp_enqueue_script( 'rcp-captcha-js','//www.google.com/recaptcha/api.js', 'jquery','', true );
		wp_enqueue_script( 'prettyPhoto-js', RECIPE_URI . 'assets/js/jquery.prettyPhoto.js', 'jquery','', true );
		wp_enqueue_style( 'prettyPhoto-style', RECIPE_CSS_URI . 'prettyPhoto.css', '', false, 'all' );
		wp_enqueue_script( 'rcp-meta', RECIPE_URI . 'assets/js/rcp-form.js', 'jquery','', true );
	}
	add_action( 'wp_enqueue_scripts', 'rcp_frontend_scripts', 99 );
}

require_once( RECIPE_INC_DIR . '/rcp-post-like.php' );
require_once( RECIPE_DIR . 'settings/rcp-class-settings.php' );
require_once( RECIPE_DIR . 'settings/options/rcp-options.php' );

// Update file
require_once( RECIPE_DIR . '/rcp-plugin-update-file.php' );

//
if ( ! function_exists( 'rcp_get_attachment_id_from_src' ) ) {
	function rcp_get_attachment_id_from_src( $image_src ) {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE guid = %s", $image_src ) );
		return $id;
	}
}
if ( ! function_exists( 'rcp_attachment_url_to_postid' ) ) {
	function rcp_attachment_url_to_postid( $url ) {
		global $wpdb;

		$dir  = wp_upload_dir();
		$path = $url;

		if ( 0 === strpos( $path, $dir['baseurl'] . '/' ) ) {
			$path = substr( $path, strlen( $dir['baseurl'] . '/' ) );
		}
		$id = $wpdb->prepare(
			"SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value = %s",
			$path
		);
		$post_id = $wpdb->get_var( $id );
		if ( ! empty( $post_id ) ) {
			return (int) $post_id;
		}
	}
}
add_image_size( 'rcp_post_image', 450, 675, true );
add_image_size( 'rcp_post_thumbnail', 60, 90, true );
add_image_size( 'rcp_medium_horizontal', 1280, 720, true );
add_image_size( 'rcp_medium_vertical', 540, 720, true );
add_image_size( 'rcp_medium_square', 540, 540, true );

// Plugin Header Output
function rcp_plugin_header() {
	global $wpdb;
	$rcp_plugin_data = get_plugin_data( __FILE__ );
	$output = '<div class="rcp-section main-heading">';
	$output .= '<div class="rcp-plugin-desc">';
	$output .= '<div class="rcp_icon green rcp-logo"><span class="dashicons dashicons-carrot"></span></div>';
	$output .= '<h3 class="plugin_title">' . esc_html( $rcp_plugin_data['Name'] ) . ' <span class="rcp_version">' . esc_html( $rcp_plugin_data['Version'] ) . '</span></h3>';
	$output .= '<div class="about-text">' . esc_html__( 'The powerful WordPress Plugin.','cookpro_textdomain' ) . '</div>';
	$output .= '</div>'; //.rcp-plugin-desc


	$output .= '<div class="rcp-manual-update"><a id="rcp_update_plugin" class="button green-button button-hero rcp_update_plugin md-trigger" data-modal="rcp_update_plugin_dialog">' . esc_html__( 'Manual Update Plugin','cookpro_textdomain' ) . '</a></div>';

	$output .= '</div>'; //. rcp-section main-heading

	// Update Plugin Dialog Form

	$output .= '<div id="rcp_update_plugin_dialog" class="rcp_update_plugin_dialog md-modal md-effect-1">';
	$output .= '<div class="md-content">';
	$output .= '<div>';
	$output .= '<h3>' . esc_html__( 'Update Cook Pro','cookpro_textdomain' ) . '</h3>';
	$output .= '<p>' . esc_html__( 'Select a file provided within the package "cook-pro.zip" If you update the plugin The files will be overwriten.','cookpro_textdomain' ) . '</p>';
	$output .= '<p>' . esc_html__( 'Choose the update file:','cookpro_textdomain' ) . '</p>';
	$output .= '<form action="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '" enctype="multipart/form-data" method="post">';
	$output .= '<input type="hidden" name="action" value="rcp_update_plugin_ajax_action">';
	$output .= '<p><input type="file" name="rcp_update_file" class="input_update_slider"></p>';
	$output .= '<p><input type="submit" class="button green-button button-hero subbtn" value="' . esc_html__( 'Update Plugin','cookpro_textdomain' ) . '"></p>';
	$output .= '</form>';
	$output .= '<p><a class="button red-button md-close">' . esc_html__( 'Close me!','cookpro_textdomain' ) . '</a></p>';
	$output .= '</div>';
	$output .= '</div>';//rcp_update_plugin_dialog
	$output .= '</div>';//md-content
	$output .= '<div class="md-overlay"></div>';

	return $output;
}

// Plugin Section Header Output
function iva_rcp_section_header( $icon, $title ) {
	$output = '<div class="rcp_icon blue"><span class="ivaIcon "><i class="' . $icon . '"></i></span></div>';
	$output .= '<span class="rcp-sub-title">' . $title . '</span>';

	return $output;
}

// Adds login logout to the admin menu
add_filter( 'wp_nav_menu_items', 'cookpro_add_login_logout_link', 10, 2 );
function cookpro_add_login_logout_link( $items, $args) {
	ob_start();
	wp_loginout('index.php');
	$loginoutlink = ob_get_contents();
	ob_end_clean();
	$items .= '<li>'. $loginoutlink .'</li>';
	return $items;
}
//
if ( ! function_exists( 'rcp_category_enqueue_scripts' ) ) {
	function rcp_category_enqueue_scripts() {
		// if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
			wp_enqueue_script( 'rcp-cpt-custom-script', RECIPE_URI . 'assets/js/rcp-category-script.js', false, '', false );
		// }
	}
	add_action( 'admin_enqueue_scripts', 'rcp_category_enqueue_scripts' );
}
