<?php
/* Recipe Meta box setup function. */
global $post;
$rcp_difficulty_level_arr = array();
$rcp_diff_level_options = get_option( 'rcp_diff_level_options' );
if ( ! empty( $rcp_diff_level_options ) ) {
	$rcp_diff_level_array = explode( "\r\n", $rcp_diff_level_options );
	if ( ! empty( $rcp_diff_level_array ) ) {
		foreach ( $rcp_diff_level_array as $key => $val ) {
			$rcp_difficulty_level_arr[ $val ] = $val;
		}
	}
}
$rcp_difficulty_level = array(
	'easy' 	=> esc_html__( 'Easy', 'cookpro_textdomain' ),
	'medium' => esc_html__( 'Medium', 'cookpro_textdomain' ),
	'hard' 	=> esc_html__( 'Hard', 'cookpro_textdomain' ),
);
if ( ! empty( $rcp_diff_level_options ) || ! empty( $rcp_difficulty_level_arr ) ) {
	$rcp_difficulty_level = array_merge( $rcp_difficulty_level_arr, $rcp_difficulty_level );
}

$this->meta_box[] = array(
	'id'		=> 'Recipe-meta-box',
	'title'		=> esc_html__( 'Recipe Information', 'cookpro_textdomain' ),
	'page'		=> array( 'recipe' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(
		// Recipe Single Style
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Show Layout Style', 'cookpro_textdomain' ),
			'desc'  => esc_html__( 'Description that will appearin single recipe page', 'cookpro_textdomain' ),
			'id'	=> 'rcp_single_layout',
			'std'	=> '',
			'type'	=> 'select',
			'options' => array(
					'' => esc_html__( 'Default From Settings', 'cookpro_textdomain' ),
					'horizontal_style' => esc_html__( 'Horizontal Style', 'cookpro_textdomain' ),
					'vertical_style' => esc_html__( 'Vertical Style', 'cookpro_textdomain' ),
					),
		),

		// Recipe Sub Title
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Sub Title', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Text that will appear under recipe title on the single recipe page (optional)', 'cookpro_textdomain' ),
			'id'	=> 'recipe_sub_title',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Recipe Ingredients
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Recipe Ingredients', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'One item per line use double hyphen for grouping( ex: --New Group )', 'cookpro_textdomain' ),
			'id'	=> 'recipe_ingredients',
			'std'	=> '',
			'type'	=> 'textarea',
		),
		// Recipe Ingredients Count
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Recipe Ingredients Count', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Displays indgredients count', 'cookpro_textdomain' ),
			'id'	=> 'recipe_ingredients_count',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Recipe Steps
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Recipe Steps', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'One item per line use double hyphen for grouping( ex: --New Group ) and use tilde for time duration ( ex: ~30 mins~ )', 'cookpro_textdomain' ),
			'id'	=> 'recipe_steps',
			'std'	=> '',
			'type'	=> 'textarea',
		),
		// Recipe Qucik Description
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Quick Description', 'cookpro_textdomain' ),
			'desc'  => esc_html__( 'Description that will appearin single recipe page, keep it short and sweet', 'cookpro_textdomain' ),
			'id'	=> 'recipe_short_info',
			'std'	=> '',
			'type'	=> 'textarea',
			'class' => ' select50',
		),
		// Recipe Servings
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Serves', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'How many people does it serve. A number for the servings amount. eg.4', 'cookpro_textdomain' ),
			'id'	=> 'recipe_servings',
			'std'	=> '',
			'type'	=> 'text',
			'class' => ' select25',
		),
		// Recipe Difficulty Level
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Difficulty Level', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Choose level to made recipe', 'cookpro_textdomain' ),
			'id'	=> 'recipe_diff_level',
			'std'	=> '',
			'type'	=> 'select',
			'options' => $rcp_difficulty_level,
			'class' => ' select25 last',
		),
		// Recipe Preparation Time
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Preparation Time', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'The time takes to prepare the recipe.', 'cookpro_textdomain' ),
			'id'	=> 'recipe_ptime',
			'std'	=> '',
			'type'	=> 'recipe_timing_meta',
			'class' => ' select50',
		),
		// Recipe Cooking Time
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Cooking Time', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'The time takes to cook the recipe.', 'cookpro_textdomain' ),
			'id'	=> 'recipe_ctime',
			'std'	=> '',
			'type'	=> 'recipe_timing_meta',
			'class' => ' select50 last',
		),
		// Recipe Equipment Needed
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Equipment Needed (Optional)', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Any special equipment worthy of mentioning that is required. eg. Thermomix, Slow-Cooker', 'cookpro_textdomain' ),
			'id'	=> 'recipe_equipments',
			'std'	=> '',
			'type'	=> 'equipments_meta',
			'class' => ' select50',
		),
		// Recipe Video URL
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Video', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Enter the video embed code which will display on your single-recipe.php', 'cookpro_textdomain' ),
			'id'	=> 'recipe_video_url',
			'std'	=> '',
			'type'	=> 'textarea',
			'class' => ' select50 last',
		),
		// Recipe nutritions
		//--------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Recipe Nutritions', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Add all of the nutritions for this recipe.', 'cookpro_textdomain' ),
			'id'	=> 'recipe_nutritions',
			'std'	=> '',
			'type'	=> 'nutrition_meta',
		),
	),
);
$this->meta_box[] = array(
	'id'		=> 'Recipe-gallery-meta-box',
	'title'		=> esc_html__( 'Recipe Information', 'cookpro_textdomain' ),
	'page'		=> array( 'recipe' ),
	'context'	=> 'side',
	'priority'	=> 'core',
	'fields'	=> array(
		array(
			'name'	=> esc_html__( 'Recipe Gallery', 'cookpro_textdomain' ),
			'desc'	=> esc_html__( 'Recipe Gallery.', 'cookpro_textdomain' ),
			'id'	=> 'recipe_gallery',
			'std'	=> '',
			'type'	=> 'gallery_meta',
		),
	),
);
