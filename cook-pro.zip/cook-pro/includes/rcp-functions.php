<?php
/**
 * function rcp_get_option()
 * Retrieves options data from database
 */
if ( ! function_exists( 'rcp_get_option' ) ) {
	function rcp_get_option( $key, $default = false ) {
		$value = get_option( $key ) ? get_option( $key ) : $default;
		return $value;
	}
}
/**
 * function rcp_registration_form()
 * User Registration Form
 */
function cookpro_body_classes($classes) {
        $classes[] = 'rcp-cook-pro';
        return $classes;
}
add_filter('body_class', 'cookpro_body_classes');
/**
 * function rcp_registration_form()
 * User Registration Form
 */
if ( ! function_exists( 'rcp_registration_form' ) ) {
	function rcp_registration_form( $first_name, $last_name ,$email, $position, $reg_captcha ) {

		$out = '<form action="' . $_SERVER['REQUEST_URI'] . '" method="post" class="wp-user-form">';
		$out .= do_action( 'recipe_before_registration_fields' );

		// first name
		$out .= '<p class="first_name">';
		$out .= '<label for="first_name">' . esc_html__( 'First Name','cookpro_textdomain' ) . '<span class="required">*</span></label>';
		$out .= '<input type="text" name="first_name" value="' . ( isset( $_POST['first_name'] ) ? $first_name : null ) . '" id="first_name" tabindex="101" />';
		$out .= '</p>';

		// Last name
		$out .= '<p class="last_name">';
		$out .= '<label for="last_name">' . esc_html__( 'Last Name', 'cookpro_textdomain' ) . '<span class="required">*</span></label>';
		$out .= '<input type="text" name="last_name" value="' . ( isset( $_POST['last_name'] ) ? $last_name : null ) . '" id="last_name" tabindex="102" />';
		$out .= '</p>';

		// email
		$out .= '<p class="email">';
		$out .= '<label for="email">' . esc_html__( 'Email ID', 'cookpro_textdomain' ) . '<span class="required">*</span></label>';
		$out .= '<input type="text" name="email" value="' . ( isset( $_POST['email'] ) ? $email : null ) . '" id="email" tabindex="103" />';
		$out .= '</p>';

		// Position
		$out .= '<p class="position">';
		$out .= '<label for="email">' . esc_html__( 'Position', 'cookpro_textdomain' ) . '</label>';
		$out .= '<input type="text" name="position" value="' . ( isset( $_POST['position'] ) ? $position : null ) . '" id="position" tabindex="103" />';
		$out .= '</p>';

		$rcp_site_key = rcp_get_option( 'rcp_google_api_site_key' ) ? rcp_get_option( 'rcp_google_api_site_key' ) : '';
		$out .= '<div class="g-recaptcha" data-sitekey="' . esc_attr( $rcp_site_key ). '"></div>';
		$out .= do_action( 'recipe_after_registration_fields' );
		$out .= '<br /><input type="submit" name="submit" value="' . esc_html__( 'Register','cookpro_textdomain' ) . '" class="user-submit" tabindex="105" />';
		$out .= '</form>';

		return $out;
	}
}
/**
 * function rcp_user_edit_form()
 * User Edit Form
 */
if ( ! function_exists( 'rcp_user_edit_form' ) ) {
	function rcp_user_edit_form() {
		global $post;

		$current_user = wp_get_current_user();

		$out = '<form method="post" enctype="multipart/form-data" id="rcp-user-edit-form" action="' . get_permalink() . '">';
		$out .= '<div class="rcp-form-options">';
		$out .= '<div class="rcp-form-field rcp-user-username">';
		$out .= '<label for="username">' . esc_html__( 'User Name', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="user_login" type="text" id="username" value="' . $current_user->user_login . '" disabled /></div>';
		$out .= '</div>'; // .rcp-user-nickname

		$out .= '<div class="rcp-form-field rcp-user-nickname">';
		$out .= '<label for="nickname">' . esc_html__( 'Display Name', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="nickname" type="text" id="nickname" value="' . get_the_author_meta( 'nickname', $current_user->ID ) . '" /></div>';
		$out .= '</div>'; // .rcp-user-nickname

		$out .= '<div class="rcp-form-field rcp-user-email">';
		$out .= '<label for="email">' . esc_html__( 'E-mail *', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="email" type="text" id="email" value="' . get_the_author_meta( 'user_email', $current_user->ID ) . '" disabled /></div>';
		$out .= '</div>';//rcp-user-email

		$out .= '<div class="rcp-form-field rcp-user-url">';
		$out .= '<label for="url">' . esc_html__( 'Website', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="url" type="text" id="url" value="' . get_the_author_meta( 'user_url', $current_user->ID ) . '"></div>';
		$out .= '</div>'; //.rcp-user-url

		$out .= '<div class="rcp-form-field rcp-user-password">';
		$out .= '<label for="pass1">' . esc_html__( 'Change Password', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="pass1" type="password" id="pass1" /></div>';
		$out .= '</div>'; //.Change-password

		$out .= '<div class="rcp-form-field rcp-user-password">';
		$out .= '<label for="pass2">' . esc_html__( 'Repeat Password', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="pass2" type="password" id="pass2" /></div>';
		$out .= '</div>'; // .Repeat-password

		$out .= '<div class="rcp-form-field rcp-user-textarea">';
		$out .= '<label for="description">' . esc_html__( 'Short Bio', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><textarea name="description" id="description" rows="3" cols="50">' . esc_textarea( get_the_author_meta( 'description', $current_user->ID ) ) . '</textarea></div>';
		$out .= '</div>';// .rcp-user-textarea

		// action hook for plugin and extra fields
		ob_start();
		$out .= do_action( 'edit_user_profile', $current_user );
		$out .= ob_get_clean();

		$out .= '<div class="rcp-form-field rcp-user-avatar">';
		$out .= '<label for="avatar">' . esc_html__( 'Update Avatar', 'cookpro_textdomain' ) . '</label>';
		$out .= '<div class="rcp-form-input"><div class="rcp-profile-upload">';
		$out .= '<input class="field" name="avatar" type="file" id="avatar" value="" /></div></div>';

		if ( get_user_meta( $current_user->ID, 'avatar',true ) ) {
			$out .= wp_get_attachment_image( get_user_meta( $current_user->ID,'avatar',true ), array( 80, 80 ) );
		} else {
			$out .= get_avatar( $current_user->ID, 80 );
		}

		$out .= wp_nonce_field( 'avatar_upload', 'avatar_nonce' );
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'JPG or PNG. 100ï¿½100 pixels. If your image is bigger than the sizes above, weï¿½ll help you crop it.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-user-nickname

		$out .= '<div class="rcp-form-field rcp-user-submit">';
		$out .= '<div class="rcp-form-input"><input name="rcp_update_user" type="submit" id="updateuser" class="submit button" value="' . esc_html__( 'Update Settings', 'cookpro_textdomain' ) . '" /></div>';
		$out .= wp_nonce_field( 'rcp-update-user' );
		$out .= '<input name="action" type="hidden" id="action" value="rcp-update-user" />';
		$out .= '</div>'; //rcp-user-submit
		$out .= '</div>'; // rcp-form-options/
		$out .= '</form>'; // #adduser

		return $out;
	}
}
/**
 * function rcp_submit_form_fields()
 * Submit Form
 */
if ( ! function_exists( 'rcp_submit_form_fields' ) ) {
	function rcp_submit_form_fields( $rcp_id ) {
		$rcp_difficulty_level_arr = array();
		$rcp_diff_level_options = rcp_get_option( 'rcp_diff_level_options' );
		if ( ! empty( $rcp_diff_level_options ) ) {
			$rcp_diff_level_array = explode( "\r\n", $rcp_diff_level_options );
			if ( ! empty( $rcp_diff_level_array ) ) {
				foreach ( $rcp_diff_level_array as $key => $val ) {
					$rcp_difficulty_level_arr[$val] = $val;
				}
			}
		}
		$rcp_difficulty_level = array(
			'easy' 	=> esc_html__( 'Easy', 'cookpro_textdomain' ),
			'medium'=> esc_html__( 'Medium','cookpro_textdomain' ),
			'hard' 	=> esc_html__( 'Hard','cookpro_textdomain' ),
		);
		if ( ! empty( $rcp_diff_level_options) || !empty($rcp_difficulty_level_arr) ) {
			$rcp_difficulty_level = array_merge( $rcp_difficulty_level_arr, $rcp_difficulty_level );
		}
		$rcp_post_categories 	  = rcp_get_terms( $taxonomy = 'recipe_cat' );
		$rcp_post_cuisines 		  = rcp_get_terms( $taxonomy = 'recipe_cuisine' );
		$rcp_post_cooking_methods = rcp_get_terms( $taxonomy = 'recipe_method' );
		$rcp_post_tags 			  = rcp_get_terms( $taxonomy = 'post_tag' );
		// Resets the values if already submitted
		if ( $rcp_id == 'clear' ) {
			$rcp_title = $rcp_sub_title = $rcp_desc = $rcp_servings = $rcp_diff_level = $rcp_categories = $rcp_prep_hrs = $rcp_prep_mns = $rcp_cook_hrs = $rcp_cook_mns = $rcp_ingredients = $rcp_steps = '';
		}

		if ( ! empty( $rcp_id ) ) {
			$rcp_title 			 = get_the_title( $rcp_id );
			$rcp_sub_title  	 = get_post_meta( $rcp_id,'recipe_sub_title', true );
			$rcp_ingredients 	 = get_post_meta( $rcp_id,'recipe_ingredients', true );
			$rcp_steps 			 = get_post_meta( $rcp_id,'recipe_steps', true );
			$rcp_diff_level		 = get_post_meta( $rcp_id,'recipe_diff_level', true );

			$rcp_tags			 = wp_get_post_terms( $rcp_id, 'post_tag', array( "fields" => "ids" ) );
			$rcp_categories 	 = wp_get_post_terms( $rcp_id, 'recipe_cat', array( "fields" => "ids" ) );
			$rcp_cuisines   	 = wp_get_post_terms( $rcp_id, 'recipe_cuisine', array( "fields" => "ids" ) );
			$rcp_cooking_methods = wp_get_post_terms( $rcp_id, 'recipe_method', array( "fields" => "ids" ) );

			$recipe_ptime = get_post_meta( $rcp_id,'recipe_ptime', true );
			if ( ! empty( $recipe_ptime ) ) {
				$rcp_prep_hrs = $recipe_ptime['hrs'];
				$rcp_prep_mns = $recipe_ptime['mins'];
			}

			$recipe_ctime = get_post_meta( $rcp_id,'recipe_ctime', true );
			if ( ! empty( $recipe_ctime ) ) {
				$rcp_cook_hrs = $recipe_ctime['hrs'];
				$rcp_cook_mns = $recipe_ctime['mins'];
			}
			$rcp_nutritions  	 = get_post_meta( $rcp_id,'recipe_nutritions', true );
			$rcp_equipments 	 = get_post_meta( $rcp_id,'recipe_equipments', true );
			$rcp_desc 			 = get_post_meta( $rcp_id,'recipe_short_info', true );
		    $rcp_video 			 = get_post_meta( $rcp_id,'recipe_video_url', true );
			$rcp_servings		 = get_post_meta( $rcp_id,'recipe_servings', true );
		} else {
			$rcp_title 			 = isset( $_POST['rcp_title'] ) ? $_POST['rcp_title'] : null;
			$rcp_sub_title  	 = isset( $_POST['rcp_title'] ) ? $_POST['rcp_sub_title'] : null;
			$rcp_ingredients 	 = isset( $_POST['rcp_ingredients'] ) ?  $_POST['rcp_ingredients'] : null;
			$rcp_steps 			 = isset( $_POST['rcp_steps'] ) ?  $_POST['rcp_steps'] : null;
			$rcp_tags			 = isset( $_POST['rcp_tags'] ) ?  $_POST['rcp_tags'] : null;
			$rcp_diff_level		 = isset( $_POST['rcp_diff_level'] ) ?  $_POST['rcp_diff_level'] : null;
			$rcp_categories		 = isset( $_POST['rcp_categories'] ) ?  $_POST['rcp_categories'] : null;
			$rcp_cuisines 		 = isset( $_POST['rcp_cuisines'] ) ?  $_POST['rcp_cuisines'] : null;
			$rcp_cooking_methods = isset( $_POST['rcp_cooking_methods'] ) ?  $_POST['rcp_cooking_methods'] : null;
			$rcp_prep_hrs 		 = isset( $_POST['rcp_prep_hrs'] ) ?  $_POST['rcp_prep_hrs'] : null;
			$rcp_prep_mns 		 = isset( $_POST['rcp_prep_mns'] ) ?  $_POST['rcp_prep_mns'] : null;
			$rcp_cook_hrs 		 = isset( $_POST['rcp_cook_hrs'] ) ?  $_POST['rcp_cook_hrs'] : null;
			$rcp_cook_mns 		 = isset( $_POST['rcp_cook_mns'] ) ?  $_POST['rcp_cook_mns'] : null;
			$rcp_nutritions  	 = isset( $_POST['rcp_nutritions'] ) ?  $_POST['rcp_nutritions'] : null;
			$rcp_equipments 	 = isset( $_POST['rcp_equipments'] ) ?  $_POST['rcp_equipments'] : null;
			$rcp_desc 			 = isset( $_POST['rcp_desc'] ) ? $_POST['rcp_desc'] : null;
			$rcp_video 			 = isset( $_POST['rcp_video'] ) ? $_POST['rcp_video']: null;
			$rcp_servings		 = isset( $_POST['rcp_servings'] ) ? $_POST['rcp_servings']  : null;
		}

		$out = '<form method="post" enctype="multipart/form-data" id="rcp-user-edit-form" action="' . $_SERVER['REQUEST_URI'] . '">';
		$out .= '<div class="rcp-form-options">';

		// Title
		$out .= '<div class="rcp-form-field rcp-title">';
		$out .= '<div class="rcp-form-label"><label for="rcp_title">' . esc_html__( 'Recipe Title', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="rcp_title" type="text" id="rcp_title" value="' . esc_html( $rcp_title ) . '"></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Enter recipe title here', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-post-title

		// Sub Title
		$out .= '<div class="rcp-form-field rcp-sub-title">';
		$out .= '<div class="rcp-form-label"><label for="rcp_sub_title">' . esc_html__( 'Recipe Sub Title', 'cookpro_textdomain' ) . '</label></div>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="rcp_sub_title" type="text" id="rcp_sub_title" value="' . esc_html( $rcp_sub_title ) . '"></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'This will shows right below the title.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-post-title

		// Ingredirens
		$out .= '<div class="rcp-form-field rcp-ingredients">';
		$out .= '<div class="rcp-form-label rcp_ingredients__header"><label for="rcp_ingredients">' . esc_html__( 'Recipe Ingredirens', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label>';
		// Count Info
		$out .= '<div class="rcp_ingredients__countinfo">';
		$out .= '<span class="rcp-group-count">' . esc_html__( 'Groups:', 'cookpro_textdomain' ) . '<span id="rcp_groups"></span></span>';
		$out .= '<span class="rcp-item-count">' . esc_html__( 'Items:', 'cookpro_textdomain' ) . '<span id="rcp_items"></span></span>';
		$out .= '</div>';
		$out .= '</div>';

		$out .= '<div class="rcp-form-input"><textarea name="rcp_ingredients" id="rcp_ingredients" rows="10" cols="50">' . esc_textarea( $rcp_ingredients ) . '</textarea></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'One ingredient per line. Use double hyphen for new titles ( ex: --New Title ).', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field
		// Ingredient ends

		// Steps Starts
		$out .= '<div class="rcp-form-field rcp-steps">';
		$out .= '<div class="rcp-form-label"><label for="rcp_steps">' . esc_html__( 'Recipe Steps', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input"><textarea name="rcp_steps"  id="rcp_steps" rows="10" cols="50">' . esc_textarea( $rcp_steps ) . '</textarea></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'One ingredient per line. Use double hyphen for new titles ( ex: --New Title ) and use title for time duration ( ex: ~30 mins~ ).', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field
		// Steps Ends

		// Description
		$out .= '<div class="rcp-form-field rcp-desc select70">';
		$out .= '<div class="rcp-form-label"><label for="rcp_desc">' . esc_html__( 'Quick Description', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input"><textarea name="rcp_desc" id="rcp_desc" rows="3" cols="50">' . esc_textarea( $rcp_desc ) . '</textarea></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Description that will appearin single recipe page, keep it short and sweet', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>';// .rcp-user-textarea

		// Tags
		$out .= '<div class="rcp-form-field rcp-tags select30 last">';
		$out .= '<div class="rcp-form-label"><label for="rcp_tags">' . esc_html__( 'Recipe Tags', 'cookpro_textdomain' ) . '</label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<select name="rcp_tags[]" class="rcp_tags" id="rcp_tags"  multiple="multiple">';
		foreach ( $rcp_post_tags as $key => $value ) {
			$selected = ( is_array( $rcp_tags ) && in_array( $key, $rcp_tags ) ) ? ' selected="selected"' :'';
			$out .= '<option value="' . esc_attr( $key ) . '" ' . $selected . '>' . esc_html( $value ) . '</option>';
		}
		$out .= '</select>';// .rcp_tags
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Select tags for this recipe', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Video URL
		$out .= '<div class="rcp-form-field rcp-video">';
		$out .= '<div class="rcp-form-label"><label for="rcp_video">' . esc_html__( 'Recipe Video', 'cookpro_textdomain' ) . '</label></div>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="rcp_video" type="text" id="rcp_video" value="' . esc_html( $rcp_video ) . '"></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( '(Optional) If you want have recipe video just page in the URL(ex. https://youtu.be/jThoJAwyTXQ or https://vimeo.com/34766296) and it will shows on recipe image in a lightbox option.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-video

		// Difficulty Level
		$out .= '<div class="rcp-form-field rcp-difficulty select50">';
		$out .= '<div class="rcp-form-label"><label for="rcp_diff_level">' . esc_html__( 'Recipe Difficulty Level', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<select name="rcp_diff_level">';
		$out .= '<option value="">' . esc_html__( 'Select Difficulty Level', 'cookpro_textdomain' ) . '</option>';
		foreach ( $rcp_difficulty_level as $key => $value) {
			$selected = ( $rcp_diff_level == $key ) ? ' selected="selected"' :'';
			$out .= '<option value="' . esc_attr( $key ) . '"  ' . $selected . '>' . esc_html( $value ) . '</option>';
		}
		$out .= '</select>'; //.rcp_diif_level
		$out .= '</div>'; //.rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Choose level to made recipe', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Servings
		$out .= '<div class="rcp-form-field rcp-servings select50 last">';
		$out .= '<div class="rcp-form-label"><label for="rcp_servings">' . esc_html__( 'Serves', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input"><input class="text-input" name="rcp_servings" type="text" id="rcp_servings" value="' . esc_html( $rcp_servings ) . '"></div>';
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'How many people does it serve. A number for the servings amount. eg.4', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-servings

		// Categories
		$out .= '<div class="rcp-form-field rcp-category select30">';
		$out .= '<div class="rcp-form-label"><label for="rcp_categories">' . esc_html__( 'Recipe Categories', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<select name="rcp_categories[]" class="rcp_categories" id="rcp_categories" multiple="multiple">';
		foreach ( $rcp_post_categories as $key => $value ) {
			$selected = ( is_array( $rcp_categories ) && in_array( $key, $rcp_categories ) ) ? ' selected="selected"' :'';
			$out .= '<option value="' . esc_attr( $key ) . '" ' . $selected . '>' . esc_html( $value ) . '</option>';
		}
		$out .= '</select>';// .rcp_categories
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Select categories ', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Cuisines
		$out .= '<div class="rcp-form-field rcp-cuisines select30">';
		$out .= '<div class="rcp-form-label"><label for="rcp_cuisines">' . esc_html__( 'Cuisines', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<select name="rcp_cuisines[]" class="rcp_cuisines" id="rcp_cuisines"  multiple="multiple">';
		foreach ( $rcp_post_cuisines as $key => $value ) {
			$selected = ( is_array( $rcp_cuisines ) && in_array( $key, $rcp_cuisines ) ) ? ' selected="selected"' :'';
			$out .= '<option value="' . esc_attr( $key ) . '" ' . $selected . '>' . esc_html( $value ) . '</option>';
		}
		$out .= '</select>';// .rcp_categories
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Select Cuisines', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Cooking Methods
		$out .= '<div class="rcp-form-field rcp-methods select30 last">';
		$out .= '<div class="rcp-form-label"><label for="rcp_cooking_methods">' . esc_html__( 'Cooking Style', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<select name="rcp_cooking_methods[]" class="rcp_cooking_methods" id="rcp_cooking_methods" multiple="multiple">';
		foreach ( $rcp_post_cooking_methods as $key => $value ) {
			$selected = ( is_array( $rcp_cooking_methods ) && in_array( $key, $rcp_cooking_methods ) ) ? ' selected="selected"' :'';
			$out .= '<option value="' . esc_attr( $key ) . '" ' . $selected . '>' . esc_html( $value ) . '</option>';
		}
		$out .= '</select>';// .rcp_cooking_methods
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Select Cooking Methods', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Preparation Time
		$out .= '<div class="rcp-form-field rcp-prep-time select50">';
		$out .= '<div class="rcp-form-label"><label for="rcp_cooking_methods">' . esc_html__( 'Preparation Time', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<input class="text-input" name="rcp_prep_hrs" type="text" placeholder="' . esc_html__( 'Hours (eg:2)', 'cookpro_textdomain' ) . '" value="' . esc_html( $rcp_prep_hrs ) . '" >';
		$out .= '<input class="text-input" name="rcp_prep_mns" type="text" placeholder="' . esc_html__( 'Minutes (eg:35)', 'cookpro_textdomain' ) . '" value="' . esc_html( $rcp_prep_mns ) . '">';
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'The time takes to prepare the recipe.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Cook Time
		$out .= '<div class="rcp-form-field rcp-cook-time select50 last">';
		$out .= '<div class="rcp-form-label"><label for="rcp_cooking_methods">' . esc_html__( 'Cooking Time', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<input class="text-input" name="rcp_cook_hrs" type="text" placeholder="' . esc_html__( 'Hours (eg:2)', 'cookpro_textdomain' ) . '" value="' . esc_html( $rcp_cook_hrs ) . '">';
		$out .= '<input class="text-input" name="rcp_cook_mns" type="text" placeholder="' . esc_html__( 'Minutes (eg:35)', 'cookpro_textdomain' ) . '" value="' . esc_html( $rcp_cook_mns ) . '">';
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'The time takes to cook the recipe.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field

		// Nutritions Starts
		$out .= '<div class="rcp-form-field rcp-nutritions">';
		$out .= '<div class="rcp-form-label"><label for="rcp_cooking_methods">' . esc_html__( 'Recipe Nutritions', 'cookpro_textdomain' ) . '</label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<div id="rcp-nutrition-wrap" class="rcp-fields-container" style="display: block;">';
		$out .= '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
		$out .= '<div class="rcp-sort-row-ds" style="width: 5%;"><span>#</span></div>';
		$out .= '<div class="rcp-sort-row-dn" style="width: 34%;">' . esc_html__( 'Nutrition Name', 'cookpro_textdomain' ) . '</div>';
		$out .= '<div class="rcp-sort-row-dv" style="width: 34%;">' . esc_html__( 'Nutrition Value', 'cookpro_textdomain' ) . '</div>';
		$out .= '<div class="rcp-sort-row-da" style="width: 27%;">' . esc_html__( 'Action', 'cookpro_textdomain' ) . '</div>';
		$out .= '</div>'; // field-nutrition

		$out .= '<div class="rcp-fields-templates">';

		$out .= '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
		$out .= '<input name="" value="nutrition" data-field-name="[type]" type="hidden">';
		$out .= '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><i class="fa fa-bars" aria-hidden="true"></i></div>';

		// Nutrition Name
		$rcp_nutritions_names = array(
			'Serving Size',
			'Calories',
			'Total Fat',
			'Saturated Fat',
			'Polyunsaturated Fat',
			'Monounsaturated Fat',
			'Trans Fat',
			'Cholesterol',
			'Sodium',
			'Potassium',
			'Total Carbohydrate',
			'Fiber',
			'Sugar',
			'Protein',
		);
		$out .= '<div class="rcp_input rcp-sort-row-dn" style="width: 34%;">';
		$out .= '<div class="rcp-input-details">';
		$out .= '<select name="" data-field-name="[name]">';
		foreach ( $rcp_nutritions_names as $key => $value ) {
			$out .= '<option value="' . $value . '">' . $value . '</option>';
		}
		$out .= '</select>';
		$out .= '</div></div>';

		// Nutrition Value
		$out .= '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
		$out .= '<div class="rcp-input-details">';
		$out .= '<input name="" value="" data-field-name="[value]" type="text">';
		$out .= '</div></div>';

		// actions-holder
		$out .= '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
		$out .= '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
		<i class="fa fa-files-o" aria-hidden="true"></i>
		</a>';
		$out .= '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
		<i class="fa fa-trash" aria-hidden="true"></i>
		</a>';
		$out .= '</div>';//.actions-holder
		$out .= '</div>';//.rcp-sort-row
		$out .= '</div>';//.rcp-fields-templates
		$out .= '<div class="rcp-fields-live rcp-sort-table ui-sortable" data-field-index="0" data-name="rcp_nutritions">';
		if ( ! empty( $rcp_nutritions ) && isset( $rcp_nutritions ) ) {
			foreach ( $rcp_nutritions as $key => $data ) {
				$rcp_field_name = 'rcp_nutritions[' . $key . ']';
				$rcp_data_name 	= ! empty( $data['name'] ) ? $data['name'] : '';
				$rcp_data_value = ! empty( $data['value'] ) ? $data['value'] : '';

				$out .= '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
				$out .= '<input name="' . $rcp_field_name . '[type]" value="nutrition" data-field-name="[type]" type="hidden">';
				$out .= '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><i class="fa fa-bars" aria-hidden="true"></i></div>';

				// Nutrition Name
				$out .= '<div class="rcp_input rcp-sort-row-dn" style="width: 34%;">';
				$out .= '<div class="rcp-input-details">';
				$out .= '<select name="' . $rcp_field_name . '[name]" data-field-name="[name]">';
				foreach ( $rcp_nutritions_names as $key => $value ) {
					$out .= '<option value="' . $value . '" ' . selected( $rcp_data_name, $value, false ) . '>' . $value . '</option>';
				}
				$out .= '</select>';
				$out .= '</div></div>';

				// Nutrition Value
				$out .= '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
				$out .= '<div class="rcp-input-details">';
				$out .= '<input name="' . $rcp_field_name . '[value]" value="' . esc_html( $rcp_data_value ) . '" data-field-name="[value]" type="text">';
				$out .= '</div></div>';

				// actions-holder
				$out .= '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
				$out .= '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
				<i class="fa fa-files-o" aria-hidden="true"></i>
				</a>';
				$out .= '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
				<i class="fa fa-trash" aria-hidden="true"></i>
				</a>';
				$out .= '</div>';//.actions-holder
				$out .= '</div>';//.rcp-sort-row
			}
		}
		$out .= '</div>'; //. rcp-fields-live
		$out .= '<div class="rcp-repeater-actions">';
		$out .= '<button class="rcp-form-button rcp-form-button-primary" data-action="clone" data-clone="field-nutrition">' . esc_html__( 'Add Nutrition', 'cookpro_textdomain' ) . '</button>&nbsp;&nbsp;';
		$out .= '</div>';//.rcp-nutrition-actions -->
		$out .= '</div>';// .rcp-ingre-wrap
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Add all of the nutritions.', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field
		// Nutrition Ends

		// Equipment starts here
		$out .= '<div class="rcp-form-field rcp-equipments">';
		$out .= '<div class="rcp-form-label"><label for="rcp_equipments">' . esc_html__( 'Recipe Equipments', 'cookpro_textdomain' ) . '</label></div>';
		$out .= '<div class="rcp-form-input">';
		$out .= '<div id="rcp-equipment-wrap" class="rcp-fields-container" style="display: block;">';
		$out .= '<div class="rcp-sort-row field-equipment rcp-fields-row">';
		$out .= '<div class="rcp-sort-row-ds" style="width: 5%;"><span>#</span></div>';
		$out .= '<div class="rcp-sort-row-dv" style="width: 34%;">' . esc_html__( 'Equipments', 'cookpro_textdomain' ) . '</div>';
		$out .= '<div class="rcp-sort-row-da" style="width: 27%;">' . esc_html__( 'Action', 'cookpro_textdomain' ) . '</div>';
		$out .= '</div>'; // field-nutrition

		$out .= '<div class="rcp-fields-templates">';

		$out .= '<div class="rcp-sort-row field-equipment rcp-fields-row">';
		$out .= '<input name="" value="equipment" data-field-name="[type]" type="hidden">';
		$out .= '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><i class="fa fa-bars" aria-hidden="true"></i></div>';

		// Equipment Value
		$out .= '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
		$out .= '<div class="rcp-input-details">';
		$out .= '<input name="" value="" data-field-name="[value]" type="text">';
		$out .= '</div></div>';

		// actions-holder
		$out .= '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
		$out .= '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
		<i class="fa fa-files-o" aria-hidden="true"></i>
		</a>';
		$out .= '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
		<i class="fa fa-trash" aria-hidden="true"></i>
		</a>';
		$out .= '</div>';//.actions-holder
		$out .= '</div>';//.rcp-sort-row
		$out .= '</div>';//.rcp-fields-templates
		$out .= '<div class="rcp-fields-live rcp-sort-table ui-sortable" data-field-index="0" data-name="rcp_equipments">';
		if ( ! empty( $rcp_equipments ) && isset( $rcp_equipments ) ) {
			foreach ( $rcp_equipments as $key => $data ) {
				$rcp_field_name = 'rcp_equipments[' . $key . ']';
				$rcp_equipment_name = ! empty( $data['value'] ) ? $data['value'] : '';

				$out .= '<div class="rcp-sort-row field-equipment rcp-fields-row">';
				$out .= '<input name="' . $rcp_field_name . '[type]" value="equipment" data-field-name="[type]" type="hidden">';
				$out .= '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><i class="fa fa-bars" aria-hidden="true"></i></div>';

				// Equipment Value
				$out .= '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
				$out .= '<div class="rcp-input-details">';
				$out .= '<input name="' . $rcp_field_name . '[value]" value="' . esc_html( $rcp_equipment_name ) . '" data-field-name="[value]" type="text">';
				$out .= '</div></div>';

				// actions-holder
				$out .= '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
				$out .= '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
				<i class="fa fa-files-o" aria-hidden="true"></i>
				</a>';
				$out .= '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
				<i class="fa fa-trash" aria-hidden="true"></i>
				</a>';
				$out .= '</div>';//.actions-holder
				$out .= '</div>';//.rcp-sort-row
			}
		}
		$out .= '</div>'; //. rcp-fields-live
		$out .= '<div class="rcp-repeater-actions">';
		$out .= '<button class="rcp-form-button rcp-form-button-primary" data-action="clone" data-clone="field-equipment">' . esc_html__( 'Add Equipment', 'cookpro_textdomain' ) . '</button>&nbsp;&nbsp;';
		$out .= '</div>';//.rcp-equipment-actions -->
		$out .= '</div>';// .rcp-equipment-wrap
		$out .= '</div>'; // .rcp-form-input
		$out .= '<span class="rcp-form-hints">' . esc_html__( 'Any special equipment worthy of mentioning that is required. eg. Thermomix, Slow-Cooker', 'cookpro_textdomain' ) . '</span>';
		$out .= '</div>'; // .rcp-form-field
		// Equipment Ends here

		// Upload image
		$out .= '<div class="rcp-form-field rcp-upload">';
		$out .= '<div class="rcp-form-label"><label for="rcp_upload_img">' . esc_html__( 'Recipe Image', 'cookpro_textdomain' ) . '<span class="rcp-required">*</span></label></div>';
		$out .= '<div class="rcp-form-input">';
		if ( ! empty( $rcp_id ) ) {
			if ( has_post_thumbnail( $rcp_id ) ) {
				$out .= '<div class="rcp-img"><figure>'. get_the_post_thumbnail( $rcp_id,'medium') . '</figure></div>';
			}
		}
		$out .= '<input class="text-input" type="file" name="rcp_upload_img" id="rcp_upload_img"  />';
		$out .= '</div>'; // .rcp-form-input
		$out .= '</div>'; // .rcp-form-field
		// Upload image

		// Captcha
		if ( empty( $rcp_id ) ) {
			$rcp_site_key = rcp_get_option( 'rcp_google_api_site_key' ) ? rcp_get_option( 'rcp_google_api_site_key' ) : '';
			$out .= '<div class="g-recaptcha rcp-form-field" data-sitekey="' . esc_attr( $rcp_site_key ). '"></div>';
		}

		// Recipe Submit
		$out .= '<div class="rcp-form-field rcp-submit">';
		$out .= '<div class="rcp-form-input">';

		if ( ! empty( $rcp_id ) ) {
			$out .= '<input name="rcp_edit_post_submit" type="submit" id="rcp_edit_post_submit" class="rcp-submit button" value="' . esc_html__( 'Edit Recipe', 'cookpro_textdomain' ) . '" />';
			$out .= wp_nonce_field( 'rcp-edit-post-submit' );
			$out .= '<input name="rcp_id" type="hidden" id="rcp_id" value="' . $rcp_id . '" />';
			$out .= '<input name="action" type="hidden" id="action" value="rcp-edit-post-submit" />';
		} else {
			$out .= '<input name="rcp_post_submit" type="submit" id="rcp_post_submit" class="rcp-submit button" value="' . esc_html__( 'Publish Recipe', 'cookpro_textdomain' ) . '" />';
			$out .= '<input name="rcp_drafted_post_submit" type="submit" id="rcp_drafted_post_submit" class="rcp-draft button" value="' . esc_html__( 'Draft Recipe', 'cookpro_textdomain' ) . '" />';
			$out .= wp_nonce_field( 'rcp-post-submit' );
			$out .= '<input name="action" type="hidden" id="action" value="rcp-post-submit" />';
		}
		$out .= '</div>'; // .rcp-form-input
		$out .= '</div>'; // .rcp-form-field
		$out .= '</div>'; // rcp-form-options/
		$out .= '</form>'; // #adduser

		return $out;

	}
}
/**
 * function rcp_edit_form_submit()
 * Recipe Edit Form
 */
if ( ! function_exists( 'rcp_edit_form_submit' ) ) {
	function rcp_edit_form_submit( $rcp_id ) {
		$out = '';
		if ( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['action'] ) && $_POST['action'] == 'rcp-edit-post-submit' ) {
			$rcp_title  	 	 = isset( $_POST['rcp_title'] ) ? $_POST['rcp_title'] : '';
			$rcp_sub_title  	 = isset( $_POST['rcp_sub_title'] ) ? $_POST['rcp_sub_title'] : '';
			$rcp_desc 			 = isset( $_POST['rcp_desc'] ) ? $_POST['rcp_desc'] : '';
			$rcp_video 			 = isset( $_POST['rcp_video'] ) ? $_POST['rcp_video'] : '';
			$rcp_servings 	 	 = isset( $_POST['rcp_servings'] ) ? $_POST['rcp_servings'] : '';
			$rcp_diff_level 	 = isset( $_POST['rcp_diff_level'] ) ? $_POST['rcp_diff_level'] : '';
			$rcp_tags 	 		 = isset( $_POST['rcp_tags'] ) ? $_POST['rcp_tags'] : '';
			$rcp_categories		 = isset( $_POST['rcp_categories'] ) ? $_POST['rcp_categories'] : '';
			$rcp_cuisines 	 	 = isset( $_POST['rcp_cuisines'] ) ? $_POST['rcp_cuisines'] : '';
			$rcp_cooking_methods = isset( $_POST['rcp_cooking_methods'] ) ? $_POST['rcp_cooking_methods'] : '';
			$rcp_prep_hrs 	 	 = isset( $_POST['rcp_prep_hrs'] ) ? $_POST['rcp_prep_hrs'] : '';
			$rcp_prep_mns 	 	 = isset( $_POST['rcp_prep_mns'] ) ? $_POST['rcp_prep_mns'] : '';
			$rcp_cook_hrs	 	 = isset( $_POST['rcp_cook_hrs'] ) ? $_POST['rcp_cook_hrs'] : '';
			$rcp_cook_mns 	 	 = isset( $_POST['rcp_cook_mns'] ) ? $_POST['rcp_cook_mns'] : '';
			$rcp_ingredients 	 = isset( $_POST['rcp_ingredients'] ) ? $_POST['rcp_ingredients'] : '';
			$rcp_steps 		 	 = isset( $_POST['rcp_steps'] ) ? $_POST['rcp_steps'] : '';
			$rcp_equipments  	 = isset( $_POST['rcp_equipments'] ) ? $_POST['rcp_equipments'] : '';
			$rcp_nutritions  	 = isset( $_POST['rcp_nutritions'] ) ? $_POST['rcp_nutritions'] : '';
			$rcp_upload_img 	 = isset( $_POST['rcp_upload_img'] ) ? $_POST['rcp_upload_img'] : '';
			$rcp_captcha 	 	 = isset( $_POST['g-recaptcha-response'] ) ? $_POST['g-recaptcha-response'] : '';

			$rcp_post_id = $rcp_id;
			$errors = rcp_submit_form_validation( $rcp_id, $rcp_title, $rcp_sub_title, $rcp_desc, $rcp_servings, $rcp_diff_level, $rcp_categories, $rcp_prep_hrs, $rcp_prep_mns, $rcp_cook_hrs, $rcp_cook_mns, $rcp_ingredients, $rcp_steps, $rcp_upload_img, $rcp_captcha );

			if ( empty( $errors ) ) {
				if ( 1 > count( $errors ) ) {
					$rcp_allowed_roles = array( 'editor', 'administrator' );
					$current_user = wp_get_current_user();
					if ( array_intersect( $rcp_allowed_roles, $current_user->roles ) ) {
						$rcp_post_status = 'publish';
					} else {
						$rcp_post_status = 'pending';
					}
					$rcp_data = array(
						'ID'			=> $rcp_id,
						'post_title' 	=> $rcp_title,
						'post_type'		=> 'recipe',
						'post_status'   => $rcp_post_status,
					);
					wp_update_post( $rcp_data );

					$rcp_post_id = $rcp_id;

					if ( ! empty( $rcp_servings ) ) {
						update_post_meta( $rcp_post_id, 'recipe_servings', $rcp_servings );
					}
					if ( ! empty( $rcp_desc ) ) {
						update_post_meta( $rcp_post_id, 'recipe_short_info', $rcp_desc );
					}
					if ( ! empty( $rcp_sub_title ) ) {
						update_post_meta( $rcp_post_id, 'recipe_sub_title', $rcp_sub_title );
					}
					if ( ! empty( $rcp_diff_level ) ) {
						update_post_meta( $rcp_post_id, 'recipe_diff_level', $rcp_diff_level );
					}
					if ( ! empty( $rcp_video ) ) {
						update_post_meta( $rcp_post_id, 'recipe_video_url', $rcp_video );
					}
					// Inserting ingredients into meta fields
					$rcp_prep_time_data = array();
					if ( ! empty( $rcp_prep_hrs ) || ! empty( $rcp_prep_mns ) ) {
					   $rcp_prep_time_data = array(
						'hrs' => $rcp_prep_hrs,
						'mins' => $rcp_prep_mns
					   );
					}
					//
					$rcp_cook_time_data = array();
					if ( ! empty( $rcp_cook_hrs ) || ! empty( $rcp_cook_mns ) ) {
					   $rcp_cook_time_data = array(
						'hrs' => $rcp_cook_hrs,
						'mins' => $rcp_cook_mns
					   );
					}

					// Save the Preparation Time
					if ( ! empty( $rcp_prep_time_data ) ) {
						update_post_meta( $rcp_post_id, 'recipe_ptime', $rcp_prep_time_data );
					}
					// Save the Cooking Time
					if ( ! empty( $rcp_cook_time_data ) ) {
						update_post_meta( $rcp_post_id, 'recipe_ctime', $rcp_cook_time_data );
					}
					// Save the Equipments
					if ( ! empty( $rcp_equipments ) ) {
						update_post_meta( $rcp_post_id, 'recipe_equipments', $rcp_equipments );
					}
					// Nutritions Data
					if ( ! empty( $rcp_nutritions ) ) {
						update_post_meta( $rcp_post_id, 'recipe_nutritions', $rcp_nutritions );
					}
					// Ingredients Data
					if ( ! empty( $rcp_ingredients ) ) {
						update_post_meta( $rcp_post_id, 'recipe_ingredients', $rcp_ingredients );
					}
					// Steps Data
					if ( ! empty( $rcp_steps ) ) {
						update_post_meta( $rcp_post_id, 'recipe_steps', $rcp_steps );
					}

					if ( $_FILES['rcp_upload_img']['name']!='') {
						rcp_sui_process_image( 'rcp_upload_img', $rcp_post_id, $rcp_title );
					}
					// Inserting recipe tags
					if ( ! empty( $rcp_tags ) ) {
						$rcp_tags_ids = array_map( 'intval', $rcp_tags );
						wp_set_object_terms( $rcp_post_id, $rcp_tags_ids, 'post_cat' );
					}
					// Inserting recipe tags
					if ( ! empty( $rcp_categories ) ) {
						$rcp_category_ids = array_map( 'intval', $rcp_categories );
						wp_set_object_terms( $rcp_post_id, $rcp_category_ids, 'recipe_cat' );
					}
					// Inserting recipe cuisines into meta field
					if ( ! empty( $rcp_cuisines ) ) {
						$rcp_cuisine_ids = array_map( 'intval', $rcp_cuisines );
						wp_set_object_terms( $rcp_post_id, $rcp_cuisine_ids, 'recipe_cuisine' );
					}
					// Inserting recipe cuisines into meta field
					if ( ! empty( $rcp_cooking_methods ) ) {
						$rcp_cooking_methods = array_map( 'intval', $rcp_cooking_methods );
						wp_set_object_terms( $rcp_post_id, $rcp_cooking_methods, 'recipe_method' );
					}

					// Send a email to user
					$current_user = wp_get_current_user();
					$user_id = $current_user->ID;
					$user_email = $current_user->user_email;
					$user_name  = $current_user->display_name;

					$email_message = get_option( 'rcp_update_email_message' );
					$email_subject = get_option( 'rcp_update_email_subject' );
					$user_email = $user_email;
					$admin_email_ids = $admin_emailids = array();
					$admin_email_ids[] = get_option( 'admin_email' );
					$admin_emails = get_option( 'rcp_submit_admin_email_ids' );
					if ( ! empty( $admin_emails ) ) {
						if ( strpos( $admin_emails, ',' ) !== false ) {
							$admin_emailids = explode( ',', $admin_emails );
							$admin_email_ids = array_merge( $admin_email_ids, $admin_emailids );
						} else {
							$admin_email_ids[] .= $admin_emails;
						}
					}
					$admin_email = implode( ',', $admin_email_ids );

					$rcp_link = get_permalink( $rcp_post_id );

					if ( $email_message && $email_subject ) {
						$rcp_logo_img = '';
						$rcp_logo = rcp_get_option( 'rcp_email_template_logo' );
						if ( ! empty( $rcp_logo ) ) {
							$attachment_id = rcp_get_attachment_id_from_src( $rcp_logo );
							$rcp_logo_img = wp_get_attachment_image( $attachment_id,  array( '200', '100' ), '', '' );
						}

						$subj_placeholders = array( '[username]', '[recipename]' );
						$subj_replacements = array( $user_name, $rcp_title );
						$msg_placeholders = array( '[username]', '[recipename]', '[recipelink]' );
						$msg_replacements = array( $user_name, $rcp_title, $rcp_link );

						$rcp_email_message  = str_replace( $msg_placeholders, $msg_replacements, $email_message );
						$email_subject 		= str_replace( $subj_placeholders, $subj_replacements, $email_subject );

						$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
						$email_placeholders = array( '[logo]','[message]' );
						$email_replacements = array( $rcp_logo_img, $rcp_email_message );
						$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
						$email_message      = do_shortcode( $email_message );

						$emails	 = $user_email . ',' . $admin_email;
						$headers = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $admin_email . '>' . "\r\n\\";
						$headers .= "MIME-Version: 1.0\r\n";
						$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

						wp_mail( $emails, $email_subject, $email_message, $headers );
					}
					$rcp_sub_success_msg = get_option( 'rcp_submission_edit_success_msg' ) ? get_option( 'rcp_submission_edit_success_msg' ) : esc_html__( 'Submission complete', 'cookpro_textdomain' );
					$rcp_sub_msg_placeholders  = array( '[username]' );
					$rcp_sub_msg_replacements  = array( $user_name );
					$rcp_submission_success_msg = str_replace( $rcp_sub_msg_placeholders, $rcp_sub_msg_replacements, $rcp_sub_success_msg );
					$rcp_submission_success_msg = do_shortcode( $rcp_submission_success_msg );
					$rcp_submission_complete = '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice"><strong>' . esc_html__( 'Success!', 'cookpro_textdomain' ) . '</strong><br />' . $$rcp_submission_success_msg . '</p></div>';
				}
			}  else {
				$rcp_submission_complete = 'error';
			}
		} else {
			$rcp_submission_complete = false;
		}
		//
		if ( $rcp_submission_complete && $rcp_submission_complete != 'error' ) {
			$out .= $rcp_submission_complete;
		} else {
			if ( $rcp_submission_complete == 'error' ){
				$out .= '<div class="rcp-custom-error" style="display:block">' . implode( '<br>', $errors ) . '</div>';
			}
			$out .= rcp_submit_form_fields( $rcp_id );
		}
		return $out;
	}
}
/**
 * function rcp_get_user_recipes_count()
 * recipes count submitted by user
 **/
if ( ! function_exists( 'rcp_get_user_recipes_count' ) ) {
	function rcp_get_user_recipes_count( $rcp_user_id ) {
		// Recipes submitted by user
		$rcp_args = array(
			'post_type' => 'recipe',
			'post_status' => 'any',
			'author' => $rcp_user_id
		);
		$rcp_query = new WP_Query( $rcp_args );
		$rcp_total_count = $rcp_query->found_posts;

		return $rcp_total_count;
	}
}
/**
 * function rcp_get_user_reviews_count()
 * reviews count submitted by user
 **/
if ( ! function_exists( 'rcp_get_user_reviews_count' ) ) {
	function rcp_get_user_reviews_count( $rcp_user_id ) {
		// Reviews submitted by user
		$args = array(
			'post_status' => 'publish',
			'post_type'	  => 'recipe',
			'orderby' 	  => 'date',
			'order'		  => 'desc',
			'status'	  => 'approve',
			'user_id'	  => $rcp_user_id,
		);
		$rcp_user_reviews = get_comments( $args );
		foreach( $rcp_user_reviews as $key => $id ) {
			if ( $id->post_author == $rcp_user_id ) {
				unset( $rcp_user_reviews[$key] );
			}
		}
		$rcp_review_count = count( $rcp_user_reviews );

		return $rcp_review_count;
	}
}
/**
 * function rcp_get_user_favorites_count()
 * returns favorites count submitted by user
 **/
if ( ! function_exists( 'rcp_get_user_favorites_count' ) ) {
	function rcp_get_user_favorites_count( $rcp_user_id ) {
		// User Favoutrites
		$limit   = rcp_get_option( 'rcp_user_fav_limit','3' );
		$orderby = rcp_get_option( 'rcp_user_fav_orderby','ID' );
		$order 	 = rcp_get_option( 'rcp_user_fav_order','ASC' );
		$rcp_user_favorite_postids = get_user_meta( $rcp_user_id, 'recipe_love', true );
		$rcp_user_favourites = array();
		if ( ! empty( $rcp_user_favorite_postids ) ) {
			foreach ( $rcp_user_favorite_postids as $rcp_postid ) {
				$rcp_user_favourites[] = $rcp_postid;
			}
		}
		if ( ! empty( $rcp_user_favourites ) ) {
			$rcp_like_args = array(
				'post_type' 	=> 'recipe',
				'post_status' 	=> 'any',
				'post__in' 		=> $rcp_user_favourites,
			);
			$rcp_favourite_query = new WP_Query( $rcp_like_args );
			$rcp_favourites_count = $rcp_favourite_query->post_count;

			return $rcp_favourites_count;
		} else {
			return 0;
		}
	}
}
/**
 * function rcp_get_terms()
 * returns taxonomy terms
 **/
if ( ! function_exists( 'rcp_get_terms' ) ) {
	function rcp_get_terms( $taxonomy ) {
		$rcp_tax_terms = array();
		$rcp_categories = get_terms( $taxonomy, 'orderby=name&hide_empty=0');
		if ( count ( $rcp_categories ) >= 1 ) {
			foreach ( $rcp_categories as $rcp_category ) {
				$rcp_tax_terms[$rcp_category->term_id] = $rcp_category->name;
			}
		}
		return $rcp_tax_terms;
	}
}
/**
 * function rcp_get_avatar()
 * returns avatar image
 **/
if ( ! function_exists( 'rcp_get_avatar' ) ) {
	function rcp_get_avatar( $user_id, $size = 150 ) {
		if ( get_user_meta( $user_id, 'avatar',true ) ) {
			return wp_get_attachment_image( get_user_meta( $user_id,'avatar',true ), array( $size, $size ) );
		} else {
			return get_avatar( $user_id, $size );
		}
	}
}
/**
 * function rcp_post_title()
 * returns recipe post title
 **/
if ( ! function_exists( 'rcp_post_title' ) ) {
	function rcp_post_title( $post_id ) {
		return '<h2 class="rcp__post-title">' . get_the_title( $post_id ) . '</h2>';
	}
}
/**
 * function rcp_sub_title()
 * return sub title
 **/
if ( ! function_exists( 'rcp_sub_title' ) ) {
	function rcp_sub_title( $post_id ) {
		$rcp_sub_title = get_post_meta( $post_id, 'recipe_sub_title', true );
		if ( ! empty( $rcp_sub_title ) ) {
			echo '<span class="rcp__subheading">' . $rcp_sub_title . '</span>';
		}
	}
}
/**
 * function rcp_get_time()
 * return time in hrrs and mins
 **/
if ( ! function_exists( 'rcp_get_time' ) ) {
	function rcp_get_time( $post_id, $meta_id ) {
		$recipe_time = get_post_meta( $post_id, $meta_id , true );
		$rcp_time = '';
		if ( ! empty( $recipe_time ) ) {
			$rcp_hrs 	= intval( $recipe_time['hrs'] );
			$rcp_mins 	= intval( $recipe_time['mins'] );
			if ( 0 != $rcp_hrs ) {
				$rcp_time .= $rcp_hrs . esc_html__( ' hr', 'cookpro_textdomain' );
			}
			if ( 0 != $rcp_mins ) {
				$rcp_time .= $rcp_mins . esc_html__( ' min', 'cookpro_textdomain' );
			}
			return $rcp_time;
		} else {
			return 0;
		}
	}
}
/**
 * function rcp_cook_time()
 * returns time in minutes
 **/
if ( ! function_exists( 'rcp_cook_time' ) ) {
	function rcp_cook_time( $post_id ) {
		$recipe_ctime = get_post_meta( $post_id, 'recipe_ctime', true );
		if ( ! empty( $recipe_ctime ) ) {
			$rcp_hrs = intval( $recipe_ctime['hrs'] );
			$rcp_mins = intval( $recipe_ctime['mins'] );
			$rcp_ctime = intval( ( $rcp_hrs * 60 ) + $rcp_mins ) ;
			return $rcp_ctime;
		} else {
			return 0;
		}
	}
}
/**
 * function rcp_cook_time()
 * returns time in minutes
 **/
if ( ! function_exists( 'rcp_total_time' ) ) {
	function rcp_total_time( $post_id ) {
		$recipe_ctime = get_post_meta( $post_id, 'recipe_ctime', true );
		$recipe_ptime = get_post_meta( $post_id, 'recipe_ptime', true );
		if ( ! empty( $recipe_ctime ) ) {
			$rcp_hrs = intval( $recipe_ctime['hrs'] ) + intval( $recipe_ptime['hrs'] );
			$rcp_mins = intval( $recipe_ctime['mins'] ) + intval( $recipe_ptime['mins'] );
			$rcp_total_time = intval( ( $rcp_hrs * 60 ) + $rcp_mins ) ;
			$hours = floor( $rcp_total_time / 60 );
			$minutes = ( $rcp_mins % 60 );
			if ( $hours !=0 ) {
				$hours = $hours . '<span>' . esc_html__( ' Hours','cookpro_textdomain' ) . '</span>';
			} else {
				$hours = '';
			}
			if ( $minutes != 0 ) {
				$minutes = $minutes . '<span>' . esc_html__( ' mins','cookpro_textdomain' ) . '</span>';
			} else {
				$minutes = '';
			}
		 	$rcp_total_time = '<div class="rcp__ptotaltime">' . $hours . ' ' . $minutes . '</span>';
			return $rcp_total_time;
		} else {
			return 0;
		}
	}
}
/**
 * function rcp_short_info()
 * returns short info
 **/
if ( ! function_exists( 'rcp_short_info' ) ) {
	function rcp_short_info( $post_id ) {
		$recipe_short_info   = get_post_meta( $post_id, 'recipe_short_info', true );
		if ( !empty( $recipe_short_info ) ) {
			echo '<div class="rcp__short-info">';
			echo '<p>' . $recipe_short_info . '</p>';
			echo '</div>'; //.rcp__short-info
		}
	}
}
/**
 * function rcp_post_thumbnail()
 * returns post thumbnail
 **/
if ( ! function_exists( 'rcp_post_thumbnail' ) ) {
	function rcp_post_thumbnail( $post_id ) {
		echo '<div class="rcp__featured-image clearfix">';
		$rcp_video_url = get_post_meta( $post_id, 'recipe_video_url', true );
		if ( $rcp_video_url ) {
			echo '<a href="' . esc_url( $rcp_video_url ) . '" rel="prettyPhoto">';
		} else {
			echo '<a href="' . esc_url( get_permalink( $post_id ) ).'">';
		}
		if ( has_post_thumbnail( $post_id ) ) {
			echo '<div class="rcp-thumbnail">' . get_the_post_thumbnail( $post_id, 'rcp_medium_vertical' ) . '</div>';
		} else {
			echo '<img src="' . RECIPE_IMG_URI . '/no_image.jpg" alt="img"/>';
		}
		echo '</a>';
		echo '</div>'; //.rcp__featured-image
	}
}
/**
 * function rcp_meta_details()
 * returns recipe meta details
 **/
if ( ! function_exists( 'rcp_meta_details' ) ) {
	function rcp_meta_details( $post_id ) {

		$rcp_servings 		= get_post_meta( $post_id, 'recipe_servings', true );
		$rcp_prepare_time  	= rcp_get_time( $post_id ,'recipe_ptime');
		$rcp_cook_time  	= rcp_get_time( $post_id ,'recipe_ctime' );
		$rcp_diff_level   	= get_post_meta( $post_id, 'recipe_diff_level', true );
		$hide_time        = rcp_get_option( 'rcp_hide_time', 'no' );
		$hide_difflevel   = rcp_get_option( 'rcp_hide_difflevel', 'no' );
		$hide_yields      = rcp_get_option( 'rcp_hide_yields', 'no' );

		echo '<div class="rcp__meta-details">';
		echo '<ul>';
		if ( ! empty( $rcp_prepare_time ) && ( 'yes' !== $hide_time ) ) {
			echo '<li><p>' . esc_html__( 'To prep', 'cookpro_textdomain' ) . ' </p><em> ' . $rcp_prepare_time . '</em></li>';
		}
		if ( ! empty( $rcp_cook_time ) && ( 'yes' !== $hide_time ) ) {
			echo '<li><p>' . esc_html__( 'To cook', 'cookpro_textdomain' ) . '</p><em> ' . $rcp_cook_time . '</em></li>';
		}
		if ( ! empty( $rcp_diff_level ) && ( 'yes' !== $hide_difflevel ) ) {
			echo '<li><p>' . esc_html__( 'Level', 'cookpro_textdomain' ) .'</p><em>' . ucfirst( $rcp_diff_level ). '</em></li>';
		}
		if ( ! empty( $rcp_servings ) && ( 'yes' !== $hide_yields ) ) {
			echo '<li><p>' . esc_html__( 'Servings', 'cookpro_textdomain' ) . '</p><em>' . $rcp_servings . '</em></li>';
		}
		echo '</ul>';
		echo '</div>'; //. rcp__meta-details
	}
}
/**
 * function rcp_ingredients_count()
 * returns Ingredirens count
 **/
if ( ! function_exists( 'rcp_ingredients_count' ) ) {
	function rcp_ingredients_count( $post_id ) {
		$rcp_ingredients  = get_post_meta( $post_id, 'recipe_ingredients_count', true );
		if ( ! empty( $rcp_ingredients ) ) {
			$rcp_ingredients_count = $rcp_ingredients;
		} else {
			return 0;
		}
		return $rcp_ingredients_count;
	}
}
/**
 * function rcp_calories()
 * returns Calories count
 **/
if ( ! function_exists( 'rcp_calories' ) ) {
	function rcp_calories( $post_id ) {
		$rcp_nutritions = get_post_meta( $post_id, 'recipe_nutritions', true );
		if ( ! empty( $rcp_nutritions ) ) {
			$nutritions = 0;
			foreach ( $rcp_nutritions as $key => $data ) {
				if ( ( $data['name'] === 'Calories' ) || ( $data['name'] === 'calories' ) ) {
					$nutritions = $rcp_nutritions[$data['name']] = $data['value'];
				}
			}
			return $nutritions;
		} else {
			return 0;
		}
	}
}
/**
 * function rcp_categories()
 * returns Categories
 **/
if ( ! function_exists( 'rcp_categories' ) ) {
	function rcp_categories( $post_id ) {
		$rcp_category_term_list = wp_get_post_terms( $post_id, 'recipe_cat', array( "fields" => "all" ) );
		if ( count( $rcp_category_term_list ) >= 1 ) {
			echo '<div class="rcp__categories">';
			echo esc_html__( 'Categories ', 'cookpro_textdomain' ) . get_the_term_list( $post_id, 'recipe_cat', '', ', ' );
			echo '</div>'; //.rcp__categories
		} else {
			return false;
		}
	}
}
/**
 * function rcp_custom_categories()
 * returns Categories
 **/
if ( ! function_exists( 'rcp_custom_categories' ) ) {
	function rcp_custom_categories( $post_id ) {

		$rcp_method_term_list = wp_get_post_terms( $post_id, 'recipe_method', array( "fields" => "names" ) );
		$rcp_category_term_list = wp_get_post_terms( $post_id, 'recipe_cat', array( "fields" => "names" ) );
		$rcp_cuisine_term_list  = wp_get_post_terms( $post_id, 'recipe_cuisine', array( "fields" => "names" ) );
		$rcp_tags_list 			= wp_get_object_terms( $post_id, 'post_tag', array( "fields" => "names" ) );
        if ( count( $rcp_tags_list ) >= 1 ) {
		echo '<div class="rcp__tags-wrapper">';
			echo '<div class="rcp__ingredients">';
			echo get_the_term_list( $post_id, 'post_tag', '<ul class="rcp__ingredients-tags"><li>', '</li><li>', '</li></ul>' );
			echo '</div>'; //.rcp__cooking-method

		echo '</div>'; //.rcp__tags-wrapper
        }
	}
}
/**
 * function rcp_post_content()
 * returns content
 **/
if ( ! function_exists( 'rcp_post_content' ) ) {
	function rcp_post_content( $post_id ) {
		$rcp_post_content = get_the_content( $post_id );
		if ( !empty( $rcp_post_content ) ) {
			echo '<div class="rcp-full-details-wrapper">';
			echo '<div class="rcp__decription">';
			echo '<h2>' . esc_html__( 'Description', 'cookpro_textdomain' ) . '</h2>';
			echo $rcp_post_content;
			echo '</div>';
			echo '</div>'; //.rcp-full-details-wrapper
		}
	}
}
/**
 * function rcp_ingredient_names()
 * returns ingredient names
 **/
if ( ! function_exists( 'rcp_ingredient_names' ) ) {
	function rcp_ingredient_names( $post_id ) {
		$rcp_ingredient_names = '';
		$recipe_ingredients  = get_post_meta( $post_id, 'recipe_ingredients', true );
		if ( ! empty( $recipe_ingredients ) ) {
			foreach ( $recipe_ingredients as $key => $data ) {
				switch ( $data['type'] ) :
					case 'ingredient':
						$rcp_ingredient_names[] =  $data['name'];
						break;
				endswitch;
			}
			if ( ! empty( $rcp_ingredient_names ) ) {
				$rcp_ingredient_names = implode( ',',$rcp_ingredient_names );
			}
		}
		if ( ! empty ( $rcp_ingredient_names ) ) {
			echo '<div class="rcp__ingredients">';
			echo esc_html__( 'Ingredients ', 'cookpro_textdomain' ) . $rcp_ingredient_names;
			echo '</div>';
		} else {
			return false;
		}
	}
}
/**
 * function rcp_get_post_ratings()
 * returns ratings
 **/
if ( ! function_exists( 'rcp_get_post_ratings' ) ) {
	function rcp_get_post_ratings( $post_id ) {
		$out = '';
		$rcp_comment_avg_rating = get_post_meta( $post_id, 'rcp_comment_avg_rating', true );
		$out .= '<div class="rcp___prating">';
		$out .='
		<div class="rcp-comment-ratings-review" data-rated=' . $rcp_comment_avg_rating . '>
		<i class="star_1 fa fa-star"></i>
		<i class="star_2 fa fa-star"></i>
		<i class="star_3 fa fa-star"></i>
		<i class="star_4 fa fa-star"></i>
		<i class="star_5 fa fa-star"></i>
		</div>';
		$out .= '</div>'; //.comment_rating

		return $out;
	}
}
/**
 * function rcp_comments_list()
 * returns comments list
 **/
if ( ! function_exists( 'rcp_comments_list' ) ) {
	function rcp_comments_list( $post_id ) {

		$rcp_comment_nonce = wp_create_nonce( 'rcp-comment-nonce' );
		$orderby = 'comment_ID';
		$order 	 = rcp_get_option( 'rcp_comment_order', 'ASC' );
		$pagination = rcp_get_option( 'rcp_comment_pagination', 'enable' );
		$limit 	 = rcp_get_option( 'rcp_comment_limit', null );

		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}
		$offset = ( $paged * $limit ) - $limit;
		$args = array(
			'post_id' => $post_id,
		    'status'  =>'approve',
		    'offset'  => $offset,
		    'number'  => $limit,
			'orderby' => $orderby,
			'order'   => $order,
		);
		$total_comments = get_comments( array( 'post_id' => $post_id, 'status' => 'approve' ) );
		$rcp_comments = get_comments( $args );
		$rcp_comment_count = ceil( count( $total_comments ) );
		$hide_ratings = rcp_get_option('rcp_hide_ratings','no' );
		if ( null != $limit ) {
			$pages = ceil( count( $total_comments ) / $limit );
		}
		echo '<div class="rcp__comments-area">';
		if ( ! empty( $rcp_comments ) ) {
			$rcp_title = get_the_title( $post_id );
			echo '<h2 class="rcp-comment__title">';
			echo sprintf( _nx('One Review & Rating', '%1$s Reviews & Ratings',$rcp_comment_count,'reviews','cookpro_textdomain'), $rcp_comment_count );
			echo '</h2>';
			echo '<div class="rcp-comment-module">';
			echo '<ol class="rcp-comment__list rcp-comment-module-content">';
			foreach( $rcp_comments as $review ) {
				$comment_rating = get_comment_meta( $review->comment_ID, 'comment_rating', true );
				$rcp_comment_date = strtotime( $review->comment_date );
				$comment_date = sprintf( esc_html__( '%1$s at %2$s' ),
	    			get_comment_date( esc_html__( 'M j, Y' ), $review->comment_ID ),
	    			get_comment_date( esc_html__( 'g:i a' ), $review->comment_ID )
	   			);
				echo '<li id="comment-' . $review->comment_ID . '" class="rcp-comment-post rcp-comment-item">';
				echo '<div class="rcp-comment__review">';
				echo '<div class="comment__meta">';
				echo '<div class="comment__author vcard">';
				echo rcp_get_avatar( $review->user_id, 60 );//.avatar
				echo '<b class="fn">' . $review->comment_author . '</b>';
				echo '</div>'; //comment__author vcard
				echo '<div class="comment__metadata">';
				echo '<span>' . $comment_date . '</span>';
				echo '</div>'; //comment__metadata
	 			echo '</div>'; //comment__meta
	 			echo '<div class="comment__content">';
	 			echo '<p>' . $review->comment_content . '</p>';

    			if ( 'yes' !== $hide_ratings ) {
					if ( ! empty( $comment_rating ) ) {
						echo '<div class="rcp___prating">';
						echo '
						<div class="rcp-comment-ratings-review" data-rated=' . $comment_rating . '>
						<i class="star_1 fa fa-star"></i>
						<i class="star_2 fa fa-star"></i>
						<i class="star_3 fa fa-star"></i>
						<i class="star_4 fa fa-star"></i>
						<i class="star_5 fa fa-star"></i>
						</div>';
						echo '</div>'; //.comment_rating
					}
				}
				echo '</div>'; //.comment__content
				echo '</div>'; //.rcp-comment__review
				echo '</li>';
			}
			echo '</ol>'; //.rcp-comment__list
			echo '</div>'; //.rcp-comment-module-content
			if ( $pagination == 'enable' ) {
				if ( $rcp_comment_count > 1 && $rcp_comment_count > $limit  ) {
					echo paginate_links(
						array(
							'base'         => @add_query_arg( 'page', '%#%' ),
							'format'       => '?page=%#%',
							'total'        => $pages,
							'current'      => $paged,
							'show_all'     => False,
							'mid_size'     => 1,
							'prev_text' => '<i class="fa fa-chevron-left"></i>',
							'next_text' => '<i class="fa fa-chevron-right"></i>',
						)
					);
				}
			}
		}
		$rcp_comment_error = esc_html__( 'All fields and rating are required to submit a review.','cookpro_textdomain' );
		$comments_args = array(
			'label_submit'		   => esc_html__( 'Submit Review', 'cookpro_textdomain' ),
			'title_reply'		   => esc_html__( 'Leave a Reply', 'cookpro_textdomain' ),
			'comment_notes_before' => '',
			'comment_notes_after'  => '<p class="rcp-comment-error">' . $rcp_comment_error . '</p>',
			'comment_field'		   => '<div class="comment-form-comment"><label for="comment">' . esc_html__( 'Review', 'cookpro_textdomain' ) . '</label><textarea id="comment" name="comment" aria-required="true"></textarea></div>',
			'submit_field'         => '<div class="form-submit">%1$s %2$s</div>',
		);
		echo comment_form( $comments_args, $post_id );
		echo '</div>';//.rcp__comments-area-wrapper
	}
}
/**
 * function rcp_share_list()
 * returns share list
 **/
if ( ! function_exists( 'rcp_share_list' ) ) {
	function rcp_share_list( $post_id ) {
		$out = $output = '';
		// Facebook
		if ( get_option( 'rcp_sociable_facebook' ) === 'on' ) {
			$out .= '<li><a class="facebook customer share" href="http://www.facebook.com/sharer.php?u=' . esc_url( get_permalink( $post_id ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'Share on Facebook','cookpro_textdomain' ) . '" target="_blank"><i class="fa fa-facebook fa-fw"></i></a></li>';
		}
		// Twitter
		if ( get_option( 'rcp_sociable_twitter' ) === 'on' ) {
			$out .= '<li><a class="twitter customer share" href="http://twitter.com/share?url=' . esc_url( get_permalink( $post_id ) ) . '&amp;text=' . get_the_title() . '" title="' . esc_html__( 'Share on Twitter', 'cookpro_textdomain' ) . '" target="_blank"><i class="fa fa-twitter fa-fw"></i></a></li>';
		}
		// Google+
		if ( get_option( 'rcp_sociable_googleplus' ) === 'on' ) {
			$out .= '<li><a class="google_plus customer share" target="_blank" href="http://plus.google.com/share?url=' . esc_url( get_permalink( $post_id ) ) . '&amp;title=' . get_the_title() . '&amp;annotation=' . get_the_title() . '"  title="' . esc_html__( 'Share on Google+', 'cookpro_textdomain' ) . '"><i class="fa fa-google-plus fa-fw"></i></a></li>';
		}
		// Linkdedin
		if ( get_option( 'rcp_sociable_linkedin' ) === 'on' ) {
			$out .= '<li><a class="linkedin customer share" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=' . esc_url( get_permalink($post_id) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'Share on linkedin', 'cookpro_textdomain' ) . '" target="_blank"><i class="fa fa-linkedin fa-fw"></i></a></li>';
		}

		if ( ! empty( $out ) ) {
			$output .= '<ul class="rcp__share-list">';
			$output .= $out;
			$output .= '</ul>';//.rcp__share-list
			return $output;
		}
	}
}
/**
 * function rcp_get_print_link()
 * returns print links
 **/
if ( ! function_exists( 'rcp_get_print_link' ) ) {
	function rcp_get_print_link( $post_id ) {
		$using_permalink = get_option( 'permalink_structure' );
		$print_link = get_permalink( $post_id );
		if ( ! empty( $using_permalink ) ) {
			if ( substr( $print_link, -1, 1 ) != '/' ) {
				$print_link = $print_link.'/';
			}
			$print_link = $print_link.'print/';
		} else {
			$print_link = $print_link.'&amp;print=1';
		}
		return $print_link;
	}
}
/**
 * function rcp_get_edit_link()
 * returns edit links
 **/
if ( ! function_exists( 'rcp_get_edit_link' ) ) {
	function rcp_get_edit_link( $post_id ) {
		$using_permalink = get_option( 'permalink_structure' );
		$print_link = get_permalink( $post_id );
		if ( ! empty( $using_permalink ) ) {
			if ( substr( $print_link, -1, 1 ) != '/' ) {
				$print_link = $print_link.'/';
			}
			$print_link = $print_link.'?edit';
		} else {
			$print_link = $print_link.'&amp;edit=1';
		}
		return $print_link;
	}
}
/**
 * function rcp_post_view()
 * updates post views
 **/
if ( ! function_exists( 'rcp_post_view' ) ) {
	function rcp_post_view( $post_id ) {
	    $countKey = 'rcp_post_views';
	    $count = get_post_meta( $post_id, $countKey, true );
	    if ( $count=='' ) {
	        $count = 0;
	        delete_post_meta( $post_id, $countKey);
	        add_post_meta( $post_id, $countKey, '0');
	    }else{
	        $count++;
	        update_post_meta( $post_id, $countKey, $count);
	    }
	}
}
/**
 * function rcp_like_email_print_links()
 * returns like email favorite links
 **/
if ( ! function_exists( 'rcp_like_email_print_links' ) ) {
	function rcp_like_email_print_links( $post_id, $rcp_user_favourites ) {
		$rcp_view_count 				= get_post_meta( $post_id, 'rcp_post_views', true );
		$rcp_likes_section_display 		= rcp_get_option( 'rcp_likes_section_display', 'enable' );
		$rcp_favorites_section_display  = rcp_get_option( 'rcp_favorites_section_display', 'enable' );
		$rcp_views_section_display 		= rcp_get_option( 'rcp_views_section_display', 'enable' );
		$rcp_print_section_display 		= rcp_get_option( 'rcp_print_section_display', 'enable' );
		$rcp_email_section_display 		= rcp_get_option( 'rcp_email_section_display', 'enable' );
		echo '<div class="rcp__print-love">';
		if ( $rcp_likes_section_display !== 'disable' ) {
			echo '<span class="rcp_pll meta-likes">' . rcp_post_like( 'rcp_like' )  . '</span>';
		}
		if ( $rcp_favorites_section_display !== 'disable' ) {
			if ( in_array( $post_id, $rcp_user_favourites ) ) {
				echo '<span class="rcp_pll meta-favorites">' . rcp_get_favorites( $post_id ) . '</span>';
			} else {
				echo '<span class="rcp_pll meta-favorites">' . rcp_post_favorite( 'rcp_favorite' )  . '</span>';
			}
		}
		if ( $rcp_views_section_display !== 'disable' ) {
			echo '<span class="rcp_pll meta-views"><i class="fa fa-eye fa-lg" aria-hidden="true"></i> ' . $rcp_view_count . '</span>';
		}
		if ( $rcp_print_section_display !== 'disable' ) {
			echo '<span class="rcp_pll"><a class="print" href="' . esc_url( rcp_get_print_link( $post_id ) ) . '" target="_blank"><i class="fa fa-print fa-lg" aria-hidden="true"></i></a></span>';
		}
		if ( $rcp_email_section_display !== 'disable' ) {
			echo '<span class="rcp_pll"><a class="email" href="mailto:?subject=' . esc_attr( get_the_title( $post_id ) ) . '&body=' . esc_url( get_permalink( $post_id ) ) . '"><i class="fa fa-envelope-o fa-lg" aria-hidden="true"></i></a></span>';
		}
		echo '</div>'; //. rcp__print-love
	}
}
/**
 * function rcp_ingredient_list()
 * returns Ingredirens list
 **/
if ( ! function_exists( 'rcp_ingredient_list' ) ) {
	function rcp_ingredient_list( $post_id ) {
		global $wp_query; $disabled = '';
		$rcp_ingredients = get_post_meta( $post_id ,'recipe_ingredients', true );
		if ( ! empty( $rcp_ingredients ) ) {
			if ( array_key_exists( 'print' , $wp_query->query_vars ) ) {
				echo '<h3>' . esc_html__( 'Ingredients','cookpro_textdomain' ) . '</h3>';
				$disabled = 'disabled';
			}
			echo '<div class="rcp__ingrdnt-group">';
			echo '<ul class="rcp__ingrdnt-list">';
			$list = explode( "\n", trim( $rcp_ingredients ) );
			foreach ( $list as $key => $data ) {
				$data = preg_replace('/^\s*\-{2}(.*)/', '<h4>$1</h4>', $data );
				$pos = strpos( $data, '<h4>' );
				if ( $pos === false ) {
					echo '<li>';
					echo '<div class="ingrdnt-checkbox"></div>';
					echo '<div class="ingrdnt-desc">' . $data . '</div>';
					echo '</li>';
				} else {
					echo $data;
				}
			}
			echo '</ul>';
			echo '</div>'; //.rcp__ingrdnt-group
		}
	}
}
/**
 * function rcp_nutrition_list()
 * returns nutritions list
 **/
if ( ! function_exists( 'rcp_nutrition_list' ) ) {
	function rcp_nutrition_list( $post_id ) {
		global $wp_query;
		$rcp_nutritions = get_post_meta( $post_id, 'recipe_nutritions', true );
		if ( ! empty( $rcp_nutritions ) ) {
			echo '<div class="rcp__ingrdnt-nutri">';
			echo '<ul class="rcp__nutrition">';
			foreach ( $rcp_nutritions as $key => $data ) {
				echo '<li> ' . $data['name'] . '<span> ' . $data['value'].  '</span></li>';
			}
			echo '</ul>';
			$rcp_nutrition_info = rcp_get_option( 'rcp_nutrition_info' );
			if ( ! empty( $rcp_nutrition_info ) ) {
				echo '<p>' . esc_textarea( $rcp_nutrition_info ) . '</p>';
			}
			echo '</div>';
		}
	}
}
/**
 * function rcp_steps_list()
 * returns steps list
 **/
if ( ! function_exists( 'rcp_steps_list' ) ) {
	function rcp_steps_list( $post_id ) {
		$rcp_steps = get_post_meta( $post_id, 'recipe_steps', true );
		if ( ! empty( $rcp_steps) ) {
			echo '<h3 class="rcp__steps-title">' . esc_html__( 'Method','cookpro_textdomain' ) . '</h3>';
			echo '<ul class="rcp__steps">';
			$list = explode( "\n", trim( $rcp_steps ) );
			foreach ( $list as $key => $data ) {
				if ( preg_match('/^\s*\-{2}([^~]+)(~([^~]+)~)/', $data, $matches ) ) {
					echo '<li>';
					echo '<div class="rcp__step-numdur">';
					echo '<div class="rcp__step-number">' . $matches[1] . '</div>';
					echo '<div class="rcp__step-duration">' . $matches[3] . '</div>';
					echo '</div>'; //.rcp__step-numdur
				} elseif ( preg_match('/^\s*\-{2}([^~]+)/', $data, $matchess ) ) {
					echo '<li>';
					echo '<div class="rcp__step-numdur">';
					echo '<div class="rcp__step-number">' . $matchess[1] . '</div>';
					echo '</div>';//.rcp__step-numdur
				}
				else {
					$patterns = array(
						'/^\s*\-{2}([^~]+)(~([^~]+)~)/',
						'/(~([^~]+)~)/',
						'/^\s*\-{2}([^~]+)/',
					);
					$desc = preg_replace( $patterns, '', $data );
					echo '<div class="rcp__step-decription">' . $desc . '</div>';
					echo '</li>';
				}
			}
			echo '</ul>'; //.rcp__steps
		}
	}
}
function rcp_equiments_list( $post_id ) {
	$rcp_equipments = get_post_meta( $post_id, 'recipe_equipments', true );
	echo '<div class="rcp__equipments-wrapper">';
	echo '<h3 class="rcp__equipments-title">' . esc_html__( 'Equipments', 'cookpro_textdomain' ) . '</h3>';
	echo '<ul class="rcp__equipments">';
	foreach ( $rcp_equipments as $key => $value ) {
		echo '<li>' . $value['value'] . '</li>';
	}
	echo '</ul>';
	echo '</div>';
}
/**
 * function rcp_single_page_data()
 * returns single page content
 **/
if ( ! function_exists( 'rcp_single_page_data' ) ) {
	function rcp_single_page_data( $post_id ) {
		rcp_post_view( $post_id );
		$rcp_ingredients = get_post_meta( $post_id, 'recipe_ingredients',true );
		$rcp_steps  	 = get_post_meta( $post_id, 'recipe_steps', true );
		$rcp_nutritions  = get_post_meta( $post_id, 'recipe_nutritions', true );
		$rcp_gallery 	 = get_post_meta( $post_id, 'recipe_gallery', true );
		$rcp_video_url 	 = get_post_meta( $post_id, 'recipe_video_url', true );
		$rcp_post_author_id = get_post_field( 'post_author', $post_id );

		$rcp_ads_content 				 = rcp_get_option( 'rcp_ads_content' );
		$rcp_ads_display 				 = rcp_get_option( 'rcp_ads_display','enable' );
		$rcp_post_title_section_display  = rcp_get_option( 'rcp_title_display','enable' );
		$rcp_sub_title_section_display 	 = rcp_get_option( 'rcp_sub_title_display','enable' );
		$rcp_author_info_display 		 = rcp_get_option( 'rcp_author_info_display','enable' );
		$rcp_ingre_section_display 		 = rcp_get_option( 'rcp_ingre_section_display','enable' );
		$rcp_nutri_section_display 		 = rcp_get_option( 'rcp_nutri_section_display','enable' );
		$rcp_steps_section_display 		 = rcp_get_option( 'rcp_steps_section_display','enable' );
		$rcp_equipments_display 		 = rcp_get_option( 'rcp_equipments_display','enable' );
		$rcp_rating_section_display 	 = rcp_get_option( 'rcp_rating_section_display','enable' );
		$rcp_share_links_section_display = rcp_get_option( 'rcp_share_links_section_display','enable' );
		$rcp_img_section_display 		 = rcp_get_option( 'rcp_img_section_display','enable' );
		$rcp_desc_section_display 		 = rcp_get_option( 'rcp_desc_section_display','enable' );
		$rcp_meta_section_display 		 = rcp_get_option( 'rcp_meta_section_display','enable' );
		$rcp_single_layout_option 		 = rcp_get_option( 'rcp_single_layout','vertical_style' );
		$rcp_single_layout 	 			 = get_post_meta( $post_id, 'rcp_single_layout', true ) ? get_post_meta( $post_id, 'rcp_single_layout', true ) : $rcp_single_layout_option ;
		$hide_ratings                    = rcp_get_option('rcp_hide_ratings','no');
		echo '<div class="rcp-main-panel">';
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$login_id = $current_user->ID;
			$author_id = get_post_field ('post_author', $post_id );
			$rcp_status = get_post_status( $post_id );
			$rcp_user_link = get_permalink( rcp_get_option( 'rcp_profile_page_id', '' ) ) . '?username=' . $current_user->user_login;

			$rcp_user_favorite_postids = get_user_meta( $login_id, 'recipe_love', true );
			$rcp_user_favourites = array();
			if ( ! empty( $rcp_user_favorite_postids ) ) {
				foreach ( $rcp_user_favorite_postids as $rcp_postid ) {
					$rcp_user_favourites[] = $rcp_postid;
					$rcp_user_favourites = array_unique( $rcp_user_favourites );
				}
			}
			if ( in_array( $post_id, $rcp_user_favourites ) ) {
				echo '<div class="rcp-favorited-panel" id="rcp-favorited-panel">';
				echo '<p class="rcp-editing__info">';
				echo esc_html__( 'You already favorited this recipe.', 'cookpro_textdomain' );
				echo '</p>'; //.rcp-editing__info
				echo '</div>'; // rcp-favorite-panel
			}
			//
			echo '<div class="rcp-favorite-panel" id="rcp-favorite-panel">';
			echo '<div class="rcp-favorite-editing__left">';
			echo '<p class="rcp-editing__info">';
			echo esc_html__( 'You\'ve favorited this recipe. Visit your profile to view all your saved recipes!','cookpro_textdomain' );
			echo '</p>'; //.rcp-editing__info
			echo '</div>'; //. rcp-favorite-editing__left
			echo '<div class="rcp-favorite-editing__right">';
			echo '<a class="rcp-btn rcp-btn-sm rcp-btn-dark" href="' . esc_url( $rcp_user_link ) . '">' . esc_html__( 'View Favourite Recipes', 'cookpro_textdomain' ) . '</a>';
			echo '</div>'; //. rcp-favorite-editing__left
			echo '</div>'; // rcp-favorite-panel
			if ( $login_id == $author_id ) {
				echo '<div class="rcp-main-editing-panel">';
				echo '<div class="rcp-main-editing__left">';
				if (  $rcp_status == 'private' ) {
					echo '<span class="rcp-editing__tag rcp__private">' . esc_html__( 'Private Recipe', 'cookpro_textdomain' ) . '</span>';
				}
				if (  $rcp_status == 'publish' ) {
					echo '<span class="rcp-editing__tag rcp__public">' . esc_html__( 'Public Recipe', 'cookpro_textdomain' ) . '</span>';
				}
				if (  $rcp_status == 'pending' ) {
					echo '<span class="rcp-editing__tag rcp__inreview">' . esc_html__( 'In Review', 'cookpro_textdomain' ) . '</span>';
				}
				echo '<p class="rcp-editing__info">';
				if (  $rcp_status == 'private' ) {
				echo esc_html__( 'This recipe is private (only you can see it). You have the option to do the following:','cookpro_textdomain' );
				}
				if (  $rcp_status == 'publish' ) {
					echo esc_html__( 'This is your recipe! You have the following option:', 'cookpro_textdomain' );
				}
				if (  $rcp_status == 'pending' ) {
					echo esc_html__( 'This is your recipe! Its under review process.', 'cookpro_textdomain' );
				}
				echo '</p>'; //.rcp-editing__info
				echo '</div>'; //.rcp-main-editing__left
				echo '<div class="rcp-main-editing__right">';
				if (  $rcp_status != 'pending' ) {
					echo '<a class="rcp-btn rcp-btn-primary rcp-btn-sm rcp-btn-simple" href="' . esc_url( rcp_get_edit_link( $post_id ) ) . '">' . esc_html__( 'Edit Recipe','cookpro_textdomain' ) . '</a>';
				}
				if (  $rcp_status == 'private' ) {
					echo '<a class="rcp-btn rcp-btn-sm rcp-btn-dark rcp-post-status-link" href="" data-url="' . esc_url( get_permalink( $post_id ) ) . '"data-id="' . esc_attr( $post_id ) . '">' . esc_html__( 'Make Recipe Public', 'cookpro_textdomain' ). '</a>';
				}
				if (  $rcp_status == 'publish' ) {
					echo '<a class="rcp-btn rcp-btn-sm rcp-btn-dark rcp-post-status-link" href="" data-url="' . esc_url( get_permalink( $post_id ) ) . '"data-id="' . esc_attr( $post_id ) . '">' . esc_html__( 'Make Recipe Private', 'cookpro_textdomain' ) . '</a>';
				}
				echo '</div>'; //.rcp-main-editing__right
				echo '</div>'; //.rcp-main-editing-panel
			}
		}
		echo '<div class="rcp__panel-header">';
		echo '<div class="rcp__main-heading">';
		if ( $rcp_post_title_section_display !== 'disable' ) {
			echo rcp_post_title( $post_id );
		}
		if ( $rcp_sub_title_section_display !== 'disable' ) {
			echo rcp_sub_title( $post_id );
		}
		echo '</div>'; //.rcp__main-heading
		echo '<div class="rcp__share-review">';
        if ( $rcp_share_links_section_display !== 'disable' ) {
			echo '<span class="rcp__share-toolbar">';
			echo rcp_share_list( $post_id );
			echo '</span>'; //.rcp__share-toolbar
		}
		if ( $rcp_rating_section_display !== 'disable' && 'yes' !== $hide_ratings ) {
			echo '<span class="rcp__review">';
			echo rcp_get_post_ratings( $post_id );
			echo '</span>'; //.rcp__review
		}
		echo '</div>'; //.rcp__share-review
		echo '</div>'; //.rcp__panel-header
		// style1 layout
		$rcp_user_favourites = array();
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$login_id = $current_user->ID;
			$rcp_user_favorite_postids = get_user_meta( $login_id, 'recipe_love', true );

			if ( ! empty( $rcp_user_favorite_postids ) ) {
				foreach ( $rcp_user_favorite_postids as $rcp_postid ) {
					$rcp_user_favourites[] = $rcp_postid;
					$rcp_user_favourites = array_unique( $rcp_user_favourites );
				}
			}
		}
		if ( $rcp_single_layout == 'vertical_style' ) {
			echo '<div class="rcp__details-wrapper">';
			if ( $rcp_img_section_display !== 'disable' ) {
				if ( ! empty( $rcp_gallery ) ) {
					do_action( 'rcp_plugin_flexslider', $post_id );
					$rcp_gallery_ids = array_filter( explode(',', $rcp_gallery ) );
					echo '<div class="rcp__featured-image clearfix">';
					echo '<div class="flexslider">';
					echo '<ul class="slides">';
					foreach( $rcp_gallery_ids as $img_id ) {
						echo '<li>' . wp_get_attachment_image( $img_id, 'rcp_medium_vertical' ) . '</li>';
					}
					echo '</ul>'; //.slides
					echo '</div></div>';
				} else {
					echo rcp_post_thumbnail( $post_id, $rcp_video_url );
				}
			}
			echo '<div class="rcp__detail-block">';
			echo '<div class="rcp__detail-inner">';
			echo rcp_like_email_print_links( $post_id, $rcp_user_favourites );
			if ( $rcp_desc_section_display !== 'disable' ) {
				echo rcp_short_info( $post_id );
			}
			if ( $rcp_meta_section_display !== 'disable' ) {
				echo rcp_meta_details( $post_id );
			}
			echo '</div>'; //. rcp__detail-inner
			echo '</div>'; //. rcp__detail-block
			echo '</div>'; //.rcp__details-wrapper
		}
		if ( $rcp_single_layout == 'horizontal_style' ) {
			echo '<div class="panel recipe-details rcp-horizontal">';
			echo '<div class="panel-content">';
			echo '<div class="rcp-image-wrapper">';
			if ( $rcp_img_section_display !== 'disable' ) {
				if ( ! empty( $rcp_gallery ) ) {
					do_action( 'rcp_plugin_flexslider', $post_id );
					$rcp_gallery_ids = array_filter( explode(',', $rcp_gallery ) );
					echo '<div class="rcp__featured-image clearfix">';
					echo '<div class="flexslider">';
					echo '<ul class="slides">';
					foreach( $rcp_gallery_ids as $img_id ) {
						echo '<li>' . wp_get_attachment_image( $img_id, 'rcp_medium_horizontal' ) . '</li>';
					}
					echo '</ul>'; //.slides
					echo '</div></div>';
				} else {
					$rcp_video_url = get_post_meta( $post_id, 'recipe_video_url', true );
					if ( $rcp_video_url ) {
						echo '<a href="' . esc_url( $rcp_video_url ) . '" rel="prettyPhoto">';
					}
					if ( has_post_thumbnail( $post_id ) ) {
						echo get_the_post_thumbnail( $post_id, 'rcp_medium_horizontal', array( 'class' => 'rcp-thumbnail' ) );
					} else {
						echo '<img src="' . RECIPE_IMG_URI . '/no_image.jpg" alt="' . get_the_title( $post_id ) . '"/>';
					}
					echo '</a>';
				}
			}
			echo '<div class="rcp__detail-block">';
			$rcp_view_count 				= get_post_meta( $post_id, 'rcp_post_views', true );
			$rcp_likes_section_display 		= rcp_get_option( 'rcp_likes_section_display', 'enable' );
			$rcp_favorites_section_display  = rcp_get_option( 'rcp_favorites_section_display', 'enable' );
			$rcp_views_section_display 		= rcp_get_option( 'rcp_views_section_display', 'enable' );
			echo '<div class="rcp__print-love">';
			if ( $rcp_likes_section_display !== 'disable' ) {
				echo '<span class="rcp_pll meta-likes">' . rcp_post_like( 'rcp_like' )  . '</span>';
			}
			if ( $rcp_favorites_section_display !== 'disable' ) {
				if ( in_array( $post_id, $rcp_user_favourites ) ) {
					echo '<span class="rcp_pll meta-favorites">' . rcp_get_favorites( $post_id ) . '</span>';
				} else {
					echo '<span class="rcp_pll meta-favorites">' . rcp_post_favorite( 'rcp_favorite' )  . '</span>';
				}
			}
			if ( $rcp_views_section_display !== 'disable' ) {
				echo '<span class="rcp_pll meta-views"><i class="fa fa-eye fa-lg" aria-hidden="true"></i> ' . $rcp_view_count . '</span>';
			}
			echo '</div>'; //. rcp__print-love
			echo '</div>'; //. rcp__detail-block
			echo '</div>'; //.rcp-image-wrapper
			if ( $rcp_meta_section_display !== 'disable' ) {
				echo '<div class="rcp-meta-details">';
				$rcp_servings              = get_post_meta( $post_id, 'recipe_servings', true );
				$rcp_prepare_time          = rcp_get_time( $post_id ,'recipe_ptime' );
				$rcp_cook_time             = rcp_get_time( $post_id ,'recipe_ctime' );
				$rcp_diff_level            = get_post_meta( $post_id, 'recipe_diff_level', true );
				$total_comments            = get_comments( array( 'post_id' => $post_id, 'status' => 'approve' ) );
				$rcp_comment_count         = ceil( count( $total_comments ) );
				$rcp_print_section_display = rcp_get_option( 'rcp_print_section_display', 'enable' );
				$rcp_email_section_display = rcp_get_option( 'rcp_email_section_display', 'enable' );
				$hide_time                 = rcp_get_option( 'rcp_hide_time', 'no' );
				$hide_difflevel            = rcp_get_option( 'rcp_hide_difflevel', 'no' );
				$hide_yields               = rcp_get_option( 'rcp_hide_yields', 'no' );
				$hide_ratings              = rcp_get_option('rcp_hide_ratings','no' );
				echo '<ul>';
				if ( ! empty( $rcp_prepare_time ) && ( 'yes' !== $hide_time ) ) {
					echo '<li><em> ' . $rcp_prepare_time . '</em><p>' . esc_html__( 'To prep', 'cookpro_textdomain' ) . ' </p></li>';
				}
				if ( ! empty( $rcp_cook_time ) && ( 'yes' !== $hide_time ) ) {
					echo '<li><em> ' . $rcp_cook_time . '</em><p>' . esc_html__( 'To cook', 'cookpro_textdomain' ) . '</p></li>';
				}
				if ( ! empty( $rcp_diff_level ) && ( 'yes' !== $hide_difflevel ) ) {
					echo '<li><em>' . ucfirst( $rcp_diff_level ) . '</em><p>' . esc_html__( 'Level', 'cookpro_textdomain' ) . '</p></li>';
				}
				if ( ! empty( $rcp_servings ) && ( 'yes' !== $hide_yields ) ) {
					echo '<li><em>' . $rcp_servings . '</em><p>' . esc_html__( 'Yields', 'cookpro_textdomain' ) . '</p></li>';
				}
				if( 'yes' !== $hide_ratings ){
					echo '<li>' . rcp_get_post_ratings( $post_id );
				}
				echo '<p>' . esc_html__( 'Average rating', 'cookpro_textdomain' ) . '</p>';
				echo '<p>' . sprintf( _nx( 'One comment', '%1$s comments', $rcp_comment_count, 'comments', 'cookpro_textdomain' ), $rcp_comment_count ) . '</p>';
				echo '</li>';
				echo '</ul>';
				echo '<div class="panel-foot-btns">';
				if ( $rcp_print_section_display !== 'disable' ) {
					echo '<a class="print rcp-rate" href="' . esc_url( rcp_get_print_link( $post_id ) ) . '" target="_blank">' . esc_html__( 'Print this recipe','recipe' ) . '</a>';
				}
				if ( $rcp_email_section_display !== 'disable' ) {
					echo '<a class="email rcp-fav" href="mailto:?subject=' . esc_attr( get_the_title( $post_id ) ) . '&body=' . esc_url( get_permalink( $post_id ) ) . '">' . esc_html__( 'Email this recipe','recipe' ) . '</a>';
				}
				echo '</div>'; //.panel-foot-btns
				echo '</div>'; //.rcp-meta-details
			}
			echo '</div>'; //. panel-content
			// echo '<div class="panel-description">';
			// if ( $rcp_desc_section_display !== 'disable' ) {
			// 	echo rcp_short_info( $post_id );
			// }
			// echo '</div>'; //.panel-description
			echo '</div>'; //.recipe-details
		}
		// Description
		echo rcp_post_content( $post_id );

		if ( ! empty( $rcp_ingredients )  || ! empty( $rcp_nutritions ) ) {
			echo '<div class="rcp__ingrdnt-nutri">';
			echo '<ul class="rcp__ingrdnt_pane">';
			if ( $rcp_ingre_section_display !== 'disable' ) {
				if ( ! empty( $rcp_ingredients ) ) {
					echo '<li class="" id="#pane0"><a href="#pane0">' . esc_html__( 'Ingredients', 'cookpro_textdomain' ) . '</a></li>';
				}
			}
			if ( $rcp_nutri_section_display !== 'disable' ) {
				if ( ! empty( $rcp_nutritions ) ) {
					echo '<li class="" id="#pane1"><a href="#pane1">' . esc_html__( 'Nutrition', 'cookpro_textdomain' ) . '</a></li>';
				}
			}
			echo '</ul>'; //.rcp__pane

			echo '<div class="rcp__pane_content">';
			if ( $rcp_ingre_section_display !== 'disable' ) {
				echo '<div class="pane_content" id="#pane0">';
				echo rcp_ingredient_list( $post_id );
				echo '</div>'; //.pane_content
			}
			if ( $rcp_nutri_section_display !== 'disable' ) {
				echo '<div class="pane_content" id="#pane1">';
				echo rcp_nutrition_list( $post_id );
				echo '</div>';
			}
			echo '</div>'; //.rcp__pane_content
			echo '</div>'; //.rcp__ingrdnt-nutri
		}
		if ( $rcp_ads_display !== 'disable' ) {
			echo '<div class="rcp__ads-wrapper">';
			echo '<div class="rcp__adsplace">';
			if ( ! empty( $rcp_ads_content ) ) {
				echo do_shortcode( $rcp_ads_content );
			} else {
				echo '<img src="' . RECIPE_IMG_URI . '/ads.jpg" alt="img"/>';
			}
			echo '</div>'; //.rcp__adsplace
			echo '</div>'; //.rcp__ads-wrapper
		}
		// Steps
		if ( $rcp_steps_section_display !== 'disable' ) {
			if ( ! empty( $rcp_steps ) ) {
				echo '<div class="rcp__steps-wrapper">';
				echo rcp_steps_list( $post_id );
				echo '</div>'; //.rcp__steps-wrapper
			}
		}
		if ( 'disable' !== $rcp_equipments_display ) {
			$rcp_equipments = get_post_meta( $post_id, 'recipe_equipments', true );
			if ( ! empty( $rcp_equipments ) ) {
				echo rcp_equiments_list( $post_id );
			}
		}
		echo rcp_custom_categories( $post_id );
		if ( $rcp_share_links_section_display !== 'disable' ) {
			echo '<div class="rcp__footer-share-wrapper">';
		    echo '<div class="rcp__share-review">';
			echo '<span class="rcp__share-toolbar">';
			echo rcp_share_list( $post_id );
			echo '</span>';
			echo '<span class="rcp__share-toolbar">';
			echo rcp_like_email_print_links( $post_id, $rcp_user_favourites );
			echo '</span>';
			echo '</div>'; //.rcp__share-review
			echo '</div>'; //.rcp__footer-share-wrapper
		}
		// Recipe Chef
		if ( $rcp_author_info_display !== 'disable' ) {
			$rcp_user_info 	 = get_userdata( $rcp_post_author_id );
			$rcp_user_avatar = rcp_get_avatar( $rcp_post_author_id , 100 );
			$rcp_user_url  	 = $rcp_user_info->user_url;
			$rcp_user_position = get_user_meta( $rcp_post_author_id , 'position', true );
			$rcp_user_desc 	 = get_user_meta( $rcp_post_author_id , 'description', true );
			$rcp_user_link	= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) );
			if ( get_the_author_meta( 'description' ) != '' ) {
				echo '<div class="rcp-chef-wrapper">';
				echo '<div class="rcp-chef_thumb">';
				echo $rcp_user_avatar;
				echo '</div>';//.rcp-wg__chef_thumb
				echo '<div class="rcp-chef_info_more">';
				echo '<div class="rcp-chef_label">Recipe By</div>';
				echo '<h2 class="rcp-chef_name">' . $rcp_user_info->display_name;
				if ( ! empty( $rcp_user_position ) ) {
					echo '<span>' . $rcp_user_position . '</span>';
				}
				echo '</h2>';
				if ( $rcp_user_desc ) {
					echo wpautop( $rcp_user_desc );
				}
				echo '</div>';//.rcp__info
				echo '</div>';//.rcp-wg-chef-wrapper
			}
		}

		// More Recipes From this Categories
		// ob_start();
		if ( rcp_get_option( 'rcp_more_recipe_categories' ) !== 'disable' ) {
			echo rcp_get_single_more_categories( $post_id, $taxonomy_name = 'recipe_cat' );
		}
		echo rcp_comments_list( $post_id );
		// echo ob_get_clean();
		echo '</div>'; //.rcp-main-panel
	}
}
/**
 * function rcp_registration_validation()
 * registration validation
 **/
if ( ! function_exists( 'rcp_registration_validation' ) ) {
	function rcp_registration_validation( $username, $email, $reg_captcha ) {
		global $reg_errors;
		$reg_errors = new WP_Error;
		$errors = array();
		if ( empty( $username ) || empty( $email ) ) {
			$reg_errors->add( 'field', esc_html__( 'All fields are required to register.','cookpro_textdomain' ) );
		}

		if ( ! empty( $username ) ) {
			if ( ! empty( $username ) && 5 > strlen( $username ) ) {
				$reg_errors->add( 'username_length', esc_html__( 'That username is too short; at least 4 characters is required.', 'cookpro_textdomain' ) );
			}
			if ( ! empty( $username ) && username_exists( $username ) ) {
		    	$reg_errors->add( 'user_name', esc_html__( 'That username already exists.','cookpro_textdomain' ) );
		    }
		    if ( ! empty( $username ) && ( ! validate_username( $username ) ) ) {
			    $reg_errors->add( 'username_invalid', esc_html__( 'That username is not valid.' . $username, 'cookpro_textdomain' ) );
			}
		}
	    if ( ! empty( $email ) && ! is_email( $email ) ) {
		    $reg_errors->add( 'email_invalid', esc_html__( 'That email address is not valid.', 'cookpro_textdomain' ) );
		}
		if ( ! empty( $email ) && email_exists( $email ) ) {
		    $reg_errors->add( 'email', esc_html__( 'That email is already in use.', 'cookpro_textdomain' ) );
		}
		$rcp_secret_key 	 = rcp_get_option( 'rcp_google_api_secret_key' ) ? rcp_get_option( 'rcp_google_api_secret_key' ) : '6LcBgBQUAAAAAPsh-jvaYi7n3vbGUY10psO8vxbL';
		if ( isset( $rcp_secret_key ) && empty( $reg_captcha ) ) {
			$reg_errors->add( 'field', esc_html__( 'Click on the reCAPTCHA box.','cookpro_textdomain' ) );
		}
		if ( ! empty( $reg_captcha ) ) {
	 		$rcp_verify_response = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $rcp_secret_key . '&response=' . $_POST['g-recaptcha-response'] );
			$rcp_response_data 	 = json_decode( $rcp_verify_response );
			if ( $rcp_response_data->success ) {
			} else {
				$reg_errors->add( 'field', esc_html__( 'Robot verification failed, please try again.','cookpro_textdomain' ) );
			}
		}
		if ( is_wp_error( $reg_errors ) ) {
			foreach ( $reg_errors->get_error_messages() as $error ) {
				$errors[] = $error;
		    }
		}
		return $errors;
	}
}
/**
 * function rcp_sui_process_image()
 * uploaded image set to featured image
 **/
if ( ! function_exists( 'rcp_sui_process_image' ) ) {
	function rcp_sui_process_image( $file, $post_id, $caption ) {
		require_once( ABSPATH . "wp-admin" . '/includes/image.php' );
		require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
		require_once( ABSPATH . "wp-admin" . '/includes/media.php' );

		$attachment_id = media_handle_upload( $file, $post_id );

		update_post_meta( $post_id, '_thumbnail_id', $attachment_id );
		set_post_thumbnail( $post_id, $attachment_id );

		$attachment_data = array(
			'ID' => $attachment_id,
			'post_excerpt' => $caption
		);
		wp_update_post( $attachment_data );
		return $attachment_id;
	}
}
/**
 * function rcp_submit_form_validation()
 * submit form validation
 **/
if ( ! function_exists( 'rcp_submit_form_validation' ) ) {
	function rcp_submit_form_validation( $rcp_id, $rcp_title, $rcp_sub_title, $rcp_desc, $rcp_servings, $rcp_diff_level, $rcp_categories, $rcp_prep_hrs, $rcp_prep_mns, $rcp_cook_hrs, $rcp_cook_mns, $rcp_ingredients, $rcp_steps, $rcp_upload_img, $rcp_captcha ) {

		global $rcp_submit_form_errors;
		$rcp_submit_form_errors = new WP_Error;
		$errors = array();
		if ( empty( $rcp_title ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Recipe Title.','cookpro_textdomain' ) );
		}
		if ( empty( $rcp_desc ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Recipe Description.','cookpro_textdomain' ) );
		}
		if ( empty( $rcp_servings ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Servings','cookpro_textdomain' ) );
		}
		if ( empty( $rcp_diff_level ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Select Difficulty Level','cookpro_textdomain' ) );
		}
		if ( empty( $rcp_categories ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Select Categories','cookpro_textdomain' ) );
		}
		if ( !isset( $rcp_prep_hrs ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Preparation Time in hours','cookpro_textdomain' ) );
		}
		if ( !isset( $rcp_prep_mns ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Preparation Time in minutes','cookpro_textdomain' ) );
		}
		if ( !isset( $rcp_cook_hrs ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Cooking Time in hours','cookpro_textdomain' ) );
		}
		if ( !isset( $rcp_cook_mns ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Cooking Time in minutes','cookpro_textdomain' ) );
		}
		if ( empty( $rcp_ingredients ) ) {
			$rcp_submit_form_errors->add( 'field', esc_html__( 'Enter Recipe Ingredirens.','cookpro_textdomain' ) );
		}
		if ( !isset( $rcp_id ) ) {
			if ( empty( $_FILES['rcp_upload_img']['name'] ) ) {
				$rcp_submit_form_errors->add( 'field', esc_html__( 'Upload Recipe Image.','cookpro_textdomain' ) );
			}
		}
		if ( ! empty( $_FILES['rcp_upload_img']['name'] ) ) {
			$filename = $_FILES['rcp_upload_img']['name'];
			$result = rcp_sui_parse_file_errors( $_FILES['rcp_upload_img'], $filename, $filesize = 200000, $file_size_limit = '195kb' );
			if ( $result['error'] ){
				$rcp_submit_form_errors->add( 'field', $result['error'] );
			}
		}

		if ( !isset( $rcp_id ) ) {
			if ( empty( $rcp_captcha ) ) {
				$rcp_submit_form_errors->add( 'field', esc_html__( 'Click on the reCAPTCHA box.','cookpro_textdomain' ) );
			}
			if ( ! empty( $rcp_captcha ) ){
				$rcp_secret_key 	 = rcp_get_option( 'rcp_google_api_secret_key' ) ? rcp_get_option( 'rcp_google_api_secret_key' ) : '';
		 		$rcp_verify_response = @file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $rcp_secret_key . '&response=' . $_POST['g-recaptcha-response'] );
				$rcp_response_data 	 = json_decode( $rcp_verify_response );
				if( !empty( $rcp_response_data ) ) {
					if ( $rcp_response_data->success ) {
					} else {
						$rcp_submit_form_errors->add( 'field', esc_html__( 'Robot verification failed, please try again.','cookpro_textdomain' ) );
					}
				}
			}
		}
		if ( is_wp_error( $rcp_submit_form_errors ) ) {
			foreach ( $rcp_submit_form_errors->get_error_messages() as $error ) {
				$errors[] = $error;
		    }
		}
		return $errors;
	}
}
/**
 * function rcp_sui_parse_file_errors()
 * image validation
 **/
if ( ! function_exists( 'rcp_sui_parse_file_errors' ) ) {
	function rcp_sui_parse_file_errors( $file = '', $image_caption, $filesize, $file_size_limit ) {
		define( 'MAX_UPLOAD_SIZE', $filesize );
		define( 'TYPE_WHITELIST', serialize( array(
			'image/jpeg',
			'image/png',
			'image/jpg'
		) ) );
		$result = array();
		$result['error'] = 0;
		if ( $file['error'] ) {
			$result['error'] = esc_html__( 'No file uploaded or there was an upload error!','cookpro_textdomain' );
			return $result;
		}
		$image_caption = trim( preg_replace('/[^a-zA-Z0-9\s]+/', ' ', $image_caption) );

		$result['caption'] = $image_caption;
		$image_data = getimagesize( $file['tmp_name'] );
		if ( ! in_array( $image_data['mime'], unserialize( TYPE_WHITELIST ) ) ) {
			$result['error'] = esc_html__( 'Your image must be a jpeg, png or jpg!','cookpro_textdomain' );
		} elseif( ( $file['size'] > MAX_UPLOAD_SIZE ) ) {
			$result['error'] =  sprintf( esc_html__( 'Your image was %s bytes! It must not exceed %s.' , 'cookpro_textdomain' ), $file['size'], $file_size_limit );
		}

		return $result;
	}
}
/**
 * function rcp_get_page_id()
 * returns page id
 **/
if ( ! function_exists( 'rcp_get_page_id' ) ) {
	function rcp_get_page_id( $key = null ) {
		if ( $key != null ) {
			$rcp_page_id = get_option( $key ) ? get_option(  $key ) : false;
			return $rcp_page_id;
		}
		return false;
	}
}
/**
 * function rcp_desc_max_charlength()
 * description length
 **/
if ( ! function_exists( 'rcp_desc_max_charlength' ) ) {
	function rcp_desc_max_charlength( $desc , $charlength ) {
		$excerpt = $desc;
		$charlength++;
		if ( mb_strlen( $excerpt ) > $charlength ) {
			$subex = mb_substr( $excerpt, 0, $charlength - 5 );
			$exwords = explode( ' ', $subex );
			$excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
			if ( $excut < 0 ) {
				return mb_substr( $subex, 0, $excut );
			} else {
				return $subex;
			}
			return '[...]';
		} else {
			return $excerpt;
		}
	}
}
/**
 * function rcp_get_single_more_categories()
 * related recipes
 **/
if ( ! function_exists( 'rcp_get_single_more_categories' ) ) {
	function rcp_get_single_more_categories( $post_id, $taxonomy_name ) {
		$out = '';
		$out .= '<div class="rcp__related-posts">';
		$out .= '<h3 class="rcp__rposts-title">' . esc_html__( 'You May also Like', 'cookpro_textdomain' ) . '</h3>';
		$rcp_termcat = array();
		$rcp_cat_terms = get_the_terms( $post_id, $taxonomy_name );
		if ( $rcp_cat_terms && ! is_wp_error( $rcp_cat_terms ) ) {
			foreach ( $rcp_cat_terms as $term ) {
				$rcp_termcat[] = $term->slug;
			}
		}
		// Columns for Recipe Thumbs
		$column_index = 0;

		if( $taxonomy_name == 'recipe_cat' ){
			$limit   = rcp_get_option( 'rcp_single_cat_limit','4' );
			$orderby = rcp_get_option( 'rcp_single_cat_orderby','ID' );
			$order 	 = rcp_get_option( 'rcp_single_cat_order','ASC' );
			$columns = rcp_get_option( 'rcp_single_cat_columns','4' );
		}
		if ( $columns == '3' ) { $class = 'item3'; }
		if ( $columns == '2' ) { $class = 'item2'; }
		$args = array(
			'post_type' => 'recipe',
			'tax_query' => array(
					array(
						'taxonomy' => $taxonomy_name,
						'field' => 'slug',
						'terms' => $rcp_termcat,
					),
			),
			'post_status' => 'publish',
			'posts_per_page' => $limit,
			'post__not_in'	=> array( $post_id ),
			'order' => $order,
			'orderby' => $orderby
		);
		$rcp_cat_query = new WP_Query( $args );

		if ( $rcp_cat_query->have_posts() ) : while ( $rcp_cat_query->have_posts() )  :  $rcp_cat_query->the_post();

			$column_index++;
			$rcp_cat_post_id = get_the_ID();
			$rcp_short_info  		= get_post_meta( $rcp_cat_post_id, 'recipe_short_info', true );
			$rcp_servings 			= get_post_meta( $rcp_cat_post_id, 'recipe_servings', true );
			$rcp_cook_time  		= rcp_get_time( $rcp_cat_post_id ,'recipe_ctime' );
			$rcp_diff_level   		= get_post_meta( $rcp_cat_post_id, 'recipe_diff_level', true );
			$rcp_post_author_id 	= get_post_field ('post_author', $rcp_cat_post_id );
			$rcp_user_info 	 		= get_userdata( $rcp_post_author_id );
			$rcp_user_link			= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $rcp_user_info->user_login ;
			$rcp_meta_section       = rcp_get_option('rcp_meta_section_display','enable');

			$hide_cooktime  = rcp_get_option('rcp_hide_cooktime','no');
			$hide_difflevel = rcp_get_option('rcp_hide_difflevel', 'no');
			$hide_yields  	= rcp_get_option('rcp_hide_yields','no');
			$hide_ratings  	= rcp_get_option('rcp_hide_ratings','no');
			$hide_author  	= get_option( 'rcp_hide_author_name' ) ? get_option( 'rcp_hide_author_name' ) : get_option( 'rcp_hide_author' );
			$display_style  = rcp_get_option('rcp_display_style','style1');

			$out .= '<div class="rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
			$out .= rcp_results_data( $rcp_cat_post_id, $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
			$out .= '</div>'; //.rcp-post-item

			if ( $column_index == $columns ) {
				$column_index = 0;
			}
		endwhile;
			else :
			$out .= '<p>' . esc_html__( 'Sorry, No related recipes found.', 'cookpro_textdomain' ).'</p>';
		endif;
		wp_reset_query();
		$out .= '</div>'; // .container

		return $out;
	}
}
// Recipes
function rcp_results_data( $rcp_post_id, $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style ){
	$rcp_short_info  	= get_post_meta( $rcp_post_id, 'recipe_short_info', true );
	$rcp_servings 		= get_post_meta( $rcp_post_id, 'recipe_servings', true );
	$rcp_cook_time  	= rcp_get_time( $rcp_post_id ,'recipe_ctime' );
	$rcp_diff_level   	= get_post_meta( $rcp_post_id, 'recipe_diff_level', true );
	$rcp_fav_count 		= get_post_meta( $rcp_post_id, 'rcp_post_favorite', true );
	$rcp_view_count 	= get_post_meta( $rcp_post_id, 'rcp_post_views', true );
	$total_comments 	= get_comments( array( 'post_id' => $rcp_post_id, 'status' => 'approve' ) );
	$rcp_comment_count 	= ceil( count( $total_comments ) );
	$rcp_post_author_id = get_post_field( 'post_author', $rcp_post_id );
	$rcp_user_info 	 	= get_userdata( $rcp_post_author_id );
	$rcp_user_link		= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $rcp_user_info->user_login ;
	$rcp_user_avatar 	= get_avatar( $rcp_post_author_id, 20 );
	$rcp_meta_section   = rcp_get_option('rcp_meta_section_display','enable');
	$hide_author        = rcp_get_option( 'rcp_hide_author_name', 'no' );
	$hover_class = $out = '';
	$hide_ratings = get_option('rcp_hide_ratings') ?  get_option('rcp_hide_ratings') : $hide_ratings;
	if( $display_style == 'style1' ){
		$out .= '<div class="rcp__item">';
		$out .= '<div class="rcp__item_img hover_dots">';
		if ( has_post_thumbnail( $rcp_post_id ) ) {
			$out .= get_the_post_thumbnail( $rcp_post_id, 'rcp_post_image', '' );
		} else {
			$out .= '<img src="' . RECIPE_IMG_URI . '/no_image.jpg" alt="img"/>';
		}
		$out .= '<div class="rcp__mask"></div>';
		$out .= '<a href="' . esc_url( get_permalink( $rcp_post_id ) ) . '" title="' . get_the_title( $rcp_post_id ) . '" class="rcp__icons">';
		$out .= '<span></span><span></span><span></span><span></span><span></span>';
		$out .= '</a>';
		if ( 'yes' !== $hide_ratings ) {
			$out .= '<div class="rcp__item_rating">' . rcp_get_post_ratings( $rcp_post_id ) . '</div>' ;
		}
		$out .= '</div>'; //.rcp__item_img
		$out .= '<div class="rcp__item_detail">';
		$out .= '<h2 class="title"><a href="' . esc_url( get_permalink( $rcp_post_id ) ) . '">' . get_the_title( $rcp_post_id ) . '</a></h2>';
		if ( 'yes' !== $hide_author ) {
			$out .= '<div class="rcp__item_chef">' . esc_html__( 'by', 'cookpro_textdomain' ) . '&nbsp;<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . ucfirst( get_the_author() ) . '</a></div>';
		}
		$out .= '</div>'; //.rcp__item_detail

		if( $rcp_meta_section !== 'disable' ){
			if ( 'yes' !== $hide_cooktime || 'yes' !== $hide_difflevel || 'yes' !== $hide_yields ) {
				$out .= '<div class="rcp__item_footer">';
				$out .= '<ul>';
				if ( 'yes' !== $hide_cooktime ) {
					if ( ! empty( $rcp_cook_time ) ) {
						$out .= '<li><strong>' . esc_html__( 'To cook', 'cookpro_textdomain' ) . '</strong> ' . $rcp_cook_time . '</li>';
					}
				}
				if ( 'yes' !== $hide_difflevel ) {
					if ( ! empty( $rcp_diff_level ) ) {
						$out .= '<li><strong>' . esc_html__( 'Level', 'cookpro_textdomain' ) . '</strong>' . ucfirst( $rcp_diff_level ) . '</li>';
					}
				}
				if ( 'yes' !== $hide_yields ) {
					if ( ! empty( $rcp_servings ) ) {
						$out .= '<li><strong>' . esc_html__( 'Servings', 'cookpro_textdomain' ) . '</strong>' . $rcp_servings . '</li>';
					}
				}
				$out .= '</ul>';
				$out .= '</div>';//.rcp__item_footer
			}
		}
		$out .= '</div>'; //.rcp__item
	}
	if( $display_style == 'style2' ){
		$out .= '<div class="rcp__item">';
		$out .= '<div class="rcp__item_img">';
		if ( has_post_thumbnail( $rcp_post_id ) ) {
			$out .= '<a  class="rcp__llink" href="' . esc_url( get_permalink( $rcp_post_id ) ) . '">'. get_the_post_thumbnail( $rcp_post_id, 'rcp_medium_square', '' ) . '</a>';
		} else {
			$out .= '<img src="' . RECIPE_IMG_URI . '/no_image.jpg" alt=""/>';
		}
		$out .= '<a  class="rcp__lhover" href="' . esc_url( get_permalink( $rcp_post_id ) ) . '"><strong>' . get_the_title( $rcp_post_id ) . '</strong><em class="rcp_timestamp">';
		$out .= get_the_date();
		$out .= '</em></a>';
		if ( 'yes' !== $hide_ratings ) {
			$out .= '<div class="rcp__item_rating">' . rcp_get_post_ratings( $rcp_post_id ) . '</div>' ;
		}
		$out .= '</div>'; //.rcp__item_img

		$out .= '<ul class="rcp__item_info">';
		$out .= '<li><i class="aicon_heart"></i> ' . $rcp_fav_count . '</li>';
		$out .= '<li><i class="aicon_comment"></i> ' . $rcp_comment_count . '</li>';
		$out .= '<li><i class="aicon_view"></i> ' . $rcp_view_count . '</li>';
		$out .= '</ul>';
		$out .= '</div>'; //.rcp__item
		if ( 'yes' !== $hide_author ) {
			$out .= '<h2 class="rcp_lauthor">';
			$out .= '<span class="rcp_luser">';
			$out .= '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' .$rcp_user_avatar . ucfirst( get_the_author() ) . '</a>	';
			$out .= '</span>';//.rcp_luser
			$out .= '</h2>'; //.rcp_lauthor
		}
	}
	return $out;
}
// post tags support
function recipe_cpt_custom_tags( $query ) {
    if ( $query->is_tag() && $query->is_main_query() ) {
        $query->set( 'post_type', array( 'recipe' ) );
    }
}
add_action( 'pre_get_posts', 'recipe_cpt_custom_tags' );
/**
 * function epicer_pagination()
 */
if ( ! function_exists( 'rcp_pagination' ) ) :
	/**
	* Display navigation to next/previous set of posts when applicable.
	*
	* @since hopes 1.0
	*/
	function rcp_pagination() {

		// Don't print empty markup if there's only one page.
		if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
			return;
		}
		// var_dump( 'dd');
		$out = '';
		$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts    = explode( '?', $pagenum_link );
		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

		$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

		// Set up paginated links.
		$links = paginate_links( array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $GLOBALS['wp_query']->max_num_pages,
			'current'  => $paged,
			'mid_size' => 1,
			'add_args' => array_map( 'urlencode', $query_args ),
			'prev_text' => '<i class="fa fa-angle-left fa-fw"></i>' . esc_html__( 'Previous', 'cookpro_textdomain' ),
			'next_text' => esc_html__( 'Next', 'cookpro_textdomain' ) . '<i class="fa fa-angle-right fa-fw"></i>',
		) );

		if ( $links ) {
			$out = '<nav class="navigation paging-navigation">';
			$out .= '<div class="pagination loop-pagination">';
			$out .= $links;
			$out .= '</div>';
			$out .= '</nav>';
		}
		echo $out;
		// echo wp_kses_post( $out );
	}
endif;
// check for plugin using plugin name
global $rcp_plugin_activated;
$rcp_plugin_activated = false;
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {
	//plugin is activated
	$rcp_plugin_activated = true;
}
