<?php
class Rcp_Post_Like {
	function __construct() {
		// Enqueues the scripts.
		add_action( 'wp_enqueue_scripts', array( &$this, 'rcp_enqueue_scripts' ) );

		// Handle the request
		add_action( 'wp_ajax_rcp_like_ajax_action', array( &$this, 'rcp_ajax_like' ) );
		add_action( 'wp_ajax_nopriv_rcp_like_ajax_action', array( &$this, 'rcp_ajax_like' ) );

		add_action( 'wp_ajax_rcp_favorite_ajax_action', array( &$this, 'rcp_ajax_favorite' ) );
		add_action( 'wp_ajax_nopriv_rcp_favorite_ajax_action', array( &$this, 'rcp_ajax_favorite' ) );
	}
	/**
	 * function recipe_enqueue_scripts()
	 *
	 * enqueues the scripts.
	 * @uses wp_enqueue_script()
	 */
	function rcp_enqueue_scripts() {
		// In javascript, object properties are accessed as ajax_object.ajax_url
		wp_localize_script( 'jquery', 'rcp_post_like_localize', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'youLikedit' => esc_html__( 'You already liked it!', 'cookpro_textdomain' ),
		));
		wp_localize_script( 'jquery', 'rcp_post_favorite_localize', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'youFavoritedit' => esc_html__( 'You already favourite it!', 'cookpro_textdomain' ),
		));
	}
	/**
	 *
	 * Handle request then generate response using WP_Ajax_Response
	 *
	 */
	function rcp_ajax_like( $post_id ) {

		$likes_id = sanitize_text_field( $_POST['likes_id'] );
		// Update
		if ( isset( $likes_id ) ) {
			$post_id = str_replace( 'rcp-like-', '', $likes_id );
			echo wp_kses_post( $this->rcp_like_post( $post_id, 'update' ) );
		} else {
			echo $post_id = str_replace( 'rcp-like-', '', $likes_id );
			echo wp_kses_post( $this->rcp_like_post( $post_id, 'get' ) );
		}

		exit;
	}
	function rcp_ajax_favorite( $post_id ) {

		$favorite_id = sanitize_text_field( $_POST['favorite_id'] );
		// Update
		if ( isset( $favorite_id ) ) {
			$post_id = str_replace( 'rcp-favorite-', '', $favorite_id );
			echo wp_kses_post( $this->rcp_favorite_post( $post_id, 'update' ) );
		} else {
			echo $post_id = str_replace( 'rcp-favorite-', '', $favorite_id );
			echo wp_kses_post( $this->rcp_favorite_post( $post_id, 'get' ) );
		}

		exit;
	}

	function rcp_favorite_post( $post_id, $action = 'get' ) {
		if ( ! is_numeric( $post_id ) ) { return; }
		$current_user = wp_get_current_user();
		$user_id = $current_user->ID;

		switch ( $action ) {
			case 'get':
				$love_count = get_post_meta( $post_id, 'rcp_post_favorite', true );
				if ( ! $love_count ) {
					$love_count = 0;
					add_post_meta( $post_id, 'rcp_post_favorite', $love_count, true );
				}
				return '<span class="rcp-favorite-count">' . $love_count . ' </span>';
				break;

			case 'update':

				$love_count = get_post_meta( $post_id, 'rcp_post_favorite', true );
				if ( isset( $_COOKIE[ 'rcp_favorite_' . $post_id ] ) ) { return $love_count; }

				$love_count++;
				update_post_meta( $post_id, 'rcp_post_favorite', $love_count );

				if ( $user_id ) {
					$user_likes = get_user_meta( $user_id, 'recipe_love', true );
					$user_likes[] = $post_id;
					update_user_meta( $user_id, 'recipe_love', $user_likes );
				}

				setcookie( 'rcp_favorite_' . $post_id, $post_id, time() * 20, '/' );

				return '<span class="rcp-favorite-count">' . $love_count . ' </span>';
				break;
		}
	}
	function rcp_like_post( $post_id, $action = 'get' ) {
		if ( ! is_numeric( $post_id ) ) {
			return;
		}
		$current_user = wp_get_current_user();
		$user_id = $current_user->ID;

		switch ( $action ) {
			case 'get':
				$like_count = get_post_meta( $post_id, 'rcp_post_like', true );
				if ( ! $like_count ) {
					$like_count = 0;
					add_post_meta( $post_id, 'rcp_post_like', $like_count, true );
				}

				return '<span class="rcp-like-count">' . $like_count . '</span>';
				break;

			case 'update':

				$like_count = get_post_meta( $post_id, 'rcp_post_like', true );
				if ( isset( $_COOKIE[ 'rcp_like_' . $post_id ] ) ) { return $like_count; }

				$like_count++;
				update_post_meta( $post_id, 'rcp_post_like', $like_count );
				setcookie( 'rcp_like_' . $post_id, $post_id, time() * 20, '/' );

				return '<span class="rcp-like-count">' . $like_count . '</span>';
				break;
		}
	}

	function rcp_add_favorite() {
		global $post;

		$output = $this->rcp_favorite_post( $post->ID );
		$class = 'rcp-post-favorite';
		$title = esc_html__( 'Add to Favorite', 'cookpro_textdomain' );
		if ( isset( $_COOKIE[ 'rcp_favorite_' . $post->ID ] ) ) {
			$class = 'rcp-post-favorite favorited';
			$title = esc_html__( 'You already favorited this!', 'cookpro_textdomain' );
			return $output . ' <i class="fa fa-heart fa-lg"></i>';
		}
		if ( is_user_logged_in() ) {
			return '<a href="#" class="' . $class . '" id="rcp-favorite-' . $post->ID . '" title="' . $title . '">' . $output . ' <i class="fa fa-heart fa-lg"></i></a>';
		} else {
			return '<a href="' . get_permalink( get_option( 'rcp_login_page_id' ) ) . '" title="' . esc_html__( 'Login to add favorite', 'cookpro_textdomain' ) . '"> ' . $output . '<i class="fa fa-heart fa-lg"></i></a>';
		}
	}
	function rcp_add_like() {
		global $post;

		$output = $this->rcp_like_post( $post->ID );
		$class = 'rcp-post-like';
		$title = esc_html__( 'Like this','cookpro_textdomain' );
		if ( isset( $_COOKIE[ 'rcp_like_' . $post->ID ] ) ) {
			$class = 'rcp-post-like liked';
			$title = esc_html__( 'You already like this!','cookpro_textdomain' );
		}
		return '<a href="#" class="' . $class . '" id="rcp-like-' . $post->ID . '" title="' . $title . '"><i class="fa fa-thumbs-o-up fa-lg"></i> ' . $output . '</a>';
	}
}

$rcp_post_like = new Rcp_Post_Like();

function rcp_get_favorites( $post_id ) {
	$love_count = get_post_meta( $post_id, 'rcp_post_favorite', true );
	return '<span class="rcp-favorite-count">' . $love_count . ' </span><i class="fa fa-heart"></i>';
}

// get the ball rollin'
function rcp_post_like( $recipe_like = '' ) {
	global $rcp_post_like;
	if ( $recipe_like == 'rcp_like' ) {
		return $rcp_post_like->rcp_add_like();
	} else {
		echo wp_kses_post( $rcp_post_like->rcp_add_like() );
	}
}
// get the ball rollin'
function rcp_post_favorite( $recipe_favorite = '' ) {
	global $rcp_post_like;
	if ( $recipe_favorite == 'rcp_favorite' ) {
		return $rcp_post_like->rcp_add_favorite();
	} else {
		echo wp_kses_post( $rcp_post_like->rcp_add_favorite() );
	}
}

add_action( 'wp_ajax_rcp_rem_favorite_ajax_action', 'rcp_rem_favorite' );
add_action( 'wp_ajax_nopriv_rcp_favorite_ajax_action', 'rcp_rem_favorite' );
function rcp_rem_favorite() {
	$post_id = sanitize_text_field( $_POST['postid'] );
	$user_id = sanitize_text_field( $_POST['userid'] );
	$rcp_fav_count = get_post_meta( $post_id, 'rcp_post_favorite', true );
	if ( ! empty( $rcp_fav_count ) ) {
		$rcp_fav_count--;
		$rcp_user_favorite_postids = get_user_meta( $user_id, 'recipe_love', true );
		if ( is_array( $rcp_user_favorite_postids ) ) {
			foreach ( array_keys( $rcp_user_favorite_postids, $post_id ) as $key ) {
				unset( $rcp_user_favorite_postids[$key] );
			}
		}
		update_user_meta( $user_id, 'recipe_love', $rcp_user_favorite_postids );
		echo esc_html__( 'Removed recipe from your favorites', 'cookpro_textdomain' );
	}
	exit;
}
