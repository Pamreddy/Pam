
<!-- Print Page template for Cook Pro -->
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php bloginfo( 'name' ); ?> <?php wp_title(); ?></title>
	<meta http-equiv="Content-Type" content="<?php bloginfo( 'html_type' ); ?>; charset=<?php bloginfo( 'charset' ); ?>" />
	<link rel="stylesheet" href="<?php echo esc_url( RECIPE_URI . '/assets/css/rcp-print-style.css' ); ?>" type="text/css" media="screen, print" />
</head>
<body>
	<main role="main" class="center">
		<?php
		the_post();
		global $post;
		$rcp_post_id = get_the_ID();
		$rcp_print_page_logo 			= rcp_get_option( 'rcp_print_page_logo' );
		$rcp_copyright_section 			= rcp_get_option( 'rcp_print_copy_right_section' );
		$rcp_print_logo_display 		= rcp_get_option( 'rcp_print_logo_display','enable' );
		$rcp_print_image_display 		= rcp_get_option( 'rcp_print_image_display','enable' );
		$rcp_print_steps_display 		= rcp_get_option( 'rcp_print_steps_display','enable' );
		$rcp_equipments_display 		= rcp_get_option( 'rcp_equipments_display','enable' );
		$rcp_print_copy_right_display 	= rcp_get_option( 'rcp_print_copy_right_display','enable' );
		$rcp_sub_title = get_post_meta( $rcp_post_id, 'recipe_sub_title', true );

		echo '<div class="container">';
		echo '<div class="rpc-print-wrapper">';
		echo '<div class="rcp-print-header">';
		if ( 'disable' !== $rcp_print_logo_display ) {
			echo '<div class="rcp-print__logo">';
			if ( ! empty( $rcp_print_page_logo ) ) {
				$attachment_id = rcp_get_attachment_id_from_src( $rcp_print_page_logo );
				echo wp_get_attachment_image( $attachment_id,  array( '200', '100' ), '', '' );
			} else {
				echo '<img src="' . esc_url( RECIPE_URI . '/assets/images/print_logo.jpg' ) . '" alt="img"/>';
			}
			echo '</div>'; //.rcp-print__logo
		}
		echo '</div>'; //.rcp-print__logo
		echo '<div class="rcp-print-main">';
		echo '<h2 class="rcp-print__title">' . get_the_title( $rcp_post_id ) . '</h2>';
		echo '<span class="rcp-print__subheading">' . esc_html( $rcp_sub_title ) . '</span>';
		echo '<div class="rcp-print__content">';
		if ( 'disable' !== $rcp_print_image_display ) {
			echo '<div class="rcp-print__image">';
			echo rcp_post_thumbnail( $rcp_post_id );
			echo '</div>';
		}
		echo '<div class="rcp-print__details">';
		$rcp_nutritions = get_post_meta( $rcp_post_id, 'recipe_nutritions', true );
		if ( ! empty( $rcp_nutritions ) ) {
			if ( array_key_exists( 'print' , $wp_query->query_vars ) ) {
				echo '<h3>' . esc_html__( 'Nutrition', 'cookpro_textdomain' ) . '<span>' . esc_html__( 'Per Serving', 'cookpro_textdomain' ) . '</span></h3>';
			} else {
				echo '<span>' . esc_html__( 'Per Serving*','cookpro_textdomain' ) . '</span>';
			}
			echo '<div class="rcp__ingrdnt-nutri">';
			echo '<ul class="rcp__nutrition">';
			foreach ( $rcp_nutritions as $key => $data ) {
				echo '<li> ' . $data['name'] . '<span> ' . $data['value']. '</span></li>';
			}
			echo '</ul>';
			$rcp_nutrition_info = rcp_get_option( 'rcp_nutrition_info' );
			if ( ! empty( $rcp_nutrition_info ) ) {
				echo '<p>' . esc_textarea( $rcp_nutrition_info ) . '</p>';
			}
			echo '</div>';
		}
		echo rcp_meta_details( $rcp_post_id );
		echo '</div>'; //.rcp-print__details
		echo '</div>'; //.rcp-print__content
		echo '</div>'; //.rcp-print-main

		// Ingredients
		echo '<div class="rcp-print-ingrdient">';
		echo rcp_ingredient_list( $rcp_post_id );
		echo '</div>';

		// Steps
		if ( 'disable' !== $rcp_print_steps_display ) {
			echo '<div class="rcp-print-steps">';
			$rcp_steps = get_post_meta( $rcp_post_id, 'recipe_steps', true );
			if ( ! empty( $rcp_steps) ) {
				echo '<h3 class="rcp__steps-title">' . esc_html__( 'Method','cookpro_textdomain' ) . '</h3>';
				echo '<ul class="rcp-print__steps">';
				$list = explode( PHP_EOL, trim( $rcp_steps ) );
				foreach ( $list as $key => $data ) {
					if ( preg_match('/^\s*\-{2}([^~]+)(~([^~]+)~)/', $data, $matches ) && ( strpos( $data, '~' ) !== false ) ) {
						echo '<li>';
						echo '<div class="rcp__step-numdur">';
					    echo '<div class="rcp__step-number">' . $matches[1] . '</div>';
					    echo '<div class="rcp__step-duration">' . $matches[3] . '</div>';
						echo '</div>';
					} else {
					    //replacing data with span tags around it
					    echo $data = str_replace( $data, '<div class="rcp__step-decription">' . $data . '</div>', $data );
						echo '</li>';
					}
				}
				echo '</ul>'; //.rcp__steps
			}
			echo '</div>';
		}
		if ( 'disable' !== $rcp_equipments_display ) {
			$rcp_equipments = get_post_meta( $rcp_post_id, 'recipe_equipments', true );
			if ( ! empty( $rcp_equipments ) ) {
				echo rcp_equiments_list( $rcp_post_id );
			}
		}
		// Copy right
		if ( 'disable' !== $rcp_print_copy_right_display ) {
			echo '<div class="rcp-print-footer">';
			if ( ! empty( $rcp_copyright_section ) ) {
				echo $rcp_copyright_section;
			} else {
				echo esc_html__( 'All rights reserved. Designed by AivahThemes', 'cookpro_textdomain' );
			}
			echo '</div>'; // rcp-print-footer
		}
		echo '</div>'; // rpc-print-wrapper
		echo '</div>'; //.container
		?>
	</main>
</body>
</html>
<?php
