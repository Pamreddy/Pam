<?php
// Comment template
add_filter( 'comments_template', 'rcp_no_default_comments' );
add_filter( 'comment_form_default_fields', 'rcp_comment_fields' );
// if ( get_post_type() == 'recipe' ) {
	add_action( 'comment_form_logged_in_after', 'rcp_rating_fields' );
	add_action( 'comment_form_after_fields', 'rcp_rating_fields' );
	add_action( 'comment_post', 'rcp_save_comment_meta_data' );
// }

// User Profile Fields
add_action( 'show_user_profile', 'rcp_custom_user_profile_fields' );
add_action( 'edit_user_profile', 'rcp_custom_user_profile_fields' );
add_action( 'personal_options_update', 'rcp_save_custom_user_profile_fields' );
add_action( 'edit_user_profile_update', 'rcp_save_custom_user_profile_fields' );
// Adds Print var in wp_query
add_action( 'init', 'rcp_print_endpoint' );
add_filter( 'query_vars', 'rcp_print_variables' );
// Loads Print page
add_filter( 'template_redirect', 'rcp_print_page' );
// Load Single Recipe
add_filter( 'the_content', 'rcp_single_page_content' );
// Load More search recipes
add_action( 'wp_ajax_rcp_more_search_ajax', 'rcp_more_search_ajax' );
add_action( 'wp_ajax_nopriv_rcp_more_search_ajax', 'rcp_more_search_ajax' );
// Load more user recipes
add_action( 'wp_ajax_rcp_user_more_recps_ajax', 'rcp_user_more_recps_ajax' );
add_action( 'wp_ajax_nopriv_rcp_user_more_recps_ajax', 'rcp_user_more_recps_ajax' );
// Load more user reviews
add_action( 'wp_ajax_nopriv_rcp_user_more_reviews_ajax', 'rcp_user_more_reviews_ajax' );
add_action( 'wp_ajax_rcp_user_more_reviews_ajax', 'rcp_user_more_reviews_ajax' );
// Load more user favorites
add_action( 'wp_ajax_rcp_user_more_favorites_ajax', 'rcp_user_more_favorites_ajax' );
add_action( 'wp_ajax_nopriv_rcp_user_more_favorites_ajax', 'rcp_user_more_favorites_ajax' );
// Load more users-list
add_action( 'wp_ajax_rcp_more_users_ajax', 'rcp_more_users_ajax' );
add_action( 'wp_ajax_nopriv_rcp_more_users_ajax', 'rcp_more_users_ajax' );

// Load more users-list
add_action( 'wp_ajax_rcp_more_comments_ajax', 'rcp_more_comments_ajax' );
add_action( 'wp_ajax_nopriv_rcp_more_comments_ajax', 'rcp_more_comments_ajax' );

// Load more recent recipes in shortcode
add_action( 'wp_ajax_rcp_recent_sh_more_recps_ajax', 'rcp_recent_sh_more_recps_ajax' );
add_action( 'wp_ajax_nopriv_rcp_recent_sh_more_recps_ajax', 'rcp_recent_sh_more_recps_ajax' );

// Load more recipes by category,cuisine,method,ingredient based in shortcode
add_action( 'wp_ajax_rcp_sh_cat_more_ajax', 'rcp_sh_cat_more_ajax' );
add_action( 'wp_ajax_nopriv_rcp_sh_cat_more_ajax', 'rcp_sh_cat_more_ajax' );
// Load more highest rated recipes in shortcode
add_action( 'wp_ajax_rcp_highest_sh_more_recps_ajax', 'rcp_highest_sh_more_recps_ajax' );
add_action( 'wp_ajax_nopriv_rcp_highest_sh_more_recps_ajax', 'rcp_highest_sh_more_recps_ajax' );

 // Make Recipe as private or public
add_action( 'wp_ajax_rcp_status_ajax_action', 'rcp_status_ajax_action' );
add_action( 'wp_ajax_nopriv_rcp_status_ajax_action', 'rcp_status_ajax_action' );
//
add_action( 'wp_login_failed', 'rcp_fe_login_fail' );  // hook failed login
// Recipe steps upload actions
add_action( 'wp_ajax_rcp_step_upload_files', 'rcp_step_upload_files' );
add_action( 'wp_ajax_nopriv_rcp_step_upload_files', 'rcp_step_upload_files' ); // Allow front-end submission

// Settings Import
add_action( 'admin_init', 'rcp_settings_import' );
// Settings Export
add_action( 'admin_init', 'rcp_settings_export' );
add_action( 'wp_enqueue_scripts', 'rcp_skin_generator', 100 );

add_action( 'rcp_before_main_content', 'rcp_output_content_wrapper', 10 );
add_action( 'rcp_after_main_content', 'rcp_output_content_wrapper_end', 10 );
function rcp_output_content_wrapper() {
	$template = get_option( 'template' );
	switch ( $template ) {
		case 'twentyeleven' :
			echo '<div id="primary"><div id="content" role="main" class="twentyeleven">';
			break;
		case 'twentytwelve' :
			echo '<div id="primary" class="site-content"><div id="content" role="main" class="twentytwelve">';
			break;
		case 'cookprotheme' :
			echo '<div id="primary" class="site-content"><div id="content" role="main" class="twentytwelve">';
			break;
		case 'twentythirteen' :
			echo '<div id="primary" class="site-content"><div id="content" role="main" class="entry-content twentythirteen">';
			break;
		case 'twentyfourteen' :
			echo '<div id="primary" class="content-area"><div id="content" role="main" class="site-content twentyfourteen"><div class="tfwc">';
			break;
		case 'twentyfifteen' :
			echo '<div id="primary" role="main" class="content-area twentyfifteen"><div id="main" class="site-main t15wc">';
			break;
		case 'twentysixteen' :
			echo '<div id="primary" class="content-area twentysixteen"><main id="main" class="site-main" role="main">';
			break;
		default :
			echo '<div id="container"><div id="content" role="main">';
			break;
	}
}
function rcp_output_content_wrapper_end() {
	$template = get_option( 'template' );
	switch ( $template ) {
		case 'twentyeleven' :
			echo '</div>';
			get_sidebar( 'shop' );
			echo '</div>';
			break;
		case 'twentytwelve' :
			echo '</div></div>';
			break;
		case 'cookprotheme' :
			echo '</div></div>';
			break;
		case 'twentythirteen' :
			echo '</div></div>';
			break;
		case 'twentyfourteen' :
			echo '</div></div></div>';
			get_sidebar( 'content' );
			break;
		case 'twentyfifteen' :
			echo '</div></div>';
			break;
		case 'twentysixteen' :
			echo '</main></div>';
			break;
		default :
			echo '</div></div>';
			break;
	}
}
function rcp_skin_generator() {
	$rcp_option_var = array(
		'rcp_link_color',
		'rcp_btn_primary_txt_color',
		'rcp_btn_primary_bg_color',
		'rcp_btn_primary_hover_color',
		'rcp_btn_primary_hover_bg_color',
		'rcp_btn_secondary_txt_color',
		'rcp_btn_secondary_bg_color',
		'rcp_btn_secondaty_hover_color',
		'rcp_btn_secondaty_hover_bg_color',
	);

	foreach ( $rcp_option_var as $value ) {
		$$value = get_option( $value );
	}

	$custom_css =  $rcp_extracss = '';
	$link_color = isset( $rcp_link_color ) ? $rcp_link_color : '';
	if ( '' !== $link_color ) {
		$rcp_extracss = "
		.content-area a,
		.rcp__print-love a {
			color:{$link_color};
		}
	";
	}
	$custom_css .= $rcp_extracss;
	if ( isset( $rcp_btn_primary_hover_color ) && isset( $rcp_btn_primary_hover_bg_color ) ) {
		$custom_css .= rcp_gen_css_prop( array(
			'.rcp-btn-primary:hover',
			), array(
				'color' => $rcp_btn_primary_hover_color,
				'background-color' => $rcp_btn_primary_hover_bg_color,
			)
		);
	}
	if ( isset( $rcp_btn_primary_txt_color ) && isset( $rcp_btn_primary_bg_color ) ) {
		$custom_css .= rcp_gen_css_prop( array(
			'.rcp-btn-primary',
			), array(
				'color' => $rcp_btn_primary_txt_color,
				'background-color' => $rcp_btn_primary_bg_color,
			)
		);
	}
	if ( isset( $rcp_btn_secondary_hover_color ) && isset( $rcp_btn_secondary_hover_bg_color ) ) {
		$custom_css .= rcp_gen_css_prop( array(
			'.rcp-btn-secondary:hover',
			), array(
				'color' => $rcp_btn_secondary_hover_color,
				'background-color' => $rcp_btn_secondary_hover_bg_color,
			)
		);
	}
	if ( isset( $rcp_btn_secondary_txt_color ) && isset( $rcp_btn_secondary_bg_color ) ) {
		$custom_css .= rcp_gen_css_prop( array(
			'.rcp-btn-secondary',
			), array(
				'color' => $rcp_btn_secondary_txt_color,
				'background-color' => $rcp_btn_secondary_bg_color,
			)
		);
	}
	wp_add_inline_style( 'rcp-frontend-style', $custom_css );
}
function rcp_gen_css_prop( $selectors = null, $properties = null ) {
	$css = $inline_css = '';

	if ( is_array( $properties ) && ! empty( $properties ) ) {
		foreach ( $properties as $name => $value ) {
			if ( '' != $value ) {
				if ( 'font-family' === $name ) {
					$value = '"' . $value . '"';
				}
				$css .= "$name:$value; ";
			}
		}
	}
	if ( isset( $selectors ) ) {
		if ( is_string( $selectors ) && '' != $selectors ) {
			$inline_css .= $selectors;
		} elseif ( is_array( $selectors ) && ! empty( $selectors ) ) {
			$inline_css .= implode( ",\n$inline_css",  $selectors );
		}
	}
	// Apply inline CSS
	if ( '' == trim( $inline_css ) ) {
		$inline_css .= $css;
	} else {
		$inline_css .= '{ ' . $css . '} ';
	}

	// Format/Clean the CSS.
	$inline_css = "\n" . $inline_css;
	if ( '' != $css ) {
		return $inline_css;
	}
}
function rcp_settings_export() {
	if ( empty( $_POST['rcp_export_action'] ) || 'rcp_export_settings' != $_POST['rcp_export_action'] )
		return;
	if ( ! wp_verify_nonce( $_POST['rcp_export_nonce'], 'rcp_export_nonce' ) )
		return;
	if ( ! current_user_can( 'manage_options' ) )
		return;
	global $wpdb, $wp_filesystem;
	$rcp_get_all_options = wp_load_alloptions();
	$rcp_options  = array();
	foreach ( $rcp_get_all_options as $key => $value ) {
		if ( strpos( $key, 'rcp_' ) !== 0 ) {
			continue;
		}
		if ( ! empty( $value ) ) {
			$rcp_options[ $key ] = $value;
		}
	}
	ignore_user_abort( true );
	nocache_headers();
	header( 'Content-Type: application/json; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=rcp-settings-export-' . date( 'm-d-Y' ) . '.json' );
	header( "Expires: 0" );

	echo wp_json_encode( $rcp_options );
	exit;
}
function rcp_settings_import() {
	if( empty( $_POST['rcp_import_action'] ) || 'rcp_import_settings' != $_POST['rcp_import_action'] )
		return;

	if( ! wp_verify_nonce( $_POST['rcp_import_nonce'], 'rcp_import_nonce' ) )
		return;

	if( ! current_user_can( 'manage_options' ) )
		return;

	$import_file = $_FILES['rcp_import_file']['name'];
	$file_info = pathinfo( $import_file );
	$extension = $file_info['extension'];
	if ( $extension !== 'json' ) {
		wp_die( esc_html__( 'Please upload a valid .json file', 'cookpro_textdomain' ) );
	}

	$import_file = $_FILES['rcp_import_file']['tmp_name'];

	if ( empty( $import_file ) ) {
		wp_die( esc_html__( 'Please upload a file to import', 'cookpro_textdomain' ) );
	}

	// Retrieve the settings from the file and convert the json object to an array.
	$settings = (array) json_decode( file_get_contents( $import_file ) );
	if ( !empty( $settings ) ) {
		foreach ( $settings as $key => $value) {
			update_option( $key, $value );
		}
	}
	wp_safe_redirect( admin_url( 'edit.php?post_type=recipe&page=recipe_settings' ) ); exit;
}
if ( get_option( 'rcp_facebook_app_id' ) != '' ) {
	add_action( 'wp_head', 'rcp_fb_ogg_metadata' );
}
function rcp_fb_ogg_metadata() {
	if ( is_singular( 'recipe' ) ) {
		global $post;
		$post_var = get_post( $post->ID );
		$raw_content = $post_var->post_content;
		if ( '' != $post_var->post_content ):
		if ( '' != $post_var->post_excerpt ):
			$fbcontent = wp_trim_words( strip_shortcodes( strip_tags( $post_var->post_excerpt ) ) );
		else:
			$fbcontent = wp_trim_words( strip_shortcodes( strip_tags( $post_var->post_content ) ) );
		endif;
		else:
			$fbcontent = wp_trim_words( strip_shortcodes( strip_tags( $post_var->post_content ) ) );
		endif;
		?>
		<!-- Open Graph Meta Tags for Facebook and LinkedIn Sharing !-->
		<?php if ( get_option( 'rcp_facebook_app_id' ) != '' ) { ?>
			<meta property="fb:app_id" content="<?php echo get_option( 'rcp_facebook_app_id' );?>" />
		<?php } ?>
			<meta property="og:title" content="<?php the_title(); ?>"/>
			<meta property="og:description" content="<?php echo $fbcontent; ?>" />
			<meta property="og:url" content="<?php the_permalink(); ?>"/>
		<?php $fb_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'large' ); ?>
		<?php if ( $fb_image ) { ?>
			<meta property="og:image" content="<?php echo $fb_image[0]; ?>" />
			<meta property="og:image:secure_url" content="<?php echo $fb_image[0]; ?>">
		<?php } ?>
		<meta property="og:type" content="<?php if ( is_single() || is_page()) { echo 'article'; } else { echo 'website'; } ?>">
		<meta property="og:site_name" content="<?php bloginfo( 'name' ); ?>">
		<!-- End Open Graph Meta Tags !-->
	<?php
	}
}
function rcp_step_upload_files() {
	$parent_post_id = isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0;  // The parent ID of our attachments.
	$upload_overrides = array( 'rcp_upload_form' => false );
	$files = $_FILES['rcp_images'];
	if ( ! empty( $files ) ) {
		foreach ( $files['name'] as $key => $value ) {
			if ( $files['name'][$key] ) {
		        $file = array(
		          'name'     => $files['name'][$key],
		          'type'     => $files['type'][$key],
		          'tmp_name' => $files['tmp_name'][$key],
		          'error'    => $files['error'][$key],
		          'size'     => $files['size'][$key]
		        );
				$_FILES = array( 'rcp_img_btn' => $file );
			}
		}
		foreach ( $_FILES as $file => $array ) {
			echo rcp_sui_step_process_image( $file, $parent_post_id, 'test' );
		}
	}
	exit;
}
function rcp_sui_step_process_image( $file, $post_id, $caption ) {
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	require_once( ABSPATH . 'wp-admin/includes/file.php' );
	require_once( ABSPATH . 'wp-admin/includes/media.php' );
	$attachment_id = media_handle_upload( $file, $post_id );
	$attachment_data = array(
		'ID' => $attachment_id,
		'post_excerpt' => $caption,
	);
	wp_update_post( $attachment_data );
	$rcp_image_url = wp_get_attachment_url( $attachment_id );
	return $rcp_image_url;
}
function rcp_fe_login_fail( $username ) {
	$referrer =  (isset($_SERVER['HTTP_REFERER'])) ? $_SERVER['HTTP_REFERER'] : $_SERVER['PHP_SELF'];
	$referrer = explode( '?', $referrer );
	$referrer = $referrer[0];
	if ( ! empty( $referrer ) && ! strstr( $referrer, 'wp-login' ) && ! strstr( $referrer, 'wp-admin' ) ) {
		wp_redirect( $referrer . '?loginfailed' );
		exit;
	}
}
function rcp_status_ajax_action() {
	$postid = $_POST['postid'];
	// Update
	if ( isset( $postid ) ) {
		if ( get_post_status( $postid ) == 'private' ) {
			$status = 'publish';
		} else {
			$status = 'private';
		}
		$rcp_post = array(
	      'ID'         => $postid,
	      'post_type'  => 'recipe',
		  'post_status' => $status,
		);
		wp_update_post( $rcp_post );
		echo 'success';
	}
	wp_die();
}
function rcp_single_page_content( $content ) {
	global $post;
	if ( is_singular( 'recipe' ) &&  ( 'recipe' === get_post_type() ) ) {
		if ( isset( $_GET['edit'] ) ) {
			$rcp_id = get_the_id();
			$rcp_status = get_post_status( $rcp_id );
			$content .= '<div class="rcp-main-editing-panel">';
			$content .= '<div class="rcp-main-editing__left">';
			$content .= '<span class="rcp-editing__tag rcp__public">' . esc_html__( 'Currently Editing', 'cookpro_textdomain' ) . '</span>';
			$content .= '<p class="rcp-editing__info">';
			$content .= esc_html__( 'You are currently editing your recipe.','cookpro_textdomain' );
			$content .= '</p>';
			$content .= '</div>';
			$content .= '<div class="rcp-main-editing__right">';
			$content .= '<a class="rcp-btn rcp-btn-primary rcp-btn-sm rcp-btn-simple" href="' . esc_url( get_permalink( $rcp_id ) ) . '">' . esc_html__( 'Go Back','cookpro_textdomain' ) . '</a>';
			$content .= '</div>';
			$content .= '</div>';
			$content .= rcp_edit_form_submit( $rcp_id );
		} else {
			global $post;
			$user_id = false;
			// Single page Content
			ob_start();
			$content .= rcp_single_page_data( get_the_id() );
			$content .= ob_get_clean();
		}
		return $content;
	} else {
		return $content;
	}
	return $content;
}
function rcp_no_default_comments( $comment_template ) {
	if ( is_singular( 'recipe' ) ) {
		return RECIPE_DIR . '/templates/rcp-no-comments.php';
	}
}
if ( ! function_exists( 'rcp_comment_fields' ) ) {
	function rcp_comment_fields( $fields ) {

		$commenter = wp_get_current_commenter();
		$req = get_option( 'require_name_email' );
		$aria_req = ( $req ? " aria-required='true'" : '' );

		$fields['author'] = '<div class="comment-form-author"><label for="author">' . esc_html__( 'Name ', 'cookpro_textdomain' ) . ( $req ? '<span class="required">*</span>' : '' ) . '</label><input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
		'" size="30"' . $aria_req . ' /></div>';

		$fields['email'] = '<div class="comment-form-email"><label for="email">' . esc_html__( 'Email ', 'cookpro_textdomain' ) . ( $req ? '<span class="required">*</span>' : '' ) . '</label><input id="email" name="email" type="text" value="' . esc_attr( $commenter['comment_author_email'] ) .
		'" size="30"' . $aria_req . ' /></div>';

		$fields['url'] = '<div class="comment-form-url"><label for="url">' . esc_html__( 'Website ', 'cookpro_textdomain' ) . '</label><input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .
	    '" size="30" /></div>';

		return $fields;
	}
}
if ( ! function_exists( 'rcp_rating_fields' ) ) {
	function rcp_rating_fields() {
		// Ratings
		echo '<div class="comment-form-rating"><div class="comment-rating">
		<label for="rating">' . esc_html__( 'Rating ','cookpro_textdomain' ) . '</label>';
		echo '
		<div class="rcp-comment-ratings">
		<a class="star_1" data-rated="1"><i class="fa fa-star"></i></a>
		<a class="star_2" data-rated="2"><i class="fa fa-star"></i></a>
		<a class="star_3" data-rated="3"><i class="fa fa-star"></i></a>
		<a class="star_4" data-rated="4"><i class="fa fa-star"></i></a>
		<a class="star_5" data-rated="5"><i class="fa fa-star"></i></a>
		</div>';
		echo '<input type="hidden" name="comment_rating" id="comment_rating">';
		echo '</div></div>';
	}
}
if ( ! function_exists( 'rcp_save_comment_meta_data' ) ) {
	function rcp_save_comment_meta_data( $comment_id ) {
		if ( isset( $_POST['comment_rating'] ) && $_POST['comment_rating'] != '' ):
			$rating = intval( $_POST['comment_rating'] );
			add_comment_meta( $comment_id, 'comment_rating', $rating );
			rcp_update_post_rating_by_commentid( $comment_id );
		endif;
	}
}
function rcp_update_post_rating_by_commentid( $comment_id ) {
	$comment = get_comment( $comment_id );
	rcp_update_post_rating_by_postid( $comment->comment_post_ID );
	return true;
}
function rcp_update_post_rating_by_postid( $post_id ) {
	global $wpdb;
	$rcp_total_rating = 0;
	// Calculate average rating and total ratings
	$results = $wpdb->get_results( " SELECT " . $wpdb->prefix . "commentmeta.meta_value
						FROM " . $wpdb->prefix . "comments
						LEFT JOIN " . $wpdb->prefix . "commentmeta
						ON " . $wpdb->prefix . "comments.comment_ID = " . $wpdb->prefix . "commentmeta.comment_id
						WHERE " . $wpdb->prefix . "comments.comment_post_ID = '" . $post_id . "'
						AND " . $wpdb->prefix . "comments.comment_approved = '1'
						AND " . $wpdb->prefix . "commentmeta.meta_key = 'comment_rating'
						AND " . $wpdb->prefix . "commentmeta.meta_value != 0
						GROUP BY " . $wpdb->prefix . "commentmeta.comment_id"
					 );
	if ( count( $results ) == 0 ) {
		$rcp_total_ratings = 0;
		$rcp_avg_rating = 0;
	} else {
		$rcp_total_ratings = count( $results );
		foreach ( $results as $key=> $result ) {
			$rcp_total_rating += $result->meta_value;
		}
		$rcp_avg_rating = ( ( $rcp_total_ratings == 0 || $rcp_total_rating == 0 ) ? 0 : round( ( $rcp_total_rating / $rcp_total_ratings ), 0 ) );
	}
	update_post_meta( $post_id, 'rcp_comment_total_rating', $rcp_total_ratings );
	update_post_meta( $post_id, 'rcp_comment_avg_rating', $rcp_avg_rating );
	return true;
}

if ( ! function_exists( 'rcp_custom_user_profile_fields' ) ) {
	function rcp_custom_user_profile_fields( $user ) {
		$rcp_user_position 		= esc_attr( get_the_author_meta( 'position', $user->ID ) );
		$rcp_user_facebook 		= esc_attr( get_the_author_meta( 'facebook', $user->ID ) );
		$rcp_user_twitter 		= esc_attr( get_the_author_meta( 'twitter', $user->ID ) );
		$rcp_user_google_plus 	= esc_attr( get_the_author_meta( 'google_plus', $user->ID ) );
		$rcp_user_linkedin 		= esc_attr( get_the_author_meta( 'linkedin', $user->ID ) );

		echo '<h3>' . esc_html__( 'User Sociables', 'cookpro_textdomain' ) . '</h3>';
		echo '<div class="rcp-form-field">';
		echo '<label for="rcp_user_position">' . esc_html__( ' Position', 'cookpro_textdomain' ) . '</label>';
		echo '<div class="rcp-form-input"><input type="text" name="position" id="rcp_user_position" value="' . $rcp_user_position . '" class="regular-text"></div>';
		echo '</div>';

		echo '<div class="rcp-form-field">';
		echo '<label for="rcp_user_facebook">' . esc_html__( 'Facebook', 'cookpro_textdomain' ) . '</label>';
		echo '<div class="rcp-form-input"><input type="text" name="facebook" id="rcp_user_facebook" value="' . $rcp_user_facebook . '" class="regular-text"></div>';
		echo '</div>';

		echo '<div class="rcp-form-field">';
		echo '<label for="rcp_user_twitter">' . esc_html__( ' Twitter', 'cookpro_textdomain' ) . '</label>';
		echo '<div class="rcp-form-input"><input type="text" name="twitter" id="rcp_user_twitter" value="' . $rcp_user_twitter . '" class="regular-text"></div>';
		echo '</div>';

		echo '<div class="rcp-form-field">';
		echo '<label for="rcp_user_google_plus">' . esc_html__( ' Google Plus', 'cookpro_textdomain' ) . '</label>';
		echo '<div class="rcp-form-input"><input type="text" name="google_plus" id="rcp_user_google_plus" value="' . $rcp_user_google_plus . '" class="regular-text"></div>';
		echo '</div>';

		echo '<div class="rcp-form-field">';
		echo '<label for="rcp_user_google_linkedin">' . esc_html__( ' Linkedin', 'cookpro_textdomain' ) . '</label>';
		echo '<div class="rcp-form-input"><input type="text" name="linkedin" id="rcp_user_google_linkedin" value="' . $rcp_user_linkedin . '" class="regular-text"></div>';
		echo '</div>';
	}
}
if ( ! function_exists( 'rcp_save_custom_user_profile_fields' ) ) {
	function rcp_save_custom_user_profile_fields( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) )
			return false;

		update_user_meta( $user_id, 'position', $_POST['position'] );
		update_user_meta( $user_id, 'facebook', $_POST['facebook'] );
		update_user_meta( $user_id, 'twitter', $_POST['twitter'] );
	    update_user_meta( $user_id, 'google_plus', $_POST['google_plus'] );
		update_user_meta( $user_id, 'linkedin', $_POST['linkedin'] );
	}
}
if ( ! function_exists( 'rcp_print_endpoint' ) ) {
	function rcp_print_endpoint() {
		add_rewrite_endpoint( 'print', EP_PERMALINK | EP_PAGES );
	}
}

if ( ! function_exists( 'rcp_print_variables' ) ) {
	function rcp_print_variables( $public_query_vars ) {
		$public_query_vars[] = 'print';
		return $public_query_vars;
	}
}
if ( ! function_exists( 'rcp_print_page' ) ) {
	function rcp_print_page() {
		global $post_type,$wp_query;
		if ( array_key_exists( 'print' , $wp_query->query_vars ) ) {
			if ( $post_type == 'recipe' ) {
		    	load_template( RECIPE_INC_DIR . 'rcp-print-recipe.php', false );
				exit();
		    }
		}
	}
}
function rcp_more_comments_ajax() {
	check_ajax_referer( 'rcp-comment-nonce', 'nonce' );
	$rcp_out = '';

	$limit 		= $_POST['number'];
	$offset 	= $_POST['offset'];
	$orderby 	= $_POST['orderby'];
	$order 		= $_POST['order'];
	$post_id 	= $_POST['postid'];
	$rcp_comments = get_comments(
		array(
			'post_id' => $post_id,
			'status'  => 'approve',
			'offset'  => (int)$offset,
			'number'  => (int)$limit,
			'orderby' => $orderby,
			'order'   => $order,
		)
	);
	if ( ! empty( $rcp_comments ) ) {
		foreach ( $rcp_comments as $review ) {
			$comment_rating = get_comment_meta( $review->comment_ID, 'comment_rating', true );
			$rcp_comment_date = strtotime( $review->comment_date );
			$comment_date = sprintf( esc_html__( '%1$s at %2$s' ),
				get_comment_date( esc_html__( 'M j, Y' ), $review->comment_ID ),
				get_comment_date( esc_html__( 'g:i a' ), $review->comment_ID )
			);
			$rcp_out .= '<li class="rcp-comment-post rcp-comment-item" id="comment-' . $review->comment_ID . '">';
			$rcp_out .= '<div class="rcp-comment__review">';
			$rcp_out .= '<div class="comment__meta">';
			$rcp_out .= '<div class="comment__author vcard">';
			$rcp_out .= rcp_get_avatar( $review->user_id, 60 );//.avatar
			$rcp_out .= '<b class="fn">' . $review->comment_author . '</b>';
			$rcp_out .= '</div>'; //comment__author vcard
			$rcp_out .= '<div class="comment__metadata">';
			$rcp_out .= '<span>' . $comment_date . '</span>';
			$rcp_out .= '</div>'; //comment__metadata
			$rcp_out .= '</div>'; //comment__meta
			$rcp_out .= '<div class="comment__content">';
			$rcp_out .= '<p>' . $review->comment_content . '</p>';
			if ( ! empty( $comment_rating ) ) {
				$rcp_out .= '<div class="rcp___prating">';
				$rcp_out .= '
				<div class="rcp-comment-ratings-review" data-rated=' . $comment_rating . '>
				<i class="star_1 fa fa-star"></i>
				<i class="star_2 fa fa-star"></i>
				<i class="star_3 fa fa-star"></i>
				<i class="star_4 fa fa-star"></i>
				<i class="star_5 fa fa-star"></i>
				</div>';
				$rcp_out .= '</div>'; //.comment_rating
			}
			$rcp_out .= '</div>'; //.comment__content
			$rcp_out .= '</div>'; //.rcp-comment__review
			$rcp_out .= '</li>'; //.rcp__preview
		}
	}
	wp_die( $rcp_out );
}

function rcp_more_search_ajax() {
	check_ajax_referer( 'rcp-search-nonce', 'nonce' );

	global $post, $wpdb;
	$rcp_search_out = $rcp_cat_values = $rcp_cuisine_values = $rcp_method_values = $rcp_ingredient_values ='';

	$limit 	 = $_POST['number'];
	$orderby = $_POST['orderby'];
	$order 	 = $_POST['order'];
	$columns = $_POST['columns'];

	$rcp_data_cats		  = $_POST['category'];
	$rcp_data_cuisines	  = $_POST['cuisine'];
	$rcp_data_methods	  = $_POST['ingredient'];
	$rcp_data_ingredients = $_POST['method'];
	$rcp_search_name	  = $_POST['search_string'];
	$hide_cooktime		  = $_POST['hide_cooktime'];
	$hide_difflevel		  = $_POST['hide_difflevel'];
	$hide_yields		  = $_POST['hide_yields'];
	$hide_ratings		  = $_POST['hide_ratings'];
	$display_style		  = $_POST['display_style'];

	$scroll_page 	= isset( $_POST['scroll_page'] ) ? $_POST['scroll_page'] :'loadmore';
	$offset 		= isset( $_POST['offset'] ) ? $_POST['offset'] :1;
	$page_no		= isset( $_POST['page_no'] ) ? $_POST['page_no'] : 1;

	if ( ! empty( $rcp_data_cats ) ) {
		$rcp_cat_values = explode( ',', $rcp_data_cats );
	}
	if ( ! empty( $rcp_data_cuisines ) ) {
		$rcp_cuisine_values	= explode( ',', $rcp_data_cuisines );
	}
	if ( ! empty( $rcp_data_methods ) ) {
		$rcp_method_values = explode( ',', $rcp_data_methods );
	}
	if ( ! empty( $rcp_data_ingredients ) ) {
		$rcp_ingredient_values 	= explode( ',', $rcp_data_ingredients );
	}

	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	$ids = $wpdb->get_col( "select ID from $wpdb->posts where post_title LIKE '%" . $rcp_search_name . "%' AND post_type='recipe' AND post_status='publish'" );
	$args = array(
		'post_type'			=> 'recipe',
		'posts_per_page'	=> (int)$limit,
		'tax_query' => array(
			'relation' => 'OR',
		),
		'orderby'	=> $orderby,
		'order'		=> $order
	);
	if( $scroll_page == 'infinite') {
		$args['paged'] = $page_no;
	}
	if( $scroll_page == 'loadmore' ) {
		$args['paged'] = $page_no;
		$args['offset'] = (int)$offset;
	}
	if ( $ids != '' ) {
		$args['post__in'] = $ids;
	}
	if ( $rcp_cat_values != '' ) {
		$rcp_cat_args = array(
			'taxonomy' => 'recipe_cat',
			'field' => 'term_id',
			'terms' => $rcp_cat_values,
		);
		array_push( $args['tax_query'], $rcp_cat_args );
	}
	if ( $rcp_cuisine_values != '' ) {
		$rcp_cuisine_args = array(
			'taxonomy' => 'recipe_cuisine',
			'field' => 'term_id',
			'terms' => $rcp_cuisine_values,
		);
		array_push( $args['tax_query'], $rcp_cuisine_args );
	}
	if ( $rcp_method_values != '' ) {
		$rcp_method_args = array(
			'taxonomy' => 'recipe_method',
			'field' => 'term_id',
			'terms' => $rcp_method_values,
		);
		array_push( $args['tax_query'], $rcp_method_args );
	}
	if ( $rcp_ingredient_values != '' ) {
		$rcp_ingredient_args = array(
			'taxonomy' => 'post_tag',
			'field' => 'term_id',
			'terms' => $rcp_ingredient_values,
		);
		array_push( $args['tax_query'], $rcp_ingredient_args );
	}
	$rcp_search_query = new WP_Query( $args );
	if ( $rcp_search_query->have_posts() ) : while ( $rcp_search_query->have_posts() ) : $rcp_search_query->the_post();
		$column_index++;

		$rcp_search_out .= '<div class="rcp-search-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
		$rcp_search_out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
		$rcp_search_out .= '</div>'; //.rcp-post-item

		if ( $column_index == $columns ) {
			$column_index = 0;
		}
	endwhile;
	endif;
	wp_reset_postdata();
	wp_die( $rcp_search_out );
}
function rcp_user_more_recps_ajax() {
	check_ajax_referer( 'rcp-user-rcp-nonce', 'nonce' );

	$rcp_out = '';

	$limit   = $_POST['number'];
	$offset  = $_POST['offset'];
	$orderby = $_POST['orderby'];
	$order 	 = $_POST['order'];
	$user_id = $_POST['user_id'];

	$rcp_args = array(
		'post_type' 	=> 'recipe',
		'post_status' 	=> 'any',
		'posts_per_page'=> (int)$limit,
		'offset'        => (int)$offset,
		'orderby' 		=> $orderby,
		'order' 		=> $order,
		'author' 		=> $user_id,
	);
	$rcp_query = new WP_Query( $rcp_args );

	if ( $rcp_query->have_posts() ) : while ( $rcp_query->have_posts() ) : $rcp_query->the_post();

		global $post;

		$rcp_out .= $post->ID;
		$rcp_category_term_list = wp_get_post_terms( $post->ID, 'recipe_cat', array( 'fields' => 'names' ) );
		$rcp_cuisines_term_list = wp_get_post_terms( $post->ID, 'recipe_cuisine', array( 'fields' => 'names' ) );
		$rcp_ingredients_count	= rcp_ingredients_count( $post->ID );
		$rcp_calories 			= rcp_calories( $post->ID );
		$rcp_total_time  		= rcp_total_time( $post->ID );
		$rcp_post_status 		= get_post_status( $post->ID );

		$rcp_out .= '<tr class="rcp-user-post rcp-user-item">';
		$rcp_out .= '<td class="rcp__pimg_pmeta">';
		if ( has_post_thumbnail() ) {
			$rcp_out .= '<div class="pimg">';
			$rcp_out .= '<a href="' . esc_url( get_permalink( $post->ID ) ).'">';
			$rcp_out .= '<div class="rcp-img">' . get_the_post_thumbnail( $post->ID, array( 85, 85 ) ) . '</div>';
			$rcp_out .= '</a>';
			$rcp_out .= '</div>'; //.pimg
		}
		$rcp_out .= '<div class="pmeta">';
		$rcp_out .= '<h5><a  href="' . esc_url( get_permalink( $post->ID ) ) . '">' . get_the_title( $post->ID ) . '</a></h5>';
		if ( $rcp_post_status == 'pending' ) {
			$rcp_out .= '<span class="rcp-user-post__status rcp__pending">' . $rcp_post_status . '</span>';
		}
		if ( $rcp_post_status == 'draft' ) {
			$rcp_out .= '<span class="rcp-user-post__status rcp__drafted">' . $rcp_post_status . '</span>';
		}
		if ( count( $rcp_category_term_list ) >= 1 ) {
			$rcp_out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Categories', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cat', '', ', ' ) ) . '</span>';
		}
		if ( count( $rcp_cuisines_term_list ) >= 1 ) {
			$rcp_out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Cuisines', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cuisine', '', ', ' ) ) . '</span>';
		}
		$rcp_out .= '</div>'; //.pmeta
		$rcp_out .= '</td>'; //.rcp__pimg_pmeta
		$rcp_out .= '<td>';
		$rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_total_time . '</div>';
		$rcp_out .= '</td>';
		$rcp_out .= '<td>';
		$rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_calories . '<span>' . esc_html__( 'Calories','cookpro_textdomain' ) . '</span></div>';
		$rcp_out .= '</td>';
		$rcp_out .= '<td>';
		$rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_ingredients_count . '<span>' . esc_html__( 'Ingredients', 'cookpro_textdomain' ) . '</div>';
		$rcp_out .= '</td>';
		// $rcp_out .= '<td><a class="rcp-btn rcp-btn-primary rcp-btn-sm" href="' . esc_url( get_permalink( $post->ID ) ) . '"><span>' . esc_html__( 'View Recipe', 'cookpro_textdomain' ) . '</span></a></td>';
		$rcp_out .= '</tr>';
	endwhile;
	wp_reset_postdata();
	endif;
	wp_die( $rcp_out );
}
function rcp_user_more_reviews_ajax() {
	check_ajax_referer( 'rcp-user-review-nonce', 'nonce' );

	$rcp_out = '';

	$limit 	 = $_POST['number'];
	$offset  = $_POST['offset'];
	$orderby = $_POST['orderby'];
	$order 	 = $_POST['order'];
	$user_id = $_POST['user_id'];

	$args = array(
		'post_status' 	=> 'publish',
		'post_type' 	=> 'recipe',
		'number'		=> (int)$limit,
		'offset'        => (int)$offset,
		'orderby' 		=> $orderby,
		'order' 		=> $order,
		'status' 		=> 'approve',
		'user_id' 		=> $user_id,
	);
	$rcp_user_reviews = get_comments( $args );
	foreach ( $rcp_user_reviews as $key => $id ) {
		if ( $id->post_author == $user_id ) {
			unset( $rcp_user_reviews[ $key ] );
		}
	}
	$rcp_review_count = count( $rcp_user_reviews );
	if ( ! empty( $rcp_user_reviews ) ) {
		foreach ( $rcp_user_reviews as $review ) {
			$rcp_post_image = get_post_meta( $review->comment_post_ID, '_thumbnail_id', true );
			$rcp_comment_date = strtotime( $review->comment_date );
			$comment_date = human_time_diff( $rcp_comment_date, current_time( 'timestamp' ) ) . esc_html__( ' ago', 'cookpro_textdomain' );
			$review_rating = get_comment_meta( $review->comment_ID, 'comment_rating', true );

			$rcp_out .= '<li class="rcp-user-review-post">';
			$rcp_out .= '<div class="rcp-comment__review">';
			$rcp_out .= '<div class="comment__meta">';
			$rcp_out .= '<div class="comment__author vcard">';
			$rcp_out .= '<a href="' . esc_url( get_permalink( $review->comment_post_ID ) ) .'">';
			$rcp_out .= get_the_post_thumbnail( $review->comment_post_ID, array( 60, 60 ), '' );
			$rcp_out .= '</a>';
			$rcp_out .= '<a class="fn" href="' . esc_url( get_permalink( $review->comment_post_ID ) ) . '#comment-' . $review->comment_ID . '">' . get_the_title( $review->comment_post_ID ) . '</a>';
			$rcp_out .= '</div>'; //.comment__author vcard
			$rcp_out .= '<div class="comment__metadata">';
			$rcp_out .= '<span>' . $comment_date . '</span>';
			$rcp_out .= '</div>'; //.comment__metadata
			$rcp_out .= '</div>'; //.comment__meta
			$rcp_out .= '<div class="comment__content">';
			$rcp_out .= '<p>' . $review->comment_content . '</p>';
			if ( ! empty( $review_rating ) ) {
				$rcp_out .= '<div class="rcp___prating">';
				$rcp_out .= '
				<div class="rcp-comment-ratings-review" data-rated=' . $review_rating . '>
				<i class="star_1 fa fa-star"></i>
				<i class="star_2 fa fa-star"></i>
				<i class="star_3 fa fa-star"></i>
				<i class="star_4 fa fa-star"></i>
				<i class="star_5 fa fa-star"></i>
				</div>';
				$rcp_out .= '</div>'; //.comment_rating
			}
			$rcp_out .= '</div>'; //.comment__content
			$rcp_out .= '</div></li>'; //.rcp-comment__review
		}
	}
	wp_die( $rcp_out );
}
function rcp_user_more_favorites_ajax() {
	check_ajax_referer( 'rcp-user-fav-nonce', 'nonce' );

	$rcp_out = '';

	$limit 	 = $_POST['number'];
	$offset  = $_POST['offset'];
	$orderby = $_POST['orderby'];
	$order 	 = $_POST['order'];
	$user_id = $_POST['user_id'];

	$rcp_user_favorite_postids = get_user_meta( $user_id, 'recipe_love', true );
	$rcp_user_favourites = array();
	if ( ! empty( $rcp_user_favorite_postids ) ) {
		foreach ( $rcp_user_favorite_postids as $rcp_postid ) {
			$rcp_user_favourites[] = $rcp_postid;
		}
	}
	$rcp_like_args = array(
		'post_type' 	=> 'recipe',
		'post_status' 	=> 'any',
		'offset'        => (int)$offset,
		'posts_per_page'=> (int)$limit,
		'orderby' 		=> $orderby,
		'order' 		=> $order,
		'post__in' 		=> $rcp_user_favourites,
	);
	$rcp_favourite_query = new WP_Query( $rcp_like_args );
	$rcp_favourites_count = $rcp_favourite_query->found_posts;

	if ( $rcp_favourite_query->have_posts() ) {
		while ( $rcp_favourite_query->have_posts() ) {
			$rcp_favourite_query->the_post();
			global $post;
			$rcp_category_term_list = wp_get_post_terms( $post->ID, 'recipe_cat', array( 'fields' => 'names' ) );
			$rcp_cuisines_term_list = wp_get_post_terms( $post->ID, 'recipe_cuisine', array( 'fields' => 'names' ) );
			$rcp_ingredients_count  = rcp_ingredients_count( $post->ID );
			$rcp_calories 			= rcp_calories( $post->ID );
			$rcp_total_time  		= rcp_total_time( $post->ID );

			$rcp_out .= '<tr class="rcp-user-fav-post rcp-user-fav-item">';
			$rcp_out .= '<td class="rcp__pimg_pmeta">';
			if ( has_post_thumbnail() ) {
				$rcp_out .= '<div class="pimg">';
				$rcp_out .= '<a href="' . esc_url( get_permalink( $post->ID ) ).'">';
				$rcp_out .= '<div class="rcp-img">' . get_the_post_thumbnail( $post->ID, array( 85, 85 ), '' ) . '</div>';
				$rcp_out .= '</a>';
				$rcp_out .= '</div>'; //.pimg
			}
			$rcp_out .= '<div class="pmeta">';
			$rcp_out .= '<h5><a  href="' . esc_url( get_permalink( $post->ID ) ) . '">' . get_the_title( $post->ID ) . '</a></h5>';
			if ( count( $rcp_category_term_list ) >= 1 ) {
				$rcp_out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Categories', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cat', '', ', ' ) ) . '</span>';
			}
			if ( count( $rcp_cuisines_term_list ) >= 1 ) {
				$rcp_out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Cusines', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cuisine', '', ', ' ) ) . '</span>';
			}
			$rcp_out .= '<div class="meta-likes">' . rcp_get_favorites( $post->ID ) . '</div>';
			$rcp_out .= '</div>'; //.pmeta
			$rcp_out .= '</td>'; //.rcp__pimg_pmeta
			$rcp_out .= '<td>';
			$rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_total_time . '</div>';
			$rcp_out .= '</td>';
			$rcp_out .= '<td>';
			$rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_calories . '<span>' . esc_html__( 'Calories', 'cookpro_textdomain' ) . '</span></div>';
			$rcp_out .= '</td>';
			// $rcp_out .= '<td>';
			// $rcp_out .= '<div class="rcp__recipe_pmeta">' . $rcp_ingredients_count . '<span>' . esc_html__( 'Ingredients', 'cookpro_textdomain' ) . '</span></div>';
			// $rcp_out .= '</td>';
			$rcp_out .= '<td><a class="rcp-btn rcp-btn-primary rcp-btn-sm rcp-rem-favorite" href="#" data-id="' . $post->ID . '" data-userid="' . $user_id . '" data-url="' . esc_attr( $rcp_user_link ) . '"><span><i class="fa fa-times" aria-hidden="true"></i></span></a></td>';
			$rcp_out .= '</tr>';
		}
		/* Restore original Post Data */
		wp_reset_postdata();
	}
	wp_die( $rcp_out );
}
function rcp_more_users_ajax() {
	check_ajax_referer( 'rcp-more-users-nonce', 'nonce' );
	$rcp_out = '';

	$limit 		= $_POST['number'];
	$offset 	= $_POST['offset'];
	$orderby 	= $_POST['orderby'];
	$order 		= $_POST['order'];
	$rcp_user_query = new WP_User_Query(
		array(
			'number' => (int)$limit,
			'offset' => (int)$offset,
			'role__in' => array( 'administrator', 'contributor' ),
			'orderby' => $orderby,
			'order'  => $order,
		)
	);
	$rcp_user_list_query = $rcp_user_query->get_results();
	$rcp_user_count = $rcp_user_query->get_total();

	foreach ( $rcp_user_list_query as $user_data ) {
		$rcp_author_url  = get_author_posts_url( $user_data->ID );

		$rcp_user_link = get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $user_data->user_login ;

		$rcp_out .= '<div class="rcp-profile-header member-dir rcp-user-post rcp-user-item">';
		$rcp_out .= '<div class="rcp-profile-header_inner">';
		$rcp_out .= '<div class="rcp-profile-info">';
		$rcp_out .= '<div class="rcp-profile__thumb">' . rcp_get_avatar( $user_data->ID, 100 ) . '</div>';
		$rcp_out .= '<div class="rcp-profile__info">';
		$rcp_out .= '<h2><a href="' . esc_url( $rcp_user_link ) . '">' . $user_data->display_name  . '</a><span>' . $user_data->position  . '</span></h2>';
		$rcp_out .= '</div>'; //.rcp-profile__info
		$rcp_out .= '</div>'; //.rcp-profile-info
		$rcp_out .= '<div class="rcp-profile-exinfo">';
		$rcp_out .= '<div class="rcp__follow_wrapper">';
		$rcp_out .= '<ul class="rcp__follow_fav">';
		$rcp_out .= '<li class="rcp__following_count">' . rcp_get_user_recipes_count( $user_data->ID ) . '<span>' .esc_html__( 'Recipes', 'cookpro_textdomain' ) . '</span></li>';
		$rcp_out .= '<li class="rcp__followers_count">' . rcp_get_user_reviews_count( $user_data->ID ) . '<span>' .esc_html__( 'Reviews', 'cookpro_textdomain' ) . '</span></li>';
		$rcp_out .= '<li class="rcp__fav_count">' . rcp_get_user_favorites_count( $user_data->ID ) . '<span>' .esc_html__( 'Favotrites', 'cookpro_textdomain' ) . '</span></li>';
		$rcp_out .= '</ul>'; //.rcp__follow_fav
		$rcp_out .= '</div>'; //.rcp__follow_wrapper
		$rcp_out .= '</div>'; //.rcp-profile-exinfo
		$rcp_out .= '</div>'; //.rcp-profile-header_inner
		$rcp_out .= '</div>'; //.rcp-profile-header
	}
	wp_die( $rcp_out );
}

function rcp_recent_sh_more_recps_ajax() {
	check_ajax_referer( 'rcp-recent-sh-nonce', 'nonce' );
	$rcp_out = '';


	$orderby 		= isset( $_POST['orderby'] ) ? $_POST['orderby'] : 'date';
	$order 	 		= isset( $_POST['order'] ) ? $_POST['order']: 'DESC';
	$limit 			= $_POST['number'];
	$hide_cooktime  = $_POST['hide_cooktime'];
	$hide_difflevel = $_POST['hide_difflevel'];
	$hide_yields 	= $_POST['hide_yields'];
	$hide_ratings 	= $_POST['hide_ratings'];
	$columns 		= $_POST['columns'];
	$scroll_page 	= isset( $_POST['scroll_page'] ) ? $_POST['scroll_page'] :'loadmore';
	$offset 		= isset( $_POST['offset'] ) ? $_POST['offset'] :1;
	$page_no		= isset( $_POST['page_no'] ) ? $_POST['page_no'] : 1;
	$display_style 	= isset( $_POST['display_style'] ) ? $_POST['display_style'] : 'style1';
	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	$args = array(
		'post_type'		 => 'recipe',
		'post_status'	 => 'publish',
		'posts_per_page' => $limit,
		'orderby'		 => $orderby,
		'order'			 => $order
	);

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}

	if( $scroll_page == 'infinite') {
		$args['paged'] = $page_no;
	}
	if( $scroll_page == 'loadmore' ) {
		$args['offset'] = (int)$offset;
	}

	$rcp_recent_query = new WP_Query( $args );
	if ( $rcp_recent_query->have_posts() ) :
	while ( $rcp_recent_query->have_posts() ) : $rcp_recent_query->the_post();
		$column_index++;
		$rcp_out .= '<div class="rcp-recent-sh-post rcp-post-item  ' . esc_attr( $class ) . ' ' . $display_style . '">';
		$rcp_out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
		$rcp_out .= '</div>'; //.rcp-post-item
		if ( $column_index == $columns ) {
			$column_index = 0;
		}
	endwhile;
	endif;
	wp_die( $rcp_out );
}
function rcp_highest_sh_more_recps_ajax() {
	check_ajax_referer( 'rcp-highest-rated-sh-nonce', 'nonce' );

	$limit 			= $_POST['number'];
	$columns 		= $_POST['columns'] ;
	$hide_cooktime 	= $_POST['hide_cooktime'];
	$hide_difflevel = $_POST['hide_difflevel'];
	$hide_yields 	= $_POST['hide_yields'];
	$hide_ratings 	= $_POST['hide_ratings'];
	$display_style 	= $_POST['display_style'];

	$scroll_page 	= isset( $_POST['scroll_page'] ) ? $_POST['scroll_page'] :'loadmore';
	$offset 		= isset( $_POST['offset'] ) ? $_POST['offset'] :1;
	$page_no		= isset( $_POST['page_no'] ) ? $_POST['page_no'] : 1;

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	$args = array(
		'post_type' 	=> 'recipe',
		'post_status' 	=> 'any',
		'posts_per_page' => $limit,
		'meta_key' 		=> 'rcp_comment_avg_rating',
		'orderby' 		=> 'meta_value_num',
		'order' 		=> 'DESC',
	);
	if( $scroll_page == 'infinite') {
		$args['paged'] = $page_no;
	}
	if( $scroll_page == 'loadmore' ) {
		$args['offset'] = (int)$offset;
	}

	$rcp_top_rated_query = new WP_Query( $args );
	$rcp_highest_rated_nonce = wp_create_nonce( 'rcp-highest-rated-sh-nonce' );
	$count_results = $rcp_top_rated_query->found_posts;
	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( $rcp_top_rated_query->have_posts() ) :	while ( $rcp_top_rated_query->have_posts() ) : $rcp_top_rated_query->the_post();

		$column_index++;

		$rcp_out .= '<div class="rcp-highest-rated-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
		$rcp_out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
		$rcp_out .= '</div>'; //.rcp-post-item

		if ( $column_index == $columns ) {
			$column_index = 0;
		}
	endwhile;
	endif;
	wp_die( $rcp_out );
}

function rcp_sh_cat_more_ajax() {
	check_ajax_referer( 'rcp-by-cat-sh-nonce', 'nonce' );

	global $post;
	$rcp_cat_search_out = $rcp_cat_values = $rcp_cuisine_values = $rcp_method_values = $rcp_ingredient_values ='';

	$limit 	 			= $_POST['number'];
	$offset  			= $_POST['offset'];
	$orderby 			= $_POST['orderby'];
	$order 	 			= $_POST['order'];
	$columns 			= $_POST['columns'];
	$rcp_data_cats		  = $_POST['category'];
	$rcp_data_cuisines    = $_POST['cuisine'];
	$rcp_data_methods	  = $_POST['ingredient'];
	$rcp_data_ingredients = $_POST['method'];
	$hide_cooktime  	  = $_POST['hide_cooktime'];
	$hide_difflevel 	  = $_POST['hide_difflevel'];
	$hide_yields		  = $_POST['hide_yields'];
	$hide_ratings		  = $_POST['hide_ratings'];

	$display_style 	= isset( $_POST['display_style'] ) ? $_POST['display_style'] : 'style1';
	$scroll_page 	= isset( $_POST['scroll_page'] ) ? $_POST['scroll_page'] :'loadmore';
	$offset 		= isset( $_POST['offset'] ) ? $_POST['offset'] :1;
	$page_no		= isset( $_POST['page_no'] ) ? $_POST['page_no'] : 1;

	if ( ! empty( $rcp_data_cats ) ) {
		$rcp_cat_values = explode( ',', $rcp_data_cats );
	}
	if ( ! empty( $rcp_data_cuisines ) ) {
		$rcp_cuisine_values	= explode( ',', $rcp_data_cuisines );
	}
	if ( ! empty( $rcp_data_methods ) ) {
		$rcp_method_values = explode( ',', $rcp_data_methods );
	}
	if ( ! empty( $rcp_data_ingredients ) ) {
		$rcp_ingredient_values 	= explode( ',', $rcp_data_ingredients );
	}

	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	$args = array(
		'post_type'			=> 'recipe',
		'post_status'		=> 'publish',
		'posts_per_page'	=> (int)$limit,
		'tax_query' => array(
			'relation' => 'OR',
		),
		'orderby'	=> $orderby,
		'order'		=> $order,
	);
	if( $scroll_page == 'infinite') {
		$args['paged'] = $page_no;
	}
	if( $scroll_page == 'loadmore' ) {
		$args['paged'] = $page_no;
		$args['offset'] = (int)$offset;
	}
	if ( $rcp_cat_values != '' ) {
		$rcp_cat_args = array(
			'taxonomy' => 'recipe_cat',
			'field' => 'term_id',
			'terms' => $rcp_cat_values,
		);
		array_push( $args['tax_query'], $rcp_cat_args );
	}
	if ( $rcp_cuisine_values != '' ) {
		$rcp_cuisine_args = array(
			'taxonomy' => 'recipe_cuisine',
			'field' => 'term_id',
			'terms' => $rcp_cuisine_values,
		);
		array_push( $args['tax_query'], $rcp_cuisine_args );
	}
	if ( $rcp_method_values != '' ) {
		$rcp_method_args = array(
			'taxonomy' => 'recipe_method',
			'field' => 'term_id',
			'terms' => $rcp_method_values,
		);
		array_push( $args['tax_query'], $rcp_method_args );
	}
	if ( $rcp_ingredient_values != '' ) {
		$rcp_ingredient_args = array(
			'taxonomy' => 'post_tag',
			'field' => 'term_id',
			'terms' => $rcp_ingredient_values,
		);
		array_push( $args['tax_query'], $rcp_ingredient_args );
	}
	$rcp_cat_search_query = new WP_Query( $args );

	if ( $rcp_cat_search_query->have_posts() ) : while ( $rcp_cat_search_query->have_posts() ) : $rcp_cat_search_query->the_post();

		$column_index++;

		$rcp_cat_post_id 	= get_the_ID();
		$rcp_short_info  	= get_post_meta( $rcp_cat_post_id, 'recipe_short_info', true );
		$rcp_servings 		= get_post_meta( $rcp_cat_post_id, 'recipe_servings', true );
		$rcp_cook_time  	= rcp_get_time( $rcp_cat_post_id ,'recipe_ctime' );
		$rcp_diff_level   	= get_post_meta( $rcp_cat_post_id, 'recipe_diff_level', true );
		$rcp_post_author_id = get_post_field ('post_author', $rcp_cat_post_id );
		$rcp_user_info 	 	= get_userdata( $rcp_post_author_id );
		$rcp_user_link		= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $rcp_user_info->user_login ;

		$rcp_cat_search_out .= '<div class="rcp-sh-by-cat-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
		$rcp_cat_search_out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
		$rcp_cat_search_out .= '</div>'; //.rcp-post-item

		if ( $column_index == $columns ) {
			$column_index = 0;
		}
	endwhile;
	endif;
	wp_reset_postdata();
	wp_die( $rcp_cat_search_out );
}
// recipe taxonomy page
function cookpro_taxonomy_posttypes()
{
  	if( is_tax('recipe_cat')){
		return RECIPE_DIR .'/templates/taxonomy-recipe_cat.php';
	}
	if( is_tax('recipe_cuisine')){
		return RECIPE_DIR .'/templates/taxonomy-recipe_cuisine.php';
	}
	if( is_tax('recipe_method')){
		return RECIPE_DIR .'/templates/taxonomy-recipe_method.php';
	}


}
// recipe archive page
function cookpro_get_custom_post_type_template( $archive_template ) {
	global $post;

	if ( is_post_type_archive ( 'recipe' ) ) {
		$archive_template = RECIPE_DIR . '/templates/archive-recipe.php';
	}
	if ( get_post_type() == 'recipe'
		&& file_exists( RECIPE_DIR . '/templates/archive-recipe.php' )
		&& ! file_exists( get_stylesheet_directory() . '/archive-recipe.php' )
		&& ! file_exists( get_template_directory() . '/archive-recipe.php' ) ) {
		$archive_template = RECIPE_DIR . '/templates/archive-recipe.php';
	} elseif ( get_post_type() == 'recipe' && file_exists( get_stylesheet_directory() . '/archive-recipe.php' ) ) {
		$archive_template = get_stylesheet_directory() . '/archive-recipe.php';
	} elseif ( get_post_type() == 'recipe' && file_exists( get_template_directory() . '/archive-recipe.php' ) ) {
		$archive_template = get_template_directory() . '/archive-recipe.php';
	}
	return $archive_template;
}
add_filter('taxonomy_template', 'cookpro_taxonomy_posttypes');
add_filter('archive_template', 'cookpro_get_custom_post_type_template');
