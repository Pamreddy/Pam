<?php
// CUSTOM META BOXES
//--------------------------------------------------------
if ( ! class_exists( 'Aivah_Recipe_Customfields' ) ) {
	class Aivah_Recipe_Customfields {

		function __construct( $meta_box ) {
			$this->_meta_box = $meta_box;
			add_action( 'admin_menu',array( &$this, 'metabox' ) );
			add_action( 'save_post',array( &$this, 'savemeta' ), 10, 2 );
		}

		// Add meta box
		function metabox() {
			foreach ( $this->_meta_box['page'] as $page ) {
				add_meta_box( $this->_meta_box['id'], $this->_meta_box['title'], array( &$this, 'show_metabox' ), $page, $this->_meta_box['context'], $this->_meta_box['priority'] );
			}
		}

		// Callback function to show fields in meta box
		function show_metabox() {

			global $page_layout, $post,$meta_box;

			// M E T A B O X   W R A P
			//--------------------------------------------------------
			echo '<div class="at-admin-meta-options">';
			// Use nonce for verification
			echo '<input type="hidden" name="rcp_page_layout_nonce" value="', wp_create_nonce( plugin_dir_path( __FILE__ ) ), '" />';

			foreach ( $this->_meta_box['fields'] as $field ) {

				// get current post meta data
				$meta = get_post_meta( $post->ID, $field['id'], true );

				//Default Meta Array Value if empty
				if ( $meta == '' ) { $meta = $field['std']; }

				if ( ! isset( $field['class'] ) ) { $field['class'] = ''; }
				if ( ! isset( $field['desc'] ) ) { $field['desc'] = ''; }

				// M E T A B O X   O P T I O N S
				//--------------------------------------------------------
				echo '<div class="at-form-field' . $field['class'] . '">','<div class="at-label"><label>', $field['name'], '</label></div>',
				'<div class="at-input">';
				switch ( $field['type'] ) {
					case 'text':
						echo '<input type="text" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" size="25" />';
						break;
					case 'color':
						echo '<div class="meta_page_selectwrap"><input class="color"  name="' . $field['id'] . '" id="' . $field['id'] . '" type="text" value="', $meta ? $meta : $field['std'], '"  />';
						echo '<div id="' . $field['id'] . '_color" class="wpcolorSelector"><div></div></div></div>';
						break;
					case 'textarea':
						$meta = (is_array($meta)) ? wp_json_encode($meta) : $meta ;
						echo '<textarea name="', $field['id'], '" id="', $field['id'], '" cols="60" rows="6" style="resize: both;">', $meta ? $meta : $field['std'], '</textarea>';
						break;
					case 'select':
						echo '<select class="select" name="', $field['id'], '" id="', $field['id'], '">';
						foreach ( $field['options'] as $key => $value ) {
							echo '<option value="' . $key . '"', $meta == $key ? ' selected="selected"' : '', '>', $value, '</option>';
						}
						echo '</select>';
						break;
					case 'gallery_meta':
						echo '<div id="recipe_images_container">';
						echo '<ul class="recipe_images">';
						if ( metadata_exists( 'post', $post->ID, $field['id'] ) ) {
							$recipe_image_gallery = get_post_meta( $post->ID, $field['id'], true );
						} else {
							$recipe_image_gallery = '';
						}
						$attachments = array_filter( explode( ',', $recipe_image_gallery ) );
						if ( $attachments ) {
							foreach ( $attachments as $attachment_id ) {
								echo '<li class="image" data-attachment_id="' . esc_attr( $attachment_id ) . '">
								' . wp_get_attachment_image( $attachment_id, 'thumbnail' ) . '
								<ul class="actions">
								<li><a href="#" class="delete tips" data-tip="' . esc_attr__( 'Delete image', 'cookpro_textdomain' ).'">' . esc_attr__( 'Delete', 'cookpro_textdomain' ) . '</a></li>
								</ul>
								</li>';
							}
						}
						echo '</ul>';
						echo '<input type="hidden" id="recipe_image_gallery" name="'.$field['id'].'" value="'. esc_attr( $recipe_image_gallery ).'" />';
						echo '</div>';
						echo '<p class="add_recipe_images hide-if-no-js">';
						echo '<a href="#" data-choose="'. esc_html__( 'Add Images to Recipe Gallery', 'cookpro_textdomain' ).'" data-update="' . esc_html__( 'Add to gallery', 'cookpro_textdomain' ).'" data-delete="'. esc_html__( 'Delete image', 'cookpro_textdomain' ).'" data-text="'. esc_html__( 'Delete', 'cookpro_textdomain' ).'">'.esc_html__( 'Add recipe gallery images', 'recipe-hero' ).'</a>';
						echo '</p>';
						break;
					case 'multiselect':
						echo '<div class="select_wrapper2">';
						$count = count( $field['options'] );
						if ( $count > 0 ) {
							echo '<select multiple="multiple"  name="', $field['id'], '[]" id="', $field['id'], '[]">';
							foreach ( $field['options'] as $key => $value ) {
								echo '<option value="' . $key . '"',  ( is_array( $meta ) && in_array( $key, $meta ) ) ? ' selected="selected"' : '', '>', $value, '</option>';
							}
							echo '</select>';
						} else {
							echo '<strong>' . esc_html__( 'No Posts in Categories', 'cookpro_textdomain' ) . '</strong>';
						}
						echo '</div>';
						break;
					case 'checkbox':
						$meta != '' ? 'on' : 'off';
						echo '<input  type="checkbox" name="', $field['id'], '" id="', $field['id'], '"', $meta == 'on' ? ' checked="checked"' : '', ' />
						<label for="',$field['id'],'">',$field['desc'],'</label>';
						break;
					case 'multicheckbox':
						foreach ( $field['options'] as $key => $value ) {
						    echo '<div><input  type="checkbox"  ' , (isset( $meta[$key] ) == $key ) ? ' checked="checked"' : '','  name="',$field['id'],'[',$key,']','"    value="',$key,'" id="',$value,'"  /> ';
						    echo '<label for="',$value,'">',$value,'</label></div>';
						}
						break;
					case 'default_editor':
						$editor_settings = array(
							'wpautop' 		=> true,
							'media_buttons' => true,
							'editor_class'	=> '',
							'textarea_rows' => 5,
							'tabindex' 		=> 4,
							'teeny' 		=> true,
						);
						$recipe_meta_box_value = $meta ? $meta : $field['std'];
						wp_editor( $recipe_meta_box_value, $field['id'],$editor_settings );
						break;
					case 'custom_meta':
						$output = '<div id="custom_meta_field">';
						if ( ! empty( $meta ) ) {
							foreach ( $meta as $custom_meta ) {
								$output .= '<div class="custom-meta-row"><input  class="' . $field['class'] . '"  type="text" name="' . $field['id'] . '[]" value="' . $custom_meta . '" /> <a class="button button-secondary" href="javascript:void(0)" onClick="jQuery(this).parent().remove();">Delete</a></div>';
							}
						}
						$output .= '</div><button type="button" class="button button-primary button-small" name="add_custom_field" value="Add Row" onClick="addCustomMetaRow()">Add row</button>';
						?>
						<script>
						function addCustomMetaRow(){
							jQuery("#custom_meta_field").append("<div class='custom-meta-row'><input  class='<?php echo $field['class']; ?>' type='text' name='<?php echo $field['id'];?>[]' value='' /><a class='button button-secondary ' href='javascript:void(0)' onClick='jQuery(this).parent().remove();'>Delete</a></div>");
						}
						</script>
						<?php
						echo $output;
						break;
					case 'nutrition_meta':
					    $rcp_nutritions = get_post_meta( $post->ID, 'recipe_nutritions', true );
						if ( empty( $rcp_nutritions ) ) {
							$no_of_nutritions = 0;
						} else {
					    	$no_of_nutritions = count( $rcp_nutritions );
					    }

				      	echo '<div id="rcp-nutrition-wrap" class="rcp-fields-container" style="display: block;">';

					    echo '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
					    echo '<div class="rcp-sort-row-ds" style="width: 5%;"><span>#</span></div>';
					    echo '<div class="rcp-sort-row-dn" style="width: 34%;">' . esc_html__( 'Nutrition Name', 'cookpro_textdomain' ) . '</div>';
					    echo '<div class="rcp-sort-row-dv" style="width: 34%;">' . esc_html__( 'Nutrition Value', 'cookpro_textdomain' ) . '</div>';
					    echo '<div class="rcp-sort-row-da" style="width: 27%;">' . esc_html__( 'Action', 'cookpro_textdomain' ) . '</div>';
					    echo '</div>'; // field-nutrition

					    echo '<div class="rcp-fields-templates">';

					    echo '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
					    echo '<input name="" value="nutrition" data-field-name="[type]" type="hidden">';
					    echo '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><span class="dashicons dashicons-menu"></span></div>';

					    // Nutrition Name
						$rcp_nutritions_names = array(
							'Serving Size',
							'Calories',
							'Total Fat',
							'Saturated Fat',
							'Polyunsaturated Fat',
							'Monounsaturated Fat',
							'Trans Fat',
							'Cholesterol',
							'Sodium',
							'Potassium',
							'Total Carbohydrate',
							'Fiber',
							'Sugar',
							'Protein',
						);
					    echo '<div class="rcp_input rcp-sort-row-dn" style="width: 34%;">';
						echo '<div class="rcp-input-details">';
						// echo '<input name="" value="" data-field-name="[name]" type="text">';
						echo '<select name="" data-field-name="[name]">';
						foreach ( $rcp_nutritions_names as $key => $value ) {
							echo '<option value="' . $value . '">' . $value . '</option>';
						}
						echo '</select>';
					    echo '</div></div>';

					    // Nutrition Value
					    echo '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
					    echo '<div class="rcp-input-details">';
					    echo '<input name="" value="" data-field-name="[value]" type="text">';
					    echo '</div></div>';

					    // actions-holder
					    echo '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
					    echo '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
					    <span class="dashicons dashicons-admin-page"></span>
					    </a>';
					    echo '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
					    <span class="dashicons dashicons-trash"></span>
					    </a>';
					    echo '</div>';//.actions-holder
					    echo '</div>';//.rcp-sort-row
					    echo '</div>';//.rcp-fields-templates

					    echo '<div class="rcp-fields-live rcp-sort-table ui-sortable" data-field-index="' . $no_of_nutritions . '" data-name="' . $field['id'] . '">';
					    if ( ! empty( $rcp_nutritions ) && isset( $rcp_nutritions ) ) {
					    	foreach ( $rcp_nutritions as $key => $data ) {

								$rcp_field_name = $field['id'].'['.$key.']';
								$rcp_data_name = ! empty( $data['name'] ) ? $data['name'] : '';
								$rcp_data_value = ! empty( $data['value'] ) ? $data['value'] : '';

					        	echo '<div class="rcp-sort-row field-nutrition rcp-fields-row">';
					        	echo '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><span class="dashicons dashicons-menu"></span></div>';

					        	// name
					        	echo '<input name="' . $rcp_field_name . '[type]" value="nutrition" data-field-name="[type]" type="hidden">';

								echo '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
					        	echo '<div class="rcp-input-details">';
							    // echo '<input name="' . $rcp_field_name . '[name]" value="' . $rcp_data_name . '" data-field-name="[name]" type="text">';
								echo '<select name="' . $rcp_field_name . '[name]" data-field-name="[name]">';
								foreach ( $rcp_nutritions_names as $key => $value ) {
									echo '<option value="' . $value . '"  ' . selected( $rcp_data_name, $value ) . '>' . $value . '</option>';
								}
								echo '</select>';
					        	echo '</div></div>'; //.nutrition value

					        	// Value
					        	echo '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
					        	echo '<div class="rcp-input-details">';
					        	echo '<input name="' . $rcp_field_name . '[value]" value="' . $rcp_data_value . '" data-field-name="[value]" type="text">';
					        	echo '</div></div>'; //.measurement

					        	// Actions
					        	echo '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
					        	echo '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">';
					        	echo '<span class="dashicons dashicons-admin-page"></span>';
					        	echo '</a>';
					        	echo '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">';
					        	echo '<span class="dashicons dashicons-trash"></span>';
					        	echo '</a>';
					        	echo '</div>'; // actions-holder
					        	echo '</div>'; //.rcp_sort_row
					       	}
						}
					    echo '</div>'; //. rcp-fields-live
					    echo '<div class="rcp-repeater-actions">';
					    echo '<button class="button button-primary button-small" data-action="clone" data-clone="field-nutrition">' . esc_html__( 'Add Nutrition', 'cookpro_textdomain' ) . '</button>&nbsp;&nbsp;';
					    echo '</div>';//.rcp-repeater-actions -->
					    echo '</div>';// .rcp-ingre-wrap
					    break;
						case 'equipments_meta':
						    $rcp_equipments = get_post_meta( $post->ID, 'recipe_equipments', true );
							if ( empty( $rcp_equipments ) ) {
								$no_of_equipments = 0;
							} else {
						    	$no_of_equipments = count( $rcp_equipments );
						    }

					      	echo '<div id="rcp-equipment-wrap" class="rcp-fields-container" style="display: block;">';

						    echo '<div class="rcp-sort-row field-equipment rcp-fields-row">';
						    echo '<div class="rcp-sort-row-ds" style="width: 5%;"><span>#</span></div>';
						    echo '<div class="rcp-sort-row-dn" style="width: 34%;">' . esc_html__( 'Equipment Name', 'cookpro_textdomain' ) . '</div>';
						    echo '<div class="rcp-sort-row-da" style="width: 27%;">' . esc_html__( 'Action', 'cookpro_textdomain' ) . '</div>';
						    echo '</div>'; // field-nutrition

						    echo '<div class="rcp-fields-templates">';

						    echo '<div class="rcp-sort-row field-equipment rcp-fields-row">';
						    echo '<input name="" value="equipment" data-field-name="[type]" type="hidden">';
						    echo '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><span class="dashicons dashicons-menu"></span></div>';

						    // Equipment Value
						    echo '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
						    echo '<div class="rcp-input-details">';
						    echo '<input name="" value="" data-field-name="[value]" type="text">';
						    echo '</div></div>';

						    // actions-holder
						    echo '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
						    echo '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">
						    <span class="dashicons dashicons-admin-page"></span>
						    </a>';
						    echo '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">
						    <span class="dashicons dashicons-trash"></span>
						    </a>';
						    echo '</div>';//.actions-holder
						    echo '</div>';//.rcp-sort-row
						    echo '</div>';//.rcp-fields-templates
						    echo '<div class="rcp-fields-live rcp-sort-table ui-sortable" data-field-index="' . $no_of_equipments . '" data-name="' . $field['id'] . '">';
						    if ( ! empty( $rcp_equipments ) && isset( $rcp_equipments ) ) {
						    	foreach ( $rcp_equipments as $key => $data ) {
									$rcp_field_name = $field['id'].'[' . $key . ']';
									$rcp_equipment_name = ! empty( $data['value'] ) ? $data['value'] : '';
						        	echo '<div class="rcp-sort-row field-equipment rcp-fields-row">';
						        	echo '<div class="rcp-sort-icon-holder rcp-sort-row-ds order" style="width: 5%;"><span class="dashicons dashicons-menu"></span></div>';

						        	// name
						        	echo '<input name="' . $rcp_field_name . '[type]" value="equipment" data-field-name="[type]" type="hidden">';
						        	// Value
						        	echo '<div class="rcp_input rcp-sort-row-dv" style="width: 34%;">';
						        	echo '<div class="rcp-input-details">';
						        	echo '<input name="' . $rcp_field_name . '[value]" value="' . $rcp_equipment_name . '" data-field-name="[value]" type="text">';
						        	echo '</div></div>'; //.measurement
						        	// Actions
						        	echo '<div class="actions-holder rcp-sort-row-da action" style="width: 27%;">';
						        	echo '<a href="#" class="rcp-action-button clone-button" data-action="clone" title="' . esc_html__( 'Clone', 'cookpro_textdomain' ) . '">';
						        	echo '<span class="dashicons dashicons-admin-page"></span>';
						        	echo '</a>';
						        	echo '<a href="#" class="rcp-action-button remove-button" data-action="remove" title="' . esc_html__( 'Remove', 'cookpro_textdomain' ) . '">';
						        	echo '<span class="dashicons dashicons-trash"></span>';
						        	echo '</a>';
						        	echo '</div>'; // actions-holder
						        	echo '</div>'; //.rcp_sort_row
						       	}
							}
						    echo '</div>'; //. rcp-fields-live
						    echo '<div class="rcp-repeater-actions">';
						    echo '<button class="button button-primary button-small" data-action="clone" data-clone="field-equipment">' . esc_html__( 'Add Equipments', 'cookpro_textdomain' ) . '</button>&nbsp;&nbsp;';
						    echo '</div>';//.rcp-repeater-actions -->
						    echo '</div>';// .rcp-ingre-wrap
						    break;
					case 'recipe_timing_meta':
						$recipe_time_meta = $meta;
						$hrs = $mins  = '';
						if ( ! empty( $recipe_time_meta ) ) {
							$hrs = $recipe_time_meta['hrs'];
							$mins = $recipe_time_meta['mins'];
						}
						echo '<div class="rcp_input"><div class="rcp-input-details">';
						echo '<input name="' . $field['id'] . '_hrs" id="recipe_hrs" value="' . $hrs . '"  placeholder="' . esc_html__( 'Hours (eg:2)', 'cookpro_textdomain' ) . '" size="25" type="text">';
						echo '<p class="desc">' . esc_html__( 'Hours (eg:2)', 'cookpro_textdomain' ) . '</p>';
						echo '</div></div>'; //.rcp_input
						echo '<div class="rcp_input"><div class="rcp-input-details">';
						echo '<input name="' . $field['id'] . '_mins" id="recipe_mins" value="' . $mins . '" placeholder="' . esc_html__( 'Minutes (eg:35)', 'cookpro_textdomain' ) . '" size="25" type="text">';
						echo '<p class="desc">' . esc_html__( 'Minutes (eg:35)', 'cookpro_textdomain' ) . '</p>';
						echo '</div></div>'; //.mins
						break;
				}
				if ( $field['type'] != 'checkbox' ) {
					echo '<p class="desc">',$field['desc'],'</p>';
				}
				echo '</div></div>';
			}
			echo '</div>';
		}
		// E N D  - SHOW METABOX

		// S A V E   M E T A   D A T A
		//--------------------------------------------------------
		function savemeta( $post_id, $post ) {

			/* Verify the nonce before proceeding. */
			if ( ! isset( $_POST['rcp_page_layout_nonce'] ) || ! wp_verify_nonce( $_POST['rcp_page_layout_nonce'], plugin_dir_path( __FILE__ ) ) ) {
				return $post_id;
			}

			/* Get the post type object. */
			$post_type = get_post_type_object( $post->post_type );

			/* Check if the current user has permission to edit the post. */
			if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) ) {
				return $post_id;
			}

			// Is the user allowed to edit the post or page?
			foreach ( $this->_meta_box['fields'] as $field ) {
				$field_type = $field['type'] ;
				if ( $field_type === 'background' ) {
					if ( isset( $field['id'] ) && $field['id'] != '' ) {
						$bg_props = array();
						$bg_props[] = array(
							'image' 		=> isset( $_POST[ $field['id'] . '_image' ] ) ? $_POST[ $field['id'] . '_image' ] : '',
							'color' 		=> isset( $_POST[ $field['id'] . '_color' ] ) ? $_POST[ $field['id'] . '_color' ] : '',
							'repeat'		=> isset( $_POST[ $field['id'] . '_repeat' ] ) ? $_POST[ $field['id'] . '_repeat' ] : '',
							'position'		=> isset( $_POST[ $field['id'] . '_position' ] ) ? $_POST[ $field['id'] . '_position' ] : '',
							'attachement'	=> isset( $_POST[ $field['id'] . '_attachement' ] ) ? $_POST[ $field['id'] . '_attachement' ] : '',
						);

						if ( get_post_meta( $post_id, $field['id'],true ) == '' ) {
							add_post_meta( $post_id, $field['id'], $bg_props, true );
						} elseif ( $bg_props != get_post_meta( $post_id, $field['id'], true ) ) {
							update_post_meta( $post_id, $field['id'], $bg_props );
						}
					}
				}
				if ( $field_type == 'gallery_meta' ) {
					$attachment_ids = array_filter( explode( ',', sanitize_text_field( $_POST[ $field['id'] ] ) ) );
					update_post_meta( $post_id, $field['id'], implode( ',', $attachment_ids ) );
				}
				if ( $field_type == 'recipe_timing_meta' ) {
					if ( isset( $field['id'] ) && $field['id'] != '' ) {
						$rcp_time_props = array();
						$rcp_time_props = array(
							'hrs' => isset( $_POST[ $field['id'] . '_hrs' ] ) ? $_POST[ $field['id'] . '_hrs' ] : '',
							'mins' => isset( $_POST[ $field['id'] . '_mins' ] ) ? $_POST[ $field['id'] . '_mins' ] : '',
						);
						if ( get_post_meta( $post_id, $field['id'],true ) == '' ) {
							add_post_meta( $post_id, $field['id'], $rcp_time_props, true );
						} elseif ( $rcp_time_props != get_post_meta( $post_id, $field['id'], true ) ) {
							update_post_meta( $post_id, $field['id'], $rcp_time_props );
						}
					}
				} else {
					$old = get_post_meta( $post_id, $field['id'], true );
					$new = isset( $_POST[ $field['id'] ] ) ? $_POST[ $field['id'] ] : '';
					if ( $field['type'] == 'dateformat' ) {
						$new = strtotime( $new );
					}
					if ( $new && $new != $old ) {
						update_post_meta( $post_id, $field['id'], $new );
					} elseif ( '' == $new && $old ) {
						delete_post_meta( $post_id, $field['id'], $old );
					}
				}
			}
		}

		// function get_custom_options - fetch pages/posts/cats
		//--------------------------------------------------------
		function get_custom_options( $type ) {
			switch ( $type ) {
				case 'page':
					$entries = get_pages( 'title_li=&orderby=name' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[ $entry->ID ] = $entry->post_title;
					}
					break;
				case 'cat':
					$entries = get_categories( 'title_li=&orderby=name&hide_empty=0' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[ $entry->term_id ] = $entry->name;
					}
					break;
				case 'post':
					$entries = get_posts( 'orderby=title&numberposts=-1&order=ASC' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[ $entry->ID ] = $entry->post_title;
					}
					break;
				default:
					$iva_objects = false;
			}
			return $iva_objects;
		}
	}
}
foreach ( $this->meta_box as $meta_box ) {
	$aivah_recipe_customfields = new Aivah_Recipe_Customfields( $meta_box );
}
