<?php get_header(); ?>
<?php
		/**
		 * rcp_before_main_content hook.
		 *
		 * outputs opening divs for the content
		 */
		do_action( 'rcp_before_main_content' );
	?>
	<?php
		$columns = 3;
		$out = '';
		if ( $columns == '3' ) {
			$class = 'item3';
		}
		if ( $columns == '2' ) {
			$class = 'item2';
		}
		$hide_cooktime  = rcp_get_option( 'rcp_hide_cooktime', 'no' );
		$hide_difflevel = rcp_get_option( 'rcp_hide_difflevel', 'no' );
		$hide_yields    = rcp_get_option( 'rcp_hide_yields', 'no');
		$hide_ratings   = rcp_get_option( 'rcp_hide_ratings', 'no');
		$hide_author    = get_option( 'rcp_hide_author_name' ) ? get_option( 'rcp_hide_author_name' ) : get_option( 'rcp_hide_author' );
		$display_style  = rcp_get_option( 'rcp_display_style', 'style1');

		if ( get_query_var('paged') ) {
			$paged = get_query_var('paged');
		} elseif ( get_query_var('page') ) {
			$paged = get_query_var('page');
		} else {
			$paged = 1;
		}
		$column_index = 0;
		$taxonomy_recipe_tag_obj = $wp_query->get_queried_object();
		$args = array(
			'post_type'	=> 'recipe',
			'tax_query' => array(
					array(
						'taxonomy' => 'recipe_tag',
						'field' => 'id',
						'terms' => $taxonomy_recipe_tag_obj->term_id
					)
			),
			'paged'		=> $paged,
			'orderby'	=> 'DESC',
			'order'		=> 'ID'
		);

		$rcp_tag_query = new WP_Query( $args );
		if ( $rcp_tag_query->have_posts() ) {

			$out .= '<div class="rcp-highest-rated-sh-module">';
			$out .= '<div class="rcp-highest-rated-sh-module-content">';

			while ( $rcp_tag_query->have_posts() ) : $rcp_tag_query->the_post();
				global $post;

				$column_index++;

				$out .= '<div class="rcp-highest-rated-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
				$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
				$out .= '</div>'; //.rcp-post-item
				if ( $column_index == $columns ) {
					$column_index = 0;
				}
			endwhile;
			wp_reset_postdata();
			$out .= '</div>'; //.rcp-highest-rated-module-content
			$out .= '</div>'; //.rcp-highest-rated-module-row
			ob_start();
			$out .= rcp_pagination();
			$out .= ob_get_contents();
			ob_end_clean();
		} else {
			$out .= '<p class="rcp-main-highest-rated-norecipe">' . esc_html__( 'No recipes were found matching your selection.', 'cook-pro' ) . '</p>';
		}
		echo $out;
		?>
		<?php
			/**
			 * rcp_after_main_content hook.
			 *
			 * outputs closing divs for the content
			 */
			do_action( 'rcp_after_main_content' );
		?>
		<?php get_sidebar(); ?>
		<!-- .sidebar -->
<?php
get_footer();
