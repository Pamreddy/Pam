<?php
/**
* Class Aivah_Recipe_Zip
*/
if ( ! class_exists( 'Aivah_Recipe_Zip' ) ) {
	class Aivah_Recipe_Zip {
		private $zip;
		public static function is_zip_exists() {
			$exists = class_exists( 'ZipArchive' );
			return $exists;
		}
		public function extract( $src, $dest ) {
			$zip = new ZipArchive;
			if ( $zip->open( $src ) == true ) {
				$zip->extractTo( $dest );
				$zip->close();
				return true;
			}
			return false;
		}
	}
}

/**
 * function rcp_throw_error
 * throws error message
 */
if ( ! function_exists( 'rcp_throw_error' ) ) {
	function rcp_throw_error( $message ) {
		throw new Exception( $message );
	}
}

/**
 * function rcp_check_create_dir
 * checks directory exist or not
 * if not it creates directory
 */
if ( ! function_exists( 'rcp_check_create_dir' ) ) {
	function rcp_check_create_dir( $dir ) {
		if ( ! is_dir( $dir ) ) { mkdir( $dir ); }
		if ( ! is_dir( $dir ) ) { return "Could not create directory: $dir"; }
	}
}

/**
 * function rcp_copy_dir
 * copys directory
 */
if ( ! function_exists( 'rcp_copy_dir' ) ) {
	function rcp_copy_dir( $path, $dest ) {
		if ( is_dir( $path ) ) {
			@mkdir( $dest );
			$objects = scandir( $path );
			if ( count( $objects ) > 0 ) {
				foreach ( $objects as $file ) {
					if ( '.' == $file || '..' == $file ) { continue; }

					// go on
					if ( is_dir( $path . '/' . $file ) ) {
						rcp_copy_dir( $path . '/' . $file, $dest . '/' . $file );
					} else {
						@copy( $path . '/' . $file, $dest . '/' . $file );
					}
				}
			}
			return true;
		} elseif ( is_file( $path ) ) {
			return copy( $path, $dest );
		} else {
			return false;
		}
	}
}

/**
 * function rcp_delete_dir
 * deletes directory
 */
if ( ! function_exists( 'rcp_delete_dir' ) ) {
	function rcp_delete_dir( $str ) {
		if ( is_file( $str ) ) { return @unlink( $str );
		} elseif ( is_dir( $str ) ) {
			$scan = glob( rtrim( $str,'/' ) . '/*' );
			if ( ! empty( $scan ) ) {
				foreach ( $scan as $index => $path ) {
					rcp_delete_dir( $path );
				}
			}
			return @rmdir( $str );
		}
	}
}

/**
* function rcp_update_plugin
* Updates the plugin
*/
add_action( 'wp_ajax_rcp_update_plugin_ajax_action', 'rcp_update_plugin' );
add_action( 'wp_ajax_nopriv_rcp_update_plugin_ajax_action', 'rcp_update_plugin' );
function rcp_update_plugin() {
	// Creates Zip Class Object
	$rcp_zip = new Aivah_Recipe_Zip();

	try {
		if ( function_exists( 'unzip_file' ) == false ) {
			if ( Aivah_Recipe_Zip::is_zip_exists() == false ) {
				rcp_throw_error( esc_html__( "The ZipArchive php extension not exists, can't extract the update file. Please turn it on in php ini.","cookpro_textdomain" ) );
			}
		}
		echo esc_html__( 'Update in progress...','cookpro_textdomain' );

		// If update files empty returns error
		if ( empty( $_FILES ) ) {
			rcp_throw_error( esc_html__( 'Update file not found.','cookpro_textdomain' ) );
		}

		// Current Plugin main file path
		$rcp_main_file 			= RECIPE_DIR . '/cook-pro/';

		// Update file path info
		$rcp_file_name 			= $_FILES['rcp_update_file']['name'];
		$rcp_file_temp_path 	= $_FILES['rcp_update_file']['tmp_name'];
		$rcp_file_type 			= $_FILES['rcp_update_file']['type'];

		// Current Plugin path
		$rcp_plugin_path 		= dirname( $rcp_main_file ) . '/';

		// Current Plugin temporary path
		$rcp_plugin_temp_path 	= $rcp_plugin_path . 'temp/';

		// Current Plugin path info
		$rcp_plugin_file_info		= pathinfo( $rcp_main_file );
		$rcp_plugin_file_basename 	= $rcp_plugin_file_info['basename'];
		$rcp_plugin_file_name 		= str_replace( '.php','',$rcp_plugin_file_basename );

		// checks uploaded file is not empty
		if ( empty( $rcp_file_name ) ) {
			rcp_throw_error( esc_html__( 'You have not selected a file to upload, please select a file.','cookpro_textdomain' ) );
		}

		// Checks uploaded file is zip file or not
		$rcp_upload_file_ext = pathinfo( $rcp_file_name, PATHINFO_EXTENSION );
		if ( 'zip' != $rcp_upload_file_ext ) {
			rcp_throw_error( esc_html__( 'Uploaded file is not a zip file, Select zip file and upload.','cookpro_textdomain' ) );
		}

		// Checks temporary folder is exist or not
		if ( file_exists( $rcp_file_temp_path ) == false ) {
			rcp_throw_error( esc_html__( 'Cannot find the update files','cookpro_textdomain' ) );
		}

		// Crates temporary folder
		rcp_check_create_dir( $rcp_plugin_temp_path );

		// Copys the zip file.
		$rcp_zip_filepath = $rcp_plugin_temp_path . $rcp_file_name;

		// Moves the zip file.
		$rcp_success = move_uploaded_file( $rcp_file_temp_path, $rcp_zip_filepath );

		// If success
		if ( false == $rcp_success ) {
			rcp_throw_error( "Can't move the update files here: {$rcp_zip_filepath}." );
		}

		if ( function_exists( 'unzip_file' ) == true ) {
			WP_Filesystem();
			$response = unzip_file( $rcp_zip_filepath, $rcp_plugin_temp_path );
		} else {
			$rcp_zip->extract( $rcp_zip_filepath, $rcp_plugin_temp_path );
		}

		// Scans update file and returns all files
		$rcp_tmp_dir_files = scandir( $rcp_plugin_temp_path );
		$rcp_extracted_files 	= array();
		foreach ( $rcp_tmp_dir_files as $file ) {
			if ( '.' == $file || '..' == $file ) { continue; }
			// Uploaded file path
			$filepath = $rcp_plugin_temp_path . $file;
			// If update file is directory then returns extracted folder
			if ( is_dir( $filepath ) ) {
				$rcp_extracted_files[] = $file;
			}
		}

		// Gets extracted folder
		$rcp_extracted_folder = $rcp_extracted_files;

		if ( empty( $rcp_extracted_folder ) ) {
			rcp_throw_error( esc_html__( 'The update folder is not extracted','cookpro_textdomain' ) );
		}
		if ( count( $rcp_extracted_folder ) > 1 ) {
			rcp_throw_error( esc_html__( 'Extracted folders are more then 1. Please check the update file.','cookpro_textdomain' ) );
		}

		// Gets update folder
		$rcp_uploaded_folder = $rcp_extracted_folder[0];
		if ( empty( $rcp_uploaded_folder ) ) {
			rcp_throw_error( esc_html__( 'Wrong update folder.','cookpro_textdomain' ) );
		}

		// Checks if update folder is match the main plugin filename
		if ( $rcp_uploaded_folder != $rcp_plugin_file_name ) {
			rcp_throw_error( esc_html__( 'The update folder do not match the current plugin folder, please check the updated file.','cookpro_textdomain' ) );
		}

		// Update file path
		$rcp_update_file_path  = $rcp_plugin_temp_path . $rcp_uploaded_folder . '/';

		//check some file in folder to validate it's the real one:
		$rcp_check_filepath = $rcp_update_file_path . $rcp_uploaded_folder . '.php';

		if ( file_exists( $rcp_check_filepath ) == false ) {
			// delete the update file from temporary path
			rcp_delete_dir( $rcp_plugin_temp_path );

			//rcp_throw_error("The file: $rcp_uploaded_folder.php not found in update folder.");
			rcp_throw_error( esc_html__( 'Wrong update folder.','cookpro_textdomain' ) );
		}

		// Copy update files to destination folder
		rcp_copy_dir( $rcp_update_file_path, $rcp_plugin_path );

		// delete the update file from temporary path
		rcp_delete_dir( $rcp_plugin_temp_path );

		echo esc_html__( 'Plugin Updated Successfully and redirecting...', 'cookpro_textdomain' );
		echo "<script>location.href='edit.php?post_type=recipe&page=recipe_settings'</script>";

	} catch ( Exception $e ) {
		$rcp_message  = $e->getMessage();
		$rcp_message .= '<br>' . esc_html__( 'Please update the plugin manually via the ftp','cookpro_textdomain' );
		echo '<div style="color:#ff0000;font-size:20px;"><b>' . esc_html__( 'Update Error:','cookpro_textdomain' ) . '</b>' . esc_html( $rcp_message ) . '</div><br>';
		echo '<a href="edit.php?post_type=recipe&page=recipe_settings">' . esc_html__( 'Go Back','cookpro_textdomain' ) . '</a>';
		exit();
	}
}
