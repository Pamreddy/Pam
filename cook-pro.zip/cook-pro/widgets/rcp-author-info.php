<?php
/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'rcp_author_info' );
function rcp_author_info() {
	register_widget( 'Rcp_Author_Info_Widget' );
}
// Define the Widget as an extension of WP_Widget
class Rcp_Author_Info_Widget extends WP_Widget {

	/* constructor */
	public function __construct() {

		/* Widget settings. */
		$widget_ops = array(
			'classname'		=> 'rcp-author-info',
			'description'	=> esc_html__( 'Displays Author Info.', 'cook-pro' ),
		);

		/* Widget control settings. */
		$control_ops = array(
			'width'		=> 300,
			'height'	=> 350,
			'id_base'	=> 'rcp_author_info',
		);
		/* Create the widget. */
		parent:: __construct( 'rcp_author_info', esc_html__( 'Cook Pro - Recipe Author Info','cook-pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );

		$out = '';

		$title 	= $instance['title'];

		$out .= $before_widget;

		// Title
		if ( $title ) {
			$out .= $before_title . $title . $after_title;
		}
		global $post, $current_user;
		// USer Profile Info
		$current_user 	 = wp_get_current_user();
		$rcp_user_info 	 = get_userdata( $current_user->ID );
		$rcp_user_avatar = rcp_get_avatar( $current_user->ID, 100 );
		$rcp_user_url  	 = $current_user->user_url;
		$rcp_user_position = get_user_meta( $current_user->ID, 'position', true );
		$rcp_user_desc 	 = $current_user->description;
		$rcp_user_link	= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) );
		if ( is_user_logged_in() ) {
			$out .= '<div class="rcp-wg-chef-wrapper">';
			$out .= '<div class="rcp-wg__chef_thumb">';
			$out .= $rcp_user_avatar;
			$out .= '</div>';//.rcp-wg__chef_thumb

			$out .= '<h2 class="rcp-wg__chef_name">' . $rcp_user_info->display_name;
			if ( ! empty( $rcp_user_position ) ) {
				$out .= '<span>' . $rcp_user_position . '</span>';
			}
			$out .= '</h2>';
			$out .= '<div class="rcp-wg__chef_info_more">';
			if ( $rcp_user_desc ) {
				$out .= wpautop( $rcp_user_desc );
			}
			$out .= '</div>';//.rcp__info
			$out .= '<a rel="nofollow" class="rcp-wg__chef_info_more" href="' . esc_url( $rcp_user_link ) . '"><span>' . esc_html__( 'View My Profile', 'cook-pro' ) . '</span></a>';
			$out .= '</div>';//.rcp-wg-chef-wrapper
		}
		$out .= $after_widget;
		if ( is_user_logged_in() ) {
			echo $out;
		}
	}
	//processes widget options to be saved

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );

		return $instance;
	}

	// Outputs the options form on admin
	function form( $instance ) {

		/* Set up some default widget settings. */
		$instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
		$title = strip_tags( $instance['title'] );

		echo '<p>';
		echo '<label for="' . $this->get_field_id( 'title' ) . '">' . esc_html__( 'Title:', 'cook-pro' ) . '</label>';
		echo '<input class="widefat" id="' . $this->get_field_id( 'title' ) . '" name="' . $this->get_field_name( 'title' ) . '" type="text" value="' . esc_html( $title ) . '" />';
		echo '</p>';
	}
}
