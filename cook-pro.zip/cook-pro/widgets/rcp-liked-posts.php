<?php
/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'rcp_liked_posts' );
function rcp_liked_posts() {
	register_widget( 'Rcp_Liked_Posts_Widget' );
}
// Define the Widget as an extension of WP_Widget
class Rcp_Liked_Posts_Widget extends WP_Widget {

	/* constructor */
	public function __construct() {

		/* Widget settings. */
		$widget_ops = array(
			'classname'		=> 'rcp-liked-posts',
			'description'	=> esc_html__( 'Displays Most Liked Posts.', 'cook-pro' ),
		);

		/* Widget control settings. */
		$control_ops = array(
			'width'		=> 300,
			'height'	=> 350,
			'id_base'	=> 'rcp_liked_posts',
		);
		/* Create the widget. */
		parent:: __construct( 'rcp_liked_posts', esc_html__( 'Cook Pro - Recipe Most Liked Posts','cook-pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );

		$out = '';

		$title 				= $instance['title'];
		$limit 				= $instance['limit'];
		$disable_categories = isset( $instance['disable_categories'] ) ? $instance['disable_categories'] : false;
		$disable_cuisines 	= isset( $instance['disable_cuisines'] ) ? $instance['disable_cuisines'] : false;

		$out .= $before_widget;

		// Title
		if ( $title ) {
			$out .= $before_title . $title . $after_title;
		}
		$rcp_args = array(
			'post_type' 	=> 'recipe',
			'post_status' 	=> 'any',
			'posts_per_page' => $limit,
			'meta_key' 		=> 'rcp_post_like',
			'orderby' 		=> 'meta_value_num',
			'order' 		=> 'DESC',
		);

		$rcp_query = new WP_Query( $rcp_args );
		$out .= '<div class="rcp-wg-lposts">';
		if (  $rcp_query->have_posts() ) :
			$out .= '<ul>';
			while ( $rcp_query->have_posts() ) : $rcp_query->the_post();
				$out .= '<li class="rcp-wg-lposts-item">';
				$rcp_like_count = get_post_meta( get_the_ID(), 'rcp_post_like', true );
				$rcp_category_term_list = wp_get_post_terms( get_the_ID(), 'recipe_cat', array( 'fields' => 'names' ) );
				$rcp_cuisines_term_list = wp_get_post_terms( get_the_ID(), 'recipe_cuisine', array( 'fields' => 'names' ) );
				if ( $rcp_like_count != 0 ) {
					if ( has_post_thumbnail() ) {
						$out .= '<div class="wg__thumb_link">';
						$out .= '<a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">';
						$out .= get_the_post_thumbnail( get_the_id(), array( 200, 300 ), array( 'class' => 'wg__thumb' ) );
						$out .= '</a>';
						$out .= '</div>';
					}
					$out .= '<div class="rcp-wg-lposts-wrap">';
					$out .= '<h2 class="wg__title"><a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">' . get_the_title() . '</a></h2>';
					$out .= '<div class="pmeta">';
					if ( $disable_categories != 'on' ) {
						if ( count( $rcp_category_term_list ) >= 1 ) {
							$out .= '<span class="rcp-cat"><strong>' . esc_html__( 'Categories', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( get_the_ID(), 'recipe_cat', '', ', ' ) ) . '</span>';
						}
					}
					if ( $disable_cuisines != 'on' ) {
						if ( count( $rcp_cuisines_term_list ) >= 1 ) {
							$out .= '<span class="rcp-cus"><strong>' . esc_html__( 'Cuisines', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( get_the_ID(), 'recipe_cuisine', '', ', ' ) ) . '</span>';
						}
					}
					$out .= '<span class="wg__likes"><i class="fa fa-thumbs-o-up fa-fw"></i>' . $rcp_like_count . '</span>';
					$out .= '</div>'; //.pmeta
					
					$out .= '</div>'; //.rcp-wg-lposts-wrap
				}
				$out .= '</li>'; //.rcp-wg-lposts-item
			endwhile;
			$out .= '</ul>';
		endif;
		$out .= '</div>';
		$out .= $after_widget;

		echo $out;
	}
	// processes widget options to be saved

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] 				= strip_tags( $new_instance['title'] );
		$instance['limit'] 				= absint( $new_instance['limit'] );
		$instance['disable_categories']	= strip_tags( $new_instance['disable_categories'] );
		$instance['disable_cuisines'] 	= strip_tags( $new_instance['disable_cuisines'] );

		return $instance;
	}

	// Outputs the options form on admin
	function form( $instance ) {

		/* Set up some default widget settings. */
		$instance 			= wp_parse_args( (array) $instance, array( 'title' => '' ) );
		$title 				= strip_tags( $instance['title'] );
		$limit 				= isset( $instance['limit'] ) ? absint( $instance['limit'] ) : 5;
		$disable_categories = isset( $instance['disable_categories'] ) ? (bool) $instance['disable_categories'] : false;
		$disable_cuisines 	= isset( $instance['disable_cuisines'] ) ? (bool) $instance['disable_cuisines'] : false;

		// Title
		echo '<p>';
		echo '<label for="' . $this->get_field_id( 'title' ) . '">' . esc_html__( 'Title:', 'cook-pro' ) . '</label>';
		echo '<input class="widefat" id="' . $this->get_field_id( 'title' ) . '" name="' . $this->get_field_name( 'title' ) . '" type="text" value="' . esc_html( $title ) . '" />';
		echo '</p>';

		// Limit
		echo '<p>';
		echo '<label for="' . $this->get_field_id( 'limit' ) . '">' . esc_html__( 'Number of posts to show:', 'cook-pro' ) . '</label>';
		echo '<input class="widefat" id="' . $this->get_field_id( 'limit' ) . '" name="' . $this->get_field_name( 'limit' ) . '" type="text" value="' . esc_html( $limit ) . '" />';
		echo '</p>';

		// Disable Categories
		$category_checked = checked( $disable_categories,true,false );
		echo '<p>';
		echo '<input class="checkbox" type="checkbox"  ' . esc_attr( $category_checked ) . ' id="' . $this->get_field_id( 'disable_categories' ) . '" name="' . $this->get_field_name( 'disable_categories' ) . '" />';
		echo '<label for="' . $this->get_field_id( 'disable_categories' ) . '">' . esc_html__( 'Disable Categories:', 'cook-pro' ) . '</label>';
		echo '</p>';

		// Disable Cuisines
		$cuisine_checked = checked( $disable_cuisines,true,false );
		echo '<p>';
		echo '<input class="checkbox" type="checkbox"  ' . esc_attr( $cuisine_checked ) . ' id="' . $this->get_field_id( 'disable_cuisines' ) . '" name="' . $this->get_field_name( 'disable_cuisines' ) . '" />';
		echo '<label for="' . $this->get_field_id( 'disable_cuisines' ) . '">' . esc_html__( 'Disable Cuisines:', 'cook-pro' ) . '</label>';
		echo '</p>';
	}
}
