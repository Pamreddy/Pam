<?php
/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'rcp_chef' );
function rcp_chef() {
	register_widget( 'Rcp_Chef_Widget' );
}
// Define the Widget as an extension of WP_Widget
class Rcp_Chef_Widget extends WP_Widget {

	/* constructor */
	public function __construct() {

		/* Widget settings. */
		$widget_ops = array(
			'classname'		=> 'rcp-chef',
			'description'	=> esc_html__( 'Featured Chef.', 'cook-pro' ),
		);

		/* Widget control settings. */
		$control_ops = array(
			'width'		=> 300,
			'height'	=> 350,
			'id_base'	=> 'rcp_chef',
		);
		/* Create the widget. */
		parent:: __construct( 'rcp_chef', esc_html__( 'Cook Pro - Featured Chef','cook-pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );

		$out = '';

		$title 	 = $instance['title'];
		$chef_id = (int)$instance['chef_id'];

		$out .= $before_widget;

		// Title
		if ( $title ) {
			$out .= $before_title . $title . $after_title;
		}
		$rcp_user_data = get_user_by( 'id', $chef_id );
		if ( ! empty( $rcp_user_data ) ) {

			$rcp_user_url 	 	= $rcp_user_data->user_url;
		 	$rcp_user_desc	  	= get_user_meta( $rcp_user_data->ID, 'description', true );
			$rcp_user_position	= get_user_meta( $rcp_user_data->ID, 'position', true );
			$rcp_user_link		= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $rcp_user_data->user_login ;

			$out .= '<div class="rcp-wg-chef-wrapper">';
			$out .= '<div class="rcp-wg__chef_thumb">';
			$out .= '<a href="' . esc_url( $rcp_user_url ) . '" class="wg__chef_thumb_link">';
			$out .= rcp_get_avatar( $rcp_user_data->ID, 100 );
			$out .= '</a>';
			$out .= '</div>'; //.rcp-wg__chef_thumb
			$out .= '<h2 class="rcp-wg__chef_name">';
			$out .= $rcp_user_data->display_name;
			if ( ! empty( $rcp_user_position ) ) {
				$out .= '<span>' . $rcp_user_position . '</span>';
			}
			$out .= '</h2>';
			$out .= '<div class="rcp-wg__chef_info_more">';
			if ( ! empty( $rcp_user_desc ) ) {
				$out .= '<p>' . rcp_desc_max_charlength( $rcp_user_desc,200 ) . '</p>';
			}
			$out .= '<a rel="nofollow" rel="noreferrer"class="rcp-wg__chef_more" href="' . esc_url( $rcp_user_link ) . '"><span>' . esc_html__( 'More From This Chef', 'cook-pro' ) . '</span></a>';
			$out .= '</div>'; //.rcp-wg__chef_info_more
			$out .= '</div>'; //.rcp-wg-chef-wrapper
		}
		$out .= $after_widget;
		echo $out;
	}
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] 	 = strip_tags( $new_instance['title'] );
		$instance['chef_id'] = (int)$new_instance['chef_id'];

		return $instance;
	}

	// Outputs the options form on admin
	function form( $instance ) {

		/* Set up some default widget settings. */
		$instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
		$title 	  = strip_tags( $instance['title'] );
		$chef_id  = isset( $instance['chef_id'] ) ? (bool) $instance['chef_id'] : false;

		// Title
		echo '<p>';
		echo '<label for="' . $this->get_field_id( 'title' ) . '">' . esc_html__( 'Title:', 'cook-pro' ) . '</label>';
		echo '<input class="widefat" id="' . $this->get_field_id( 'title' ) . '" name="' . $this->get_field_name( 'title' ) . '" type="text" value="' . esc_html( $title ) . '" />';
		echo '</p>';

		// List Authors
		$args = array(
			'orderby' => 'ID',
			'order'  => 'ASC',
		);
		$rcp_user_list_query = get_users( $args );
		echo '<p>';
		echo '<label for="' . $this->get_field_id( 'chef_id' ) . '">' . esc_html__( 'Choose Chef', 'cook-pro' ) . '</label>';
		echo '<select name="' . $this->get_field_name( 'chef_id' ) . '" id="' . $this->get_field_id( 'chef_id' ) . '">';
		foreach ( $rcp_user_list_query as $user_data ) {
			$selected = selected( $chef_id, $user_data->ID, false );
			echo '<option value="' . $user_data->ID . '"  ' . $selected . '>' . $user_data->display_name . '</option>';	
		}
		echo '</select>';
		echo '</p>';
	}
}
