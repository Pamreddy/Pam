<?php
/*
 * function rcp_custom_posttype
 * post_type = recipe
 * taxonomy = recipe_cat
 * taxonomy = recipe_cuisine
 * taxonomy = recipe_method
 */
if ( ! function_exists( 'rcp_custom_posttype' ) ) {
	function rcp_custom_posttype() {
		$labels = array(
			'name'                  => esc_html_x( 'Recipes', 'Post Type General Name', 'cookpro_textdomain' ),
			'singular_name'         => esc_html_x( 'Recipe', 'Post Type Singular Name', 'cookpro_textdomain' ),
			'menu_name'             => esc_html__( 'Recipes', 'cookpro_textdomain' ),
			'name_admin_bar'        => esc_html__( 'Recipe', 'cookpro_textdomain' ),
			'archives'              => esc_html__( 'Recipe Archives', 'cookpro_textdomain' ),
			'attributes'            => esc_html__( 'Recipe Attributes', 'cookpro_textdomain' ),
			'parent_item_colon'     => esc_html__( 'Parent Recipe:', 'cookpro_textdomain' ),
			'all_items'             => esc_html__( 'All Recipes', 'cookpro_textdomain' ),
			'add_new_item'          => esc_html__( 'Add New Recipe', 'cookpro_textdomain' ),
			'add_new'               => esc_html__( 'Add New', 'cookpro_textdomain' ),
			'new_item'              => esc_html__( 'New Recipe', 'cookpro_textdomain' ),
			'edit_item'             => esc_html__( 'Edit Recipe', 'cookpro_textdomain' ),
			'update_item'           => esc_html__( 'Update Recipe', 'cookpro_textdomain' ),
			'view_item'             => esc_html__( 'View Recipe', 'cookpro_textdomain' ),
			'view_items'            => esc_html__( 'View Recipes', 'cookpro_textdomain' ),
			'search_items'          => esc_html__( 'Search Recipe', 'cookpro_textdomain' ),
			'not_found'             => esc_html__( 'Not found', 'cookpro_textdomain' ),
			'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'cookpro_textdomain' ),
			'featured_image'        => esc_html__( 'Featured Image', 'cookpro_textdomain' ),
			'set_featured_image'    => esc_html__( 'Set featured image', 'cookpro_textdomain' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'cookpro_textdomain' ),
			'use_featured_image'    => esc_html__( 'Use as featured image', 'cookpro_textdomain' ),
			'insert_into_item'      => esc_html__( 'Insert into Recipe', 'cookpro_textdomain' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'cookpro_textdomain' ),
			'items_list'            => esc_html__( 'Recipes list', 'cookpro_textdomain' ),
			'items_list_navigation' => esc_html__( 'Recipes list navigation', 'cookpro_textdomain' ),
			'filter_items_list'     => esc_html__( 'Filter Recipes list', 'cookpro_textdomain' ),
		);
		$rcp_recipe_slug = get_option( 'rcp_recipe_slug' ) ? get_option( 'rcp_recipe_slug' ) : 'recipe';
		$args = array(
			'label'                 => esc_html__( 'Recipe', 'cookpro_textdomain' ),
			'description'           => esc_html__( 'Recipe Description', 'cookpro_textdomain' ),
			'labels'                => $labels,
			'supports'              => array( 'title', 'author', 'thumbnail', 'page-attributes', 'comments' ),
			'taxonomies'            => array( 'recipe_tag', 'recipe_cat', 'recipe_cuisine', 'recipe_method' ),
			'hierarchical'          => false,
			'public'                => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'menu_position'         => null,
			'menu_icon'             => 'dashicons-carrot',
			'show_in_admin_bar'     => true,
			'show_in_nav_menus'     => true,
			'can_export'            => true,
			'has_archive'           => true,
			'exclude_from_search'   => false,
			'publicly_queryable'    => true,
			'capability_type'       => 'post',
			'query_var'				=> true,
			'rewrite'				=> array( 'slug' => $rcp_recipe_slug ),
		);
		register_post_type( 'recipe', $args );
	}
	add_action( 'init', 'rcp_custom_posttype' );
}
add_action( 'init', 'rcp_tag_init' );
function rcp_tag_init() {
	$labels = array(
		'name'                       => esc_html_x( 'Recipe Tags', 'Category', 'cookpro_textdomain' ),
		'singular_name'              => esc_html_x( 'Recipe Tag', 'Category', 'cookpro_textdomain' ),
		'menu_name'                  => esc_html__( 'Recipe Tag', 'cookpro_textdomain' ),
		'all_items'                  => esc_html__( 'All Recipe Tags', 'cookpro_textdomain' ),
		'parent_item'                => esc_html__( 'Parent Recipe Tag', 'cookpro_textdomain' ),
		'parent_item_colon'          => esc_html__( 'Parent Recipe Tag:', 'cookpro_textdomain' ),
		'new_item_name'              => esc_html__( 'New Recipe Tag Name', 'cookpro_textdomain' ),
		'add_new_item'               => esc_html__( 'Add New Recipe Tag', 'cookpro_textdomain' ),
		'edit_item'                  => esc_html__( 'Edit Recipe Tag', 'cookpro_textdomain' ),
		'update_item'                => esc_html__( 'Update Recipe Tag', 'cookpro_textdomain' ),
		'view_item'                  => esc_html__( 'View Recipe Tag', 'cookpro_textdomain' ),
		'separate_items_with_commas' => esc_html__( 'Separate Recipe Tags with commas', 'cookpro_textdomain' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove Recipe Tags', 'cookpro_textdomain' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'cookpro_textdomain' ),
		'popular_items'              => esc_html__( 'Popular Recipe Tags', 'cookpro_textdomain' ),
		'search_items'               => esc_html__( 'Search Recipe Tags', 'cookpro_textdomain' ),
		'not_found'                  => esc_html__( 'Not Found', 'cookpro_textdomain' ),
		'no_terms'                   => esc_html__( 'No Recipe Tags', 'cookpro_textdomain' ),
		'items_list'                 => esc_html__( 'Recipe Tags list', 'cookpro_textdomain' ),
		'items_list_navigation'      => esc_html__( 'Recipe Tags list navigation', 'cookpro_textdomain' ),
	);
	$rcp_tag_slug = get_option( 'rcp_tag_slug' ) ? get_option( 'rcp_tag_slug' ) : 'recipe_tag';
	$args = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'query_var'			=> true,
		'sort' 				=> true,
		'rewrite'			=> array( 'slug' => $rcp_tag_slug ),
		'args' 				=> array( 'orderby' => 'menu_order' ),
	);
	register_taxonomy( 'recipe_tag', array( 'recipe' ), $args );
}
add_action( 'init', 'rcp_cat_init' );
function rcp_cat_init() {
	$labels = array(
		'name'                       => esc_html_x( 'Categories', 'Category', 'cookpro_textdomain' ),
		'singular_name'              => esc_html_x( 'Category', 'Category', 'cookpro_textdomain' ),
		'menu_name'                  => esc_html__( 'Category', 'cookpro_textdomain' ),
		'all_items'                  => esc_html__( 'All Categories', 'cookpro_textdomain' ),
		'parent_item'                => esc_html__( 'Parent Category', 'cookpro_textdomain' ),
		'parent_item_colon'          => esc_html__( 'Parent Category:', 'cookpro_textdomain' ),
		'new_item_name'              => esc_html__( 'New Category Name', 'cookpro_textdomain' ),
		'add_new_item'               => esc_html__( 'Add New Category', 'cookpro_textdomain' ),
		'edit_item'                  => esc_html__( 'Edit Category', 'cookpro_textdomain' ),
		'update_item'                => esc_html__( 'Update Category', 'cookpro_textdomain' ),
		'view_item'                  => esc_html__( 'View Category', 'cookpro_textdomain' ),
		'separate_items_with_commas' => esc_html__( 'Separate Categories with commas', 'cookpro_textdomain' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove Categories', 'cookpro_textdomain' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'cookpro_textdomain' ),
		'popular_items'              => esc_html__( 'Popular Categories', 'cookpro_textdomain' ),
		'search_items'               => esc_html__( 'Search Categories', 'cookpro_textdomain' ),
		'not_found'                  => esc_html__( 'Not Found', 'cookpro_textdomain' ),
		'no_terms'                   => esc_html__( 'No Categories', 'cookpro_textdomain' ),
		'items_list'                 => esc_html__( 'Categories list', 'cookpro_textdomain' ),
		'items_list_navigation'      => esc_html__( 'Categories list navigation', 'cookpro_textdomain' ),
	);
	$rcp_category_slug = get_option( 'rcp_category_slug' ) ? get_option( 'rcp_category_slug' ) : 'recipe_cat';
	$args = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'query_var'			=> true,
		'sort' 				=> true,
		'rewrite'			=> array( 'slug' => $rcp_category_slug ),
		'args' 				=> array( 'orderby' => 'menu_order' ),
	);
	register_taxonomy( 'recipe_cat', array( 'recipe' ), $args );
}
add_action( 'init', 'rcp_cuisine_init' );
function rcp_cuisine_init() {
	$labels = array(
		'name'                       => esc_html_x( 'Cuisines', 'Cuisines', 'cookpro_textdomain' ),
		'singular_name'              => esc_html_x( 'Cuisine', 'Cuisine', 'cookpro_textdomain' ),
		'menu_name'                  => esc_html__( 'Cuisine', 'cookpro_textdomain' ),
		'all_items'                  => esc_html__( 'All Cuisines', 'cookpro_textdomain' ),
		'parent_item'                => esc_html__( 'Parent Cuisine', 'cookpro_textdomain' ),
		'parent_item_colon'          => esc_html__( 'Parent Cuisine:', 'cookpro_textdomain' ),
		'new_item_name'              => esc_html__( 'New Cuisine Name', 'cookpro_textdomain' ),
		'add_new_item'               => esc_html__( 'Add New Cuisine', 'cookpro_textdomain' ),
		'edit_item'                  => esc_html__( 'Edit Cuisine', 'cookpro_textdomain' ),
		'update_item'                => esc_html__( 'Update Cuisine', 'cookpro_textdomain' ),
		'view_item'                  => esc_html__( 'View Cuisine', 'cookpro_textdomain' ),
		'separate_items_with_commas' => esc_html__( 'Separate Cuisines with commas', 'cookpro_textdomain' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove Cuisines', 'cookpro_textdomain' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'cookpro_textdomain' ),
		'popular_items'              => esc_html__( 'Popular Cuisines', 'cookpro_textdomain' ),
		'search_items'               => esc_html__( 'Search Cuisines', 'cookpro_textdomain' ),
		'not_found'                  => esc_html__( 'Not Found', 'cookpro_textdomain' ),
		'no_terms'                   => esc_html__( 'No Cuisines', 'cookpro_textdomain' ),
		'items_list'                 => esc_html__( 'Cuisines list', 'cookpro_textdomain' ),
		'items_list_navigation'      => esc_html__( 'Cuisines list navigation', 'cookpro_textdomain' ),
	);
	$rcp_cuisine_slug = get_option( 'rcp_cuisine_slug' ) ? get_option( 'rcp_cuisine_slug' ) : 'recipe_cuisine';
	$args = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'query_var'			=> true,
		'sort' 				=> true,
		'rewrite'			=> array( 'slug' => $rcp_cuisine_slug ),
		'args' 				=> array( 'orderby' => 'menu_order' ),
	);
	register_taxonomy( 'recipe_cuisine', array( 'recipe' ), $args );
}
add_action( 'init', 'rcp_method_init' );
function rcp_method_init() {
	$labels = array(
		'name'                       => esc_html_x( 'Cooking Methods', 'method', 'cookpro_textdomain' ),
		'singular_name'              => esc_html_x( 'Method', 'method', 'cookpro_textdomain' ),
		'menu_name'                  => esc_html__( 'Method', 'cookpro_textdomain' ),
		'all_items'                  => esc_html__( 'All Cooking Methods', 'cookpro_textdomain' ),
		'parent_item'                => esc_html__( 'Parent Method', 'cookpro_textdomain' ),
		'parent_item_colon'          => esc_html__( 'Parent Methods:', 'cookpro_textdomain' ),
		'new_item_name'              => esc_html__( 'New Method Name', 'cookpro_textdomain' ),
		'add_new_item'               => esc_html__( 'Add New Method', 'cookpro_textdomain' ),
		'edit_item'                  => esc_html__( 'Edit Method', 'cookpro_textdomain' ),
		'update_item'                => esc_html__( 'Update Method', 'cookpro_textdomain' ),
		'view_item'                  => esc_html__( 'View Method', 'cookpro_textdomain' ),
		'separate_items_with_commas' => esc_html__( 'Separate Methods with commas', 'cookpro_textdomain' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove Methods', 'cookpro_textdomain' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'cookpro_textdomain' ),
		'popular_items'              => esc_html__( 'Popular Methods', 'cookpro_textdomain' ),
		'search_items'               => esc_html__( 'Search Methods', 'cookpro_textdomain' ),
		'not_found'                  => esc_html__( 'Not Methods Found', 'cookpro_textdomain' ),
		'no_terms'                   => esc_html__( 'No Methods', 'cookpro_textdomain' ),
		'items_list'                 => esc_html__( 'Methods list', 'cookpro_textdomain' ),
		'items_list_navigation'      => esc_html__( 'Methods list navigation', 'cookpro_textdomain' ),
	);
	$rcp_method_slug = get_option( 'rcp_method_slug' ) ? get_option( 'rcp_method_slug' ) : 'recipe_method';
	$args = array(
		'labels'            => $labels,
		'hierarchical'      => true,
		'public'            => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'query_var'			=> true,
		'sort' 				=> true,
		'rewrite'			=> array( 'slug' => $rcp_method_slug ),
		'args' 				=> array( 'orderby' => 'menu_order' ),
	);
	register_taxonomy( 'recipe_method', array( 'recipe' ), $args );
}
// Custom Post Type Columns
if ( ! function_exists( 'rcp_columns' ) ) {
	function rcp_columns( $columns ) {
		$columns = array(
			'cb'       		 => '<input type="checkbox" />',
			'title'       	 => esc_html__( 'Title', 'cookpro_textdomain' ),
			'rcp_image'	 	=> esc_html__( 'Thumbnail', 'cookpro_textdomain' ),
			'author'       	 => esc_html__( 'Author', 'cookpro_textdomain' ),
			'rcp_categories' => esc_html__( 'Categories', 'cookpro_textdomain' ),
			'rcp_cuisines'   => esc_html__( 'Cuisines', 'cookpro_textdomain' ),
			'rcp_tags'       => esc_html__( 'Tags', 'cookpro_textdomain' ),
			'rcp_methods'	 => esc_html__( 'Methods', 'cookpro_textdomain' ),
			'date'       	 => esc_html__( 'Date', 'cookpro_textdomain' ),
		);
		return $columns;
	}
	add_filter( 'manage_edit-recipe_columns', 'rcp_columns' );
}

// Manage Custom Post Type Columns
if ( ! function_exists( 'rcp_manage_columns' ) ) {
	function rcp_manage_columns( $name ) {
		global $wpdb, $wp_query, $post;
		$rcp_post_cat_terms = $rcp_post_cuisine_terms = $rcp_post_method_terms = array();
		switch ( $name ) {
			case 'rcp_image':
				if ( has_post_thumbnail() ) {
					echo the_post_thumbnail( array( 100, 100 ) );
				}
				break;
			case 'rcp_categories':
				$rcp_cat_terms = get_the_terms( $post->ID, 'recipe_cat' );
				if ( ! empty( $rcp_cat_terms ) ) {
					foreach ( $rcp_cat_terms as $term ) {
						$rcp_post_cat_terms[] = esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, '', 'edit' ) );
					}
					echo esc_html( implode( ', ', $rcp_post_cat_terms ) );
				} else {
					echo '<em>' . esc_html__( 'No terms', 'cookpro_textdomain' ) . '</em>';
				}
				break;
			case 'rcp_tags':
				$rcp_tag_terms = get_the_terms( $post->ID, 'recipe_tag' );
				if ( ! empty( $rcp_tag_terms ) ) {
					foreach ( $rcp_tag_terms as $term ) {
						$rcp_post_tag_terms[] = esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, '', 'edit' ) );
					}
					echo esc_html( implode( ', ', $rcp_post_tag_terms ) );
				} else {
					echo '<em>' . esc_html__( 'No tags', 'cookpro_textdomain' ) . '</em>';
				}
				break;
			case 'rcp_cuisines':
				$rcp_cuisine_terms = get_the_terms( $post->ID, 'recipe_cuisine' );
				if ( ! empty( $rcp_cuisine_terms ) ) {
					foreach ( $rcp_cuisine_terms as $term ) {
						$rcp_post_cuisine_terms[] = esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, '', 'edit' ) );
					}
					echo esc_html( implode( ', ', $rcp_post_cuisine_terms ) );
				} else {
					echo '<em>' . esc_html__( 'No terms', 'cookpro_textdomain' ) . '</em>';
				}
				break;
			case 'rcp_methods':
				$rcp_method_terms = get_the_terms( $post->ID, 'recipe_method' );
				if ( ! empty( $rcp_method_terms ) ) {
					foreach ( $rcp_method_terms as $term ) {
						$rcp_post_method_terms[] = esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, '', 'edit' ) );
					}
					echo esc_html( implode( ', ', $rcp_post_method_terms ) );
				} else {
					echo '<em>' . esc_html__( 'No terms', 'cookpro_textdomain' ) . '</em>';
				}
				break;
		}
	}
	add_action( 'manage_posts_custom_column', 'rcp_manage_columns', 10, 2 );
}
if ( ! function_exists( 'rcp_category_updated_messages' ) ) {
	function rcp_category_updated_messages( $messages ) {
		global $post, $post_ID;
		$messages['recipe'] = array(
			0 => '', // Unused. Messages start at index 1.
			1 => sprintf( __( 'Recipe Updated. <a href="%s">View Recipe</a>' ), esc_url( get_permalink( $post_ID ) ) ),
			2 => esc_html__( 'Custom Field Updated.', 'cookpro_textdomain' ),
			3 => esc_html__( 'Custom Field Deleted.', 'cookpro_textdomain' ),
			4 => esc_html__( 'Recipe Updated.', 'cookpro_textdomain' ),
			/* translators: %s: date and time of the revision */
			5 => isset( $_GET['revision'] ) ? sprintf( __( 'Recipe Item restored to revision from %s', 'cookpro_textdomain' ), wp_post_revision_title( ( int ) $_GET['revision'], false ) ) : false,
			6 => sprintf( __( 'Recipe Item published. <a href="%s">View Recipe</a>' ), esc_url( get_permalink( $post_ID ) ) ),
			7 => esc_html__( 'Recipe Item saved.', 'cookpro_textdomain' ),
			8 => sprintf( __( 'Recipe Item submitted. <a target="_blank" href="%s">Preview Recipe</a>' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
			9 => sprintf( __( 'Recipe Item draft updated. <a target="_blank" href="%s">Preview Recipe</a>' ), esc_url( add_query_arg( 'preview', 'true', get_permalink( $post_ID ) ) ) ),
		);
		return $messages;
	}
	//add filter to ensure the  Recipe Item, is displayed when user updates a Recipe Item
	add_filter( 'post_updated_messages', 'rcp_category_updated_messages' );
}
if ( ! function_exists( 'rcp_extra_recipe_cat_fields' ) ) {
	// add extra fields to custom taxonomy edit form callback function
	function rcp_extra_recipe_cat_fields( $tag ) {
		//check for existing taxonomy meta for term ID
		echo '<div class="form-field">';
		echo '<label for="tag-slug">' . esc_html__( 'Thumbnail', 'cookpro_textdomain' ) . '</label>';
		echo '<input name="term_meta[img]" id="term_meta_img" type="hidden" class="rcp_category_upload_image" />';
		echo '<input name="term_meta[img]" id="term_meta_img" class="rcp_category_upload_image_button button button-primary button-large clearfix" type="button" value="Choose Image" />';
		echo '<div id="rcp_cpt_imagepreview-term_meta_img" class="rcp_cat_screenshot">';
		echo '</div><br /><div class="clearfix"></div>';
		echo '<p>' . esc_html__( 'Image for Recipe Category, use full url including http:// - It will be displayed on category page.', 'cookpro_textdomain' ) . '</p>';
		echo '</div>';//.form-field
	}
	// this adds the fields
	add_action( 'recipe_cat_add_form_fields', 'rcp_extra_recipe_cat_fields', 10, 2 );
}

if ( ! function_exists( 'rcp_edit_recipe_cat_fields' ) ) {
	//add extra fields to custom taxonomy edit form callback function
	function rcp_edit_recipe_cat_fields( $tag ) {
		//check for existing taxonomy meta for term ID
		$t_id      = $tag->term_id;
		$term_meta = get_option( "taxonomy_$t_id" );
		echo '<tr class="form-field">';
		echo '<th scope="row" valign="top"><label for="cat_Image_url">' . esc_html__( 'Thumbnail', 'cookpro_textdomain' ) . '</label></th>';
		echo '<td>';
		echo '<input name="term_meta[img]" id="term_meta_img"  type="text" class="rcp_category_upload_image" value="' . $term_meta['img'] . '" />';
		echo '<input name="term_meta[img]" id="term_meta_img"  class="rcp_category_upload_image_button button button-primary button-large clearfix" type="button" value="Choose Image" />';
		echo '<div id="rcp_cpt_imagepreview-term_meta_img" class="rcp_cat_screenshot">';

		$image_attributes = wp_get_attachment_image_src( rcp_get_attachment_id_from_src( $term_meta['img'] ) );
		if ( '' !== $image_attributes[0] ) {
			echo '<img src="' . $image_attributes[0] . '" class="custom_preview_image" alt="" />';
			echo '<a href="#" class="rcp_category_image_remove button button-primary">x</a>';
		} else {
			echo '<img src="' . $term_meta['img'] . '" class="custom_preview_image" alt="" />';
			echo '<a href="#" class="rcp_category_image_remove button button-primary">x</a>';
		}
		echo '</div>';
		echo '<br /><div class="clearfix"></div>';
		echo '<span class="description">' . esc_html__( 'Image for Menutype, use full url including http:// - It will be displayed on menu types page.', 'cookpro_textdomain' ) . '</span>';
		echo '</td>';
		echo '</tr>';
	}
	add_action( 'recipe_cat_edit_form_fields', 'rcp_edit_recipe_cat_fields', 10, 2 );
} // End if().
if ( ! function_exists( 'rcp_save_extra_taxonomy_fields' ) ) {
	// save extra taxonomy fields callback function
	function rcp_save_extra_taxonomy_fields( $term_id ) {
		if ( isset( $_POST['term_meta'] ) ) {
			$t_id = $term_id;
			$term_meta = get_option( "taxonomy_$t_id" );
			$cat_keys = array_keys( $_POST['term_meta'] );
			foreach ( $cat_keys as $key ) {
				if ( isset( $_POST['term_meta'][ $key ] ) ) {
					$term_meta[ $key ] = $_POST['term_meta'][ $key ];
				}
			}
			update_option( "taxonomy_$t_id", $term_meta );
		}
	}
	// this saves the fields
	add_action( 'edited_recipe_cat', 'rcp_save_extra_taxonomy_fields', 10, 2 );
	add_action( 'created_recipe_cat', 'rcp_save_extra_taxonomy_fields', 10, 2 );
}
