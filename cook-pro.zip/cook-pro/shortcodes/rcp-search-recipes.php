<?php
add_shortcode( 'rcp-search-recipes', 'rcp_search_recipes_sc' );
function rcp_search_recipes_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'search_limit'    => 8,
			'orderby'         => '',
			'order'           => '',
			'columns'         => 4,
			'loadmore'        => 'infinite',
			'default_limit'   => 8,
			'default_orderby' => 'rand',
			'default_order'   => 'DESC',
			'hide_cooktime'	  => 'no',
			'hide_difflevel'  => 'no',
			'hide_yields'	  => 'no',
			'hide_ratings'	  => 'yes',
			'hide_author' 	  => 'no',
			'display_style'   => 'style1',
		),
		$atts,
		'rcp-search-recipes'
	);

	$rcp_search_nonce = wp_create_nonce( 'rcp-search-nonce' );
	$out = $rcp_extra_css ='';
	$search_limit    = isset( $atts['search_limit'] ) ? $atts['search_limit'] : 8;
	$orderby         = isset( $atts['orderby'] ) ? $atts['orderby'] : 'rand';
	$order           = isset( $atts['order'] ) ? $atts['order'] : 'DESC';
	$columns         = isset( $atts['columns'] ) ? $atts['columns'] : 4;
	$loadmore        = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
	$default_limit   = isset( $atts['default_limit'] ) ? $atts['default_limit'] : 8;
	$default_orderby = isset( $atts['default_orderby'] ) ? $atts['default_orderby'] : 'rand';
	$default_order   = isset( $atts['default_order'] ) ? $atts['default_order'] : 'DESC';
	$hide_cooktime   = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
	$hide_difflevel  = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
	$hide_yields  	 = isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
	$hide_ratings  	 = isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'yes';
	$hide_author	 = isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
	$display_style	 = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
	$paged = 1;
	
	if( $loadmore == 'infinite' ){
		$out .='<div id="content" class="rcp-search-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '"  data-hide_author="' .$hide_author. '" data-display_style="' . $display_style . '" data-limit="' . esc_attr( $search_limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_search_nonce ) . '">';

		$out .= rcp_search_recipes( $search_limit, $orderby, $order, $columns, $loadmore, $default_limit, $default_orderby, $default_order, $rcp_extra_css, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $paged );

		$out .= '</div>';
		$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cook-pro').'</span></div>';
	} else{
		$out .= rcp_search_recipes( $search_limit, $orderby, $order, $columns, $loadmore, $default_limit, $default_orderby, $default_order, $rcp_extra_css, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $paged );
	}

	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Search_Recipes' ) ) {
	class Rcp_VC_Search_Recipes {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_search_recipes_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-search-recipes-addon', array( $this, 'rcp_search_recipes_addon' ) );
	    }

	    public function rcp_vc_search_recipes_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Search Recipes', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Search Recipes Text', 'cook-pro' ),
	            'base' 			=> 'rcp-search-recipes-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( 'assets/rcp_search.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Display style', 'cook-pro' ),
						'param_name' 	=> 'display_style',
						'std'		 	=> 'style1',
						'value'		 	=> array(
												esc_html__( 'Select Style','cook-pro' ) => '',
												'Style1' => 'style1',
												'Style2' => 'style2',
											),
						'description'   => esc_html__( 'Select the style you wish to use for Recipes to display.', 'cook-pro' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '4',
						'value' => array(
							esc_html__( 'Select Columns','cook-pro' ) => '',
							esc_html__( '2 Columns', 'cook-pro' ) => '2',
							esc_html__( '3 Columns', 'cook-pro' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cook-pro' ),
					),
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Search Limit', 'cook-pro' ),
						'param_name'  => 'search_limit',
						'description' => esc_html__( 'Enter the limit for the search recipes to display.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cook-pro' ),
						'param_name' 	=> 'orderby',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cook-pro' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Random' 		 => 'rand',
												'Date' 			 => 'date',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the display orderby option you wish to use for search recipes display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cook-pro' ),
						'param_name' 	=> 'order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the order you wish to use for search recipes to display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Load More', 'cook-pro' ),
						'param_name' 	=> 'loadmore',
						'std'		 	=> 'infinite',
						'value'		 	=> array(
												esc_html__( 'Select Loadmore Option','cook-pro' ) => '',
												'Infinite Scroll'  => 'infinite',
												'Load More' => 'loadmore',
											),
						'description'   => esc_html__( 'Select the Loadmore you wish to use for Recent Recipe to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Cooking Time', 'cook-pro' ),
						'param_name'  => 'hide_cooktime',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Difficulty Level', 'cook-pro' ),
						'param_name'  => 'hide_difflevel',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Yields', 'cook-pro' ),
						'param_name'  => 'hide_yields',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Ratings', 'cook-pro' ),
						'param_name'  => 'hide_ratings',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Author', 'cook-pro' ),
						'param_name'  => 'hide_author',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Default Limit', 'cook-pro' ),
						'param_name'  => 'default_limit',
						'description' => esc_html__( 'Enter the default limit for the search recipes to display.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cook-pro' ),
						'param_name' 	=> 'default_orderby',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cook-pro' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Date' 			 => 'date',
												'Random' 			 => 'rand',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the default orderby option you wish to use for search recipes display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cook-pro' ),
						'param_name' 	=> 'default_order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the default order you wish to use for search recipes to display.', 'cook-pro' ),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_search_recipes_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'search_limit'     => 8,
				'orderby'          => 'rand',
				'order'            => 'DESC',
				'columns'          => 4,
				'loadmore'         => 'no',
				'default_limit'    => 8,
				'default_orderby'  => 'rand',
				'default_order'    => 'DESC',
		    	'css'		       => '',
		    	'extra_class'      => '',
				'hide_cooktime'	   => 'no',
				'hide_difflevel'   => 'no',
				'hide_yields'      => 'no',
				'hide_ratings'     => 'yes',
				'hide_author'	   => 'no',
				'display_style'    => '',
		    ), $atts ) );

		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

			$rcp_search_nonce = wp_create_nonce( 'rcp-search-nonce' );
			$out = '';
			$search_limit      = isset( $atts['search_limit'] ) ? $atts['search_limit'] : 8;
			$orderby           = isset( $atts['orderby'] ) ? $atts['orderby'] : 'rand';
			$order             = isset( $atts['order'] ) ? $atts['order'] : 'DESC';
			$columns           = isset( $atts['columns'] ) ? $atts['columns'] : 4;
			$loadmore          = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
			$default_limit     = isset( $atts['default_limit'] ) ? $atts['default_limit'] : 8;
			$default_orderby   = isset( $atts['default_orderby'] ) ? $atts['default_orderby'] : 'rand';
			$default_order     = isset( $atts['default_order'] ) ? $atts['default_order'] : 'DESC';
			$hide_cooktime     = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
			$hide_difflevel    = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
			$hide_yields  	   = isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
			$hide_ratings  	   = isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'yes';
			$hide_author	   = isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
			// $display_style	   = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
			$paged = 1;
			if( $loadmore == 'infinite' ){
				$out .='<div id="content" class="rcp-search-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' . $hide_author . '" data-display_style="' . $display_style . '" data-limit="' . esc_attr( $search_limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_search_nonce ) . '">';

				$out .= rcp_search_recipes( $search_limit, $orderby, $order, $columns, $loadmore, $default_limit, $default_orderby, $default_order, $rcp_extra_css, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $paged );
				$out .= '</div>';
				$out .= '<div id="inifiniteLoader"></div>';
			} else{
				$out .= rcp_search_recipes( $search_limit, $orderby, $order, $columns, $loadmore, $default_limit, $default_orderby, $default_order, $rcp_extra_css, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $paged );
			}

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Search_Recipes();
}

function rcp_search_recipes( $search_limit, $orderby, $order, $columns, $loadmore, $default_limit, $default_orderby, $default_order, $rcp_extra_css, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $scroll_paged ) {
	$out = '';
	$rcp_post_categories = rcp_get_terms(
		$taxonomy = 'recipe_cat'
	);
	$rcp_post_cuisines = rcp_get_terms(
		$taxonomy = 'recipe_cuisine'
	);
	$rcp_post_methods = rcp_get_terms(
		$taxonomy = 'recipe_method'
	);
	$rcp_post_tags = rcp_get_terms(
		$taxonomy = 'post_tag'
	);

	$count_recipes = wp_count_posts('recipe');
	$recipes_count = sprintf( esc_html__( 'Search  %s+ recipes by Ingredient, dish or keyword', 'cook-pro' ), $count_recipes->publish );
	$out .= '<form class="search" method="GET" action="' . get_permalink( rcp_get_option( 'rcp_search_page_id','' ) ) . '">';
	$out .= '<div class="rcp-main-search-wrap ' . $rcp_extra_css . '">';
	$out .= '<div class="rcp__search_box1">';
	$out .= '<div class="rcp-main-search">';
	$out .= '<input type="text" name="rcp_search_name" placeholder="' . $recipes_count . '" class="rcp__search rcp__search_input" value="">';
	$out .= '<input class="rcp__search_submit rcp-form-button-primary" type="submit" id="rcp__search_input" value="' . esc_html__( 'Search','cook-pro' ) . '">';
	$out .= wp_nonce_field( 'rcp-search-submit' );
	$out .= '<input name="action" type="hidden" id="action" value="rcp-search-submit" />';
	$out .= '</div>'; //.rcp-main-search

	$out .= '<div class="rcp__search_box2">';
	$out .= '<em class="rcp__search_advanced">+' . esc_html__( 'Advanced Search', 'cook-pro' ) . '</em>';
	$out .= '</div>';

	$out .= '<div class="rcp__search_box3">';
	$out .= '<div class="rcp__search_advance">';
	$out .= '<div class="rcp__search_bylist">';
	$out .= '<h2 class="rcp__search_advance_title">' . esc_html__( 'By Course','cook-pro' ) . '</h2>';
	$out .= '<ul>';
	foreach ( $rcp_post_categories as $category_id => $category_name ) {
		$out .= '<li><input type="checkbox" name="rcp_cats[]" value="' . $category_id . '">' . $category_name . '</li>';
	}
	$out .= '</ul>';
	$out .= '</div>'; //.rcp__search_bylist
	$out .= '<div class="clear"></div>';
	$out .= '<div class="rcp__search_bylist">';
	$out .= '<h2>' . esc_html__( 'By Cuisine','cook-pro' ) . '</h2>';
	$out .= '<ul>';
	foreach ( $rcp_post_cuisines as $category_id => $category_name ) {
		$out .= '<li><input type="checkbox" name="rcp_cuisines[]" value="' . $category_id . '">' . $category_name . '</li>';
	}
	$out .= '</ul>';
	$out .= '</div>'; //.rcp__search_bylist
	$out .= '<div class="clear"></div>';
	$out .= '<div class="rcp__search_bylist">';
	$out .= '<h2>' . esc_html__( 'By Methods','cook-pro' ) . '</h2>';
	$out .= '<ul>';
	foreach ( $rcp_post_methods as $category_id => $category_name ) {
		$out .= '<li><input type="checkbox" name="rcp_methods[]" value="' . $category_id . '">' . $category_name . '</li>';
	}
	$out .= '</ul>';
	$out .= '</div>'; //.rcp__search_bylist
	$out .= '<div class="clear"></div>';
	$out .= '<div class="rcp__search_bylist">';
	$out .= '<h2>' . esc_html__( 'By Ingredients','cook-pro' ) . '</h2>';
	$out .= '<ul>';
	foreach ( $rcp_post_tags as $tag_id => $tag_name ) {
		$out .= '<li><input type="checkbox" name="rcp_ingredients[]" value="' . $tag_id . '">' . $tag_name . '</li>';
	}
	$out .= '</ul>';
	$out .= '</div>'; //.rcp__search_bylist
	$out .= '</div>'; //.rcp__search_advance
	$out .= '</div>'; //.rcp__search_box3
	$out .= '</div>'; //.rcp__search_box1
	$out .= '</div>'; //.rcp-main-search-wrap
	$out .= '</form>';

	$out .= '<div class="clear"></div>';
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}

	if ( $loadmore =='infinite' ){ $paged = $scroll_paged; }

	// Results
	if ( ! empty( $_GET['action'] ) && $_GET['action'] == 'rcp-search-submit' ) {

		$rcp_data_cats = $rcp_data_cuisines = $rcp_data_methods = $rcp_data_ingredients = '';
		$rcp_cat_values = $rcp_cuisine_values = $rcp_method_values = $rcp_ingredient_values = array();

		$rcp_search_name 		= isset( $_GET['rcp_search_name'] ) ? $_GET['rcp_search_name'] : '';
		$rcp_cat_values 		= isset( $_GET['rcp_cats'] ) ? $_GET['rcp_cats'] : '';
		$rcp_cuisine_values 	= isset( $_GET['rcp_cuisines'] ) ? $_GET['rcp_cuisines'] : '';
		$rcp_method_values 		= isset( $_GET['rcp_methods'] ) ? $_GET['rcp_methods'] : '';
		$rcp_ingredient_values 	= isset( $_GET['rcp_ingredients'] ) ? $_GET['rcp_ingredients'] : '';

		if ( ! empty( $rcp_cat_values ) ) {
			$rcp_data_cats 	= implode( ',', $rcp_cat_values );
		}
		if ( ! empty( $rcp_cuisine_values ) ) {
			$rcp_data_cuisines 	= implode( ',', $rcp_cuisine_values );
		}
		if ( ! empty( $rcp_method_values ) ) {
			$rcp_data_methods = implode( ',', $rcp_method_values );
		}
		if ( ! empty( $rcp_ingredient_values ) ) {
			$rcp_data_ingredients = implode( ',', $rcp_ingredient_values );
		}
		global $wpdb;
		$ids = $wpdb->get_col( "select ID from $wpdb->posts where post_title LIKE '%" . $rcp_search_name . "%' AND post_type='recipe' AND post_status='publish'" );
		$args = array(
			'post_type'			=> 'recipe',
			'posts_per_page'	=> $search_limit,
			'paged'				=> $paged,
			'tax_query' => array(
				'relation' => 'OR',
			),
			'orderby'	=> $orderby,
			'order'		=> $order,
		);
		if ( $ids != '' ) {
			$args['post__in'] = $ids;
		}

		if ( $rcp_cat_values != '' ) {
			$rcp_cat_args = array(
				'taxonomy' => 'recipe_cat',
				'field' => 'term_id',
				'terms' => $rcp_cat_values,
			);
			array_push( $args['tax_query'], $rcp_cat_args );
		}
		if ( $rcp_cuisine_values != '' ) {
			$rcp_cuisine_args = array(
				'taxonomy' => 'recipe_cuisine',
				'field' => 'term_id',
				'terms' => $rcp_cuisine_values,
			);
			array_push( $args['tax_query'], $rcp_cuisine_args );
		}
		if ( $rcp_method_values != '' ) {
			$rcp_method_args = array(
				'taxonomy' => 'recipe_method',
				'field' => 'term_id',
				'terms' => $rcp_method_values,
			);
			array_push( $args['tax_query'], $rcp_method_args );
		}
		if ( $rcp_ingredient_values != '' ) {
			$rcp_ingredient_args = array(
				'taxonomy' => 'post_tag',
				'field' => 'term_id',
				'terms' => $rcp_ingredient_values,
			);
			array_push( $args['tax_query'], $rcp_ingredient_args );
		}
		$rcp_search_query = new WP_Query( $args );
		$rcp_search_nonce = wp_create_nonce( 'rcp-search-nonce' );
		$count_results = $rcp_search_query->found_posts;
		$max_num_pages = $rcp_search_query->max_num_pages;
		$column_index = 0;

		if ( $columns == '3' ) { $class = 'item3'; }
		if ( $columns == '2' ) { $class = 'item2'; }

		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}
		if ( $rcp_search_query->have_posts() ) :
			$out .= '<div class="rcp-search-module row">';
			$out .= '<div class="rcp-search-module-content" data-max_no_pages="' . esc_attr( $max_num_pages ) . '" data-order="' . esc_attr( $order ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-categories="' . esc_attr( $rcp_data_cats ) . '" data-cuisines="' . esc_attr( $rcp_data_cuisines ) . '"  data-methods="' . esc_attr( $rcp_data_methods ) . '"  data-ingredients="' . esc_attr( $rcp_data_ingredients ) . '" data-searchstring="' . esc_attr( $rcp_search_name ) . '">';
			while ( $rcp_search_query->have_posts() ) : $rcp_search_query->the_post();
				$column_index++;
				$out .= '<div class="rcp-search-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
				$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
				$out .= '</div>'; //.rcp-post-item
				if ( $column_index == $columns ) {
					$column_index = 0;
				}
			endwhile;
			wp_reset_query();
			$out .= '</div>'; //.rcp-search-module-content
			if ( 'loadmore' === $loadmore ) {
				if ( $count_results > 1 && $count_results > $search_limit ) {
					$out .= '<div class="rcp-search-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-count="' . esc_attr( $count_results ) . '" data-nonce="' . esc_attr( $rcp_search_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-columns="' . esc_attr( $columns ) . '" data-categories="' . esc_attr( $rcp_data_cats ) . '" data-cuisines="' . esc_attr( $rcp_data_cuisines ) . '"  data-methods="' . esc_attr( $rcp_data_methods ) . '"  data-ingredients="' . esc_attr( $rcp_data_ingredients ) . '" data-searchstring="' . esc_attr( $rcp_search_name ) . '" data-number="' . esc_attr( $search_limit ) . '" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-style="' . esc_attr( $display_style ) . '">' . esc_html__( 'Load More Posts', 'cook-pro' ) . '</a></div>';
				}
			}
			$out .= '</div>'; //.rcp-search-module-row
			else :
				$out .= '<p class="rcp-main-search-norecipe">' . esc_html__( 'No recipes were found matching your selection.', 'cook-pro' ) . '</p>';
			endif;
	} else {
		$args = array(
			'post_type'			=> 'recipe',
			'posts_per_page'	=> $default_limit,
			'paged'				=> $paged,
			'post_status'		=> 'publish',
			'tax_query' => array(
				'relation' => 'OR',
			),
			'orderby'	=> $default_orderby,
			'order'		=> $default_order,
		);
		$rcp_recent_query = new WP_Query( $args );
		$rcp_recent_nonce = wp_create_nonce( 'rcp-recent-sh-nonce' );
		$count_results = $rcp_recent_query->found_posts;
		$column_index = 0;

		if ( $columns == '3' ) { $class = 'item3'; }
		if ( $columns == '2' ) { $class = 'item2'; }

		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}
		if ( $rcp_recent_query->have_posts() ) {
			$out .= '<div class="rcp-recent-sh-module">';
			$out .= '<div class="rcp-recent-sh-module-content">';
			while ( $rcp_recent_query->have_posts() ) : $rcp_recent_query->the_post();

				$column_index++;

				$out .= '<div class="rcp-recent-sh-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
				$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
				$out .= '</div>'; //.rcp-post-item

				if ( $column_index == $columns ) {
					$column_index = 0;
				}
			endwhile;
			wp_reset_query();
			$out .= '</div>'; //.rcp-recent-module-content
			$out .= '</div>'; //.rcp-recent-module-row
		} else {
			$out .= '<p class="rcp-main-recent-norecipe">' . esc_html__( 'No recipes were found matching your selection.', 'cook-pro' ) . '</p>';
		} // End if().
	} // End if().
	return $out;
}
