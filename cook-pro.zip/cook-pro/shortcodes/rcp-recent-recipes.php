<?php
add_shortcode( 'rcp-recent-recipes', 'rcp_recent_recipes_sc' );
function rcp_recent_recipes_sc( $atts, $content = null ) {
	$a = shortcode_atts(
		array(
			'limit'     	 => 6,
		    'columns'   	 => 3,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'loadmore' 		 => 'infinite',
			'hide_cooktime'  => 'no',
			'hide_difflevel' => 'no',
			'hide_yields' 	 => 'no',
			'hide_ratings' 	 => 'no',
			'hide_author' 	 => 'no',
			'display_style'  => 'style1',
		),
		$atts,
		'rcp-recent-recipes'
	);
	$rcp_extra_css = $out = '';

	$limit      	= isset( $a['limit'] ) ? $a['limit'] : 6;
	$columns   	 	= isset( $a['columns'] ) ? $a['columns'] : 4;
	$loadmore   	= isset( $a['loadmore'] ) ? $a['loadmore'] : '';
	$hide_cooktime  = isset( $a['hide_cooktime'] ) ? $a['hide_cooktime'] : 'no';
	$hide_difflevel = isset( $a['hide_difflevel'] ) ? $a['hide_difflevel'] : 'no';
	$hide_yields  	= isset( $a['hide_yields'] ) ? $a['hide_yields'] : 'no';
	$hide_ratings   = isset( $a['hide_ratings'] ) ? $a['hide_ratings'] : 'no';
	$hide_author    = isset( $a['hide_author'] ) ? $a['hide_author'] : 'no';
	$display_style  = isset( $a['display_style'] ) ? $a['display_style'] : 'style1';
	$orderby        = isset( $a['orderby'] ) ? $a['orderby'] : 'date';
	$order          = isset( $a['order'] ) ? $a['order'] : 'DESC';

	$rcp_recent_nonce   = wp_create_nonce( 'rcp-recent-sh-nonce' );

	$paged = 1;
	if( $loadmore == 'infinite' ){
		$out .= '<div id="content" class="rcp-recent-sh-module-content-ajax rcp_scroll_pages" role="main" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields . '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' . $hide_author . '" data-display_style="' . $display_style . '" data-nonce="' . esc_attr( $rcp_recent_nonce ) . '" data-limit="' . esc_attr( $limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-display_style="' . $display_style . '">';
		$out .= rcp_recent_recipes( $limit, $orderby, $order, $loadmore, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $columns, $rcp_extra_css, $paged );
		$out .= '</div>';
		$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cook-pro').'</span></div>';
	}else{
		$out .= rcp_recent_recipes( $limit, $orderby, $order, $loadmore, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $columns, $rcp_extra_css, $paged );
	}
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Recent_Recipes' ) ) {
	class Rcp_VC_Recent_Recipes {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_recent_recipes_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-recent-recipes-addon', array( $this, 'rcp_recent_recipes_addon' ) );
	    }

	    public function rcp_vc_recent_recipes_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Recent Recipes', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display recent submitted recipes.', 'cook-pro' ),
	            'base' 			=> 'rcp-recent-recipes-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_recent-recipe.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Display style', 'cook-pro' ),
						'param_name' 	=> 'display_style',
						'std'		 	=> 'style1',
						'value'		 	=> array(
												esc_html__( 'Select Style','cook-pro' ) => '',
												'Style1' => 'style1',
												'Style2' => 'style2',
											),
						'description'   => esc_html__( 'Select the style you wish to use for Recipes to display.', 'cook-pro' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '3',
						'value' => array(
							esc_html__( 'Select Columns','cook-pro' ) => '',
							esc_html__( '2 Columns', 'cook-pro' ) => '2',
							esc_html__( '3 Columns', 'cook-pro' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cook-pro' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cook-pro' ),
						'param_name' 	=> 'orderby',
						'std'		 	=> 'date',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cook-pro' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Random' 		 => 'rand',
												'Date' 			 => 'date',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the display orderby option you wish to use for recent recipes display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cook-pro' ),
						'param_name' 	=> 'order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the order you wish to use for search recipes to display.', 'cook-pro' ),
					),
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the recent recipes to display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Load More', 'cook-pro' ),
						'param_name' 	=> 'loadmore',
						'std'		 	=> 'infinite',
						'value'		 	=> array(
												'Infinite Scroll'  => 'infinite',
												'Load More' => 'loadmore',
											),
						'description'   => esc_html__( 'Select the Loadmore you wish to use for Recent Recipe to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Cooking Time', 'cook-pro' ),
						'param_name'  => 'hide_cooktime',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Difficulty Level', 'cook-pro' ),
						'param_name'  => 'hide_difflevel',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Yields', 'cook-pro' ),
						'param_name'  => 'hide_yields',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Ratings', 'cook-pro' ),
						'param_name'  => 'hide_ratings',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Author', 'cook-pro' ),
						'param_name'  => 'hide_author',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_recent_recipes_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'			 => 6,
		    	'loadmore'		 => '',
				'hide_cooktime'	 => 'no',
				'hide_difflevel' => 'no',
				'hide_yields' 	 => 'no',
				'hide_ratings' 	 => 'no',
				'hide_author' 	 => 'no',
				'display_style'  => 'style1',
				'orderby'        => 'date',
				'order'          => 'DESC',
		    	'columns'	  	 => 3,
		    	'css'		  	 => '',
		    	'extra_class' 	 => '',
		    ), $atts ) );
			$out = '';
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}
		    $limit     		= isset( $atts['limit'] ) ? $atts['limit'] : 6;
			$loadmore  		= isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
			$hide_cooktime  = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
			$hide_difflevel = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
			$hide_yields  	= isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
			$hide_ratings  	= isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'no';
			$hide_author    = isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
			$display_style  = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
			$columns   		= isset( $atts['columns'] ) ? $atts['columns'] : 3;
			$orderby        = isset( $atts['orderby'] ) ? $atts['orderby'] : 'date';
			$order          = isset( $atts['order'] ) ? $atts['order'] : 'DESC';

			$rcp_recent_nonce   = wp_create_nonce( 'rcp-recent-sh-nonce' );

			// scrolling pagination
			$paged  = 1;
			if( $loadmore == 'infinite' ){
				$out .= '<div id="content" role="main" class="rcp-recent-sh-module-content-ajax rcp_scroll_pages '. $display_style .'" data-limit="' . esc_attr( $limit ) . '"  data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '"  data-columns="' . esc_attr( $columns ) . '" data-nonce="' . esc_attr( $rcp_recent_nonce ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-display_style="' . $display_style . '">';
				$out .= rcp_recent_recipes( $limit, $orderby, $order, $loadmore, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author,$display_style, $columns, $rcp_extra_css, $paged );
				$out .= '</div>';
				$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cook-pro').'</span></div>';
			} else {
				$out .= rcp_recent_recipes( $limit, $orderby, $order, $loadmore, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $columns, $rcp_extra_css, $paged );
			}
			return $out;
	    }
	}
} // End if().

// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Recent_Recipes();
}

function rcp_recent_recipes( $limit, $orderby, $order, $loadmore, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style, $columns, $rcp_extra_css, $scroll_paged ) {
	$out = '';
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	if ( $loadmore =='infinite' ){ $paged = $scroll_paged; }

	$loadmore =  $loadmore ? $loadmore : 'loadmore';

	$args = array(
		'post_type'      => 'recipe',
		'posts_per_page' => $limit,
		'paged'          => $paged,
		'post_status'    => 'publish',
		'tax_query' => array(
			'relation' => 'OR',
		),
		'orderby'        => $orderby,
		'order'          => $order,
	);
	$rcp_recent_query   = new WP_Query( $args );
	$rcp_recent_nonce   = wp_create_nonce( 'rcp-recent-sh-nonce' );
	$count_results 		= $rcp_recent_query->found_posts;
	$max_num_pages 		= $rcp_recent_query->max_num_pages;

	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( $rcp_recent_query->have_posts() ) {
		$out .= '<div class="rcp-recent-sh-module' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-recent-sh-module-content" data-max_no_pages="' . esc_attr( $max_num_pages ) . '" data-order="' . esc_attr( $order ) . '" data-orderby="' . esc_attr( $orderby ) . '">';
		while ( $rcp_recent_query->have_posts() ) : $rcp_recent_query->the_post();

			$column_index++;

			$out .= '<div class="rcp-recent-sh-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
			$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
			$out .= '</div>'; //.rcp-recent-sh-post

			if ( $column_index == $columns ) {
				$column_index = 0;
			}
		endwhile;
		wp_reset_postdata();
		$out .= '</div>'; //.rcp-recent-module-content
		if ( 'loadmore' === $loadmore ) {
			if ( $count_results > 1 && $count_results > $limit ) {
				$out .= '<div class="rcp-recent-sh-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' . $hide_author . '" data-display_style="' .$display_style. '" data-count="' . $count_results . '"
				data-columns="' . esc_attr( $columns ) . '" data-nonce="' . esc_attr( $rcp_recent_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-number="' . esc_attr( $limit ) . '" >' . esc_html__( 'Load More Recipes', 'cook-pro' ) . '</a></div>';
			}
		}
		$out .= '</div>'; //.rcp-recent-module-row
	} else {
		$out .= '<p class="rcp-main-recent-norecipe">' . esc_html__( 'No recipes were found matching your selection.', 'cook-pro' ) . '</p>';
	} // End if().

	return $out;
}
