<?php
add_shortcode( 'rcp-users-list', 'rcp_users_list_sc' );
function rcp_users_list_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit'    => 6,
		    'orderby'  => 'ID',
			'order'	   => 'ASC',
			'loadmore' => 'no',
		),
		$atts,
		'rcp-users-list'
	);
	$limit      = isset( $atts['limit'] ) ? $atts['limit'] : 6;
	$orderby    = isset( $atts['orderby'] ) ? $atts['orderby'] : 'ID';
	$order      = isset( $atts['order'] ) ? $atts['order'] : 'ASC';
	$loadmore   = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'no';

	$out = rcp_users_list( $limit, $orderby, $order, $loadmore, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Users_List' ) ) {
	class Rcp_VC_Users_List {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_users_list_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-users-list-addon', array( $this, 'rcp_users_list_addon' ) );
	    }

	    public function rcp_vc_users_list_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Users List', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display list of register contributor.', 'cook-pro' ),
	            'base' 			=> 'rcp-users-list-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_user-list.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the users list to display.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cook-pro' ),
						'param_name' 	=> 'orderby',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cook-pro' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Date' 			 => 'date',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the display orderby option you wish to use for users list display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cook-pro' ),
						'param_name' 	=> 'order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the order you wish to use for users list to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Load More', 'cook-pro' ),
						'param_name'  => 'loadmore',
						'description' => esc_html__( 'Check this if you wish to enable the loadmore for users list to display. ( Default: disable )', 'cook-pro' ),
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_users_list_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'    => 6,
		    	'orderby'  => 'ID',
		    	'order'    => 'ASC',
		    	'loadmore' => 'no',
		    	'css'	   => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $limit    = isset( $atts['limit'] ) ? $atts['limit'] : 6;
			$orderby  = isset( $atts['orderby'] ) ? $atts['orderby'] : 'ID';
			$order    = isset( $atts['order'] ) ? $atts['order'] : 'ASC';
			$loadmore = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'no';
		    $out = rcp_users_list( $limit, $orderby, $order, $loadmore, $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Users_List();
}

function rcp_users_list( $limit, $orderby, $order, $loadmore, $rcp_extra_css ) {

	$rcp_more_users_nonce = wp_create_nonce( 'rcp-more-users-nonce' );
	ob_start();
	$out = '';
	$rcp_user_query = new WP_User_Query(
		array(
			'number' => (int) $limit,
			'role__in' => array( 'administrator', 'contributor' ),
			'orderby' => $orderby,
			'order'  => $order,
		)
	);
	$rcp_user_list_query = $rcp_user_query->get_results();
	$rcp_user_count = $rcp_user_query->get_total();

	if ( ! empty( $rcp_user_list_query ) ) {
		$out .= '<div class="rcp-user-list-module ' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-user-list-module-content">';
		$out .= '<h3>';
		// $out .= sprintf( esc_html__( 'We have %s Recipe Contributor!','cook-pro' ), $rcp_user_count );
		$out .= '</h3>';
		foreach ( $rcp_user_list_query as $user_data ) {
			$rcp_author_url  = get_author_posts_url( $user_data->ID );
			$rcp_user_link = get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $user_data->user_login ;
			$out .= '<div class="rcp-profile-header member-dir rcp-user-post rcp-user-item">';
			$out .= '<div class="rcp-profile-header_inner">';
			$out .= '<div class="rcp-profile-info">';
			$out .= '<div class="rcp-profile__thumb">' . rcp_get_avatar( $user_data->ID, 100 ) . '</div>';
			$out .= '<div class="rcp-profile__info">';
			$out .= '<h2><a href="' . esc_url( $rcp_user_link ) . '">' . $user_data->display_name . '</a><span>' . $user_data->position . '</span></h2>';
			$out .= '</div>'; //.rcp-profile__info
			$out .= '</div>'; //.rcp-profile-info
			$out .= '<div class="rcp-profile-exinfo">';
			$out .= '<div class="rcp__follow_wrapper">';
			$out .= '<ul class="rcp__follow_fav">';
			$out .= '<li class="rcp__following_count">' . rcp_get_user_recipes_count( $user_data->ID ) . '<span>' . esc_html__( 'Recipes', 'cook-pro' ) . '</span></li>';
			$out .= '<li class="rcp__followers_count">' . rcp_get_user_reviews_count( $user_data->ID ) . '<span>' . esc_html__( 'Reviews', 'cook-pro' ) . '</span></li>';
			$out .= '<li class="rcp__fav_count">' . rcp_get_user_favorites_count( $user_data->ID ) . '<span>' . esc_html__( 'Favotrites', 'cook-pro' ) . '</span></li>';
			$out .= '</ul>'; //.rcp__follow_fav
			$out .= '</div>'; //.rcp__follow_wrapper
			$out .= '</div>'; //.rcp-profile-exinfo
			$out .= '</div>'; //.rcp-profile-header_inner
			$out .= '</div>'; //.rcp-profile-header
		}
		$out .= '</div>'; // .rcp-user-list-module
		if ( 'no' !== $loadmore ) {
			if ( $rcp_user_count > 1 && $rcp_user_count > $limit ) {
				$out .= '<div class="rcp-users-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-count="' . esc_attr( $rcp_user_count ) . '" data-nonce="' . esc_attr( $rcp_more_users_nonce ) . '"  data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-number="' . esc_attr( $limit ) . '" >' . esc_html__( 'Load More Contributors', 'cook-pro' ) . '</a></div>';
			}
		}
		$out .= '</div>'; // .rcp-user-list-module-content
	} // End if().
	$out .= ob_get_clean();
	return $out;
}
