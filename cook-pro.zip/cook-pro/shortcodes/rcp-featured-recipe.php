<?php
add_shortcode( 'rcp-featured-recipe', 'rcp_featured_recipe' );
function rcp_featured_recipe( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'id' => 2178,
			'hide_cooktime'  => 'no',
			'hide_difflevel' => 'no',
			'hide_yields' 	 => 'no',
			'hide_ratings' 	 => 'no',
			'hide_author' 	 => 'no',
			'display_style' => 'style1',
		),
		$atts,
		'rcp-featured-recipe'
	);
	$out = $class ='';
	$id             = $atts['id'];
	$hide_cooktime  = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
	$hide_difflevel = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
	$hide_yields    = isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
	$hide_ratings   = isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'no';
	$hide_author    = isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
	$display_style  = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';

	if ( ! empty( $id ) ) {
		$rcp_query = get_post( $id );
		$post_id = $rcp_query->ID;
		$out .= '<div class="rcp-recent-sh-post rcp-post-item item4 ' . $display_style . '">';
		$out .= rcp_results_data( $post_id, $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
		$out .= '</div>'; //.rcp-recent-sh-post
	}
	return $out;
}
// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Featured_Recipe' ) ) {
	class Rcp_VC_Featured_Recipe {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_featured_recipe_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-featured-recipe-addon', array( $this, 'rcp_featured_recipe_addon' ) );
	    }

	    public function rcp_vc_featured_recipe_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }
			$recipe_ids = array();
			$recipe_query = get_posts( 'post_type=recipe&orderby=title&numberposts=-1&order=ASC' );
			foreach ( $recipe_query as $key => $entry ) {
				$recipe_ids[ $entry->post_title ] = $entry->ID;
			}
	        vc_map( array(
	            'name' 			=> esc_html__( 'Featured Recipe', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display Featured Recipe.', 'cook-pro' ),
	            'base' 			=> 'rcp-featured-recipe-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_recent-recipe.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' 			=> 'dropdown',
						'holder' 		=> 'div',
						'class' 		=> '',
						'heading' 		=> esc_html__( 'ID', 'cook-pro' ),
						'param_name' 	=> 'id',
						'value' 		=> $recipe_ids,
						'description' 	=> esc_html__( 'Select ids', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Display style', 'cook-pro' ),
						'param_name' 	=> 'display_style',
						'std'		 	=> 'style1',
						'value'		 	=> array(
												esc_html__( 'Select Style','cook-pro' ) => '',
												'Style1' => 'style1',
												'Style2' => 'style2',
											),
						'description'   => esc_html__( 'Select the style you wish to use for Recipe to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Cooking Time', 'cook-pro' ),
						'param_name'  => 'hide_cooktime',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Difficulty Level', 'cook-pro' ),
						'param_name'  => 'hide_difflevel',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Yields', 'cook-pro' ),
						'param_name'  => 'hide_yields',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Ratings', 'cook-pro' ),
						'param_name'  => 'hide_ratings',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Author', 'cook-pro' ),
						'param_name'  => 'hide_author',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_featured_recipe_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
				'hide_cooktime'	 => 'no',
				'hide_difflevel' => 'no',
				'hide_yields' 	 => 'no',
				'hide_ratings' 	 => 'no',
				'hide_author' 	 => 'no',
				'display_style'  => 'style1',
		    	'css'		  	 => '',
		    	'extra_class' 	 => '',
		    ), $atts ) );

			$rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
			if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}
			$out = '';
			$id             = $atts['id'];
			$hide_cooktime  = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
			$hide_difflevel = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
			$hide_yields    = isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
			$hide_ratings   = isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'no';
			$hide_author    = isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
			$display_style  = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
			$class = '';
			if ( ! empty( $id ) ) {
				$rcp_query = get_post( $id );
				$post_id = $rcp_query->ID;
				$out = '<div class="rcp-fc-recipe-wrapper ' . $rcp_extra_css . '">';
				$out .= '<div class="rcp-recent-sh-post rcp-post-item item4 ' . $display_style . '">';
				$out .= rcp_results_data( $post_id, $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
				$out .= '</div>'; //.rcp-recent-sh-post
				$out .= '</div>'; //.rcp-fc-recipe-wrapper
			}

			return $out;
		}
	}
} // End if().

// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Featured_Recipe();
}
