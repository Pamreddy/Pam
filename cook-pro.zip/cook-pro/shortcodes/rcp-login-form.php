<?php
add_shortcode( 'rcp-login', 'rcp_login_form_sc' );
function rcp_login_form_sc( $atts, $content = null ) {
	$out = rcp_login_form( '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Login_Form' ) ) {
	class Rcp_VC_Login_Form {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_login_form_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-login-form-addon', array( $this, 'rcp_login_form_addon' ) );
	    }

	    public function rcp_vc_login_form_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Login Form', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display the login and registration form.', 'cook-pro' ),
	            'base' 			=> 'rcp-login-form-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_login-form.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
	            	array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
				),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_login_form_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		    	'css'		  => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $out = rcp_login_form( $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Login_Form();
}

// add_shortcode( 'rcp-login', 'rcp_login_form' );
function rcp_login_form( $atts, $content = null ) {
	global $post;
	$out = $rcp_active_class = $first_name = $last_name = $email = $position = $reg_captcha = '';
	ob_start();

	$rcp_logout_msg = get_option( 'rcp_logout_msg' ) ? get_option( 'rcp_logout_msg' ): esc_html__( 'Login to submit the recipe','cook-pro' );
	$rcp_logout_msg = do_shortcode( $rcp_logout_msg );
	if ( ! is_user_logged_in() ) {
		$out .= '<p>' . $rcp_logout_msg . '</p>';
	}

	$out .= '<div class="rcp-profile__panes">';
	$out .= '<ul class="rcp__pane">';
	$out .= '<li id="#pane0"><a href="#pane0">' . esc_html__( 'Login', 'cook-pro' ) . '</a></li>';

	if ( isset( $_POST['submit'] ) && ( $_POST['submit'] == 'Register' ) ) {
		$rcp_active_class = 'current';
	}

	$out .= '<li id="#pane1" class="' . $rcp_active_class . '"><a href="#pane1">' . esc_html__( 'Register', 'cook-pro' ) . '</a></li>';
	$out .= '<li id="#pane2"><a href="#pane2">' . esc_html__( 'Forgot Password', 'cook-pro' ) . '</a></li>';
	$out .= '</ul>'; //.rcp_tabs

	$out .= '<div class="rcp__pane_content">';

	// Login Form
	$out .= '<div id="pane0" class="pane_content">';
	$out .= '<div class="rcp-profile-login">';
	$out .= '<h3 class="user-form-welcome">' . esc_html__( 'Welcome Back.','cook-pro' ) . '</h3>';
	if ( isset( $reset ) && $reset == true ) {
		$out .= '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice">';
		$out .= '<strong>' . esc_html__( 'Success!', 'cook-pro' ) . '</strong><br />';
		$out .= esc_html__( 'Check your email to reset your password.', 'cook-pro' );
		$out .= '</p></div>';
	}
	$out .= '<div class="rcp-form-wrap">';
	$out .= '<div class="rcp-custom-error">' . esc_html__( 'Both fields are required to log in.', 'cook-pro' ) . '</div>';
	if ( isset( $_GET['loginfailed'] ) ) {
		$out .= '<div class="rcp-custom-error not-hidden">' . esc_html__( 'Sorry, those login credentials are incorrect.', 'cook-pro' ) . '</div>';
	}
	$out .= wp_login_form( array(
		'echo' => false,
		'redirect' => get_the_permalink( rcp_get_option( 'rcp_profile_page_id' ) ),
	) );
	$out .= '</div>'; //.rcp-form-wrap
	$out .= '</div>'; //.rcp-profile-login
	$out .= '</div>'; //.rcp-login

	// Register form
	$out .= '<div id="pane1" class="pane_content">';
	if ( get_option( 'users_can_register' ) ) {
		$out .= '<div class="rcp-profile-register">';
		if ( isset( $_POST['submit'] ) ) {
			// sanitize user form input
	        global $username, $first_name, $last_name, $password, $email, $position, $reg_captcha;

	        $first_name 	= apply_filters( 'recipe_registration_first_name', sanitize_user( $_POST['first_name'] ) );
			$last_name 		= apply_filters( 'recipe_registration_last_name', sanitize_user( $_POST['last_name'] ) );
	        $password 		= apply_filters( 'recipe_registration_password', wp_generate_password() );
	        $email      	= apply_filters( 'recipe_registration_email', sanitize_email( $_POST['email'] ) );
			$position      	= apply_filters( 'recipe_registration_position', sanitize_user( $_POST['position'] ) );
			$reg_captcha    = apply_filters( 'recipe_registration_captcha', sanitize_user( $_POST['g-recaptcha-response'] ) );

		    if ( $last_name ) {
				$username = $first_name . $last_name;
			} else {
				$username = $first_name;
			}
			$username = preg_replace( '/&([a-z])[a-z]+;/i', '$1', htmlentities( $username ) );
			$errors = rcp_registration_validation( $username, $email, $reg_captcha );
			if ( ! empty( $errors ) ) {
				$rand = rand( 111, 999 );
				if ( $last_name ) {
					$username = $first_name . $last_name . '_' . $rand;
				} else {
					$username = $first_name . '_' . $rand;
			 	}
				$username = preg_replace( "/&([a-z])[a-z]+;/i", "$1", htmlentities( $username ) );
			}
			if ( empty( $errors ) ) {
				if ( 1 > count( $errors ) ) {
			        $userdata = array(
			        	'user_login'    => $username,
						'user_email'    => $email,
						'user_pass'     => $password,
						'first_name'	=> $first_name,
						'last_name'		=> $last_name,
						'role' 			=> 'contributor',
			    	);
			        $user_id = wp_insert_user( $userdata );
			        $nickname = $first_name . ( $last_name ? ' ' . $last_name : '' );
					wp_update_user( array(
						'ID' => $user_id,
						'display_name' => $nickname,
					) );
			        update_user_meta( $user_id, 'nickname', $nickname );
					update_user_meta( $user_id, 'position', $position );

			        // Send a registration welcome email to the new user?
					$email_message       = get_option( 'rcp_registration_email_message' );
					$email_subject       = get_option( 'rcp_registration_email_subject' );
					$admin_email_message = get_option( 'rcp_registration_admin_email_message' );
					$admin_email_subject = get_option( 'rcp_registration_admin_email_subject' );
					$rcp_logo_img        = '';
					$rcp_logo            = rcp_get_option( 'rcp_email_template_logo' );
					if ( ! empty( $rcp_logo ) ) {
						$attachment_id = rcp_get_attachment_id_from_src( $rcp_logo );
						$rcp_logo_img  = wp_get_attachment_image( $attachment_id, array( '200', '100' ), '', '' );
					}
					$admin_email = get_option( 'admin_email' );
					if ( $email_message && $email_subject ) {
						$msg_placeholders  = array( '[name]' );
						$msg_replacements  = array( $first_name );
						$subj_placeholders = array( '[name]', '[username]', '[password]' );
						$subj_replacements = array( $first_name, $username, $password );
						$rcp_email_message = str_replace( $msg_placeholders, $msg_replacements, $email_message );
						$email_subject     = str_replace( $subj_placeholders, $subj_replacements, $email_subject );

						$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
						$email_placeholders = array( '[logo]', '[message]' );
						$email_replacements = array( $rcp_logo_img, $rcp_email_message );
						$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
						$email_message      = do_shortcode( $email_message );
						$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $admin_email . '>' . "\r\n\\";
						$headers .= "MIME-Version: 1.0\r\n";
						$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

						wp_mail( $email, $email_subject, $email_message, $headers );
					}
					if ( $admin_email_message && $admin_email_subject ) {
						$msg_placeholders  = array( '[name]' );
						$msg_replacements  = array( $first_name );
						$subj_placeholders = array( '[name]', '[username]', '[password]' );
						$subj_replacements = array( $first_name, $username, $password );
						$rcp_email_message = str_replace( $msg_placeholders, $msg_replacements, $admin_email_message );
						$email_subject     = str_replace( $subj_placeholders, $subj_replacements, $admin_email_subject );

						$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
						$email_placeholders = array( '[logo]', '[message]' );
						$email_replacements = array( $rcp_logo_img, $rcp_email_message );
						$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
						$email_message      = do_shortcode( $email_message );
						$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $email . '>' . "\r\n\\";
						$headers .= "MIME-Version: 1.0\r\n";
						$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

						wp_mail( $admin_email, $email_subject, $email_message, $headers );
					}
			        $registration_complete = '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice"><strong>' . esc_html__( 'Success!', 'cook-pro' ) . '</strong><br />' . esc_html__( 'Registration complete, check your email for login information.','cook-pro' ) . '</p></div>';
			    } // End if().
	        } else {
	        	$registration_complete = 'error';
	        } // End if().
	    } else {
	    	$registration_complete = false;
	    } // End if().
		//
		if ( $registration_complete && $registration_complete != 'error' ) {
		    $out .= $registration_complete;
			$first_name = $last_name = $email = $position = $reg_captcha = '';
	    } else {
	    	if ( $registration_complete == 'error' ) {
		    	$out .= '<div class="rcp-custom-error" style="display:block">' . implode( '<br>', $errors ) . '</div>';
	    	}
	    }
		$out .= rcp_registration_form( $first_name, $last_name , $email , $position , $reg_captcha );
		$out .= '</div>'; //.rcp-profile-register
	} else {
		$out .= esc_html__( 'Registrations are currently disabled','cook-pro' );
	} // End if().
	$out .= '</div>'; //.rcp-register
	// Forgot Form
	$out .= '<div id="pane2" class="pane_content">';
	$out .= '<div class="rcp-profile-forgot">';
	$out .= '<div class="rcp-custom-error">' . esc_html__( 'A username or email address is required to reset your password.','cook-pro' ) . '</div>';
	$out .= '<form method="post" action="' . site_url( 'wp-login.php?action=lostpassword', 'login_post' ) . '" class="wp-user-form">';
	$out .= '<p class="username">';
	$out .= '<label for="user_login" class="hide">' . esc_html__( 'Username or Email', 'cook-pro' ) . '</label>';
	$out .= '<input type="text" name="user_login" value="" size="20" id="user_login" tabindex="1001" />';
	$out .= '</p>';
	$out .= do_action( 'login_form', 'resetpass' );
	$out .= '<input type="submit" name="user-submit" value="' . esc_html__( 'Reset my password', 'cook-pro' ) . '" class="user-submit" tabindex="1002" />';
	$out .= '<input type="hidden" name="redirect_to" value="' . get_permalink() . '?reset=true" />';
	$out .= '<input type="hidden" name="user-cookie" value="1" />';
	$out .= '</form>';
	$out .= '</div>'; //.rcp-profile-forgot
	$out .= '</div>'; //.pane_content

	$out .= '</div>'; //.rcp__pane_content
	$out .= '</div>'; //.rcp-profile__panes
	$out .= ob_get_clean();
	return $out;
}
