<?php
// add shortcode
add_shortcode( 'rcp_categories_list', 'rcp_categories_list' );
function rcp_categories_list( $atts, $content = null ) {
	$atts = shortcode_atts(
		array(
			'categories' => '',
			'order'      => 'ASC',
			'orderby'    => 'menu_order',
			'columns'    => '3',
			'title'      => 'true',
			'limit'      => '',
			'pagination' => '',
		),
		$atts,
		'rcp_categories_list'
	);
	$limit      = isset( $atts['limit'] ) ? $atts['limit'] : '';
	$orderby    = isset( $atts['orderby'] ) ? $atts['orderby'] : '';
	$order      = isset( $atts['order'] ) ? $atts['order'] : '';
	$columns    = isset( $atts['columns'] ) ? $atts['columns'] : 3;
	$cat_title  = isset( $atts['cat_title'] ) ? $atts['cat_title'] : 'true';
	$cat_values = isset( $atts['categories'] ) ? $atts['categories'] : '';
	$pagination = isset( $atts['pagination'] ) ? $atts['pagination'] : '';
	$paged      = 1;
	$rcp_extra_css = '';

	$out = rcp_categories_list_data( $limit, $orderby, $order, $columns, $rcp_extra_css, $cat_values, $paged, $pagination );
	return $out;
}
// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! class_exists( 'Rcp_VC_Categories_List' ) ) {
	class Rcp_VC_Categories_List {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_categories_list_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp_categories_list_addon', array( $this, 'rcp_categories_list_addon' ) );
	    }

	    public function rcp_vc_categories_list_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }
	        //
	        $rcp_cat_options = array();
			$rcp_search_cat = get_terms( 'recipe_cat', 'parent=0&hide_empty= 1' );
			if ( ! empty( $rcp_search_cat ) ) {
				foreach ( $rcp_search_cat as $category ) {
					$rcp_cat_options[ $category->name ] = $category->term_id;
				}
			}
	        vc_map( array(
	            'name' 			=> esc_html__( 'Recipe Categories List', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display the recipe categories on your selection.', 'cook-pro' ),
	            'base' 			=> 'rcp_categories_list_addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_category.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '3',
						'value' => array(
							esc_html__( 'Select Columns','cook-pro' ) => '',
							esc_html__( '2 Columns', 'cook-pro' ) => '2',
							esc_html__( '3 Columns', 'cook-pro' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cook-pro' ),
					),
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the search by categories to display.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cook-pro' ),
						'param_name' 	=> 'orderby',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cook-pro' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Date' 			 => 'date',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the display orderby option you wish to use for categories display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cook-pro' ),
						'param_name' 	=> 'order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the order you wish to use for categories to display.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'checkbox',
						'heading'  	 	=> esc_html__( 'Select Categories', 'cook-pro' ),
						'param_name' 	=> 'categories',
						'value' 	 	=> $rcp_cat_options,
						'description' 	=> esc_html__( 'Select the categories from which you wish to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Pagination', 'cook-pro' ),
						'param_name'  => 'pagination',
						'value'		  => array(
							esc_html__( 'True', 'cook-pro' ) => 'true',
						),
						'description' => esc_html__( 'Check this if you wish to display pagination.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name' => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_categories_list_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
					'categories' => '',
					'order'      => 'ASC',
					'orderby'    => 'menu_order',
					'columns'    => '3',
					'title'      => 'true',
					'limit'      => '',
					'pagination' => '',
			        'css'		  => '',
			        'extra_class' => '',
			    ),
				$atts )
			);
			$out = '';
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

			$limit      = isset( $atts['limit'] ) ? $atts['limit'] : '';
			$orderby    = isset( $atts['orderby'] ) ? $atts['orderby'] : '';
			$order      = isset( $atts['order'] ) ? $atts['order'] : '';
			$cat_title  = isset( $atts['cat_title'] ) ? $atts['cat_title'] : 'true';
			$columns    = isset( $atts['columns'] ) ? $atts['columns'] : 3;
			$cat_values = isset( $atts['categories'] ) ? $atts['categories'] : '';
			$pagination = isset( $atts['pagination'] ) ? $atts['pagination'] : '';

			$paged = 1;

			$out .= rcp_categories_list_data( $limit, $orderby, $order, $columns, $rcp_extra_css, $cat_values, $paged, $pagination );

			return $out;
		}
	}
} // End if().
// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Categories_List();
}
function rcp_categories_list_data( $limit, $orderby, $order, $columns, $rcp_extra_css, $cat_values, $paged, $pagination ) {

	$out = $class = '';

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}

	$column_index = 0;
	$columns = $columns ? $columns : 3;
	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	$args = array(
		'taxonomy'  => 'recipe_cat',
		'hide_empty' => false,
		'include'   => $cat_values,
		'orderby'   => $orderby,
		'order'     => $order,
	);
	if ( !empty( $limit ) ) {
		$args['number'] = $limit;
	}
	if ( $pagination == 'true' ) {
		$limit   = !empty( $limit ) ? $limit : -1; // number of terms to display per page
		$offset  = ( $paged > 0 ) ?  $limit * ( $paged - 1 ) : 1;
		$args['number'] = $limit;
		$args['offset'] = $offset;
		$totalterms = count( get_terms( array(
			'taxonomy'  => 'recipe_cat',
			'hide_empty' => false,
			'include'   => $cat_values,
		) ) );
		$totalpages = ceil( $totalterms / $limit );
	}
	$rcp_cats_array = get_terms( $args );
	$out .= '<div class="rcp-catlist-sh-module ' . $rcp_extra_css . '">';
	$out .= '<div class="rcp-catlist-sh-module-content">';
	foreach ( $rcp_cats_array as $category_order ) {

		$column_index++;

		$term_id   = $category_order->term_id;
		$term_meta = get_option( "taxonomy_$term_id" );

		$out .= '<div class="rcp-catlist-sh-item rcp-post-item ' . $class . '">';
		$out .= '<div class="rcp__item">';
		$out .= '<a href="' . esc_url( get_term_link( $category_order->slug, 'recipe_cat' ) ) . '">';
		if ( isset( $term_meta['img'] ) && '' !== $term_meta['img'] ) {
			$img_id = rcp_attachment_url_to_postid( $term_meta['img'] );
			$out .= '<div class="rcp__item_catimg on-hover">';
			$out .= wp_get_attachment_image( $img_id, 'rcp_medium_horizontal' );
			$out .= '</div>';//.pimg overlay
		}
		$out .= '<div class="rcp__item_catdetails">';
		$out .= '<h2>' . $category_order->name . '</h2>';
		$out .= '<span class="catlist_count">' . $category_order->count . esc_html__( ' Recipies', 'cook-pro' ) . '</span>';
		$out .= '</div>';//.rcp__item_catdetails
		$out .= '</a>';//.rcp__item_catdetails
		$out .= '</div>'; //.rcp__item
		$out .= '</div>'; //.atg-col-4

		if ( $column_index === $columns ) {
			$column_index = 0;
		}
	}
	$out .= '</div>'; //.atg-row
	$out .= '</div>'; //.rcp-sh-by-cat-module-content
	$out .= '<div class="clear"></div>'; // clear class
	wp_reset_postdata();
	if ( $pagination == 'true' ) {
		$out .= rcp_custom_page_navi( $totalpages, $paged, 2, 0 );
	}
	return $out;
}
function rcp_custom_page_navi( $totalpages, $page, $end_size, $mid_size ){
	$bignum = 999999;
	 return paginate_links( array(
		'base'      => str_replace( $bignum, '%#%', esc_url( get_pagenum_link( $bignum ) ) ),
		'format'    => '',
		'current'   => $page,
		'total'     => $totalpages,
		'prev_text' => '<i class="fa fa-chevron-left"></i>',
		'next_text' => '<i class="fa fa-chevron-right"></i>',
		'type'      => 'list',
		'show_all'  => false,
		'end_size'  => $end_size,
		'mid_size'  => $mid_size
	) );
}
