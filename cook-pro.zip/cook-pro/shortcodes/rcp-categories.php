<?php
add_shortcode( 'rcp-categories', 'rcp_search_recps_by_categories_sc' );
function rcp_search_recps_by_categories_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit'       	=> 8,
			'orderby'     	=> 'date',
			'order'	      	=> 'DESC',
			'columns' 	  	=> 4,
			'loadmore'	  	=> 'infinite',
			'categories'  	=> '',
			'cuisines'	  	=> '',
			'methods'	  	=> '',
			'ingredients' 	=> '',
			'hide_cooktime' => 'no',
			'hide_difflevel'=> 'no',
			'hide_yields' 	=> 'no',
			'hide_ratings' 	=> 'yes',
			'hide_author' 	=> 'no',
			'display_style' => 'style1',
		),
		$atts,
		'rcp-categories'
	);
	$out = $rcp_extra_css = '';
	$limit                  = isset( $atts['limit'] ) ? $atts['limit'] : '';
	$orderby                = isset( $atts['orderby'] ) ? $atts['orderby'] : '';
	$order                  = isset( $atts['order'] ) ? $atts['order'] : '';
	$columns                = isset( $atts['columns'] ) ? $atts['columns'] : 4;
	$loadmore               = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
	$rcp_cat_values		 	= isset( $atts['categories'] ) ? $atts['categories'] : '';
	$rcp_cuisine_values 	= isset( $atts['cuisines'] ) ? $atts['cuisines'] : '';
	$rcp_method_values 		= isset( $atts['methods'] ) ? $atts['methods'] : '';
	$rcp_ingredient_values 	= isset( $atts['ingredients'] ) ? $atts['ingredients'] : '';
	$hide_cooktime  		= isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
	$hide_difflevel 		= isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
	$hide_yields  			= isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
	$hide_ratings  			= isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'yes';
	$hide_author	 		= isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
	$display_style  		= isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';

	$paged = 1;

	$rcp_by_cat_sh_nonce = wp_create_nonce( 'rcp-by-cat-sh-nonce' );

	if( $loadmore == 'infinite' ){
		$out .='<div id="content" class="rcp-sh-by-cat-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' .$hide_author. '"  data-display_style="' . $display_style . '" data-limit="' . esc_attr( $limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_by_cat_sh_nonce ) . '">';
		$out .= rcp_search_recps_by_categories( $limit, $orderby, $order, $columns, $loadmore, $rcp_cat_values, $rcp_cuisine_values, $rcp_method_values, $rcp_ingredient_values, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style,$paged );
		$out .= '</div>';
		$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cookpro_textdomain').'</span></div>';
	}else{
		$out .= rcp_search_recps_by_categories( $limit, $orderby, $order, $columns, $loadmore, $rcp_cat_values, $rcp_cuisine_values, $rcp_method_values, $rcp_ingredient_values, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style,$paged );
	}

	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Search_Recps_By_Categories' ) ) {
	class Rcp_VC_Search_Recps_By_Categories {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_search_recps_by_categories_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-categories-addon', array( $this, 'rcp_search_recps_by_categories_addon' ) );
	    }

	    public function rcp_vc_search_recps_by_categories_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }
	        //
	        $rcp_cat_options = array();
			$rcp_search_cat = get_terms( 'recipe_cat', 'parent=0&hide_empty= 1' );
			if ( ! empty( $rcp_search_cat ) ) {
				foreach ( $rcp_search_cat as $category ) {
					$rcp_cat_options[ $category->name ] = $category->term_id;
				}
			}
			//
	        $rcp_cuisines_options = array();
			$rcp_search_cuisines = get_terms( 'recipe_cuisine', 'parent=0&hide_empty= 1' );
			if ( ! empty( $rcp_search_cuisines ) ) {
				foreach ( $rcp_search_cuisines as $category ) {
					$rcp_cuisines_options[ $category->name ] = $category->term_id;
				}
			}
			//
	        $rcp_method_options = array();
			$rcp_search_method = get_terms( 'recipe_method', 'parent=0&hide_empty= 1' );
			if ( ! empty( $rcp_search_method ) ) {
				foreach ( $rcp_search_method as $category ) {
					$rcp_method_options[ $category->name ] = $category->term_id;
				}
			}
			//
	        $rcp_ingredients_options = array();
			$rcp_search_ingredients = get_terms( 'post_tag', 'parent=0&hide_empty= 1' );
			if ( ! empty( $rcp_search_ingredients ) ) {
				foreach ( $rcp_search_ingredients as $category ) {
					$rcp_ingredients_options[ $category->name ] = $category->term_id;
				}
			}

	        vc_map( array(
	            'name' 			=> esc_html__( 'Search By Categories', 'cookpro_textdomain' ),
	            'description' 	=> esc_html__( 'Display the recipe based on your selection.', 'cookpro_textdomain' ),
	            'base' 			=> 'rcp-categories-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_category.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cookpro_textdomain' ),
	            'params' 		=> array(
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Display style', 'cookpro_textdomain' ),
						'param_name' 	=> 'display_style',
						'std'		 	=> 'style1',
						'value'		 	=> array(
												esc_html__( 'Select Style','cookpro_textdomain' ) => '',
												'Style1' => 'style1',
												'Style2' => 'style2',
											),
						'description'   => esc_html__( 'Select the style you wish to use for Recipes to display.', 'cookpro_textdomain' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '4',
						'value' => array(
							esc_html__( 'Select Columns','cookpro_textdomain' ) => '',
							esc_html__( '2 Columns', 'cookpro_textdomain' ) => '2',
							esc_html__( '3 Columns', 'cookpro_textdomain' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cookpro_textdomain' ),
					),
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cookpro_textdomain' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the search by categories to display.', 'cookpro_textdomain' ),
					),
					array(
						'type' 			=> 'dropdown',
						'heading'  	 	=> esc_html__( 'Orderby', 'cookpro_textdomain' ),
						'param_name' 	=> 'orderby',
						'value' 	 	=> array(
												esc_html__( 'Select Orderby','cookpro_textdomain' ) => '',
												'ID' 			 => 'ID',
												'Title' 		 => 'title',
												'Date' 			 => 'date',
												'Menu Order' 	 => 'menu_order',
											),
						'description' 	=> esc_html__( 'Select the display orderby option you wish to use for categories display.', 'cookpro_textdomain' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Order', 'cookpro_textdomain' ),
						'param_name' 	=> 'order',
						'std'		 	=> 'DESC',
						'value'		 	=> array(
												esc_html__( 'Select Order','cookpro_textdomain' ) => '',
												'Ascending'  => 'ASC',
												'Descending' => 'DSC',
											),
						'description'   => esc_html__( 'Select the order you wish to use for categories to display.', 'cookpro_textdomain' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Load More', 'cookpro_textdomain' ),
						'param_name' 	=> 'loadmore',
						'std'		 	=> 'infinite',
						'value'		 	=> array(
												esc_html__( 'Select Loadmore Option','cookpro_textdomain' ) => '',
												'Infinite Scroll'  => 'infinite',
												'Load More' => 'loadmore',
											),
						'description'   => esc_html__( 'Select the Loadmore you wish to use for Recent Recipe to display.', 'cookpro_textdomain' ),
					),
					array(
						'type' 			=> 'checkbox',
						'heading'  	 	=> esc_html__( 'Search By Categories', 'cookpro_textdomain' ),
						'param_name' 	=> 'categories',
						'value' 	 	=> $rcp_cat_options,
						'description' 	=> esc_html__( 'Select the search by categories from which you wish to pull the recipes.', 'cookpro_textdomain' ),
					),
					array(
						'type' 			=> 'checkbox',
						'heading'  	 	=> esc_html__( 'Search By Cuisines', 'cookpro_textdomain' ),
						'param_name' 	=> 'cuisines',
						'value' 	 	=> $rcp_cuisines_options,
						'description' 	=> esc_html__( 'Select the search by cuisines from which you wish to pull the recipes.', 'cookpro_textdomain' ),
					),
					array(
						'type' 			=> 'checkbox',
						'heading'  	 	=> esc_html__( 'Search By Method', 'cookpro_textdomain' ),
						'param_name' 	=> 'method',
						'value' 	 	=> $rcp_method_options,
						'description' 	=> esc_html__( 'Select the search by method from which you wish to pull the recipes.', 'cookpro_textdomain' ),
					),
					array(
						'type' 			=> 'checkbox',
						'heading'  	 	=> esc_html__( 'Search By Ingredients', 'cookpro_textdomain' ),
						'param_name' 	=> 'ingredients',
						'value' 	 	=> $rcp_ingredients_options,
						'description' 	=> esc_html__( 'Select the search by ingredients from which you wish to pull the recipes.', 'cookpro_textdomain' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Cooking Time', 'cookpro_textdomain' ),
						'param_name'  => 'hide_cooktime',
						'value'		  => array(
							esc_html__( 'Yes', 'cookpro_textdomain' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Difficulty Level', 'cookpro_textdomain' ),
						'param_name'  => 'hide_difflevel',
						'value'		  => array(
							esc_html__( 'Yes', 'cookpro_textdomain' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Yields', 'cookpro_textdomain' ),
						'param_name'  => 'hide_yields',
						'value'		  => array(
							esc_html__( 'Yes', 'cookpro_textdomain' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Ratings', 'cookpro_textdomain' ),
						'param_name'  => 'hide_ratings',
						'value'		  => array(
							esc_html__( 'Yes', 'cookpro_textdomain' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Author', 'cookpro_textdomain' ),
						'param_name'  => 'hide_author',
						'value'		  => array(
							esc_html__( 'Yes', 'cookpro_textdomain' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cookpro_textdomain' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cookpro_textdomain' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Extra Class Name', 'cookpro_textdomain' ),
						'param_name' => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cookpro_textdomain' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_search_recps_by_categories_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'       => 8,
				'orderby'     => 'date',
				'order'       => 'DESC',
				'columns'     => 4,
				'categories'  => '',
				'cuisines'    => '',
				'methods'     => '',
				'ingredients' => '',
				'loadmore'    => 'no',
				'hide_cooktime'	=> 'no',
				'hide_difflevel'=> 'no',
				'hide_yields' 	=> 'no',
				'hide_ratings' 	=> 'yes',
				'hide_author'	=> 'no',
		        'display_style' => 'style1',
		        'css'			=> '',
		        'extra_class' 	=> '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}
			$out = '';
		    $limit                  = isset( $atts['limit'] ) ? $atts['limit'] : '';
			$orderby                = isset( $atts['orderby'] ) ? $atts['orderby'] : '';
			$order                  = isset( $atts['order'] ) ? $atts['order'] : '';
			$columns                = isset( $atts['columns'] ) ? $atts['columns'] : 4;
			$loadmore               = isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
			$rcp_cat_values		 	= isset( $atts['categories'] ) ? $atts['categories'] : '';
			$rcp_cuisine_values 	= isset( $atts['cuisines'] ) ? $atts['cuisines'] : '';
			$rcp_method_values 		= isset( $atts['methods'] ) ? $atts['methods'] : '';
			$rcp_ingredient_values 	= isset( $atts['ingredients'] ) ? $atts['ingredients'] : '';
			$hide_cooktime  		= isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
			$hide_difflevel  		= isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
			$hide_yields  			= isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
			$hide_ratings 			= isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'yes';
			$hide_author	 		= isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
			$display_style  		= isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';

			$paged = 1;
			$rcp_by_cat_sh_nonce = wp_create_nonce( 'rcp-by-cat-sh-nonce' );

			if( $loadmore == 'infinite' ){
				$out .='<div id="content" class="rcp-sh-by-cat-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '"  data-hide_author="' .$hide_author. '" data-display_style="' . $display_style . '" data-limit="' . esc_attr( $limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_by_cat_sh_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-columns="' . esc_attr( $columns ) . '" data-categories="' . esc_attr( $rcp_cat_values ) . '" data-cuisines="' . esc_attr( $rcp_cuisine_values ) . '"  data-methods="' . esc_attr( $rcp_method_values ) . '"  data-ingredients="' . esc_attr( $rcp_ingredient_values ) . '">';
				$out .= rcp_search_recps_by_categories( $limit, $orderby, $order, $columns, $loadmore, $rcp_cat_values, $rcp_cuisine_values, $rcp_method_values, $rcp_ingredient_values, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style,$paged );
				$out .= '</div>';
				$out .= '<div id="inifiniteLoader"></div>';
			}else{
				$out .= rcp_search_recps_by_categories( $limit, $orderby, $order, $columns, $loadmore, $rcp_cat_values, $rcp_cuisine_values, $rcp_method_values, $rcp_ingredient_values, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style,$paged );
			}

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Search_Recps_By_Categories();
}
function rcp_search_recps_by_categories( $limit, $orderby, $order, $columns, $loadmore, $rcp_cat_values, $rcp_cuisine_values, $rcp_method_values, $rcp_ingredient_values, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style, $scroll_paged ) {

	$out = '';

	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	if ( $loadmore =='infinite' ){ $paged = $scroll_paged; }

	if ( ! empty( $rcp_cat_values ) ) {
		$rcp_cats = explode( ',', $rcp_cat_values );
	}
	if ( ! empty( $rcp_cuisine_values ) ) {
		$rcp_cuisines	= explode( ',', $rcp_cuisine_values );
	}
	if ( ! empty( $rcp_method_values ) ) {
		$rcp_methods = explode( ',', $rcp_method_values );
	}
	if ( ! empty( $rcp_ingredient_values ) ) {
		$rcp_ingredients 	= explode( ',', $rcp_ingredient_values );
	}

	$args = array(
		'post_type'			=> 'recipe',
		'posts_per_page'	=> $limit,
		'paged'				=> $paged,
		'post_status'		=> 'publish',
		'tax_query' => array(
			'relation' => 'OR',
		),
		'orderby'	=> $orderby,
		'order'		=> $order,
	);

	if ( '' !== $rcp_cat_values ) {
		$rcp_cat_args = array(
			'taxonomy' => 'recipe_cat',
			'field' => 'term_id',
			'terms' => $rcp_cats,
		);
		array_push( $args['tax_query'], $rcp_cat_args );
	}
	if ( '' !== $rcp_cuisine_values ) {
		$rcp_cuisine_args = array(
			'taxonomy' => 'recipe_cuisine',
			'field' => 'term_id',
			'terms' => $rcp_cuisine_values,
		);
		array_push( $args['tax_query'], $rcp_cuisine_args );
	}
	if ( '' !== $rcp_method_values ) {
		$rcp_method_args = array(
			'taxonomy' => 'recipe_method',
			'field' => 'term_id',
			'terms' => $rcp_methods,
		);
		array_push( $args['tax_query'], $rcp_method_args );
	}
	if ( '' !== $rcp_ingredient_values ) {
		$rcp_ingredient_args = array(
			'taxonomy' => 'post_tag',
			'field' => 'term_id',
			'terms' => $rcp_ingredients,
		);
		array_push( $args['tax_query'], $rcp_ingredient_args );
	}
	$rcp_tax_query = new WP_Query( $args );
	$count_results = $rcp_tax_query->found_posts;
	$max_num_pages = $rcp_tax_query->max_num_pages;
	$rcp_by_cat_sh_nonce = wp_create_nonce( 'rcp-by-cat-sh-nonce' );

	$column_index = 0;

	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( $rcp_tax_query->have_posts() ) {
		$out .= '<div class="rcp-sh-by-cat-module ' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-sh-by-cat-module-content" data-max_no_pages="' . esc_attr( $max_num_pages ) . '" data-order="' . esc_attr( $order ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-categories="' . esc_attr( $rcp_cat_values ) . '" data-cuisines="' . esc_attr( $rcp_cuisine_values ) . '"  data-methods="' . esc_attr( $rcp_method_values ) . '"  data-ingredients="' . esc_attr( $rcp_ingredient_values ) . '">';
		while ( $rcp_tax_query->have_posts() ) : $rcp_tax_query->the_post();

			$column_index++;

			$rcp_cat_post_id 	= get_the_ID();
			$rcp_short_info  	= get_post_meta( $rcp_cat_post_id, 'recipe_short_info', true );
			$rcp_servings 		= get_post_meta( $rcp_cat_post_id, 'recipe_servings', true );
			$rcp_cook_time  	= rcp_get_time( $rcp_cat_post_id ,'recipe_ctime' );
			$rcp_diff_level   	= get_post_meta( $rcp_cat_post_id, 'recipe_diff_level', true );
			$rcp_post_author_id = get_post_field( 'post_author', $rcp_cat_post_id );
			$rcp_user_info 	 	= get_userdata( $rcp_post_author_id );
			$rcp_user_link		= get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $rcp_user_info->user_login ;

			$out .= '<div class="rcp-sh-by-cat-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
			$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
			$out .= '</div>'; //.rcp-post-item

			if ( $column_index == $columns ) {
				$column_index = 0;
			}
		endwhile;
		wp_reset_query();
		$out .= '</div>'; //.rcp-search-module-content
		if ( 'loadmore' === $loadmore ) {
			if ( $count_results > 1 && $count_results > $limit ) {
				$out .= '<div class="rcp-by-cat-sh-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' . $hide_yields . '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' .$hide_author. '" data-count="' . esc_attr( $count_results ) . '" data-nonce="' . esc_attr( $rcp_by_cat_sh_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-columns="' . esc_attr( $columns ) . '" data-categories="' . esc_attr( $rcp_cat_values ) . '" data-cuisines="' . esc_attr( $rcp_cuisine_values ) . '"  data-methods="' . esc_attr( $rcp_method_values ) . '"  data-ingredients="' . esc_attr( $rcp_ingredient_values ) . '" data-number="' . esc_attr( $limit ) . '" data-style="' . esc_attr( $display_style ) . '">' . esc_html__( 'Load More Posts', 'cookpro_textdomain' ) . '</a></div>';
			}
		}
		$out .= '</div>'; //.rcp-search-module-row
	} else {
		$out .= '<p class="rcp-main-search-norecipe">' . esc_html__( 'No recipes were found matching your selection.', 'cookpro_textdomain' ) . '</p>';
	} // End if().
	return $out;
}
