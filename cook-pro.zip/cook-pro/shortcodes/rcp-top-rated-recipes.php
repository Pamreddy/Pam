<?php
add_shortcode( 'rcp-top-rateds', 'rcp_top_rated_recipes_sc' );
function rcp_top_rated_recipes_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit'       => 8,
			'thumbnail'   => '',
		),
		$atts,
		'rcp-top-rateds'
	);
	$limit      = isset( $atts['limit'] ) ? $atts['limit'] : 8;
	$thumbnail  = isset( $atts['thumbnail'] ) ? $atts['thumbnail'] : '';

	$out = rcp_top_rated_recipes( $limit, $thumbnail, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Top_Rated_Recipes' ) ) {
	class Rcp_VC_Top_Rated_Recipes {
		function __construct() {
			// We safely integrate with VC with this hook
			add_action( 'init', array( $this, 'rcp_vc_top_rated_recipes_init' ) );
			// Use this when creating a shortcode addon
			add_shortcode( 'rcp-top-rated-recipes-addon', array( $this, 'rcp_top_rated_recipes_addon' ) );
		}

		public function rcp_vc_top_rated_recipes_init() {
			// Check if Visual Composer is installed
			if ( ! defined( 'WPB_VC_VERSION' ) ) {
				return;
			}

			vc_map( array(
				'name'        => esc_html__( 'Top Rated Recipe List', 'cook-pro' ),
				'description' => esc_html__( 'Display top rated recipes in list style ', 'cook-pro' ),
				'base'        => 'rcp-top-rated-recipes-addon',
				'class'       => '',
				'controls'    => 'full',
				'icon'        => plugins_url( '/assets/rcp_top-rated-list.png', __FILE__ ),
				'category'    => esc_html__( 'Cook Pro Addons', 'cook-pro' ),
				'params'      => array(
					array(
						'type'        => 'textfield',
						'holder'      => 'div',
						'class'       => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the recipes to display.', 'cook-pro' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Thumbnail', 'cook-pro' ),
						'param_name'  => 'thumbnail',
						'description' => esc_html__( 'Check this if you wish to enable the thumbnail for top rated recipes to display. ( Default: disable )', 'cook-pro' ),
						'value'       => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type'        => 'css_editor',
						'heading'     => esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name'  => 'css',
						'group'       => esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
				),
			));
		}

		/*
		Shortcode logic how it should be rendered
		*/
		static function rcp_top_rated_recipes_addon( $atts, $content = null ) {
			extract( shortcode_atts( array(
				'limit'       => 8,
				'thumbnail'   => '',
				'css'         => '',
				'extra_class' => '',
			), $atts ) );

			$rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );

			if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

			$limit      = isset( $atts['limit'] ) ? $atts['limit'] : 8;
			$thumbnail  = isset( $atts['thumbnail'] ) ? $atts['thumbnail'] : '';

			$out = rcp_top_rated_recipes( $limit, $thumbnail, $rcp_extra_css );

			return $out;
		}
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Top_Rated_Recipes();
}

function rcp_top_rated_recipes( $limit, $thumbnail, $rcp_extra_css ) {

	$out = '';
	//
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	$args = array(
		'post_type'      => 'recipe',
		'post_status'    => 'any',
		'posts_per_page' => $limit,
		'paged'          => $paged,
		'meta_key'       => 'rcp_comment_avg_rating',
		'orderby'        => 'meta_value_num',
		'order'          => 'DESC',
	);
	$rcp_top_rated_query = new WP_Query( $args );
	$rcp_highest_rated_nonce = wp_create_nonce( 'rcp-highest-rated-sh-nonce' );

	$out .= '<div class="rcp-sc-ratedposts ' . $rcp_extra_css . '">';
	if ( $rcp_top_rated_query->have_posts() ) {
		while ( $rcp_top_rated_query->have_posts() ) : $rcp_top_rated_query->the_post();

			$rcp_post_id = get_the_ID();

			$out .= '<div class="rcp-sc-common__block">';
			$rcp_comment_avg_rating = get_post_meta( get_the_ID(), 'rcp_comment_avg_rating', true );
			$hide_ratings           = rcp_get_option('rcp_hide_ratings','no' );
			if ( $rcp_comment_avg_rating != 0 ) {
				if ( has_post_thumbnail() && 'yes' == $thumbnail ) {

					$out .= '<div class="sc__thumb_link">';
					$out .= '<a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">';
					$out .= get_the_post_thumbnail( get_the_id(), array( 150, 150 ), array(
						'class' => 'sc__thumb',
					));
					$out .= '</a>';
					$out .= '</div>';
				}
				$out .= '<div class="rcp-sc-ratedposts-wrap">';
				$out .= '<h2 class="sc__title">';
				$out .= '<a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">' . get_the_title() . '</a>';
				$out .= '</h2>';
				if( 'yes' !== $hide_ratings ){
					$out .= rcp_get_post_ratings( $rcp_post_id );
				}
				$out .= '</div>'; //.rcp-sc-ratedposts-wrap
			}
			$out .= '</div>'; //.rcp-sc-common__block
		endwhile;
	}
	$out .= '</div>';
	return $out;
}
