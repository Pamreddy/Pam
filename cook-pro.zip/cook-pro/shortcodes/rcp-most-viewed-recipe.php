<?php
add_shortcode( 'rcp-most-viewed', 'rcp_most_viewed_recipes_sc' );
function rcp_most_viewed_recipes_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit'     => 8,
		    'thumbnail' => '',
		),
		$atts,
		'rcp-most-liked'
	);
	$limit     = isset( $atts['limit'] ) ? $atts['limit'] : '8';
	$thumbnail = isset( $atts['thumbnail'] ) ? $atts['thumbnail'] : '';

	$out = rcp_most_viewed_recipes( $limit, $thumbnail, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Most_Viewed_Recipes' ) ) {
	class Rcp_VC_Most_Viewed_Recipes {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_most_viewed_recipes_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-most-viewed-recipes-addon', array( $this, 'rcp_most_viewed_recipes_addon' ) );
	    }

	    public function rcp_vc_most_viewed_recipes_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Most Viewed Recipes', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display most viewed recipes.', 'cook-pro' ),
	            'base' 			=> 'rcp-most-viewed-recipes-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_most-viewed.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the most viewed recipes to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Thumbnail', 'cook-pro' ),
						'param_name'  => 'thumbnail',
						'description' => esc_html__( 'Check this if you wish to enable the thumbnail for most viewed recipes to display. ( Default: disable )', 'cook-pro' ),
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_most_viewed_recipes_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'       => 8,
		    	'thumbnail'   => '',
		    	'css'		  => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $limit     = isset( $atts['limit'] ) ? $atts['limit'] : 8;
			$thumbnail = isset( $atts['thumbnail'] ) ? $atts['thumbnail'] : '';
		    $out = rcp_most_viewed_recipes( $limit, $thumbnail, $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Most_Viewed_Recipes();
}
function rcp_most_viewed_recipes( $limit, $thumbnail, $rcp_extra_css ) {

	$out = '';
	//
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}
	$args = array(
		'post_type' 	 => 'recipe',
		'post_status' 	 => 'any',
		'posts_per_page' => $limit,
		'paged'			 => $paged,
		'meta_key' 		 => 'rcp_post_views',
		'orderby' 		 => 'meta_value_num',
		'order' 		 => 'DESC',
	);
	$rcp_most_viewed_query = new WP_Query( $args );

	$out .= '<div class="rcp-sc-vposts ' . $rcp_extra_css . '">';
	if ( $rcp_most_viewed_query->have_posts() ) {
		while ( $rcp_most_viewed_query->have_posts() ) : $rcp_most_viewed_query->the_post();
			global $post;
			$rcp_post_id = get_the_ID();
			$out .= '<div class="rcp-sc-common__block">';
			$rcp_view_count = get_post_meta( $rcp_post_id, 'rcp_post_views', true );

			if ( 0 !== $rcp_view_count ) {
				if ( has_post_thumbnail() && 'yes' == $thumbnail ) {
					$out .= '<a class="sc__thumb_link" href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">';
					$out .= get_the_post_thumbnail( $rcp_post_id, array( 150, 150 ), array(
						'class' => 'sc__thumb',
					) );
					$out .= '</a>';
				}
				$out .= '<div class="rcp-sc-vposts-wrap">';
				$out .= '<h2 class="sc__title"><a href="' . esc_url( get_permalink() ) . '" title="' . esc_attr( get_the_title() ) . '">' . get_the_title() . '</a></h2>';
				$out .= '<div class="pmeta">';
				$out .= '<span class="sc__viewed"><i class="fa fa-eye fa-fw"></i>' . $rcp_view_count . '</span>';
				$out .= '</div>'; //.pmeta
				$out .= '</div>'; //.rcp-sc-vposts-wrap
			}
			$out .= '</div>'; //.rcp-sc-common__block
		endwhile;
		wp_reset_query();
	}
	$out .= '</div>';
	return $out;
}
