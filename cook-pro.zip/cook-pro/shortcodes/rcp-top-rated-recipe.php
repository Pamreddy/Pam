<?php
add_shortcode( 'rcp-top-rated', 'rcp_top_rated_recipe_sc' );
function rcp_top_rated_recipe_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit'     	=> 8,
		    'columns'   	=> 4,
			'loadmore'  	=> 'infinite',
			'hide_cooktime' => 'no',
			'hide_difflevel'=> 'no',
			'hide_yields' 	=> 'no',
			'hide_ratings' 	=> 'no',
			'hide_author' 	=> 'no',
			'display_style' => 'style1',
		),
		$atts,
		'rcp-top-rated'
	);
	$limit      	= isset( $atts['limit'] ) ? $atts['limit'] : 8;
	$columns    	= isset( $atts['columns'] ) ? $atts['columns'] : 4;
	$loadmore   	= isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
	$hide_cooktime  = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
	$hide_difflevel = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
	$hide_yields  	= isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
	$hide_ratings  	= isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'no';
	$hide_author	= isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
	$display_style  = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
	$extra_css = $rcp_extra_css_attr = $out = '';

	$paged = 1;

	$rcp_highest_rated_nonce = wp_create_nonce( 'rcp-highest-rated-sh-nonce' );

	if( $loadmore == 'infinite' ){
		$out .='<div id="content" class="rcp-highest-rated-sh-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' .$hide_author. '" data-display_style="' . $display_style . '" data-limit="' . esc_attr( $limit ) . '"  data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_highest_rated_nonce ) . '">';
		$out .= rcp_top_rated_recipe( $limit, $loadmore, $columns, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $extra_css, $display_style, $paged );
		$out .= '</div>';
		$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cook-pro').'</span></div>';
	}else{
		$out .= rcp_top_rated_recipe( $limit, $loadmore, $columns, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $extra_css, $display_style, $paged );
	}
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Top_Rated_Recipe' ) ) {
	class Rcp_VC_Top_Rated_Recipe {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_top_rated_recipe_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-top-rated-recipe-addon', array( $this, 'rcp_top_rated_recipe_addon' ) );
	    }

	    public function rcp_vc_top_rated_recipe_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Top Rated Recipe', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display top rated recipes', 'cook-pro' ),
	            'base' 			=> 'rcp-top-rated-recipe-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_top-rated-list.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Display style', 'cook-pro' ),
						'param_name' 	=> 'display_style',
						'std'		 	=> 'style1',
						'value'		 	=> array(
												esc_html__( 'Select Style','cook-pro' ) => '',
												'Style1' => 'style1',
												'Style2' => 'style2',
											),
						'description'   => esc_html__( 'Select the style you wish to use for Recipes to display.', 'cook-pro' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '4',
						'value' => array(
							esc_html__( 'Select Columns','cook-pro' ) => '',
							esc_html__( '2 Columns', 'cook-pro' ) => '2',
							esc_html__( '3 Columns', 'cook-pro' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cook-pro' ),
					),
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the top rated recipe to display.', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Load More', 'cook-pro' ),
						'param_name' 	=> 'loadmore',
						'std'		 	=> 'infinite',
						'value'		 	=> array(
												esc_html__( 'Select Loadmore Option','cook-pro' ) => '',
												'Infinite Scroll'  => 'infinite',
												'Load More' => 'loadmore',
											),
						'description'   => esc_html__( 'Select the Loadmore you wish to use for Recent Recipe to display.', 'cook-pro' ),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Cooking Time', 'cook-pro' ),
						'param_name'  => 'hide_cooktime',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Difficulty Level', 'cook-pro' ),
						'param_name'  => 'hide_difflevel',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Yields', 'cook-pro' ),
						'param_name'  => 'hide_yields',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Ratings', 'cook-pro' ),
						'param_name'  => 'hide_ratings',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
					array(
						'type' 		  => 'checkbox',
						'heading' 	  => esc_html__( 'Hide Author', 'cook-pro' ),
						'param_name'  => 'hide_author',
						'value'		  => array(
							esc_html__( 'Yes', 'cook-pro' ) => 'yes',
						),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_top_rated_recipe_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'       	=> 8,
		    	'loadmore'    	=> 'infinite',
		    	'columns'	  	=> 4,
				'hide_cooktime' => 'no',
				'hide_difflevel'=> 'no',
				'hide_yields' 	=> 'no',
				'hide_ratings' 	=> 'no',
				'hide_author'	=> 'no',
		    	'css'		  	=> '',
		    	'extra_class' 	=> '',
				'display_style' => 'style1',
		    ), $atts ) );

			$out ='';
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

			$limit      	= isset( $atts['limit'] ) ? $atts['limit'] : 8;
			$columns    	= isset( $atts['columns'] ) ? $atts['columns'] : 4;
			$loadmore   	= isset( $atts['loadmore'] ) ? $atts['loadmore'] : 'infinite';
			$hide_cooktime  = isset( $atts['hide_cooktime'] ) ? $atts['hide_cooktime'] : 'no';
			$hide_difflevel = isset( $atts['hide_difflevel'] ) ? $atts['hide_difflevel'] : 'no';
			$hide_yields  	= isset( $atts['hide_yields'] ) ? $atts['hide_yields'] : 'no';
			$hide_ratings  	= isset( $atts['hide_ratings'] ) ? $atts['hide_ratings'] : 'no';
			$hide_author	= isset( $atts['hide_author'] ) ? $atts['hide_author'] : 'no';
			$display_style  = isset( $atts['display_style'] ) ? $atts['display_style'] : 'style1';
			$paged = 1;

			$rcp_highest_rated_nonce = wp_create_nonce( 'rcp-highest-rated-sh-nonce' );

			if( $loadmore == 'infinite' ){
				$out .='<div id="content" class="rcp-highest-rated-sh-module-content-ajax rcp_scroll_pages" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' .$hide_author. '" data-display_style="' . $display_style . '" data-limit="' . esc_attr( $limit ) . '"
				data-columns="' . esc_attr( $columns ) . '" data-scroll_page="' . esc_attr( $loadmore ) . '" data-nonce="' . esc_attr( $rcp_highest_rated_nonce ) . '">';
				$out .= rcp_top_rated_recipe( $limit, $loadmore, $columns, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style, $paged );
				$out .= '</div>';
				$out .= '<div id="inifiniteLoader"><span class="processing">'.esc_html__('Loading more','cook-pro').'</span></div>';
			}else{
				$out .= rcp_top_rated_recipe( $limit, $loadmore, $columns, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css, $display_style, $paged );
			}

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Top_Rated_Recipe();
}

function rcp_top_rated_recipe( $limit, $loadmore, $columns, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $rcp_extra_css , $display_style, $scroll_paged ) {

	$out = '';

	//
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	} else {
		$paged = 1;
	}

	if ( $loadmore =='infinite' ){ $paged = $scroll_paged; }

	$args = array(
		'post_type' 	 => 'recipe',
		'post_status' 	 => 'any',
		'posts_per_page' => $limit,
		'paged'			 => $paged,
		'meta_key' 		 => 'rcp_comment_avg_rating',
		'orderby' 		 => 'meta_value_num',
		'order' 		 => 'DESC',
	);
	$rcp_top_rated_query = new WP_Query( $args );
	$rcp_highest_rated_nonce = wp_create_nonce( 'rcp-highest-rated-sh-nonce' );
	$count_results = $rcp_top_rated_query->found_posts;
	$max_num_pages = $rcp_top_rated_query->max_num_pages;
	$column_index = 0;

	if ( $columns == '4' ) { $class = 'item4'; }
	if ( $columns == '3' ) { $class = 'item3'; }
	if ( $columns == '2' ) { $class = 'item2'; }

	if ( $rcp_top_rated_query->have_posts() ) {

		$out .= '<div class="rcp-highest-rated-sh-module ' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-highest-rated-sh-module-content" data-max_no_pages="' . esc_attr( $max_num_pages ) . '">';

		while ( $rcp_top_rated_query->have_posts() ) : $rcp_top_rated_query->the_post();
			global $post;

			$column_index++;

			$out .= '<div class="rcp-highest-rated-post rcp-post-item ' . esc_attr( $class ) . ' ' . $display_style . '">';
			$out .= rcp_results_data( get_the_ID(), $class, $hide_cooktime, $hide_difflevel, $hide_yields, $hide_ratings, $hide_author, $display_style );
			$out .= '</div>'; //.rcp-post-item
			if ( $column_index == $columns ) {
				$column_index = 0;
			}
		endwhile;
		wp_reset_postdata();
		$out .= '</div>'; //.rcp-highest-rated-module-content
		if ( 'loadmore' === $loadmore ) {
			if ( $count_results > 1 && $count_results > $limit ) {
				$out .= '<div class="rcp-hr-sh-load-more-style"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-hide_cooktime="' .$hide_cooktime. '" data-hide_difflevel="' .$hide_difflevel. '" data-hide_yields="' .$hide_yields. '" data-hide_ratings="' .$hide_ratings. '" data-hide_author="' . $hide_author . '" data-count="' . esc_attr( $count_results ) . '" data-nonce="' . esc_attr( $rcp_highest_rated_nonce ) . '"
				data-columns="' . esc_attr( $columns ) . '"  data-number="' . esc_attr( $limit ) . '" data-display_style="' . esc_attr( $display_style ) . '">' . esc_html__( 'Load More Posts', 'cook-pro' ) . '</a></div>';
			}
		}
		$out .= '</div>'; //.rcp-highest-rated-module-row
	} else {
		$out .= '<p class="rcp-main-highest-rated-norecipe">' . esc_html__( 'No recipes were found.', 'cook-pro' ) . '</p>';
	} // End if().

	return $out;
}
