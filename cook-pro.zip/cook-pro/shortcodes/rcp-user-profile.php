<?php
add_shortcode( 'rcp-user-profile', 'rcp_user_profile_sc' );
function rcp_user_profile_sc( $atts, $content = null ) {
	$out = rcp_user_profile( '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_User_Profile' ) ) {
	class Rcp_VC_User_Profile {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_user_profile_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-user-profile-addon', array( $this, 'rcp_user_profile_addon' ) );
	    }

	    public function rcp_vc_user_profile_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'User Profile', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display user profile page.', 'cook-pro' ),
	            'base' 			=> 'rcp-user-profile-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_user-profile.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
	            	array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name' => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
				),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_user_profile_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		    	'css'		  => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $out = rcp_user_profile( $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_User_Profile();
}

function rcp_user_profile( $rcp_extra_css ) {
	global $post, $current_user, $user_id;

	$out = $rcp_active_class = $before = $after = '';
	$rcp_author_name = isset( $_GET['username'] ) ? $_GET['username'] :'';
	if ( ! empty( $rcp_author_name ) ) {
		$rcp_user_data = get_user_by( 'slug', $rcp_author_name );
		if ( ! empty( $rcp_user_data ) ) {
			$user_id = $rcp_user_data->ID;
		}
	} else {
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$user_id = $current_user->ID;
		} else {
			$user_id = '';
		}
	}
	if ( ! empty( $user_id ) ) {
		$rcp_user_info 	 = get_userdata( $user_id );
		$rcp_user_name 	 = $rcp_user_info->display_name;
		$rcp_user_url 	 = $rcp_user_info->user_url;
	 	$rcp_user_desc	 = get_user_meta( $user_id, 'description', true );
		$rcp_user_avatar = rcp_get_avatar( $user_id, 100 );
		$rcp_total_count 		   = rcp_get_user_recipes_count( $user_id );
		$rcp_review_count		   = rcp_get_user_reviews_count( $user_id );
		$rcp_user_favourites_count = rcp_get_user_favorites_count( $user_id );
		//
		$rcp_user_position 		= get_the_author_meta( 'position', $user_id );
		$rcp_user_facebook 		= get_the_author_meta( 'facebook', $user_id );
		$rcp_user_twitter 		= get_the_author_meta( 'twitter', $user_id );
		$rcp_user_google_plus 	= get_the_author_meta( 'google_plus', $user_id );
		$rcp_user_linkedin 		= get_the_author_meta( 'linkedin', $user_id );

		$out .= '<div class="rcp-main-profile ' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-profile-header">';
		$out .= '<div class="rcp-profile-header_inner">';
		$out .= '<div class="rcp-profile-info">';

		$out .= '<div class="rcp-profile__thumb">';
		if ( ! empty( $rcp_user_url ) ) {
			$before = '<a href="' . esc_url( $rcp_user_url ) . '" target="_blank">';
			$after = '</a>';
		}
		$out .= $before;
		$out .= $rcp_user_avatar;
		$out .= $after;
		$out .= '</div>';//.rcp-profile__thumb

		$out .= '<div class="rcp-profile__info">';
		// $out .= '<div class="rcp-profile_follow">';
		// $out .= '<span class="rcp__follow">' . esc_html__( 'follow', 'cook-pro' ) . '</span>';
		// $out .= '</div>'; //.rcp-profile_follow
		$out .= '<h2>';

		$out .= $before;
		$out .= $rcp_user_name;
		$out .= $after;
		if ( ! empty( $rcp_user_position ) ) {
			$out .= '<span>' . $rcp_user_position . '</span>';
		}
		$out .= '</h2>';
		$out .= '<div class="rcp__info">';
		if ( $rcp_user_desc ) {
			$out .= wpautop( $rcp_user_desc );
		}
		$out .= '</div>';//.rcp__info
		$out .= '<div class="rcp__social_profile">';

		$rcp_user_fb_url 	= trim( preg_replace( '/http:\/\/www.||https:\/\/www.||https:\/\/||http:\/\/||www./', '', $rcp_user_facebook ) );
		$rcp_user_twt_url 	= trim( preg_replace( '/http:\/\/www.||https:\/\/www.||https:\/\/||http:\/\/||www./', '', $rcp_user_twitter ) );
		$rcp_user_gp_url 	= trim( preg_replace( '/http:\/\/www.||https:\/\/www.||https:\/\/||http:\/\/||www./', '', $rcp_user_google_plus ) );
		$rcp_user_ld_url 	= trim( preg_replace( '/http:\/\/www.||https:\/\/www.||https:\/\/||http:\/\/||www./', '', $rcp_user_linkedin ) );

		$out .= '<ul>';
		if ( ! empty( $rcp_user_facebook ) ) {
			$out .= '<li><a href="' . esc_url( $rcp_user_fb_url ) . '" target="_blank"><i class="fa fa-fw fa-facebook" aria-hidden="true"></i></a></li>';
		}
		if ( ! empty( $rcp_user_twitter ) ) {
			$out .= '<li><a href="' . esc_url( $rcp_user_twt_url ) . '" target="_blank"><i class="fa fa-fw fa-twitter" aria-hidden="true"></i></a></li>';
		}
		if ( ! empty( $rcp_user_google_plus ) ) {
			$out .= '<li><a href="' . esc_url( $rcp_user_gp_url ) . '" target="_blank"><i class="fa fa-fw fa-google-plus" aria-hidden="true"></i></a></li>';
		}
		if ( ! empty( $rcp_user_linkedin ) ) {
			$out .= '<li><a href="' . esc_url( $rcp_user_ld_url ) . '" target="_blank"><i class="fa fa-fw fa-linkedin" aria-hidden="true"></i></a></li>';
		}
		$out .= '</ul>';
		$out .= '</div>'; //.rcp__social_profile
		$out .= '</div>'; //.rcp-profile__info

		$out .= '</div>';//.rcp-profile-info

		$out .= '<div class="rcp-profile-exinfo">';
		$out .= '<div class="rcp__follow_wrapper">';
		$out .= '<ul class="rcp__follow_fav">';
		$out .= '<li class="rcp__following_count">' . $rcp_total_count . '<span>' . esc_html__( 'Recipes', 'cook-pro' ) . '</span></li>';
		$out .= '<li class="rcp__followers_count">' . $rcp_review_count . '<span>' . esc_html__( 'Reviews', 'cook-pro' ) . '</span></li>';
		$out .= '<li class="rcp__fav_count">' . $rcp_user_favourites_count . '<span>' . esc_html__( 'Favorites', 'cook-pro' ) . '</span></li>';
		$out .= '</ul>'; //. rcp__follow_fav
		$out .= '</div>'; //.rcp__follow_wrapper
		$out .= '</div>'; //.rcp-profile-exinfo

		$out .= '</div>'; //.rcp-profile-header_inner
		$out .= '</div>';//.rcp-profile-header

		$out .= '<div class="rcp-profile-footer">';
		$out .= '<div class="rcp-profile__panes">';
		$out .= '<ul class="rcp__pane">';
		$out .= '<li id="#pane0"><a href="#pane0">' . esc_html__( 'Recipes', 'cook-pro' ) . '</a></li>';
		$out .= '<li id="#pane1"><a href="#pane1">' . esc_html__( 'Reviews', 'cook-pro' ) . '</a></li>';
		$out .= '<li id="#pane2"><a href="#pane2">' . esc_html__( 'Favorites', 'cook-pro' ) . '</a></li>';
		if ( is_user_logged_in() ) {
			if ( empty( $rcp_author_name ) ) {
				if ( isset( $_POST['submit'] ) && ( $_POST['submit'] == 'Update' ) ) {
					$rcp_active_class = 'current';
				}
				$out .= '<li class="' . $rcp_active_class . ' rcp-edit-profile" id="#' . $rcp_author_name . '"><a href="#anusha">' . esc_html__( 'Edit Profile', 'cook-pro' ) . '</a></li>';
			}
		}
		$out .= '</ul>'; //.rcp__pane
		$out .= '<div class="rcp__pane_content">';
		// Recipes
		$out .= '<div class="pane_content" id="pane0">';
		ob_start();
		load_template( RECIPE_DIR . '/shortcodes/views/rcp-user-recipes.php', false );
		$out .= ob_get_clean();
		$out .= '</div>'; //.pane_content

		//  Reviews
		$out .= '<div class="pane_content" id="pane1">';
		ob_start();
		load_template( RECIPE_DIR . '/shortcodes/views/rcp-user-reviews.php', false );
		$out .= ob_get_clean();
		$out .= '</div>'; // .pane_content

		// Favoutrites
		$out .= '<div class="pane_content" id="pane2">';
		ob_start();
		load_template( RECIPE_DIR . '/shortcodes/views/rcp-user-favorites.php', false );
		$out .= ob_get_clean();
		$out .= '</div>'; //.pane_content

		if ( is_user_logged_in() ) {
			if ( empty( $rcp_author_name ) ) {
				$out .= '<div class="pane_content" id="#' . $rcp_author_name . '">';
				ob_start();
				load_template( RECIPE_DIR . '/shortcodes/views/rcp-user-edit-form.php', false );
				$out .= ob_get_clean();
				$out .= '</div>'; //.rcp__pane_content
			}
		}
		$out .= '</div>'; //.rcp__pane_content
		$out .= '</div>'; //.rcp-profile__panes
		$out .= '</div>'; //.rcp-profile-footer
		$out .= '</div>'; //.rcp-main-profile
	} else {
		$out .= do_shortcode( '[rcp-login]' );
	} // End if().

	return $out;
}
