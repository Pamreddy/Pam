<?php
add_shortcode( 'rcp-submit', 'rcp_submit_form_sc' );
function rcp_submit_form_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'limit' => '',
		),
		$atts,
		'rcp-submit'
	);
	$rcp_submission_limit = rcp_get_option( 'rcp_submission_limit' ) ? rcp_get_option( 'rcp_submission_limit' ) : 5;
	$limit = ! empty( $atts['limit'] ) ? $atts['limit'] : $rcp_submission_limit;
	$out = rcp_submit_form( $limit, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Submit_Form' ) ) {
	class Rcp_VC_Submit_Form {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_submit_form_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-submit-addon', array( $this, 'rcp_submit_form_addon' ) );
	    }

	    public function rcp_vc_submit_form_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Recipe Submit Form', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display form for user submission recipe. ', 'cook-pro' ),
	            'base' 			=> 'rcp-submit-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_submit.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
					array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_submit_form_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'       => '',
		    	'css'		  => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

			$rcp_submission_limit = rcp_get_option( 'rcp_submission_limit' ) ? rcp_get_option( 'rcp_submission_limit' ) : 5;
			$limit = ! empty( $atts['limit'] ) ? $atts['limit'] : $rcp_submission_limit;

			$out = rcp_submit_form( $limit, $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Submit_Form();
}

function rcp_submit_form( $limit, $rcp_extra_css ) {

	$out = '';
	global $post, $current_user,$userid;
	$current_user = wp_get_current_user();
	$user_id = $current_user->ID;
	$user_email = $current_user->user_email;
	$user_name = $current_user->display_name;
	$user_post_count = count_user_posts( 2 , 'recipe' );

	$rcp_login_msg = get_option( 'rcp_login_msg' ) ? get_option( 'rcp_login_msg' ) : esc_html__( 'Welcome Recipe Contributor!','cook-pro' );
	$rcp_login_msg_placeholders  = array( '[username]' );
	$rcp_login_msg_replacements  = array( $user_name );
	$rcp_login_msg = str_replace( $rcp_login_msg_placeholders, $rcp_login_msg_replacements, $rcp_login_msg );
	$rcp_login_msg = do_shortcode( $rcp_login_msg );
	$rcp_user_default_role = get_option( 'rcp_user_default_role' ) ? get_option( 'rcp_user_default_role' ) : 'contributor';
	if ( is_user_logged_in() ) {
		$out .= '<p>' . $rcp_login_msg . '</p>';
	}
	ob_start();

	if ( 'POST' == $_SERVER['REQUEST_METHOD'] && ! empty( $_POST['action'] ) && $_POST['action'] == 'rcp-post-submit' ) {
		$rcp_title  	 	 = isset( $_POST['rcp_title'] ) ? $_POST['rcp_title'] : '';
		$rcp_sub_title  	 = isset( $_POST['rcp_sub_title'] ) ? $_POST['rcp_sub_title'] : '';
		$rcp_desc 			 = isset( $_POST['rcp_desc'] ) ? $_POST['rcp_desc'] : '';
		$rcp_video 			 = isset( $_POST['rcp_video'] ) ? $_POST['rcp_video'] : '';
		$rcp_servings 	 	 = isset( $_POST['rcp_servings'] ) ? $_POST['rcp_servings'] : '';
		$rcp_diff_level 	 = isset( $_POST['rcp_diff_level'] ) ? $_POST['rcp_diff_level'] : '';
		$rcp_tags 	 		 = isset( $_POST['rcp_tags'] ) ? $_POST['rcp_tags'] : '';
		$rcp_categories		 = isset( $_POST['rcp_categories'] ) ? $_POST['rcp_categories'] : '';
		$rcp_cuisines 	 	 = isset( $_POST['rcp_cuisines'] ) ? $_POST['rcp_cuisines'] : '';
		$rcp_cooking_methods = isset( $_POST['rcp_cooking_methods'] ) ? $_POST['rcp_cooking_methods'] : '';
		$rcp_prep_hrs 	 	 = isset( $_POST['rcp_prep_hrs'] ) ? $_POST['rcp_prep_hrs'] : '';
		$rcp_prep_mns 	 	 = isset( $_POST['rcp_prep_mns'] ) ? $_POST['rcp_prep_mns'] : '';
		$rcp_cook_hrs	 	 = isset( $_POST['rcp_cook_hrs'] ) ? $_POST['rcp_cook_hrs'] : '';
		$rcp_cook_mns 	 	 = isset( $_POST['rcp_cook_mns'] ) ? $_POST['rcp_cook_mns'] : '';
		$rcp_ingredients 	 = isset( $_POST['rcp_ingredients'] ) ? $_POST['rcp_ingredients'] : '';
		$rcp_steps 		 	 = isset( $_POST['rcp_steps'] ) ? $_POST['rcp_steps'] : '';
		$rcp_equipments  	 = isset( $_POST['rcp_equipments'] ) ? $_POST['rcp_equipments'] : '';
		$rcp_nutritions  	 = isset( $_POST['rcp_nutritions'] ) ? $_POST['rcp_nutritions'] : '';
		$rcp_upload_img 	 = isset( $_POST['rcp_upload_img'] ) ? $_POST['rcp_upload_img'] : '';
		$rcp_captcha 	 	 = isset( $_POST['g-recaptcha-response'] ) ? $_POST['g-recaptcha-response'] : '';

		$rcp_publish_post 	 = isset( $_POST['rcp_post_submit'] ) ? $_POST['rcp_post_submit'] : '';
		$rcp_draft_post	  	 = isset( $_POST['rcp_drafted_post_submit'] ) ? $_POST['rcp_drafted_post_submit'] : '';

		if ( ! empty( $rcp_publish_post ) ) {
			$rcp_id = null;
			$errors = rcp_submit_form_validation( $rcp_id, $rcp_title, $rcp_sub_title, $rcp_desc, $rcp_servings, $rcp_diff_level, $rcp_categories, $rcp_prep_hrs, $rcp_prep_mns, $rcp_cook_hrs, $rcp_cook_mns, $rcp_ingredients, $rcp_steps, $rcp_upload_img, $rcp_captcha );
			$rcp_query_args  = array(
				'post_title' 	=> $rcp_title,
				'post_type'		=> 'recipe',
				'post_status' 	=> 'pending',
			);
			$rcp_sub_success_msg = get_option( 'rcp_submission_success_msg' ) ? get_option( 'rcp_submission_success_msg' ) : esc_html__( 'Submission complete', 'cook-pro' );
			$rcp_sub_msg_placeholders  = array( '[username]' );
			$rcp_sub_msg_replacements  = array( $user_name );
			$rcp_submission_success_msg = str_replace( $rcp_sub_msg_placeholders, $rcp_sub_msg_replacements, $rcp_sub_success_msg );
			$rcp_submission_success_msg = do_shortcode( $rcp_submission_success_msg );
			$rcp_success_msg = '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice"><strong>' . esc_html__( 'Success!', 'cook-pro' ) . '</strong><br />' . $rcp_submission_success_msg . '</p></div>';
		}
		if ( ! empty( $rcp_draft_post ) ) {
			if ( empty( $rcp_title ) ) {
				$errors[] = esc_html__( 'Enter Recipe Title.','cook-pro' );
			}
			$rcp_query_args  = array(
				'post_title' 	=> $rcp_title,
				'post_type'		=> 'recipe',
				'post_status' 	=> 'draft',
			);
			$rcp_success_msg = '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice"><strong>' . esc_html__( 'Success!', 'cook-pro' ) . '</strong><br />' . esc_html__( 'Post Drafted.','cook-pro' ) . '</p></div>';
		}
		if ( empty( $errors ) ) {
			if ( 1 > count( $errors ) ) {
				$rcp_post_id = wp_insert_post( $rcp_query_args );

				if ( ! empty( $rcp_servings ) ) {
					update_post_meta( $rcp_post_id, 'recipe_servings', $rcp_servings );
				}
				if ( ! empty( $rcp_desc ) ) {
					update_post_meta( $rcp_post_id, 'recipe_short_info', $rcp_desc );
				}
				if ( ! empty( $rcp_sub_title ) ) {
					update_post_meta( $rcp_post_id, 'recipe_sub_title', $rcp_sub_title );
				}
				if ( ! empty( $rcp_diff_level ) ) {
					update_post_meta( $rcp_post_id, 'recipe_diff_level', $rcp_diff_level );
				}
				if ( ! empty( $rcp_video ) ) {
					update_post_meta( $rcp_post_id, 'recipe_video_url', $rcp_video );
				}
				// Inserting ingredients into meta fields
				$rcp_prep_time_data = array();
				if ( ! empty( $rcp_prep_hrs ) || ! empty( $rcp_prep_mns ) ) {
					$rcp_prep_time_data = array(
						'hrs' => $rcp_prep_hrs,
						'mins' => $rcp_prep_mns,
					);
				}
				//
				$rcp_cook_time_data = array();
				if ( ! empty( $rcp_cook_hrs ) || ! empty( $rcp_cook_mns ) ) {
					   $rcp_cook_time_data = array(
						'hrs' => $rcp_cook_hrs,
						'mins' => $rcp_cook_mns,
					   );
				}

				// Save the Preparation Time
				if ( ! empty( $rcp_prep_time_data ) ) {
					update_post_meta( $rcp_post_id, 'recipe_ptime', $rcp_prep_time_data );
				}
				// Save the Cooking Time
				if ( ! empty( $rcp_cook_time_data ) ) {
					update_post_meta( $rcp_post_id, 'recipe_ctime', $rcp_cook_time_data );
				}
				// Save the Equipments
				if ( ! empty( $rcp_equipments ) ) {
					update_post_meta( $rcp_post_id, 'recipe_equipments', $rcp_equipments );
				}
				// Nutritions Data
				if ( ! empty( $rcp_nutritions ) ) {
					update_post_meta( $rcp_post_id, 'recipe_nutritions', $rcp_nutritions );
				}
				// Ingredients Data
				if ( ! empty( $rcp_ingredients ) ) {
					update_post_meta( $rcp_post_id, 'recipe_ingredients', $rcp_ingredients );
				}
				// Steps Data
				if ( ! empty( $rcp_steps ) ) {
					update_post_meta( $rcp_post_id, 'recipe_steps', $rcp_steps );
				}

				if ( $_FILES['rcp_upload_img']['name'] != '' ) {
					rcp_sui_process_image( 'rcp_upload_img', $rcp_post_id, $rcp_title );
				}

				// Inserting recipe tags
				if ( ! empty( $rcp_tags ) ) {
					$rcp_tags_ids = @array_map( 'intval', $_POST['rcp_tags'] );
					wp_set_object_terms( $rcp_post_id, $rcp_tags_ids, 'post_cat' );
				}

				// Inserting recipe tags
				if ( ! empty( $rcp_categories ) ) {
					$rcp_category_ids = @array_map( 'intval', $_POST['rcp_categories'] );
					wp_set_object_terms( $rcp_post_id, $rcp_category_ids, 'recipe_cat' );
				}

				// Inserting recipe cuisines into meta field
				if ( ! empty( $rcp_cuisines ) ) {
					$rcp_cuisine_ids = @array_map( 'intval', $_POST['rcp_cuisines'] );
					wp_set_object_terms( $rcp_post_id, $rcp_cuisine_ids, 'recipe_cuisine' );
				}

				// Inserting recipe cuisines into meta field
				if ( ! empty( $rcp_cooking_methods ) ) {
					$rcp_cooking_methods = @array_map( 'intval', $_POST['rcp_cooking_methods'] );
					wp_set_object_terms( $rcp_post_id, $rcp_cooking_methods, 'recipe_method' );
				}
				// Send a email to user
				$email_message = get_option( 'rcp_submit_email_message' );
				$email_subject = get_option( 'rcp_submit_email_subject' );

				$admin_email_message = get_option( 'rcp_submit_admin_email_message' );
				$admin_email_subject = get_option( 'rcp_submit_admin_email_subject' );

				$user_email = $user_email;
				$admin_email_ids = $admin_emailids = array();
				$admin_email_ids[] = get_option( 'admin_email' );
				$admin_emails = get_option( 'rcp_submit_admin_email_ids' );
				if ( ! empty( $admin_emails ) ) {
					if ( strpos( $admin_emails, ',' ) !== false ) {
						$admin_emailids = explode( ',', $admin_emails );
						$admin_email_ids = array_merge( $admin_email_ids, $admin_emailids );
					} else {
						$admin_email_ids[] .= $admin_emails;
					}
				}
				$admin_email = implode( ',', $admin_email_ids );

				$rcp_link = get_permalink( $rcp_post_id );

				$rcp_logo_img = '';
				$rcp_logo = rcp_get_option( 'rcp_email_template_logo' );
				if ( ! empty( $rcp_logo ) ) {
					$attachment_id = rcp_get_attachment_id_from_src( $rcp_logo );
					$rcp_logo_img = wp_get_attachment_image( $attachment_id, array( '200', '100' ), '', '' );
				}
				if ( $email_message && $email_subject ) {
					$subj_placeholders = array( '[username]', '[recipename]' );
					$subj_replacements = array( $user_name, $rcp_title );
					$msg_placeholders  = array( '[username]', '[recipename]', '[recipelink]' );
					$msg_replacements  = array( $user_name, $rcp_title, $rcp_link );

					$rcp_email_message  = str_replace( $msg_placeholders, $msg_replacements, $email_message );
					$email_subject      = str_replace( $subj_placeholders, $subj_replacements, $email_subject );
					$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
					$email_placeholders = array( '[logo]', '[message]' );
					$email_replacements = array( $rcp_logo_img, $rcp_email_message );
					$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
					$email_message      = do_shortcode( $email_message );
					$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $admin_email . '>' . "\r\n\\";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

					wp_mail( $user_email, $email_subject, $email_message, $headers );
				}
				if ( $admin_email_message && $admin_email_subject ) {
					$admin_subj_placeholders = array( '[username]', '[recipename]' );
					$admin_subj_replacements = array( $user_name, $rcp_title );
					$admin_msg_placeholders  = array( '[username]', '[recipename]', '[recipelink]' );
					$admin_msg_replacements  = array( $user_name, $rcp_title, $rcp_link );

					$rcp_email_message  = str_replace( $admin_msg_placeholders, $admin_msg_replacements, $admin_email_message );
					$email_subject      = str_replace( $admin_subj_placeholders, $admin_subj_replacements, $admin_email_subject );
					$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
					$email_placeholders = array( '[logo]', '[message]' );
					$email_replacements = array( $rcp_logo_img, $rcp_email_message );
					$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
					$email_message      = do_shortcode( $email_message );

					$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $user_email . '>' . "\r\n\\";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

					wp_mail( $admin_email, $email_subject, $email_message, $headers );
				}
				$rcp_submission_complete = $rcp_success_msg;
			} // End if().
		} else {
			$rcp_submission_complete = 'error';
		} // End if().
	} else {
		$rcp_submission_complete = false;
	} // End if().
	//
	if ( $rcp_submission_complete && $rcp_submission_complete != 'error' ) {
		$out .= $rcp_submission_complete;
		$rcp_id = 'clear';
	} else {
		$rcp_id = null;
		if ( $rcp_submission_complete == 'error' ) {
			$out .= '<div class="rcp-custom-error" style="display:block">' . implode( '<br>', $errors ) . '</div>';
		}
	}
	if ( is_user_logged_in() ) {
		if ( in_array( 'administrator' , $current_user->roles ) ) {
			if ( $user_post_count <= $limit ) {
				$out .= rcp_submit_form_fields( $rcp_id, $rcp_extra_css );
			}else {
				$out .= sprintf( esc_html__( 'Sorry, but you have hit the recipe submission limit. Each user may only have %1$s recipes at a time', 'cook-pro' ), $limit );
			}
		} elseif ( ! in_array( $rcp_user_default_role , $current_user->roles ) ) {
			$rcp_submission_complete = false;
			$out .= sprintf( esc_html__( 'Sorry you cannot have access to submit recipe only %1$s can submit recipe', 'cook-pro' ), $rcp_user_default_role );
		} else {
			if ( $user_post_count <= $limit ) {
				$out .= rcp_submit_form_fields( $rcp_id, $rcp_extra_css );
			} else {
				$out .= sprintf( esc_html__( 'Sorry, but you have hit the recipe submission limit. Each user may only have %1$s recipes at a time', 'cook-pro' ), $limit );
			}
		}
	} else {
		$out .= do_shortcode( '[rcp-login]' );
	}
	$out .= ob_get_clean();

	return $out;
}
