<?php
add_shortcode( 'rcp-top-contributors', 'rcp_top_contributors_sc' );
function rcp_top_contributors_sc( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'columns' => 4,
			'limit'   => 6,
			'style'	  => 'style1',
		),
		$atts,
		'rcp-top-contributors'
	);
	$limit      = isset( $atts['limit'] ) ? $atts['limit'] : 6;
	$columns    = isset( $atts['columns'] ) ? $atts['columns'] : 4;
	$orderby    = isset( $atts['orderby'] ) ? $atts['orderby'] : 'ID';
	$order      = isset( $atts['order'] ) ? $atts['order'] : 'ASC';
	$style      = isset( $atts['style'] ) ? $atts['style'] : 'style1';

	$out = rcp_top_contributors( $columns, $limit, $orderby, $order, $style, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Top_Contributors' ) ) {
	class Rcp_VC_Top_Contributors {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_top_contributors_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'rcp-top-contributors-addon', array( $this, 'rcp_top_contributors_addon' ) );
	    }

	    public function rcp_vc_top_contributors_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }

	        vc_map( array(
	            'name' 			=> esc_html__( 'Top Contributors', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display top recipe contributor lists.', 'cook-pro' ),
	            'base' 			=> 'rcp-top-contributors-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_top-conributor.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
	            	array(
						'type' 		  => 'textfield',
						'holder' 	  => 'div',
						'class'		  => '',
						'heading'     => esc_html__( 'Limit', 'cook-pro' ),
						'param_name'  => 'limit',
						'description' => esc_html__( 'Enter the limit for the top contributors to display.', 'cook-pro' ),
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Column', 'musicplay' ),
						'param_name' => 'columns',
						'std' => '4',
						'value' => array(
							esc_html__( 'Select Columns','cook-pro' ) => '',
							esc_html__( '4 Columns', 'cook-pro' ) => '4',
							esc_html__( '3 Columns', 'cook-pro' ) => '3',
						),
						'description' => esc_html__( 'Select the recipe columns', 'cook-pro' ),
					),
					array(
						'type' 		 	=> 'dropdown',
						'heading' 	 	=> esc_html__( 'Style', 'cook-pro' ),
						'param_name' 	=> 'style',
						'std'		 	=> '1',
						'value'		 	=> array(
												esc_html__( 'Select Order','cook-pro' ) => '',
												'style 1'  => 'style1',
												'style 2' => 'style2',
											),
						'description'   => esc_html__( 'Select the order you wish to use for top contributors to display.', 'cook-pro' ),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_top_contributors_addon( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'limit'   => 6,
				'columns' => 4,
				'orderby' => 'ID',
				'order'	  => 'ASC',
				'style'	  => 'style1',
		    	'css'	  => '',
		    	'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $limit      = isset( $atts['limit'] ) ? $atts['limit'] : 6;
			$columns    = isset( $atts['columns'] ) ? $atts['columns'] : 4;
			$orderby    = isset( $atts['orderby'] ) ? $atts['orderby'] : 'ID';
			$order      = isset( $atts['order'] ) ? $atts['order'] : 'ASC';
			$style      = isset( $atts['style'] ) ? $atts['style'] : 'style1';
		    $out = rcp_top_contributors( $columns, $limit, $orderby, $order, $style, $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Top_Contributors();
}

function rcp_top_contributors( $columns, $limit, $orderby, $order, $style, $rcp_extra_css ) {
	ob_start();
	$out = '';
	$rcp_contributors_query = new WP_User_Query(
		array(
			'number'   => (int) $limit,
			'role__in' => array( 'administrator', 'contributor' ),
			'orderby'  => $orderby,
			'order'    => $order,
		)
	);
	$column_index = 0;

	if ( $columns == '4' ) { $class = 'item4'; }
	if ( $columns == '3' ) { $class = 'item3'; }

	$rcp_top_contibutors_query = $rcp_contributors_query->get_results();
	$rcp_contributors_count = $rcp_contributors_query->get_total();
	$out .= '<div class="rcp-sc-contributor-wrapper ' . $style . $rcp_extra_css . '">';
	if ( ! empty( $rcp_top_contibutors_query ) ) {

		foreach ( $rcp_top_contibutors_query as $user_data ) {
			$top_contibutors_authors[ rcp_get_user_recipes_count( $user_data->ID ) ] = array(
				'name' => $user_data->display_name,
				'count' => rcp_get_user_recipes_count( $user_data->ID ),
				'link' => $user_data->user_login,
				'id' => $user_data->ID,
			);
		}
		krsort( $top_contibutors_authors );
		foreach ( $top_contibutors_authors as $user_meta ) {

			$column_index++;

			$rcp_user_link = get_permalink( rcp_get_option( 'rcp_profile_page_id','' ) ) . '?username=' . $user_meta['link'] ;
			$out .= '<div class="rcp-sc-common__block ' . esc_attr( $class ) . '">';
			$out .= '<a class="sc__thumb_link"  href="' . esc_url( $rcp_user_link ) . '">';
			$out .= rcp_get_avatar( $user_meta['id'], 60 );
			$out .= '</a>';
			$out .= '<div class="rcp-sc__contributor_name">';
			$out .= '<h2 class="sc__title"><a class="sc__thumb_link"  href="' . esc_url( $rcp_user_link ) . '">' . $user_meta['name'] . '</a></h2>';
			$out .= '<span>' . $user_meta['count'] . ' ' . esc_html__( 'Recipes', 'cook-pro' ) . '</span>';
			$out .= '</div>'; // .rcp-sc__contributor_name
			$out .= '</div>'; // .rcp-sc-common__block

			if ( $column_index == $columns ) {
				$column_index = 0;
			}
		}

	}
	$out .= '</div>'; // .rcp-sc-contributor-wrapper
	$out .= ob_get_clean();
	
	return $out;
}
