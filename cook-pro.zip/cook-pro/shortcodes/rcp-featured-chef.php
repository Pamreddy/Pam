<?php
add_shortcode( 'rcp-featured-chef', 'rcp_featured_chef' );
function rcp_featured_chef( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'id' => 2,
		),
		$atts,
		'rcp-featured-chef'
	);
	$id = isset( $atts['id'] ) ? $atts['id'] : '';
	$out = rcp_fchef( $id, '' );
	return $out;
}

// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
if ( ! class_exists( 'Rcp_VC_Featured_Chef' ) ) {
	class Rcp_VC_Featured_Chef {
	    function __construct() {
	        // We safely integrate with VC with this hook
	        add_action( 'init', array( $this, 'rcp_vc_featured_chef_init' ) );

	        // Use this when creating a shortcode addon
	        add_shortcode( 'featured-chef-addon', array( $this, 'rcp_featured_chef' ) );
	    }

	    public function rcp_vc_featured_chef_init() {
	        // Check if Visual Composer is installed
	        if ( ! defined( 'WPB_VC_VERSION' ) ) {
	            return;
	        }
	        $featuredchef_ids = array();
	        $blogusers = get_users( array(
				'role__in' => array(
					'administrator',
					'contributor',
				),
			) );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				$display_name = $user->display_name;
				if ( ! empty( $display_name ) ) {
					$var = $display_name;
					if ( ! empty( $user->first_name ) || ! empty( $user->last_name ) ) {
						$var .= ' ( ' . $user->first_name . ' ' . $user->last_name . ' ) ';
					}
					$featuredchef_ids[ $var ] = $user->ID;
				}
			}

	        vc_map( array(
	            'name' 			=> esc_html__( 'Featured Chef', 'cook-pro' ),
	            'description' 	=> esc_html__( 'Display the featured chef.', 'cook-pro' ),
	            'base' 			=> 'featured-chef-addon',
	            'class' 		=> '',
	            'controls' 		=> 'full',
	            'icon' 			=> plugins_url( '/assets/rcp_featured-chef.png', __FILE__ ),
	            'category' 		=> esc_html__( 'Cook Pro Addons', 'cook-pro' ),
	            'params' 		=> array(
					array(
						'type' 			=> 'dropdown',
						'holder' 		=> 'div',
						'class' 		=> '',
						'heading' 		=> esc_html__( 'ID', 'cook-pro' ),
						'param_name' 	=> 'id',
						'value' 		=> $featuredchef_ids,
						'description' 	=> esc_html__( 'Select ids', 'cook-pro' ),
					),
	                array(
						'type' 			=> 'css_editor',
						'heading' 		=> esc_html__( 'CSS Box', 'cook-pro' ),
						'param_name' 	=> 'css',
						'group' 		=> esc_html__( 'Design Options', 'cook-pro' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class Name', 'cook-pro' ),
						'param_name'  => 'extra_class',
						'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'cook-pro' ),
					),
	            ),
	        ) );
	    }

	    /*
	    Shortcode logic how it should be rendered
	    */
	    static function rcp_featured_chef( $atts, $content = null ) {
		    extract( shortcode_atts( array(
		        'id'          => '',
		        'css'         => '',
		        'extra_class' => '',
		    ), $atts ) );
		    $rcp_extra_css = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
		    if ( ! empty( $extra_class ) ) {
				$rcp_extra_css .= ' ' . $extra_class;
			}

		    $id = isset( $atts['id'] ) ? $atts['id'] : '';
		    $out = rcp_fchef( $id, $rcp_extra_css );

			return $out;
	    }
	}
} // End if().

// Finally initialize code
// Finally initialize code
global $rcp_plugin_activated;
if ( $rcp_plugin_activated ) {
	new Rcp_VC_Featured_Chef();
}
function rcp_fchef( $id, $rcp_extra_css ) {
	$rcp_user_data = get_user_by( 'id', $id );
	$out = '';
	if ( ! empty( $rcp_user_data ) ) {
		$rcp_user_url 	 	= $rcp_user_data->user_url;
		$rcp_user_desc	  	= get_user_meta( $rcp_user_data->ID, 'description', true );
		$rcp_user_position	= get_user_meta( $rcp_user_data->ID, 'position', true );
		$rcp_user_link		= get_permalink( rcp_get_option( 'rcp_profile_page_id', '' ) ) . '?username=' . $rcp_user_data->user_login;

		$out = '<div class="rcp-stc-chef-wrapper ' . $rcp_extra_css . '">';
		$out .= '<div class="rcp-stc__chef_thumb">';
		$out .= '<a href="' . esc_url( $rcp_user_url ) . '" class="stc__chef_thumb_link" >';
		$out .= rcp_get_avatar( $rcp_user_data->ID, 100 );
		$out .= '</a>';
		$out .= '</div>'; //rcp-stc__chef_thumb

		$out .= '<h2 class="rcp-stc__chef_name">';
		$out .= '<a href="' . esc_url( $rcp_user_url ) . '">';
		$out .= $rcp_user_data->display_name;
		$out .= '</a>';

		if ( ! empty( $rcp_user_position ) ) {
			$out .= '<span>' . $rcp_user_position . '</span>';
		}
		$out .= '</h2>';
		$out .= '<div class="rcp-stc__chef_info_more">';
		if ( ! empty( $rcp_user_desc ) ) {
			$out .= '<p>' . rcp_desc_max_charlength( $rcp_user_desc,200 ) . '</p>';
		}
		$out .= '<a rel="nofollow" rel="noreferrer"class="rcp-stc__chef_more rcp-btn rcp-btn-primary rcp-btn-sm" href="' . esc_url( $rcp_user_link ) . '"><span>' . esc_html__( 'More From This Chef', 'cook-pro' ) . '</span></a>';
		$out .= '</div>'; //.rcp-wg__chef_info_more
		$out .= '</div>'; //.rcp-wg-chef-wrapper
	}
	return $out;
}
