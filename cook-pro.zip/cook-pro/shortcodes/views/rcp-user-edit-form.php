<?php
	if ( 'POST' == $_SERVER['REQUEST_METHOD'] && ! empty( $_POST['action'] ) && $_POST['action'] == 'rcp-update-user' ) {

		global $errors, $post;

		$current_user = wp_get_current_user();
		$errors = array();

		/* Update user password. */
		if ( isset( $_POST['pass1'] ) && isset( $_POST['pass2'] ) && $_POST['pass1'] && $_POST['pass2'] ) {
			if ( $_POST['pass1'] === $_POST['pass2'] ) {
				wp_set_password( esc_attr( $_POST['pass1'] ), $current_user->ID );
			} else {
				$errors[] = esc_html__( 'The passwords you entered do not match. Your password was not updated.', 'cook-pro' );
			}
		}

		/* Update user information. */
		if ( isset( $_POST['url'] ) ) {
			wp_update_user( array( 'ID' => $current_user->ID, 'user_url' => esc_url( $_POST['url'] ) ) );
		}

		if ( isset( $_POST['email'] ) ) {

			$email_exists = email_exists( esc_attr( $_POST['email'] ) );
			if ( ! is_email( esc_attr( $_POST['email'] ) ) ) {
				$errors[] = esc_html__( 'The Email you entered is not valid.  try again.', 'cook-pro' );
			} elseif ( $email_exists && $email_exists != $current_user->ID ) {
				$errors[] = esc_html__( 'This email is already used by another user.  try a different one.', 'cook-pro' );
			} else {
				wp_update_user( array( 'ID' => $current_user->ID, 'user_email' => esc_attr( $_POST['email'] ) ) );
			}
		}

		if ( isset( $_POST['nickname'] ) ) {
			update_user_meta( $current_user->ID, 'nickname', esc_attr( $_POST['nickname'] ) );
			wp_update_user( array( 'ID' => $current_user->ID, 'display_name' => esc_attr( $_POST['nickname'] ) ) );
		}

		if ( isset( $_POST['description'] ) ) {
			update_user_meta( $current_user->ID, 'description', esc_attr( $_POST['description'] ) );
		}
		if ( isset( $_POST['position'] ) ) {
			update_user_meta( $current_user->ID, 'position', esc_attr( $_POST['position'] ) );
		}
		if ( isset( $_POST['facebook'] ) ) {
			update_user_meta( $current_user->ID, 'facebook', esc_attr( $_POST['facebook'] ) );
		}
		if ( isset( $_POST['twitter'] ) ) {
			update_user_meta( $current_user->ID, 'twitter', esc_attr( $_POST['twitter'] ) );
		}
		if ( isset( $_POST['google_plus'] ) ) {
			update_user_meta( $current_user->ID, 'google_plus', esc_attr( $_POST['google_plus'] ) );
		}
		if ( isset( $_POST['linkedin'] ) ) {
			update_user_meta( $current_user->ID, 'linkedin', esc_attr( $_POST['linkedin'] ) );
		}
		// AVATAR UPLOAD
		$avatar = $_FILES['avatar'];
		if ( ! empty( $_FILES['avatar']['name'] ) ) {
			$file_size_limit = '2kb';
			$filename = $_FILES['avatar']['name'];
			$filesize = 2000;
			$result = rcp_sui_parse_file_errors( $_FILES['avatar'], $filename, $filesize, $file_size_limit );
			if ( $result['error'] ) {
				$errors[] = $result['error'];
			}
			if ( empty( $result['error'] ) ) {
				if ( $avatar['tmp_name'] ) {
					if ( isset( $avatar, $_POST['avatar_nonce'] ) && $avatar && wp_verify_nonce( $_POST['avatar_nonce'], 'avatar_upload' ) ) {
						require_once( ABSPATH . 'wp-admin/includes/image.php' );
						require_once( ABSPATH . 'wp-admin/includes/file.php' );
						require_once( ABSPATH . 'wp-admin/includes/media.php' );
						$attachment_id = media_handle_upload( 'avatar', 0 );
						if ( is_wp_error( $attachment_id ) ) {
							$errors[] = esc_html__( 'Error uploading avatar.','cook-pro' );
						} else {
							update_user_meta( $current_user->ID, 'avatar', $attachment_id );
						}
					} else {
						$errors[] = esc_html__( 'Avatar uploader security check failed.','cook-pro' );
					}
				}
			}
		}
		// END AVATAR UPLOAD
		if ( empty( $errors ) ) {
			if ( 1 > count( $errors ) ) {
				// Send a registration welcome email to the new user?
				$rcp_logo_img = '';
				$email_message       = get_option( 'rcp_profile_update_email_message' );
				$email_subject       = get_option( 'rcp_profile_update_email_subject' );
				$admin_email_message = get_option( 'rcp_profile_update_admin_email_message' );
				$admin_email_subject = get_option( 'rcp_profile_update_admin_email_subject' );
				$rcp_logo = rcp_get_option( 'rcp_email_template_logo' );
				if ( ! empty( $rcp_logo ) ) {
					$attachment_id = rcp_get_attachment_id_from_src( $rcp_logo );
					$rcp_logo_img = wp_get_attachment_image( $attachment_id,  array( '200', '100' ), '', '' );
				}
				$admin_email = get_option( 'admin_email' );
				$user_email  = $_POST['email'];
				$username    = $_POST['user_login'];
				if ( $email_message && $email_subject ) {
					$msg_placeholders   = array( '[username]' );
					$msg_replacements   = array( $username );
					$subj_placeholders  = array( '[username]' );
					$subj_replacements  = array( $username );
					$rcp_email_message  = str_replace( $msg_placeholders, $msg_replacements, $email_message );
					$email_subject      = str_replace( $subj_placeholders, $subj_replacements, $email_subject );
					$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
					$email_placeholders = array( '[logo]', '[message]' );
					$email_replacements = array( $rcp_logo_img, $rcp_email_message );
					$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
					$email_message      = do_shortcode( $email_message );

					$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $admin_email . '>' . "\r\n\\";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					wp_mail( $user_email, $email_subject, $email_message, $headers );
				}
				if ( $admin_email_message && $admin_email_subject ) {
					$msg_placeholders  = array( '[username]' );
					$msg_replacements  = array( $username );
					$subj_placeholders = array( '[username]' );
					$subj_replacements = array( $username );
					$rcp_email_message = str_replace( $msg_placeholders, $msg_replacements, $admin_email_message );
					$email_subject     = str_replace( $subj_placeholders, $subj_replacements, $admin_email_subject );

					$rcp_email_template = file_get_contents( RECIPE_DIR . '/templates/rcp-email.html', true );
					$email_placeholders = array( '[logo]', '[message]' );
					$email_replacements = array( $rcp_logo_img, $rcp_email_message );
					$email_message      = str_replace( $email_placeholders, $email_replacements, $rcp_email_template );
					$email_message      = do_shortcode( $email_message );
					$headers  = 'From: ' . get_option( 'blogname' ) . ' Recipe <' . $user_email . '>' . "\r\n\\";
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					wp_mail( $admin_email, $email_subject, $email_message, $headers );
				}
				$registration_complete = '<div id="rcp_message"><span class="notice"><i class="fa fa-close fa-lg"></i></span><p class="rcp-form-notice"><strong>' . esc_html__( 'Success!', 'cook-pro' ) . '</strong><br />' . esc_html__( 'Profile Updated','cook-pro' ) . '</p></div>';
			}
		} else {
			$registration_complete = 'error';
		}
	} else {
		$registration_complete = false;
	}
	//
	if ( $registration_complete && $registration_complete != 'error' ) {
		echo $registration_complete;
	} else {
		if ( $registration_complete == 'error' ) {
			echo '<div class="rcp-custom-error" style="display:block">' . implode( '<br>', $errors ) . '</div>';
		}
	}
echo rcp_user_edit_form();
