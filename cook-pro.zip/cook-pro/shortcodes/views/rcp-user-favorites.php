<?php
// User Favoutrites
$out = '';
$limit   = rcp_get_option( 'rcp_user_favorites_limit','3' );
$orderby = rcp_get_option( 'rcp_user_favorites_orderby','ID' );
$order 	 = rcp_get_option( 'rcp_user_favorites_order','ASC' );
$loadmore = rcp_get_option( 'rcp_user_favorites_loadmore','disable' );

$rcp_author_name = isset( $_GET['username'] ) ? $_GET['username'] :'';
if ( ! empty( $rcp_author_name ) ) {
	$rcp_user_data = get_user_by( 'slug', $rcp_author_name );
	$user_id = $rcp_user_data->ID;
} else {
	$current_user = wp_get_current_user();
	$user_id = $current_user->ID;
}
$author_obj = get_user_by('id', $user_id );
$rcp_user_favorite_postids = get_user_meta( $user_id, 'recipe_love', true );
$rcp_user_favourites = array();
if ( ! empty( $rcp_user_favorite_postids ) ) {
	foreach ( $rcp_user_favorite_postids as $rcp_postid ) {
		$rcp_user_favourites[] = $rcp_postid;
	}
}
if ( ! empty( $rcp_user_favourites ) ) {
	$rcp_like_args = array(
		'post_type' 	=> 'recipe',
		'post_status' 	=> 'any',
		'posts_per_page' => $limit,
		'orderby' 		=> $orderby,
		'order' 		=> $order,
		'post__in' 		=> $rcp_user_favourites,
	);
	$rcp_favourite_query = new WP_Query( $rcp_like_args );
	$rcp_favouritequery = new WP_Query(
		array(
			'post_type' 	=> 'recipe',
			'post_status' 	=> 'any',
			'post__in' 		=> $rcp_user_favourites,
		)
 	);
	$rcp_favourites_count = $rcp_favouritequery->post_count;
	$rcp_user_fav_nonce = wp_create_nonce( 'rcp-user-fav-nonce' );
	$rcp_user_link      = get_permalink( rcp_get_option( 'rcp_profile_page_id', '' ) ) . '?username=' . $author_obj->user_login ;
	$out .= '<div class="rcp-profile__recipe rcp-user-fav-module">';
	$out .= '<table class="rcp__recipe_table rcp-user-fav-module-content"><tbody>';
	if ( $rcp_favourite_query->have_posts() ) {
		while ( $rcp_favourite_query->have_posts() ) {
			$rcp_favourite_query->the_post();
			global $post;
			$rcp_category_term_list = wp_get_post_terms( $post->ID, 'recipe_cat', array( 'fields' => 'names' ) );
			$rcp_cuisines_term_list = wp_get_post_terms( $post->ID, 'recipe_cuisine', array( 'fields' => 'names' ) );
			$rcp_ingredients_count  = rcp_ingredients_count( $post->ID );
			$rcp_calories 			= rcp_calories( $post->ID );
			$rcp_total_time  		= rcp_total_time( $post->ID );
			// $out .= '<tr>';
			// $out .= '<td  id="rcp-rem-favorite-msg"></td>';
			// $out .= '</tr>';
			$out .= '<tr class="rcp-user-fav-post rcp-user-fav-item">';
			$out .= '<td class="rcp__pimg_pmeta">';
			if ( has_post_thumbnail() ) {
				$out .= '<div class="pimg">';
				$out .= '<a href="' . esc_url( get_permalink( $post->ID ) ) . '">';
				$out .= '<div class="rcp-img">' . get_the_post_thumbnail( $post->ID, array( 85, 85 ), '' ) . '</div>';
				$out .= '</a>';
				$out .= '</div>'; //.pimg
			}
			$out .= '<div class="pmeta">';
			$out .= '<h5><a href="' . esc_url( get_permalink( $post->ID ) ) . '">' . get_the_title( $post->ID ) . '</a></h5>';
			if ( count( $rcp_category_term_list ) >= 1 ) {
				$out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Categories', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cat', '', ', ' ) ) . '</span>';
			}
			if ( count( $rcp_cuisines_term_list ) >= 1 ) {
				$out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Cusines', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cuisine', '', ', ' ) ) . '</span>';
			}
			$out .= '<div class="meta-likes">' . rcp_get_favorites( $post->ID ) . '</div>';
			$out .= '</div>'; //.pmeta
			$out .= '</td>'; //.rcp__pimg_pmeta
			$out .= '<td>';
			$out .= '<div class="rcp__recipe_pmeta">' . $rcp_total_time . '</div>';
			$out .= '</td>';
			$out .= '<td>';
			$out .= '<div class="rcp__recipe_pmeta">' . $rcp_calories . '<span>' . esc_html__( 'Calories', 'cook-pro' ) . '</span></div>';
			$out .= '</td>';
			// $out .= '<td>';
			// $out .= '<div class="rcp__recipe_pmeta">' . $rcp_ingredients_count . '<span>' . esc_html__( 'Ingredients', 'cook-pro' ) . '</span></div>';
			// $out .= '</td>';
			//$out .= '<td><a class="rcp-btn rcp-btn-primary rcp-btn-sm" href="' . esc_url( get_permalink( $post->ID ) ) . '"><span>' . esc_html__( 'View Recipe', 'cook-pro' ) . '</span></a>';
			$out .= '<td><a class="rcp-btn rcp-btn-primary rcp-btn-sm rcp-rem-favorite" href="#" data-id="' . $post->ID . '" data-userid="' . $user_id . '" data-url="' . esc_attr( $rcp_user_link ) . '"><span><i class="fa fa-times" aria-hidden="true"></i></span></a></td>';
			$out .= '</tr>';
		}
		/* Restore original Post Data */
		wp_reset_postdata();
	} else {
		$out .= esc_html__( 'No Favorites Found', 'cook-pro' );
	}
	$out .= '</tbody></table>'; //.rcp__recipe_table
	if ( 'enable' == $loadmore ) {
		if ( $rcp_favourites_count > 1 && $rcp_favourites_count > $limit ) {
			$out .= '<div class="rcp-user-fav-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-count="' . esc_attr( $rcp_favourites_count ) . '" data-nonce="' . esc_attr( $rcp_user_fav_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-userid="' . esc_attr( $user_id ) . '" data-number="' . esc_attr( $limit ) . '" >' . esc_html__( 'Load More Posts', 'cook-pro' ) . '</a></div>';
		}
	}
	$out .= '</div>'; //.rcp-profile__recipe
} else {
	$out .= esc_html__( 'No Favorites Found', 'cook-pro' );
}
echo $out;
