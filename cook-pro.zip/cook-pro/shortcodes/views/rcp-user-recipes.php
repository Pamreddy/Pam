<?php

$limit   = rcp_get_option( 'rcp_user_recps_limit','-1' );
$orderby = rcp_get_option( 'rcp_user_recps_orderby','date' );
$order 	 = rcp_get_option( 'rcp_user_recps_order','ASC' );
$loadmore = rcp_get_option( 'rcp_user_recps_loadmore','disable' );

$rcp_author_name = isset( $_GET['username'] ) ? $_GET['username'] :'';
$out = '';
if ( ! empty( $rcp_author_name ) ) {
	$rcp_user_data = get_user_by( 'slug', $rcp_author_name );
	$user_id = $rcp_user_data->ID;
} else {
	$current_user = wp_get_current_user();
	$user_id = $current_user->ID;
}
$rcp_args = array(
	'post_type' 	=> 'recipe',
	'post_status' 	=> 'any',
	'posts_per_page'=> $limit,
	'orderby' 		=> $orderby,
	'order' 		=> $order,
	'author' 		=> $user_id,
);
$rcp_query = new WP_Query( $rcp_args );
$rcpquery = new WP_Query(
	array(
		'post_type' 	=> 'recipe',
		'post_status' 	=> 'any',
		'author' 		=> $user_id,
	)
);
$rcp_total_count = $rcpquery->found_posts;

$rcp_user_rcp_nonce = wp_create_nonce( 'rcp-user-rcp-nonce' );

$out .= '<div class="rcp-profile__recipe rcp-user-module">';
$out .= '<table class="rcp__recipe_table rcp-user-module-content"><tbody>';
if ( $rcp_query->have_posts() ) {
	while ( $rcp_query->have_posts() ) {
		$rcp_query->the_post();

		global $post;

		$rcp_category_term_list = wp_get_post_terms( $post->ID, 'recipe_cat', array( 'fields' => 'names' ) );
		$rcp_cuisines_term_list = wp_get_post_terms( $post->ID, 'recipe_cuisine', array( 'fields' => 'names' ) );
		$rcp_ingredients_count	= rcp_ingredients_count( $post->ID );
		$rcp_calories 			= rcp_calories( $post->ID );
		$rcp_total_time  		= rcp_total_time( $post->ID );
		$rcp_post_status 		= get_post_status( $post->ID );

		$out .= '<tr class="rcp-user-post rcp-user-item">';
		$out .= '<td class="rcp__pimg_pmeta">';
		if ( has_post_thumbnail() ) {
			$out .= '<div class="pimg">';
			$out .= '<a href="' . esc_url( get_permalink( $post->ID ) ).'">';
			$out .= '<div class="rcp-img">' . get_the_post_thumbnail( $post->ID, array( 85, 85 ), '' ) . '</div>';
			$out .= '</a>';
			$out .= '</div>'; //.pimg
		}
		$out .= '<div class="pmeta">';
		$out .= '<h5><a  href="' . esc_url( get_permalink( $post->ID ) ) . '">' . get_the_title( $post->ID ) . '</a></h5>';
		if ( $rcp_post_status == 'pending' ) {
			$out .= '<span class="rcp-user-post__status rcp__pending">' . $rcp_post_status . '</span>';
		}
		if ( $rcp_post_status == 'draft' ) {
			$out .= '<span class="rcp-user-post__status rcp__drafted">' . $rcp_post_status . '</span>';
		}
		if ( count( $rcp_category_term_list ) >= 1 ) {
			$out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Categories', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cat', '', ', ' ) ) . '</span>';
		}
		if ( count( $rcp_cuisines_term_list ) >= 1 ) {
			$out .= '<span class="rcp-cc"><strong>' . esc_html__( 'Cuisines', 'cook-pro' ) . '</strong>' . strip_tags( get_the_term_list( $post->ID, 'recipe_cuisine', '', ', ' ) ) . '</span>';
		}
		$out .= '</div>'; //.pmeta
		$out .= '</td>'; //.rcp__pimg_pmeta
		$out .= '<td>';
		$out .= '<div class="rcp__recipe_pmeta">' . $rcp_total_time . '</div>';
		$out .= '</td>';
		$out .= '<td>';
		$out .= '<div class="rcp__recipe_pmeta">' . $rcp_calories . '<span>' . esc_html__( 'Calories','cook-pro' ) . '</span></div>';
		$out .= '</td>';
		$out .= '<td>';
		$out .= '<div class="rcp__recipe_pmeta">' . $rcp_ingredients_count . '<span>' . esc_html__( 'Ingredients', 'cook-pro' ) . '</div>';
		$out .= '</td>';
		//$out .= '<td><a class="rcp-btn rcp-btn-primary rcp-btn-sm" href="' . esc_url( get_permalink( $post->ID ) ) . '"><span>' . esc_html__( 'View Recipe', 'cook-pro' ) . '</span></a></td>';
		$out .= '</tr>';
	}
	/* Restore original Post Data */
	wp_reset_postdata();
} else {
	$out .= esc_html__( 'No Recipes Found', 'cook-pro' );
}
$out .= '</tbody></table>'; //.rcp__recipe_table
if ( 'enable' == $loadmore ) {
	if ( $rcp_total_count > 1 && $rcp_total_count > $limit ) {
		$out .= '<div class="rcp-user-rcp-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-count="' . esc_attr( $rcp_total_count ) . '" data-nonce="' . esc_attr( $rcp_user_rcp_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-userid="' . esc_attr( $user_id ) . '" data-number="' . esc_attr( $limit ) . '">' . esc_html__( 'Load More Posts', 'cook-pro' ) . '</a></div>';
	}
}
$out .= '</div>'; //.rcp-profile__recipe
echo $out;
