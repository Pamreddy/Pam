<?php
// Reviews submitted by user
$out = '';
$limit   = rcp_get_option( 'rcp_user_review_limit','10' );
$orderby = rcp_get_option( 'rcp_user_review_orderby','ID' );
$order 	 = rcp_get_option( 'rcp_user_review_order','DESC' );
$loadmore = rcp_get_option( 'rcp_user_review_loadmore','disable' );
$rcp_author_name = isset( $_GET['username'] ) ? $_GET['username'] :'';
if ( ! empty( $rcp_author_name ) ) {
	$rcp_user_data = get_user_by( 'slug', $rcp_author_name );
	$user_id = $rcp_user_data->ID;
} else {
	$current_user = wp_get_current_user();
	$user_id = $current_user->ID;
}
$args = array(
	'number' => $limit,
	'orderby' => $orderby,
	'order' => $order,
	'post_status' => 'publish',
	'post_type' => 'recipe',
	'status' => 'approve',
	'user_id' => $user_id,
);
$rcp_user_reviews = get_comments( $args );
foreach ( $rcp_user_reviews as $key => $id ) {
	if ( $id->post_author == $user_id ) {
		unset( $rcp_user_reviews[ $key ] );
	}
}
$total_reviews = get_comments( array(
	'post_status' => 'publish',
	'post_type' => 'recipe',
	'status' => 'approve',
	'user_id' => $user_id,
 ) );
 foreach ( $total_reviews as $key => $id ) {
 	if ( $id->post_author == $user_id ) {
 		unset( $total_reviews[ $key ] );
 	}
 }
$rcp_review_count = count( $total_reviews );
$rcp_user_review_nonce = wp_create_nonce( 'rcp-user-review-nonce' );
$out .= '<div class="rcp-user-review-module">';
$out .= '<div class="rcp-profile__reviews">';
$out .= '<ol class="rcp-comment__list rcp-user-review-module-content">';
if ( ! empty( $rcp_user_reviews ) ) {
	foreach ( $rcp_user_reviews as $review ) {
		$rcp_post_image = get_post_meta( $review->comment_post_ID, '_thumbnail_id', true );
		$rcp_comment_date = strtotime( $review->comment_date );
		$comment_date = human_time_diff( $rcp_comment_date, current_time( 'timestamp' ) ) . esc_html__( ' ago', 'cook-pro' );
		$review_rating = get_comment_meta( $review->comment_ID, 'comment_rating', true );
		$out .= '<li class="rcp-user-review-post">';
		$out .= '<div class="rcp-comment__review">';
		$out .= '<div class="comment__meta">';
		$out .= '<div class="comment__author vcard">';
		$out .= '<a href="' . esc_url( get_permalink( $review->comment_post_ID ) ) .'">';
		$out .= get_the_post_thumbnail( $review->comment_post_ID, array( 60, 60 ), '' );
		$out .= '<h5 class="fn"><a href="' . esc_url( get_permalink( $review->comment_post_ID ) ) . '#comment-' . $review->comment_ID . '">' . get_the_title( $review->comment_post_ID ) . '</a></h5>';
		$out .= '</a>';
		$out .= '</div>'; //.comment__author vcard
		$out .= '<div class="comment__metadata">';
		$out .= '<span>' . $comment_date . '</span>';
		$out .= '</div>'; //.comment__metadata
		$out .= '</div>'; //.comment__meta
		$out .= '<div class="comment__content">';
		$out .= '<p>' . $review->comment_content . '</p>';
		if ( ! empty( $review_rating ) ) {
			$out .= '<div class="rcp___prating">';
			$out .= '
			<div class="rcp-comment-ratings-review" data-rated=' . $review_rating . '>
			<i class="star_1 fa fa-star"></i>
			<i class="star_2 fa fa-star"></i>
			<i class="star_3 fa fa-star"></i>
			<i class="star_4 fa fa-star"></i>
			<i class="star_5 fa fa-star"></i>
			</div>';
			$out .= '</div>'; //.comment_rating
		}
		$out .= '</div>'; //.comment__content
		$out .= '</div></li>'; //.rcp-comment__review
	}
} else {
	$out .= esc_html__( 'No Reviews Found', 'cook-pro' );
}
$out .= '</ol>'; // .rcp-profile__reviews
$out .= '</div>'; // .rcp-profile__reviews
if ( 'enable' == $loadmore ) {
	if ( $rcp_review_count > 1 && $rcp_review_count > $limit ) {
		$out .= '<div class="rcp-user-review-load-more"><a href="#" class="rcp-btn rcp-btn-primary rcp-btn-sm" data-count="' . esc_attr( $rcp_review_count ) . '" data-nonce="' . esc_attr( $rcp_user_review_nonce ) . '" data-orderby="' . esc_attr( $orderby ) . '" data-order="' . esc_attr( $order ) . '" data-userid="' . esc_attr( $user_id ) . '" data-number="' . esc_attr( $limit ) . '" >' . esc_html__( 'Load More Posts', 'cook-pro' ) . '</a></div>';
	}
}
$out .= '</div>'; // .rcp-user-module;
echo $out;
