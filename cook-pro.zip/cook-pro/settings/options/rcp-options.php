<?php
/**
 * WordPress settings API demo class
 * @source-Author Tareq Hasan
 */
if ( ! class_exists( 'Aivah_Recipe_Options_Class' ) ) {
	class Aivah_Recipe_Options_Class {

		private $settings_api;
		function __construct() {
		    $this->settings_api = new Aivah_Recipe_Settings_Class;
		    add_action( 'admin_init', array( $this, 'admin_init' ) );
		    add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		}

		function admin_init() {

		    //set the settings
		    $this->settings_api->set_sections( $this->get_settings_sections() );
		    $this->settings_api->set_fields( $this->get_settings_fields() );

		    //initialize settings
		    $this->settings_api->admin_init();
		}

		function admin_menu() {
			add_submenu_page( 'edit.php?post_type=recipe', esc_html__( 'Settings', 'cook-pro' ), esc_html__( 'Settings', 'cook-pro' ), 'delete_posts', 'recipe_settings', array($this, 'plugin_page') );
		}

		function get_settings_sections() {
		    $sections = array(
		        array(
		            'id'    => 'recipe_general',
		            'title' => esc_html__( 'General', 'cook-pro' ),
		        ),
		        array(
		            'id'    => 'recipe_submission',
		            'title' => esc_html__( 'Submission', 'cook-pro' ),
		        ),
		        array(
		            'id'    => 'recipe_singlepage',
		            'title' => esc_html__( 'Single Page', 'cook-pro' ),
		        ),
				array(
		            'id'    => 'recipe_socialapikey',
		            'title' => esc_html__( 'Social & API Key', 'cook-pro' ),
		        ),
		        array(
		            'id'    => 'recipe_printpage',
		            'title' => esc_html__( 'Print Page', 'cook-pro' ),
		        ),
				array(
		            'id'    => 'recipe_email',
		            'title' => esc_html__( 'User Email', 'cook-pro' ),
					'desc'	=> wp_kses( __( 'Custom shortcodes defined for this plugin in use for the Email Message systems<br><br>
									[name]       - <em> Name </em><br>
									[username]   - <em> Username </em><br>
									[password]   - <em> Password </em><br>
									[recipename] - <em> Recipe title </em><br>
									[recipelink] - <em> Recipe link </em><br> ', 'cook-pro' ),
									array(
										'em' => true,
										'br' => array(),
									)
								),
		        ),
				array(
		            'id'    => 'recipe_admin_email',
		            'title' => esc_html__( 'Admin Email', 'cook-pro' ),
					'desc'	=> wp_kses( __( 'Custom shortcodes defined for this plugin in use for the Email Message systems<br><br>
									[name]       - <em> Name </em><br>
									[username]   - <em> Username </em><br>
									[password]   - <em> Password </em><br>
									[recipename] - <em> Recipe title </em><br>
									[recipelink] - <em> Recipe link </em><br> ', 'cook-pro' ),
									array(
										'em' => true,
										'br' => array(),
									)
								),
		        ),
		        array(
		            'id'    => 'recipe_profile',
		            'title' => esc_html__( 'Profile', 'cook-pro' ),
		        ),
				 array(
		            'id'    => 'recipe_colors',
		            'title' => esc_html__( 'Color', 'cook-pro' ),
		        ),
		    );
		    return $sections;
		}

		/**
		 * Returns all the settings fields
		 *
		 * @return array settings fields
		 */
		function get_settings_fields() {
			$rcp_all_pages = $rcp_user_roles = array();
			$rcp_get_pages = get_pages( 'sort_column=post_parent,menu_order' );
			if ( ! empty( $rcp_get_pages ) && ! is_wp_error( $rcp_get_pages ) ) {
				foreach ( $rcp_get_pages as $rcp_page ) {
					$rcp_all_pages[ $rcp_page->ID ] = $rcp_page->post_title;
				}
			}
			$rcp_user_roles = array(
				'subscriber'    => esc_html__( 'Subscriber', 'cook-pro' ),
				'contributor'   => esc_html__( 'Contributor', 'cook-pro' ),
				'author'	    => esc_html__( 'Author', 'cook-pro' ),
				'editor'        => esc_html__( 'Editor', 'cook-pro' ),
				'administrator' => esc_html__( 'Administrator', 'cook-pro' ),
			);
			$rcp_columns = array(
				'2' => esc_html__( '2 Columns', 'cook-pro' ),
				'3'	=> esc_html__( '3 Columns', 'cook-pro' ),
			);
			$rcp_comment_orderby = array(
								'comment_author' => esc_html__( 'Author', 'cook-pro' ),
								'comment_date'	 => esc_html__( 'Date', 'cook-pro' ),
								'comment_ID' 	 => esc_html__( 'ID', 'cook-pro' ),
							);
			$rcp_orderby = array(
								'title' => esc_html__( 'Title', 'cook-pro' ),
								'rand'	=> esc_html__( 'Randm', 'cook-pro' ),
								'ID' => esc_html__( 'ID', 'cook-pro' ),
								'date' => esc_html__( 'Date', 'cook-pro' ),
							);
			$rcp_order = array(
								'ASC' => esc_html__( 'Asc', 'cook-pro' ),
								'DESC'	=> esc_html__( 'Desc', 'cook-pro' ),
							);
		    $settings_fields = array(
		        'recipe_general' => array(
		            array(
		                'name'              => 'rcp_recipe_slug',
		                'label'             => esc_html__( 'Recipe Slug', 'cook-pro' ),
		                'desc'              => esc_html__( 'The default recipe slug is set "recipe". You feel free to change something else. Make sure No spaces, numbers or symbols allowed, just letters and dashes! the slug you choose does not conflict with any other pages (pages, posts, taxonomies etc.)', 'cook-pro' ),
		                'type'              => 'text',
		                'default'       => 'recipe',
		                'sanitize_callback' => 'sanitize_text_field',
		            ),
		            array(
		                'name'              => 'rcp_category_slug',
		                'label'             => esc_html__( 'Recipe Category Slug', 'cook-pro' ),
		                'desc'              => esc_html__( 'The default recipe slug is set "recipe-categor". You feel free to change something else. Make sure No spaces, numbers or symbols allowed, just letters and dashes! the slug you choose will not conflict with any other pages (pages, posts, taxonomies etc.)', 'cook-pro' ),
		                'type'              => 'text',
						'default'       => 'recipe-category',
		                'sanitize_callback' => 'sanitize_text_field',
		            ),
		            array(
		                'name'              => 'rcp_cuisine_slug',
		                'label'             => esc_html__( 'Recipe Cuisine Slug', 'cook-pro' ),
		                'desc'              => esc_html__( 'The default recipe slug is set "cuisine". You feel free to change something else. Make sure No spaces, numbers or symbols allowed, just letters and dashes! the slug you choose will not conflict with any other pages (pages, posts, taxonomies etc.).', 'cook-pro' ),
		                'type'              => 'text',
						'default'       => 'cuisine',
		                'sanitize_callback' => 'sanitize_text_field',
		            ),
		            array(
		                'name'              => 'rcp_method_slug',
		                'label'             => esc_html__( 'Recipe Cooking Method Slug', 'cook-pro' ),
		                'desc'              => esc_html__( 'The default recipe slug is set "cooking-method". You feel free to change something else. Make sure No spaces, numbers or symbols allowed, just letters and dashes! the slug you choose will not conflict with any other pages (pages, posts, taxonomies etc.).', 'cook-pro' ),
		                'type'              => 'text',
						'default'       => 'cooking-method',
		                'sanitize_callback' => 'sanitize_text_field',
		            ),
					array(
						'name' => 'rcp_profile_page_id',
						'label' => esc_html__( 'Profile Page', 'cook-pro' ),
						'desc' => __( 'Create a page using the <strong>[rcp-user-profile]</strong> shortcode where users profile is displayed.', 'cook-pro' ),
						'type' => 'select',
						'options' => $rcp_all_pages,
					),
					array(
						'name' => 'rcp_submit_form_id',
						'label' => esc_html__( 'Submit Recipe Page', 'cook-pro' ),
						'desc' => __( 'Create a page using the <strong>[rcp-submit]</strong> shortcode which will display the recipe submission form on front.', 'cook-pro' ),
						'type' => 'select',
		                'options' => $rcp_all_pages,
					),
					array(
						'name' => 'rcp_login_page_id',
						'label' => esc_html__( 'Login Page', 'cook-pro' ),
						'desc' => __( 'Create a page using the <strong>[rcp-login]</strong> shortcode which will display the login form on front.', 'cook-pro' ),
						'type' => 'select',
		                'options' => $rcp_all_pages,
					),
					array(
						'name' => 'rcp_search_page_id',
						'label' => esc_html__( 'Browse Recipe Page', 'cook-pro' ),
						'desc' => __( 'Create a page using the <strong>[rcp-recent-recipes]</strong> shortcode which will display the all the recent recipes on front.', 'cook-pro' ),
						'type' => 'select',
		                'options' => $rcp_all_pages,
					),
					array(
						'name' => 'rcp_display_style',
						'label' => esc_html__( 'Default Recipes Layout', 'cook-pro' ),
						'desc' => esc_html__( 'Select the style you wish to use for default recipes to display', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'style1',
						'options' => array(
									'style1' => esc_html__( 'Style1', 'cook-pro' ),
									'style2' => esc_html__( 'Style2', 'cook-pro' ),
									),
					),
					array(
						'name'		=> 'rcp_diff_level_options',
						'label'		=> esc_html__( 'Difficulty Level', 'cook-pro' ),
						'desc'		=> esc_html__( 'Enter Difficulty Level Options for your recipes. Default: Easy, Medium, Hard. Make sure you enter each in a new line.', 'cook-pro' ),
						'type'		=> 'textarea',
					),
					array(
						'name'  => 'rcp_nutrition_info',
						'label' => esc_html__( 'Nutrition Decription', 'cook-pro' ),
						'desc'  => esc_html__( 'Enter Nutrition Decription which displays right below the nutrition facts information.', 'cook-pro' ),
						'type'  => 'textarea',
					),
					array(
	                    'name'  => 'rcp_hide_author_name',
	                    'label' => esc_html__( 'Author Name in all recipes display', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Select the option you wish to hide author name in all recipes shortcodes display.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
	                ),
					array(
	                    'name'  => 'rcp_hide_ratings',
	                    'label' => esc_html__( 'Ratings in all recipes display', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Select the option you wish to hide ratings in all recipes shortcodes display.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
	                ),
		        ),
				'recipe_submission' => array(
					array(
						'name' => 'rcp_user_default_role',
						'label' => esc_html__( 'New User Role', 'cook-pro' ),
						'desc' => esc_html__( 'Select the user role for the newly registered', 'cook-pro' ),
						'type' => 'select',
						'options' => $rcp_user_roles,
					),
					array(
						'name' => 'rcp_submission_limit',
						'label' => esc_html__( 'Submission Limit', 'cook-pro' ),
						'desc' => esc_html__( 'This prevent users from submitting too many recipes, you can set recipe limit Defaults to 0.', 'cook-pro' ),
						'type' => 'text',
						'default' => '0',
					),
					array(
						'name' => 'rcp_submission_success_msg',
						'label' => esc_html__( 'Thankq Message', 'cook-pro' ),
						'desc' => esc_html__( 'Message which displays when form has been submitted successfully.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_submission_edit_success_msg',
						'label' => esc_html__( 'Updated Message', 'cook-pro' ),
						'desc' => esc_html__( 'Message which displays when form has been edited successfully.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_login_msg',
						'label' => esc_html__( 'Logged-In User Message', 'cook-pro' ),
						'desc' => esc_html__( 'This message to displays when you have access to form.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_logout_msg',
						'label' => esc_html__( 'Logged-Out User Message', 'cook-pro' ),
						'desc' => esc_html__( 'This message to displays when you do not have access to form.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
				),
				'recipe_singlepage' => array(
					array(
						'name' => 'rcp_single_layout',
						'label' => esc_html__( 'Recipe Single Layout', 'cook-pro' ),
						'desc' => esc_html__( 'Select the style you wish to choose for the recipe single page layout.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'vertical_style',
						'options' => array(
									'horizontal_style' => esc_html__( 'Horizontal Style', 'cook-pro' ),
									'vertical_style' => esc_html__( 'Vertical Style', 'cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_title_display',
						'label' => esc_html__( 'Recipe Title', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_sub_title_display',
						'label' => esc_html__( 'Sub Title', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_desc_section_diEsplay',
						'label' => esc_html__( 'Short Information', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_img_section_display',
						'label' => esc_html__( 'Featured Image', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_meta_section_display',
						'label' => esc_html__( 'Time | Serve | Difficulty', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_hide_time',
						'label' => esc_html__( 'Time', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Difficulty Level', 'cook-pro' ),
						// 'desc' => esc_html__( 'Select the option you wish to choose for the related recipes for the single page.', 'cook-pro' ),
						'name' => 'rcp_hide_difflevel',
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Yields', 'cook-pro' ),
						// 'desc' => esc_html__( 'Select the option you wish to choose for the related recipes for the single page.', 'cook-pro' ),
						'name' => 'rcp_hide_yields',
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_likes_section_display',
						'label' => esc_html__( 'Likes Icon', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_favorites_section_display',
						'label' => esc_html__( 'Favorites Icon', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_views_section_display',
						'label' => esc_html__( 'Views Icon', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_print_section_display',
						'label' => esc_html__( 'Print Icon', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_email_section_display',
						'label' => esc_html__( 'Email Icon', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_ingre_section_display',
						'label' => esc_html__( 'Ingredients', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_nutri_section_display',
						'label' => esc_html__( 'Nutritions', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Steps', 'cook-pro' ),
						'name' => 'rcp_steps_section_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Equipments', 'cook-pro' ),
						'name' => 'rcp_equipments_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Reviews', 'cook-pro' ),
						'name' => 'rcp_rating_section_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Social Sharing', 'cook-pro' ),
						'name' => 'rcp_share_links_section_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Advertisement', 'cook-pro' ),
						'name' => 'rcp_ads_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'About Author Info', 'cook-pro' ),
						'name' => 'rcp_author_info_display',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Related Recipes', 'cook-pro' ),
						'name' => 'rcp_more_recipe_categories',
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Cook Time', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the related recipes for the single page.', 'cook-pro' ),
						'name' => 'rcp_hide_cooktime',
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Ratings', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the related recipes for the single page.', 'cook-pro' ),
						'name' => 'rcp_hide_ratings',
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'label' => esc_html__( 'Author', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the related recipes for the single page.', 'cook-pro' ),
						'name' => 'rcp_hide_author',
						'type' => 'radio',
						'default' => 'no',
						'options' => array(
										'no' => esc_html__( 'Show', 'cook-pro' ),
										'yes' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_single_cat_columns',
						'label' => esc_html__( 'Related Recipe Display Column', 'cook-pro' ),
						'desc' => esc_html__( 'Select the no of columns which you wish to display the related recipes.', 'cook-pro' ),
						'type' => 'select',
						'options' => $rcp_columns,
					),
					array(
						'name' => 'rcp_single_cat_limit',
						'label' => esc_html__( 'Related Recipe Limits', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the limit of the related recipes to display. Currently default limit set to 4.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_single_cat_orderby',
						'label' => esc_html__( 'Related Recipe Display Orderby', 'cook-pro' ),
						'desc' => esc_html__( 'Select the orderby which you wish to display the related recipes in single page.', 'cook-pro' ),
						'type' => 'select',
						'options'	=> $rcp_orderby,
					),
					array(
						'name' => 'rcp_single_cat_order',
						'label' => esc_html__( 'Related Recipe Display Order', 'cook-pro' ),
						'desc' => esc_html__( 'Select the order which you wish to display the related recipes in single page.', 'cook-pro' ),
						'type' => 'select',
						'options'	=> $rcp_order,
					),
					array(
						'name' => 'rcp_comment_order',
						'label' => esc_html__( 'Recipe Comment order', 'cook-pro' ),
						'desc' => esc_html__( 'Select the order which you wish to display the recipe comments in single page.', 'cook-pro' ),
						'options'	=> $rcp_order,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_comment_pagination',
						'label' => esc_html__( 'Recipe Comment Pagination', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'disable',
						'options' => array(
										'enable' => esc_html__( 'Enable', 'cook-pro' ),
										'disable' => esc_html__( 'Disable', 'cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_comment_limit',
						'label' => esc_html__( 'Comment Limits', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the limit of the comments to display.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_flexslider_speed',
						'label' => esc_html__( 'Slides Speed', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the flex slider speed you want to set for the recipe single page.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_flexslider_effect',
						'label' => esc_html__( 'Slider Effect', 'cook-pro' ),
						'desc' => esc_html__( 'Select your animation type for the flex slider in the recipe single page. "fade" or "slide". ', 'cook-pro' ),
						'options' => array(
									'fade'	=> esc_html__( 'Fade', 'cook-pro' ),
									'slide'	=> esc_html__( 'Slide', 'cook-pro' ),
								),
						'type' => 'select',
					),
					array(
						'name' => 'rcp_flexslider_nav',
						'label' => esc_html__( 'Direction Nav', 'cook-pro' ),
						'desc' => esc_html__( 'Select the navigation for previous/next arrows for the flex slider in the recipe single page.', 'cook-pro' ),
						'options' => array(
										'true'	=> esc_html__( 'True', 'cook-pro' ),
										'false'	=> esc_html__( 'False', 'cook-pro' ),
									),
						'type' => 'select',
					),
					array(
						'name'        => 'rcp_ads_content',
						'label'       => esc_html__( 'Recipe Ads Content', 'cook-pro' ),
						'desc'        => esc_html__( 'Enter Recipe Ads Content.', 'cook-pro' ),
						'type'        => 'textarea',
					),
				),
				'recipe_socialapikey' => array(
					array(
						'name' 	=> 'rcp_google_api_site_key',
						'label' => esc_html__( 'Google API Key. ', 'cook-pro' ),
						'desc'  => esc_html__( 'Enter Google API Key. You can get Google API Key from https://developers.google.com/maps/documentation/javascript/get-api-key', 'cook-pro' ),
						'type'  => 'text',
					),
					array(
						'name' => 'rcp_google_api_secret_key',
						'label' => esc_html__( 'Google API Secret Key. ', 'cook-pro' ),
						'desc'  => esc_html__( 'Enter Google API Secret Key. You can get Google API Secret Key from https://developers.google.com/+/web/api/rest/oauth', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_facebook_app_id',
						'label' => esc_html__( 'Facebook App ID(OGG)', 'cook-pro' ),
						'desc' => esc_html__( 'Enter your Facebook App ID for sharing Recipe in Facebook Open Graph. You can get your Facebook App ID from https://developers.facebook.com/apps/ ', 'cook-pro' ),
						'type' => 'text',
					),
					array(
	                    'name'  => 'rcp_sociable_facebook',
	                    'label' => esc_html__( 'Facebook', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Check this if you wish to add Facebook Sharing for Recipe.', 'cook-pro' ),
	                    'type'  => 'checkbox',
	                ),
					array(
	                    'name'  => 'rcp_sociable_twitter',
	                    'label' => esc_html__( 'Twitter', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Check this if you wish to add Twitter Sharing for Recipe.', 'cook-pro' ),
	                    'type'  => 'checkbox',
	                ),
					array(
	                    'name'  => 'rcp_sociable_googleplus',
	                    'label' => esc_html__( 'Google+', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Check this if you wish to add Google+ Sharing for Recipe.', 'cook-pro' ),
	                    'type'  => 'checkbox',
	                ),
					array(
	                    'name'  => 'rcp_sociable_linkedin',
	                    'label' => esc_html__( 'LinkedIn', 'cook-pro' ),
	                    'desc'  => esc_html__( 'Check this if you wish to add LinkedIn Sharing for Recipe.', 'cook-pro' ),
	                    'type'  => 'checkbox',
	                ),
				),
				'recipe_printpage' => array(
					array(
						'name' => 'rcp_print_page_logo',
				 		'label' => esc_html__( 'Print Page Logo', 'cook-pro' ),
				 		'desc' => esc_html__( 'Choose the Image URL which you wish to display as logo in the print page. ', 'cook-pro' ),
				 		'type' => 'file',
						'default' => '',
	                    'options' => array(
	                        'button_label' => 'Choose Image'
	                    )
				 	),
					array(
						'name' => 'rcp_print_copy_right_section',
						'label' => esc_html__( 'Copyright Section', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the Copyright which you wish to display in the print page. ', 'cook-pro' ),
						'type' => 'textarea',
					),
					array(
						'name' => 'rcp_print_logo_display',
						'label' => esc_html__( 'Logo', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the logo in the print page.', 'cook-pro' ),
						'type' => 'radio',
						'options' => array(
										'enable' => esc_html__( 'Enable', 'cook-pro' ),
										'disable' => esc_html__( 'Disable','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_print_image_display',
						'label' => esc_html__( 'Image', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the image in the print page.', 'cook-pro' ),
						'type' => 'radio',
						'options' => array(
										'enable' => esc_html__( 'Enable', 'cook-pro' ),
										'disable' => esc_html__( 'Disable','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_print_steps_display',
						'label' => esc_html__( 'Steps', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the steps in the print page.', 'cook-pro' ),
						'type' => 'radio',
						'options' => array(
										'enable' => esc_html__( 'Enable', 'cook-pro' ),
										'disable' => esc_html__( 'Disable','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_print_copy_right_display',
						'label' => esc_html__( 'Copyright', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the copyright section in the print page.', 'cook-pro' ),
						'type' => 'radio',
						'options' => array(
										'enable' => esc_html__( 'Enable', 'cook-pro' ),
										'disable' => esc_html__( 'Disable','cook-pro' ),
									),
					),
				),
				'recipe_email' => array(
					array(
						'name' => 'rcp_email_template_logo',
						'label' => esc_html__( 'Email Content Logo', 'cook-pro' ),
						'desc' => esc_html__( 'Choose an image for your email header. Keep it 600px or less for best Results.', 'cook-pro' ),
						'type' => 'file',
						'default' => '',
		                'options' => array(
		                    'button_label' => esc_html__( 'Choose Image', 'cook-pro' ),
		                ),
					),
					array(
						'name' => 'rcp_registration_email_subject',
						'label' => esc_html__( 'New Registration Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to user when a new user is registered.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_registration_email_message',
						'label' => esc_html__( 'New Registration Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to user when a new user is registered.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_profile_update_email_subject',
						'label' => esc_html__( 'Profile Updated Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to user when a users profile is updated.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_profile_update_email_message',
						'label' => esc_html__( 'Profile Updated Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to user when a users profile is updated.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_submit_email_subject',
						'label' => esc_html__( 'New Recipe Approval Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to user when a new recipe is submitted.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_submit_email_message',
						'label' => esc_html__( 'New Recipe Approval Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to user when a new recipe is submitted.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_update_email_subject',
						'label' => esc_html__( 'Recipe Updated Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to user when a new recipe is updated.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_update_email_message',
						'label' => esc_html__( 'Recipe Updated Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to user when a new recipe is updated.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
				),
				'recipe_admin_email' => array(
					array(
						'name' => 'rcp_submit_admin_email_ids',
						'label' => esc_html__( 'Enter Email ids', 'cook-pro' ),
						'desc' => esc_html__( 'Enter Email ids.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_submit_admin_email_message',
						'label' => esc_html__( 'Recipe Submission Email Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to admin when a new recipe is submitted.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_submit_admin_email_subject',
						'label' => esc_html__( 'Recipe Submission Email Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to admin when a new recipe is submitted.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_update_admin_email_message',
						'label' => esc_html__( 'Recipe Update Email Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to admin when a new recipe is updated.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_update_admin_email_subject',
						'label' => esc_html__( 'Recipe Update Email Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to admin when a new recipe is updated.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_registration_admin_email_message',
						'label' => esc_html__( 'Recipe Registration Email Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to admin when a new user is registered.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_registration_admin_email_subject',
						'label' => esc_html__( 'Recipe Registration Email Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to admin when a new user is registered.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_profile_update_admin_email_message',
						'label' => esc_html__( 'Recipe Profile Update Email Message', 'cook-pro' ),
						'desc' => esc_html__( 'Email Message which goes to admin when a users profile is updated.', 'cook-pro' ),
						'type' => 'wysiwyg',
					),
					array(
						'name' => 'rcp_profile_update_admin_email_subject',
						'label' => esc_html__( 'Recipe Profile Update Email Subject', 'cook-pro' ),
						'desc' => esc_html__( 'Email Subject which goes to admin when a users profile is updated.', 'cook-pro' ),
						'type' => 'text',
					),
				),
				'recipe_profile' => array(
					array(
						'name' => 'rcp_user_recps_limit',
						'label' => esc_html__( 'User Recipes Limits', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the limit of the recipes in user profile page. ', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'name' => 'rcp_user_recps_orderby',
						'label' => esc_html__( 'User Recipes Orderby', 'cook-pro' ),
						'desc' => esc_html__( 'Select the orderby which you wish to display the recipes in user profile page.', 'cook-pro' ),
						'options'	=> $rcp_orderby,
						'default'	=> 'date',
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_recps_order',
						'label' => esc_html__( 'User Recipes Order', 'cook-pro' ),
						'desc' => esc_html__( 'Select the order which you wish to display the recipes in user profile page.', 'cook-pro' ),
						'options'	=> $rcp_order,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_recps_loadmore',
						'label' => esc_html__( 'User Recipes Load More', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the recipes load more in the user profile page.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' => 'rcp_user_favorites_limit',
						'label' => esc_html__( 'User Favorites Limits', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the limit of the favorites in user profile page.', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'label' => esc_html__( 'User Favorites Orderby', 'cook-pro' ),
						'desc' => esc_html__( 'Select the orderby which you wish to display the favourites in user profile page.', 'cook-pro' ),
						'name' => 'rcp_user_favorites_orderby',
						'options'	=> $rcp_orderby,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_favorites_order',
						'label' => esc_html__( 'User Favorites Order', 'cook-pro' ),
						'desc' => esc_html__( 'Select the order which you wish to display the favourites in user profile page.', 'cook-pro' ),
						'options'	=> $rcp_order,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_favorites_loadmore',
						'label' => esc_html__( 'User Favorites Load More', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the favourites load more in the user profile page.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
					array(
						'name' 	=> 'rcp_user_review_limit',
						'label' => esc_html__( 'User Review Limits', 'cook-pro' ),
						'desc' => esc_html__( 'Enter the limit of the reviews in user profile page. ', 'cook-pro' ),
						'type' => 'text',
					),
					array(
						'label' => esc_html__( 'User Review Orderby', 'cook-pro' ),
						'desc' => esc_html__( 'Select the orderby which you wish to display the user reviews in user profile page.', 'cook-pro' ),
						'name' => 'rcp_user_review_orderby',
						'options'	=> $rcp_comment_orderby,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_review_order',
						'label' => esc_html__( 'User Review Order', 'cook-pro' ),
						'desc' => esc_html__( 'Select the order which you wish to display the user reviews in user profile page.', 'cook-pro' ),
						'options'	=> $rcp_order,
						'type' => 'select',
					),
					array(
						'name' => 'rcp_user_review_loadmore',
						'label' => esc_html__( 'User Review Load More', 'cook-pro' ),
						'desc' => esc_html__( 'Select the option you wish to choose for the review load more in the user profile page.', 'cook-pro' ),
						'type' => 'radio',
						'default' => 'enable',
						'options' => array(
										'enable' => esc_html__( 'Show', 'cook-pro' ),
										'disable' => esc_html__( 'Hide','cook-pro' ),
									),
					),
				),
				'recipe_colors' => array(
					array(
						'name' => 'rcp_btn_primary_txt_color',
						'label' => esc_html__( 'Button Primary textcolor', 'cook-pro' ),
						'desc' => esc_html__( 'Button Primary text color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_primary_bg_color',
						'label' => esc_html__( 'Button Primary Background Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Primary Background Color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_primary_hover_color',
						'label' => esc_html__( 'Button Primary Hover Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Primary Hover Color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_primary_hover_bg_color',
						'label' => esc_html__( 'Button Primary Hover Bg Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Primary Hover Bg Color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_secondary_txt_color',
						'label' => esc_html__( 'Button Secondary textcolor', 'cook-pro' ),
						'desc' => esc_html__( 'Button Secondary text color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_secondary_bg_color',
						'label' => esc_html__( 'Button Secondary Background Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Secondary Background Color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_secondaty_hover_color',
						'label' => esc_html__( 'Button Secondary Hover Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Secondary Hover Color. ', 'cook-pro' ),
						'type' => 'color',
					),
					array(
						'name' => 'rcp_btn_secondaty_hover_bg_color',
						'label' => esc_html__( 'Button Secondary Hover Bg Color', 'cook-pro' ),
						'desc' => esc_html__( 'Button Secondary Hover Bg Color. ', 'cook-pro' ),
						'type' => 'color',
					),
				),
		    );

		    return $settings_fields;
		}

		function plugin_page() {
			echo rcp_plugin_header();
		    echo '<div class="rcp_body_wrap">';
			$iva_rcp_section_title = esc_html__( 'Recipe Settings', 'cook-pro' );
			$iva_rcp_section_icon = 'aicon_settings';
			echo iva_rcp_section_header( $iva_rcp_section_icon,  $iva_rcp_section_title );
		    $this->settings_api->show_navigation();
		    $this->settings_api->show_forms();

		    echo '</div>';
		}

		/**
		 * Get all the pages
		 *
		 * @return array page names with key value pairs
		 */
		function get_pages() {
		    $pages = get_pages();
		    $pages_options = array();
		    if ( $pages ) {
		        foreach ($pages as $page) {
		            $pages_options[$page->ID] = $page->post_title;
		        }
		    }

		    return $pages_options;
		}
	}
}
new Aivah_Recipe_Options_Class();
?>
