<?php
add_action( 'admin_menu' , 'rcp_import_export_page' );
function rcp_import_export_page() {
	add_submenu_page( 'edit.php?post_type=recipe', esc_html__( 'Backup Options', 'recipe' ), esc_html__( 'Backup Options', 'recipe' ), 'manage_options', 'rcp_import_export', 'rcp_import_export_options' );
}
function rcp_import_export_options() {
	?>
	<div class="wrap">
		<?php echo rcp_plugin_header(); ?>
		<h3><?php echo esc_html__( 'Backup Options', 'recipe' ); ?></h3>
		<div class="metabox-holder">
			<div class="postbox">
				<h3><span><?php esc_html_e( 'Export Settings', 'recipe' ); ?></span></h3>
				<div class="inside">
					<form method="post">
						<p><input type="hidden" name="rcp_export_action" value="rcp_export_settings" /></p>
						<?php wp_nonce_field( 'rcp_export_nonce', 'rcp_export_nonce' ); ?>
						<p class="submit">
							<input type="submit" name="rcp_export_settings" id="submit" class="button button-primary" value="<?php  esc_html_e( 'Export','recipe' ); ?>">
						</p>
					</form>
				</div><!-- .inside -->
			</div><!-- .postbox -->
			<div class="postbox">
				<h3><span><?php esc_html_e( 'Import Settings','recipe' ); ?></span></h3>
				<div class="inside">
					<p><?php esc_html_e( 'Import the plugin settings from a .json file. This file can be obtained by exporting the settings on another site using the form above.' ); ?></p>
					<form method="post" enctype="multipart/form-data">
						<p><input type="file" name="rcp_import_file"/></p>
						<p>
							<input type="hidden" name="rcp_import_action" value="rcp_import_settings" />
							<?php wp_nonce_field( 'rcp_import_nonce', 'rcp_import_nonce' ); ?>
							<p class="submit">
								<input type="submit" name="rcp_import_settings" id="submit" class="button button-primary" value="<?php  esc_html_e( 'Import','recipe' ); ?>">
							</p>
						</p>
					</form>
				</div><!-- .inside -->
			</div><!-- .postbox -->
		</div><!-- .metabox-holder -->
	</div><!-- .wrap -->
	<?php
}
