<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
function iva_ttm_form( $atts, $content = null, $code ) {
	extract( shortcode_atts( array(
		'title'		  => '',
		'padding' 	  => '',
		'textcolor'	  => '',
		'bgcolor'	  => '',
		'extraclass'  => '',
	), $atts ) );

	//Defines null value
	$out = '';

	//Outputs variables
	$iva_textcolor	= $textcolor ? 'color:' . $textcolor . ';' : '';
	$iva_bgcolor 	= $bgcolor ? 'background-color:' . $bgcolor . ';' : '';
	$iva_padding	= $padding ? 'padding:' . $padding . ';' : '' ;


	if ( ! empty( $iva_textcolor ) || ! empty( $iva_bgcolor ) || ! empty( $iva_padding ) ) {
		$iva_styles = ' style="' . $iva_bgcolor . $iva_textcolor . '"';
	} else {
		$iva_styles = '';
	}
	
	$ctitle_reqd_mark = $grav_email_reqd_mark = $client_job_reqd_mark = $cmpny_name_reqd_mark = $cmpny_url_reqd_mark = $client_desc_reqd_mark = '';

	$iva_ttm_client_name_txt	= get_option( 'iva_ttm_client_name_txt' ) ? get_option( 'iva_ttm_client_name_txt' ) : esc_html__( 'Name', 'iva_testimonial_pro' );
	$iva_ttm_client_pic_txt		= get_option( 'iva_ttm_client_pic_txt' ) ? get_option( 'iva_ttm_client_pic_txt' ) : esc_html__( 'Check this if you wish to use Image.', 'iva_testimonial_pro' );
	$iva_ttm_grav_email_txt		= get_option( 'iva_ttm_grav_email_txt' ) ? get_option( 'iva_ttm_grav_email_txt' ): esc_html__( 'Email ID', 'iva_testimonial_pro' );
	$iva_ttm_upload_pic_txt		= get_option( 'iva_ttm_upload_pic_txt' ) ? get_option( 'iva_ttm_upload_pic_txt' ) : esc_html__( 'Upload Photo', 'iva_testimonial_pro' );
	$iva_ttm_client_job_txt		= get_option( 'iva_ttm_client_job_txt' ) ? get_option( 'iva_ttm_client_job_txt' ) : esc_html__( 'Role', 'iva_testimonial_pro' );
	$iva_ttm_cmpny_name_txt		= get_option( 'iva_ttm_cmpny_name_txt' ) ? get_option( 'iva_ttm_cmpny_name_txt' ) : esc_html__( 'Company', 'iva_testimonial_pro' );
	$iva_ttm_cmpny_url_txt		= get_option( 'iva_ttm_cmpny_url_txt' ) ? get_option( 'iva_ttm_cmpny_url_txt' ) : esc_html__( 'Website', 'iva_testimonial_pro' );
	$iva_ttm_client_desc_txt	= get_option( 'iva_ttm_client_desc_txt' ) ? get_option( 'iva_ttm_client_desc_txt' ) : esc_html__( 'Description', 'iva_testimonial_pro' );

	//
	$iva_ttm_opt_client_name	= get_option( 'iva_ttm_opt_client_name' ) ? get_option( 'iva_ttm_opt_client_name' ) : '';
	$iva_ttm_opt_client_pic		= get_option( 'iva_ttm_opt_client_pic' ) ? get_option( 'iva_ttm_opt_client_pic' ) : '';
	$iva_ttm_opt_client_job		= get_option( 'iva_ttm_opt_client_job' ) ? get_option( 'iva_ttm_opt_client_job' ) : '';
	$iva_ttm_opt_grav_email		= get_option( 'iva_ttm_opt_grav_email' ) ? get_option( 'iva_ttm_opt_grav_email' ) : '';
	$iva_ttm_opt_cmpny_name		= get_option( 'iva_ttm_opt_cmpny_name' ) ? get_option( 'iva_ttm_opt_cmpny_name' ) : '';
	$iva_ttm_opt_cmpny_url		= get_option( 'iva_ttm_opt_cmpny_url' ) ? get_option( 'iva_ttm_opt_cmpny_url' ) : '';
	$iva_ttm_opt_client_desc	= get_option( 'iva_ttm_opt_client_desc' ) ? get_option( 'iva_ttm_opt_client_desc' ) : '';
	$iva_ttm_opt_captcha		= get_option( 'iva_ttm_opt_captcha' ) ? get_option( 'iva_ttm_opt_captcha' ) : '';

	//
	$iva_ttm_req_client_name	= get_option( 'iva_ttm_req_client_name' ) ? get_option( 'iva_ttm_req_client_name' ) : 'on';
	$iva_ttm_req_client_pic		= get_option( 'iva_ttm_req_client_pic' ) ? get_option( 'iva_ttm_req_client_pic' ) : '';
	$iva_ttm_req_gravatar		= get_option( 'iva_ttm_req_gravatar' ) ? get_option( 'iva_ttm_req_gravatar' ) : 'on';
	$iva_ttm_req_upload_pic		= get_option( 'iva_ttm_req_upload_pic' ) ? get_option( 'iva_ttm_req_upload_pic' ) : '';
	$iva_ttm_req_client_job		= get_option( 'iva_ttm_req_client_job' ) ? get_option( 'iva_ttm_req_client_job' ) : 'on';
	$iva_ttm_req_cmpny_name		= get_option( 'iva_ttm_req_cmpny_name' ) ? get_option( 'iva_ttm_req_cmpny_name' ) : '';
	$iva_ttm_req_cmpny_url		= get_option( 'iva_ttm_req_cmpny_url' ) ? get_option( 'iva_ttm_req_cmpny_url' ) : '';
	$iva_ttm_req_client_desc	= get_option( 'iva_ttm_req_client_desc' ) ? get_option( 'iva_ttm_req_client_desc' ) : '';

	// Form Inputs Style
	$iva_ttm_input_fontcolor	= get_option( 'iva_ttm_input_fontcolor' ) ? get_option( 'iva_ttm_input_fontcolor' ) : '';
	$iva_ttm_input_fontcolor 	= $iva_ttm_input_fontcolor ? 'color:' . $iva_ttm_input_fontcolor . ';' : '';

	$iva_ttm_input_fontsize		= get_option( 'iva_ttm_input_fontsize' ) ? get_option( 'iva_ttm_input_fontsize' ) : '';
	$iva_ttm_input_fontsize 	= $iva_ttm_input_fontsize ? 'font-size:' . $iva_ttm_input_fontsize . ';' : '';

	$iva_ttm_input_fontfamily	= get_option( 'iva_ttm_input_fontfamily' ) ? get_option( 'iva_ttm_input_fontfamily' ) : '';
	$iva_ttm_input_fontfamily 	= $iva_ttm_input_fontfamily ? 'font-family:' . $iva_ttm_input_fontfamily . ';' : '';

	$iva_ttm_input_fontweight	= get_option( 'iva_ttm_input_fontweight' ) ? get_option( 'iva_ttm_input_fontweight' ) : '';
	$iva_ttm_input_fontweight 	= $iva_ttm_input_fontweight ? 'font-weight:' . $iva_ttm_input_fontweight . ';' : '';

	$iva_ttm_input_borderradius	= get_option( 'iva_ttm_input_borderradius' ) ? get_option( 'iva_ttm_input_borderradius' ) : '';
	$iva_ttm_input_borderradius = $iva_ttm_input_borderradius ? 'border-radius:' . $iva_ttm_input_borderradius . ';' : '';

	$iva_ttm_input_bordercolor	= get_option( 'iva_ttm_input_bordercolor' ) ? get_option( 'iva_ttm_input_bordercolor' ) : '';
	$iva_ttm_input_bordercolor  = $iva_ttm_input_bordercolor ? 'border-color:' . $iva_ttm_input_bordercolor . ';':'';

	$iva_ttm_input_bgcolor		= get_option( 'iva_ttm_input_bgcolor' ) ? get_option( 'iva_ttm_input_bgcolor' ) : '';
	$iva_ttm_input_bgcolor 		= $iva_ttm_input_bgcolor ? 'background-color:' . $iva_ttm_input_bgcolor . ';':'';

	// Button Settings
	$iva_ttm_button_text			= get_option( 'iva_ttm_button_text' ) ? get_option( 'iva_ttm_button_text' ) : esc_html__( 'Submit', 'iva_testimonial_pro' );
	$iva_ttm_button_fontcolor		= get_option( 'iva_ttm_button_fontcolor' ) ? get_option( 'iva_ttm_button_fontcolor' ) : '';
	$iva_ttm_button_fontcolor 		= $iva_ttm_button_fontcolor ? 'color:' . $iva_ttm_button_fontcolor . ';' : '';
	$iva_ttm_button_bordercolor		= get_option( 'iva_ttm_button_bordercolor' ) ? get_option( 'iva_ttm_button_bordercolor' ) : '';
	$iva_ttm_button_bordercolor  	= $iva_ttm_button_bordercolor ? 'border-color:' . $iva_ttm_button_bordercolor . ';':'';
	$iva_ttm_button_bgcolor			= get_option( 'iva_ttm_button_bgcolor' ) ? get_option( 'iva_ttm_button_bgcolor' ) : '';
	$iva_ttm_button_bgcolor 		= $iva_ttm_button_bgcolor ? 'background-color:' . $iva_ttm_button_bgcolor . ';':'';
	$iva_ttm_button_hover_fontcolor = get_option( 'iva_ttm_button_hover_fontcolor' ) ? get_option( 'iva_ttm_button_hover_fontcolor' ) : '';
	$iva_ttm_button_hover_bordercolor = get_option( 'iva_ttm_button_hover_bordercolor' ) ? get_option( 'iva_ttm_button_hover_bordercolor' ) : '';
	$iva_ttm_button_hover_bgcolor	= get_option( 'iva_ttm_button_hover_bgcolor' ) ? get_option( 'iva_ttm_button_hover_bgcolor' ) : '';
	$iva_ttm_btn_fontsize			= get_option( 'iva_ttm_btn_fontsize' ) ? get_option( 'iva_ttm_btn_fontsize' ) : '';
	$iva_ttm_btn_fontsize  			= $iva_ttm_btn_fontsize ? 'font-size:' . $iva_ttm_btn_fontsize . ';':'';
	$iva_ttm_btn_fontfamily			= get_option( 'iva_ttm_btn_fontfamily' ) ? get_option( 'iva_ttm_btn_fontfamily' ) : '';
	$iva_ttm_btn_fontfamily  		= $iva_ttm_btn_fontfamily ? 'font-family:' . $iva_ttm_btn_fontfamily . ';':'';
	$iva_ttm_btn_fontweight			= get_option( 'iva_ttm_btn_fontweight' ) ? get_option( 'iva_ttm_btn_fontweight' ) : '';
	$iva_ttm_btn_fontweight  		= $iva_ttm_btn_fontweight ? 'font-weight:' . $iva_ttm_btn_fontweight . ';':'';
	$iva_ttm_btn_borderradius		= get_option( 'iva_ttm_btn_borderradius' ) ? get_option( 'iva_ttm_btn_borderradius' ) : '';
	$iva_ttm_btn_borderradius  		= $iva_ttm_btn_borderradius ? 'border-radius:' . $iva_ttm_btn_borderradius . ';':'';

	$ctitle_reqd 		= 'data-req=false';
	$cpic_reqd 			= 'data-req=false';
	$grav_email_reqd 	= 'data-req=false';
	$upload_pic_reqd 	= 'data-req=false';
	$client_job_reqd 	= 'data-req=false';
	$cmpny_name_reqd 	= 'data-req=false';
	$cmpny_url_reqd 	= 'data-req=false';
	$client_desc_reqd 	= 'data-req=false';

	$c_value1 = rand( 5,10 );
	$c_value2 = rand( 1,5 );
	$operators = array(
				    "+",
				    "-",
			    );
	$captcha_operator = $operators[rand( 0,1 )];
	switch ( $captcha_operator ) {
	    case "+":
	        $result = $c_value2 + $c_value1;
	        break;
	    case "-":
	        $result = $c_value1 - $c_value2;
	        break;
	}

	// Form
	$out .= '<div class="iva_ttm_section ' . $extraclass . '" ' . esc_attr( $iva_styles ) . '>';
	$out .= '<div class="iva_ttm_sh_form">';
	$out .= '<form name="iva_ttm_form" id="iva_ttm_sh_form" method="post" action="#" enctype="multipart/form-data">';
	$out .= '<div id="iva_ttm_formstatus"></div>';
	$iva_ttm_form_nonce = wp_create_nonce( 'iva-ttm-form' );
	$out .= '<input type="hidden" name="iva_ttm_form" id="iva-ttm-form" value="' . esc_attr( $iva_ttm_form_nonce ) . '" />';
	// Title
	if ( 'on' != $iva_ttm_opt_client_name ) {
		if ( 'on' == $iva_ttm_req_client_name ) {
			$ctitle_reqd = 'data-req=true';
			$ctitle_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_client_title">';
		$out .= '<input type="text" ' . esc_attr( $ctitle_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_name_txt . $ctitle_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_title" name="client_title" value="" class="client_title" />';
		$out .= '</span></p>';
	}

	// Email ID
	if ( 'on' != $iva_ttm_opt_grav_email ) {
		if ( 'on' == $iva_ttm_req_gravatar ) {
			$grav_email_reqd = 'data-req=true';
			$grav_email_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_gravatar_email">';
		$out .= '<input type="text" ' . esc_attr( $grav_email_reqd ) . '  placeholder="' . esc_attr( $iva_ttm_grav_email_txt . $grav_email_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="gravatar_email" name="gravatar_email" value="" class="gravatar_email" />';
		$out .= '</span></p>';
	}

	// Role
	if ( 'on' != $iva_ttm_opt_client_job ) {
		if ( 'on' == $iva_ttm_req_client_job ) {
			$client_job_reqd = 'data-req=true';
			$client_job_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_client_job">';
		$out .= '<input type="text" ' . esc_attr( $client_job_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_job_txt . $client_job_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_job" name="client_job" value="" class="client_job" />';
		$out .= '</span></p>';
	}

	// Company Name
	if ( 'on' != $iva_ttm_opt_cmpny_name ) {
		if ( 'on' == $iva_ttm_req_cmpny_name ) {
			$cmpny_name_reqd = 'data-req=true';
			$cmpny_name_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_company_name">';
		$out .= '<input type="text" ' . esc_attr( $cmpny_name_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_cmpny_name_txt . $cmpny_name_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="company_name" name="company_name" value="" class="company_name" />';
		$out .= '</span></p>';
	}

	// Company URL
	if ( 'on' != $iva_ttm_opt_cmpny_url ) {
		if ( 'on' == $iva_ttm_req_cmpny_url ) {
			$cmpny_url_reqd = 'data-req=true';
			$cmpny_url_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_company_url">';
		$out .= '<input type="text" ' . esc_attr( $cmpny_url_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_cmpny_url_txt . $cmpny_url_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="company_url" name="company_url" value="" class="company_url" />';
		$out .= '</span></p>';
	}

	// Description
	if ( 'on' != $iva_ttm_opt_client_desc ) {
		if ( 'on' == $iva_ttm_req_client_desc ) {
			$client_desc_reqd = 'data-req=true';
			$client_desc_reqd_mark = ' * ';
		}
		$out .= '<p><span class="iva_client_desc">';
		$out .= '<textarea ' . esc_attr( $client_desc_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_desc_txt . $client_desc_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_desc" name="client_desc" class="client_desc" rows="5" cols="15"></textarea>';
		$out .= '</span></p>';
	}

	// Client Pic
	if ( 'on' != $iva_ttm_opt_client_pic ) {
		if ( 'on' == $iva_ttm_req_client_pic ) { $cpic_reqd = 'data-req=true'; }
		$out .= '<p><span class="iva_client_image_option">';
		$out .= '<input type="checkbox" ' . esc_attr( $cpic_reqd ) . ' id="form_client_image_option" name="client_image_option"><label for="form_client_image_option" class="ivabh-desc">' . $iva_ttm_client_pic_txt . '</label>';
		$out .= '</span></p>';

		// Upload Image
		if ( 'on' == $iva_ttm_req_upload_pic ) { $upload_pic_reqd = 'data-req=true'; }
		$out .= '<p><span class="iva_client_photo">';
		$out .= '<input class="inputText ttm-browser" ' . esc_attr( $upload_pic_reqd ) . ' type="file" placeholder="' . esc_attr( $iva_ttm_upload_pic_txt ) . '" name="client_photo" multiple="" id="client_photo" />';
		$out .= '</span></p>';
	}

	// Captcha
	if ( 'on' != $iva_ttm_opt_captcha ) {
		$out .= '<p class="iva_captcha">';
		$out .= '<input name="captcha_result" id="captcha_result" placeholder="' . esc_attr( $c_value1 ) . ' ' . esc_attr( $captcha_operator ) . ' ' . esc_attr( $c_value2 ) . ' = ' . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" class="captcha_result" type="text" size="2" />';
		$out .= '<input name="captcha_val" id="captcha_val" type="hidden" value=' . esc_attr( $result ) . ' >';
		$out .= '</p>';
	}

	// Ratings
	$out .= '
	<p class="at-ttm-ratings-ch">
	<a class="star_1" data-rated="1"><i class="atmpro_star"></i></a>
	<a class="star_2" data-rated="2"><i class="atmpro_star"></i></a>
	<a class="star_3" data-rated="3"><i class="atmpro_star"></i></a>
	<a class="star_4" data-rated="4"><i class="atmpro_star"></i></a>
	<a class="star_5" data-rated="5"><i class="atmpro_star"></i></a>
	</p>';

	$out .= '<input type="hidden" name="client_ratings" id="client_ratings">';

	// Status
	$out .= '<input type="hidden" name="client_status" id="client_status" value="pending" />';

	// Submit Button
	$out .= '<div class="iva_subbtn"><a href="#" id="iva_ttm_sh_submit" class="ttm-btn medium iva_submit" style="' . $iva_ttm_button_fontcolor . $iva_ttm_button_bordercolor . $iva_ttm_button_bgcolor . $iva_ttm_btn_fontsize . $iva_ttm_btn_fontfamily . $iva_ttm_btn_fontweight . $iva_ttm_btn_borderradius . '"/><span>' . esc_attr( $iva_ttm_button_text ) . '</span></a></div>';
	$out .= '</form>';
	$out .= '</div>';
	$out .= '</div>';

	//Returns output
	return $out;
}

function iva_ttm_gen_css_prop( $selectors = null, $properties = null ) {
	$css = $inline_css = '';

	if ( is_array( $properties ) && ! empty( $properties ) ) {
		foreach ( $properties as $name => $value ) {
			if ( '' != $value ) {
				if ( 'font-family' === $name ) {
					$value = '"' . $value . '"';
				}
				$css .= "$name:$value; ";
			}
		}
	}
	if ( isset( $selectors ) ) {
		if ( is_string( $selectors ) && '' != $selectors ) {
			$inline_css .= $selectors;
		} elseif ( is_array( $selectors ) && ! empty( $selectors ) ) {
			$inline_css .= implode( ",\n$inline_css",  $selectors );
		}
	}
	// Apply inline CSS
	if ( '' == trim( $inline_css ) ) {
		$inline_css .= $css;
	} else {
		$inline_css .= '{ ' . $css . '} ';
	}

	// Format/Clean the CSS.
	$inline_css = "\n" . $inline_css;
	if ( '' != $css ) {
		return $inline_css;
	}
}

// Adds a hook for a shortcode tag.
add_shortcode( 'iva_testimonial_form', 'iva_ttm_form' );
add_action( 'wp_ajax_iva_client_rating', 'iva_client_rating' );
add_action( 'wp_ajax_nopriv_iva_client_rating', 'iva_client_rating' );
function iva_ttm_css_generator() {
	$iva_ttm_button_hover_fontcolor = get_option( 'iva_ttm_button_hover_fontcolor' ) ? get_option( 'iva_ttm_button_hover_fontcolor' ) : '';
	$iva_ttm_button_hover_bgcolor	= get_option( 'iva_ttm_button_hover_bgcolor' ) ? get_option( 'iva_ttm_button_hover_bgcolor' ) : '';
	$iva_ttm_button_hover_bordercolor = get_option( 'iva_ttm_button_hover_bordercolor' ) ? get_option( 'iva_ttm_button_hover_bordercolor' ) : '';
	// Menu Active Link Background
	$custom_css = iva_ttm_gen_css_prop( array(
		'.iva_submit:hover',
		), array(
		 	'color' => $iva_ttm_button_hover_fontcolor . ' !important ',
		 	'background-color' => $iva_ttm_button_hover_bgcolor . ' !important ',
		 	'border-color' => $iva_ttm_button_hover_bordercolor . ' !important ',
		)
	);

	wp_add_inline_style( 'iva-ttm-frontend', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'iva_ttm_css_generator', 100 );
