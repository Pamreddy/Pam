jQuery(document).ready(function($){
	// Settings
	jQuery(".update_ttm_settings").click(function() {
		var iva_bh_url = jQuery('.update_ttm_settings').attr("data_tm_url");
		var setting_nonce = jQuery("#iva-ttm-settings").val();	
		$.ajax({
			url: ajaxurl ,
			type: 'post',
			dataType: 'html',
			
			data: {
				'action' : 'iva_ttm_update_settings',
				'data'   : jQuery(".iva_ttm_settings_form").serialize(),
				setting_nonce: setting_nonce,
			},
			success: function( response ){ 
				jQuery('#settings_success_msg').html(response);
				jQuery('#iva_ttm_msg .notice-dismiss').click( function(){
					jQuery("#iva_ttm_msg").slideUp("slow");
				});
			}
		});
	}).change();
});
jQuery(document).ready(function ($) {
	
	jQuery('.iva-radio-option').click(function(){
		var iva_ttm_style_option = jQuery('input[name=iva_ttm_type]:checked').val();
		var cur_img = jQuery('.' + iva_ttm_style_option).find(":selected").attr("data-img");
		if( typeof( cur_img ) != "undefined" ){
			jQuery(".iva_demo_img").attr("src", cur_img );
		}
	});
	// Select Dropdown
	jQuery("#iva_ttm_choose").change(function () {
		var selected_dropcap = jQuery("#iva_ttm_choose option:selected").val();		
		if(selected_dropcap === 'id'){
			jQuery(".iva_postid").show();
			jQuery(".iva_categories").hide();
		}
		if(selected_dropcap === 'categories'){		
			jQuery(".iva_categories").show();
			jQuery(".iva_postid").hide();
		}				
	}).change();

	// Notification Email Dropdown
	jQuery("#iva_ttm_notificationemail").change(function () {
		var selected_dropcap = jQuery("#iva_ttm_notificationemail option:selected").val();		
		if(selected_dropcap === 'enable'){
			jQuery(".enable").show();
			jQuery(".disable").hide();
		}
		if(selected_dropcap === 'disable'){		
			jQuery(".disable").show();
			jQuery(".enable").hide();
		}				
	}).change();

	//Testimonial Select
	jQuery("#iva_ttm_column").change( function () {
	jQuery('tr.showtestimonial').hide();
		var tm_select = jQuery('#iva_ttm_column option:selected').val();
		if( tm_select!=''){
			jQuery('.'+tm_select).show();
		}
	}).change();

	// Shortcode Layouts
	jQuery("#iva_ttm_layouts, #iva_ttm_g_layouts").change(function(){
		var tm_select = jQuery('input[name=iva_ttm_type]:checked').val();
		jQuery(".iva_import_load").css("display","none");
		var cur_img = jQuery('.' + tm_select).find(":selected").attr("data-img");
		if( typeof( cur_img ) != "undefined" ){
			jQuery(".iva_demo_img").attr("src", cur_img );
		}
	}).change();

	// Testimonial Layouts
	jQuery(".ttm #iva_ttm_layouts").change(function(){
		var tm_select = jQuery('#iva_ttm_layouts option:selected').val();
		jQuery(".iva_import_load").css("display","none");
		var cur_img = jQuery(this).find(":selected").attr("data-img");
		if( typeof( cur_img ) != "undefined" ){
			jQuery(".iva_demo_img").attr( "src", cur_img );
		}
	}).change();

	// Color Picker
	jQuery(".wpcolorpicker").wpColorPicker({
		color: "#0000ff",
		onShow: function (colpkr) {
			jQuery(colpkr).fadeIn(500);
			return false;
		},
		onHide: function (colpkr) {
			jQuery(colpkr).fadeOut(500);
			return false;
		},
		onChange: function (hsb, hex, rgb) {
			jQuery(".wpcolorpicker' div").css("backgroundColor", "#" + hex);
			jQuery(".wpcolorpicker").next("input").attr("value","#" + hex);
			jQuery(".wpcolorpicker").val("#" + hex);
		}
	});
});
