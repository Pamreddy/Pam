(function($){
    'use strict';
	jQuery(document).ready(function() {
		/*-- Upload Image Remove-*/
		 jQuery('.iva_ttm_image_remove').live('click', function(event) { 
		   var defaultImage = jQuery(this).parent().siblings('.custom_default_image').text();
		   jQuery(this).parent().siblings('.iva_ttm_upload_image').val('');
		   jQuery(this).parent('.iva-ttm-screenshot').slideUp();
		   return false;
		});
		var custom_uploader,clickedID ,formfield = '';
		jQuery('.iva_ttm_upload_image_button').click(function() {
			clickedID = jQuery(this).attr('id');
			formfield = jQuery(this).prev( 'input').attr( 'id' );
			if (custom_uploader) {
				custom_uploader.open();
				return;
			}
			//Extend the wp.media object
			custom_uploader = wp.media.frames.file_frame = wp.media({
				title: 'Choose This',
				button: {
				text: 'Choose This'
				},
					multiple: false
			});
							
			custom_uploader.on('select', function() {
				var attachment = custom_uploader.state().get('selection').first().toJSON();
				var image = /(^.*\.jpg|jpeg|png|gif*)/gi;
				if(typeof(attachment.sizes.thumbnail) === 'undefined') {
					if (attachment.url.match(image)) {
					  var  btnContent = '<img src="'+attachment.url+'" alt="" />';
					  btnContent += '<a href="javascript:(void);" class="iva_ttm_image_remove button button-primary">x</a>';
					}
				}else if (attachment.sizes.thumbnail.url.match(image)) {
					var  btnContent = '<img src="'+attachment.sizes.thumbnail.url+'" alt="" />';
					btnContent += '<a href="javascript:(void);" class="iva_ttm_image_remove button button-primary">x</a>'
				}
				jQuery( '#' + formfield).val(attachment.url);
				jQuery( '#' + formfield).siblings( '#iva_ttm_imagepreview-'+clickedID).slideDown().html(btnContent); 
			});		 
			//Open the uploader dialog
			custom_uploader.open();
			return false;
		});
		
		// Color Picker
		jQuery('.wpcolorSelector').each(function() {
			var Othis 			= this; //cache a copy of the this variable for use inside nested function
			var initialColor 	= jQuery(Othis).prev('input').attr('value');
			var initialColorid 	= jQuery(Othis).prev('input').attr('id');
			
			jQuery(Othis).children('div').css('backgroundColor', initialColor);
			
			jQuery( '#' + initialColorid ).wpColorPicker( {
				color: initialColor,
				onShow: function (colpkr) {
					jQuery(colpkr).fadeIn(500);
					return false;
				},
				onHide: function (colpkr) {
					jQuery(colpkr).fadeOut(500);
					return false;
				},
				onChange: function (hsb, hex, rgb) {
					jQuery(Othis).children('div').css('backgroundColor', '#' + hex);
					jQuery(Othis).prev('input').attr('value','#' + hex);
				}
			});
		});
		
		jQuery('.showtestimonial').hide();
		jQuery('.iva-ttm-vc-styles').show();
		jQuery('.iva-radio-option').show();
		jQuery('.iva-radio-img-label').hide();
		jQuery('.iva-radio-img-radio').hide();

		var iva_ttm_style_option = jQuery('input[name=iva_ttm_type]:checked').val();
		if( typeof iva_ttm_style_option !== 'undefined' ){
			jQuery('.' + iva_ttm_style_option ).show();
		}
		
		jQuery('.iva-radio-option').click(function() {
			jQuery('.showtestimonial').hide();
			jQuery(this).parent().parent().find('.iva-radio-option').removeClass('iva-radio-option-selected');
			jQuery(this).addClass('iva-radio-option-selected');
			var iva_ttm_style_option = jQuery('input[name=iva_ttm_type]:checked').val();
			jQuery('.' + iva_ttm_style_option ).show();
		});

		jQuery('.iva-ttm-vc-styles').click(function() {
			jQuery(this).parent().parent().find('.iva-ttm-vc-styles').removeClass('iva-ttm-vc-styles-selected');
			jQuery(this).addClass('iva-ttm-vc-styles-selected');
		});

		//-----------------------------
		jQuery('#gravatar_email').on('keypress', function() {
		    var $email = this.value;
		    validateEmail($email);
		});

		function validateEmail(email) {
		    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		    if (!emailReg.test(email)) {
		    	// alert('hiiiiiiiii');
		       jQuery('#gravatar_email').addClass('error');
		    } else {
		        jQuery('#gravatar_email').removeClass('error');
		    }
		}

		// jQuery('#gravatar_email').on('keypress', function() {
	 //    var re = /([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(this.value);
	 //    if(!re) {
	 //        $('#error').show();
	 //    } else {
	 //        $('#error').hide();
	 //    }
		// })

		//*********************************//
		// jQuery('.testimonialoption gravatar').keypress(function() {
		// 	var gravatar_email = jQuery(this).val();
		// 	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;  
		//    	if(!emailReg.test(gravatar_email)) {  
		//         jQuery(this).addClass('gravatar_email');
		//    	}       
		// });
		
		/*-- custom Testimonial ratings format selection--*/
		jQuery("#client_ratings_format").change(function () {
			jQuery(".ratingsoption").hide();
			var ratingsoption = jQuery("#client_ratings_format option:selected").val();
			jQuery("."+ratingsoption).show();
		}).change();	
		
		//
		jQuery("#iva_ttm_choose").change(function () {
			jQuery(".ttm_options").hide();
			var subheader_teaser_select = jQuery("#iva_ttm_choose option:selected").val();
			jQuery("."+subheader_teaser_select).show();
		}).change();
	});
})(jQuery);
