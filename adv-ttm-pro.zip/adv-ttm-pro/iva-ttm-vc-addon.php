<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
if ( ! class_exists( 'IVA_tmp_addon' ) ) {
	class IVA_tmp_addon {
		// Constructor
		function __construct() {
			add_action( 'init', array( $this, 'iva_testimonial_init' ) );
			add_shortcode( 'iva_tmp_addon', array( $this, 'iva_testimonial_shortcode' ) );
			add_action( 'wp_enqueue_script', 'iva_vc_mul_fade_script' );
		}
		function iva_vc_mul_fade_script() {
			wp_enqueue_script( 'iva-ttm-frontend-script' );
		}

		// initialize the mapping function
		function iva_testimonial_init() {
			if ( function_exists( 'vc_map' ) ) {
				$iva_ttm_shortcode = array();
				$args = array(
					'posts_per_page' => -1,
					'post_type' 	 => 'iva_shortcode',
				);
				$testimonial_array = get_posts( $args );
				foreach ( $testimonial_array as $testimonial ) {
					$iva_ttm_shortcode[ $testimonial->post_title ] = $testimonial->post_name;
					$testimonial_ids[] = $testimonial->ID;
				}

				vc_map(
					array(
					   'name' 		 => esc_html__( 'Testimonial', 'iva_testimonial_pro' ),
					   'base' 		 => 'iva_tmp_addon',
					   'class' 		 => '',
					   'icon'		 => '',
					   'category' 	 => 'Aivah VC Addons',
					   'description' => esc_html__( 'Testimonial Shortcode', 'iva_testimonial_pro' ),
					   'params' 	 => array(
							array(
								'type' 			=> 'dropdown',
								'heading'  	 	=> esc_html__( 'Shortcodes', 'iva_testimonial_pro' ),
								'param_name' 	=> 'ttm_shortcode',
								'value' 	 	=> $iva_ttm_shortcode,
								'description' 	=> esc_html__( 'Select the Testimonials Shortcode which you wish to display.', 'iva_testimonial_pro' ),
							),
							array(
								'type' 		  => 'css_editor',
								'heading'     => esc_html__( 'css', 'iva_testimonial_pro' ),
								'param_name'  => 'css',
								'group' 	  => esc_html__( 'Design', 'iva_testimonial_pro' ),
							),
						),
					)
				);
			}
		}

		function iva_testimonial_shortcode( $args ) {
			// Attributes
			$args = shortcode_atts(
				array(
					'css'			=> '',
					'ttm_shortcode'	=> '',
				),
				$args
			);

			// Define Variables
			$css			= $args['css'];
			$ttm_shortcode	= $args['ttm_shortcode'];

			global $post;
			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );
			if ( $css_class != '' ) { echo '<div class="' . esc_attr( $css_class ) . '">'; }
			$ttm_multiple_addon = '[iva_testimonial_pro name=' . $ttm_shortcode . ' ]';
			echo do_shortcode( $ttm_multiple_addon );
			if ( $css_class != '' ) { echo '</div>'; }
		}
	}
}
if ( class_exists( 'IVA_tmp_addon' ) ) {
	$iva_tmp_addon = new IVA_tmp_addon;
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_IVA_tmp_addon extends WPBakeryShortCode {

	}
}
