<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
if ( ! function_exists( 'iva_multiple_testimonials' ) ) {
	function iva_multiple_testimonials( $args, $content = null ) {

		// Attributes
		$args = shortcode_atts(
			array(
				'id' => '',
				'name' => '',
				'style' => '',
				'cat' => '',
				'postid'  => '',
				'limit'   => '',
				'showposts'  => '',
				'speed'   => '5000',
				'itemslimit' => '1',
				'pagination' => 'false',
				'columns'   => '2',
				'orderby'  => 'ID',
				'order'   => 'DESC',
				'layout'  => '',
			),
			$args
		);

		// Define Variables
		$id			= (int) $args['id'];
		$name		= $args['name'];
		$style		= $args['style'];
		$cat		= $args['cat'];
		$postid		= (string) $args['postid'];
		$limit		= (int) $args['limit'];
		$showposts	= (int) $args['showposts'];
		$speed		= (int) $args['speed'];
		$itemslimit	= (int) $args['itemslimit'];
		$pagination	=  $args['pagination'];
		$columns	=  $args['columns'];
		$orderby	= $args['orderby'];
		$order		= $args['order'];
		$layout		= $args['layout'];

		global $post, $paged;

		$iva_ttm_rand = rand( 10, 100 );
		$out = $before = $after = $client_image_option = $client_gravatar_image = $ttm_sh_id = $iva_ttm_column = $iva_ttm_liststyle = '';

		// Shortcode Query
		$iva_sc_args = array(
		  'name' 		=> $name,
		  'post_type' 	=> 'iva_shortcode',
		  'post_status' => 'publish',
		  'showposts' 	=> 1,
		);

		if ( $name == '' ) {
			$iva_sh_args = array(
				'post_type' 	=> 'iva_shortcode',
				'post_status' => 'publish',
				'showposts' 	=> 1,
			);
		} else {
			$iva_sh_args = array(
				'name' 		=> $name,
				'post_type' 	=> 'iva_shortcode',
				'post_status' => 'publish',
				'showposts' 	=> 1,
			);
		}

		$iva_sh_post = get_posts( $iva_sh_args );
		if ( $iva_sh_post ) {
			$ttm_sh_id = $iva_sh_post[0]->ID;
		}

		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}

		$iva_limit 			= get_post_meta( $ttm_sh_id, 'iva_ttm_limit', true );
		$iva_ttm_limit 		= ! empty( $iva_limit ) ? ( $iva_limit ) : $limit;
		$iva_itemslimit 	= get_post_meta( $ttm_sh_id, 'iva_ttm_itemslimit', true );
		$iva_ttm_itemslimit = ! empty( $iva_itemslimit ) ? ( $iva_itemslimit ) : $itemslimit;
		$carousel_speed 	= get_post_meta( $ttm_sh_id, 'iva_ttm_speed', true );
		$iva_ttm_speed 		= ! empty( $carousel_speed ) ? ( $carousel_speed ) : $speed;
		$iva_pagination 	= get_post_meta( $ttm_sh_id, 'iva_ttm_pagination', true );
		$iva_ttm_pagination = ! empty( $iva_pagination ) ? ( $iva_pagination ) : $pagination;
		$iva_orderby 		= get_post_meta( $ttm_sh_id, 'iva_ttm_orderby', true );
		$iva_ttm_orderby 	= ! empty( $iva_orderby ) ? ( $iva_orderby ) : $orderby;
		$iva_order 			= get_post_meta( $ttm_sh_id, 'iva_ttm_order', true );
		$iva_ttm_order 		= ! empty( $iva_order ) ? ( $iva_order ) : $order;
		$iva_columns 		= get_post_meta( $ttm_sh_id, 'iva_ttm_columns', true );
		$iva_ttm_columns 	= ! empty( $iva_columns ) ? $iva_columns : $columns;

		

		// General Settings
		$iva_ttm_style 	= get_post_meta( $ttm_sh_id, 'iva_ttm_type', true );
		if ( '' == $layout ) {
			$iva_ttm_layouts = get_post_meta( $ttm_sh_id, 'iva_ttm_layouts', true );
		} else {
			$iva_ttm_layouts = $layout;
		}

		$iva_ttm_g_layouts 		= get_post_meta( $ttm_sh_id, 'iva_ttm_g_layouts', true );
		$iva_ttm_clientpic 		= get_post_meta( $ttm_sh_id, 'iva_ttm_clientpic', true );
		$iva_ttm_gravatar 		= get_post_meta( $ttm_sh_id, 'iva_ttm_gravatar', true );
		$iva_ttm_title 			= get_post_meta( $ttm_sh_id, 'iva_ttm_title', true );
		$iva_ttm_content 		= get_post_meta( $ttm_sh_id, 'iva_ttm_content', true );
		$iva_ttm_clientjob 		= get_post_meta( $ttm_sh_id, 'iva_ttm_clientjob', true );
		$iva_ttm_cmpnyname 		= get_post_meta( $ttm_sh_id, 'iva_ttm_cmpnyname', true );
		$iva_ttm_cmpnyurl 		= get_post_meta( $ttm_sh_id, 'iva_ttm_cmpnyurl', true );
		$iva_ttm_clientratings 	= get_post_meta( $ttm_sh_id, 'iva_ttm_clientratings', true );

		$iva_ttm_args = array(
			'post_type' => 'iva_testimonial',
			'paged'		=> $paged,
			'showposts' => $iva_ttm_limit,
			'tax_query' => array(
				'relation' => 'OR',
			),
			'orderby' => $iva_ttm_orderby,
			'order'   => $iva_ttm_order,
		);
		if ( '' != $cat ) {
			$testim_cat = explode( ',', $cat );
			$tax_cat = array(
				'taxonomy' => 'iva_testimonial_cat',
				'field'    => 'slug',
				'terms'    => $testim_cat,
			);
			array_push( $iva_ttm_args['tax_query'], $tax_cat );
		}
		if ( '' != $postid ) {
			$postid_array = array();
			$postid_array = explode( ',', $postid );
			$iva_ttm_args = array(
				'post_type'		 => 'iva_testimonial',
				'post__in'		 => $postid_array,
				'paged'			 => $paged,
				'showposts'		 => $iva_ttm_limit,
				'orderby' 		 => $iva_ttm_orderby,
				'order' 		 => $iva_ttm_order,
			);
		}
		// Query executes here
		query_posts( $iva_ttm_args );

		// Style 'carousel'
		if ( 'carousel' === $iva_ttm_style ) {
			$jcarousel_id = rand( 10,99 );
			$tc_pagination = '';
			if ( 'true' == $iva_ttm_pagination || 'on' == $iva_ttm_pagination ) {
				$tc_pagination = 'pagination :true,';
			} else {
				$tc_pagination = 'pagination :false,';
			}

			//Enqueue Owl Carousel
			wp_enqueue_style( 'iva-owl-style' );
			wp_enqueue_style( 'iva-owl-theme' );

			$out .= '<script>
			jQuery(document).ready(function($) {
				$("#owl-' . $jcarousel_id . '").owlCarousel({
					autoPlay: ' . $iva_ttm_speed . ', //Set AutoPlay to 3 seconds
					' . $tc_pagination . '
					items : ' . $iva_ttm_itemslimit . ',
					itemsDesktop : [1199,2],
					itemsDesktopSmall : [1024,2],
					itemsTablet : [768,1],
					itemsMobile : [479,1]		 
				});
			});
			</script>';
			$out .= '<div id="owl-' . $jcarousel_id . '" class="owl-carousel">';
		}

		// Style 'fade'
		if ( 'fade' === $iva_ttm_style ) {
			$out .= '<script type="text/javascript">
			jQuery(document).ready(function() {
				ttm_fadeSlider(' . $iva_ttm_speed . ',"testimonial' . $iva_ttm_rand . '");
			});
			</script>';
			$out .= '<div id="testimonial' . $iva_ttm_rand . '" class="testimonial_list" data-speed="' . $iva_ttm_speed . '"><ul class="testimonials">';
		}

			add_action( 'wp_footer', 'iva_ttm_fade_script' );

		if ( have_posts() ) :

			$count = $column_index = $iva_grid_columns = '';

			if ( 'list' === $iva_ttm_style ) {
				$out .= '<div class="testimonials-list">';
			}

			if ( 'grid' === $iva_ttm_style ) {
				if ( '2' == $columns ) {
					$iva_grid_columns = 'ttmp-col-2';
				} elseif ( '3' == $columns ) {
					$iva_grid_columns = 'ttmp-col-3';
				}
				$column_index = 0;
				$out .= '<div class="testimonial-grid">';
			}

			while ( have_posts() ) : the_post();

				$column_index++;
				$tm_last_class = $before = $after = '';
				$tm_last_class = ( $column_index == $columns && $columns != 1 ) ? 'ttmp-col-end ' : '';

				$client_image_option  = get_post_meta( $post->ID, 'client_image_option', true );
				$client_job			  = get_post_meta( $post->ID, 'client_job', true );
				$company_name		  = get_post_meta( $post->ID, 'company_name', true );
				$company_url		  = get_post_meta( $post->ID, 'company_url', true );
				$client_ratings		  = get_post_meta( $post->ID, 'client_ratings', true );
				$special_title		  = get_post_meta( $post->ID, 'special_title', true );
				$testimonial_content  = get_the_content( $post->ID );
				$client_title 		  = get_the_title( $post->ID );

				$iva_ttm_upload_image = get_option( 'iva_ttm_upload_image' ) ? get_option( 'iva_ttm_upload_image' ) : '';
				$testimonial_email 	  = get_post_meta( $post->ID, 'gravatar_email', true );

				if ( has_post_thumbnail( $id ) ) {
					$client_gravatar_image = iva_ttm_resize( $id, '', '', '', 'imageborder', '' );
				} elseif ( ! empty( $testimonial_email ) ) {
					$client_gravatar_image = get_avatar( $testimonial_email, 70 );
				} else {
					if ( ! empty( $iva_ttm_upload_image ) ) {
						$client_gravatar_image = '<img src="' . $iva_ttm_upload_image . '" alt="img" class="imageborder"/>';
					} else {
						$client_gravatar_image = '<img src="' . IVA_TTM_CPT_URI . 'assets/images/image-1.png" alt="img"/>';
					}
				}

				if ( 'grid' === $iva_ttm_style ) {
					$out .= '<div class="' . $iva_grid_columns . ' ' . $tm_last_class . '">';
				}
				if ( 'fade' === $iva_ttm_style ) {
					$out .= '<li>';
				}
				
				$iva_ttm_company_color = $iva_ttm_spltitle_color = $iva_ttm_blockquote_color= '';
				if ( get_post_meta( $ttm_sh_id, 'iva_ttm_company_color', true ) ) {
					$iva_ttm_company_color 	= get_post_meta( $ttm_sh_id, 'iva_ttm_company_color', true );
				} elseif ( get_option( 'iva_ttm_company_color' ) ) {
					$iva_ttm_company_color 	= get_option( 'iva_ttm_company_color' ) ? get_option( 'iva_ttm_company_color' ) : '';
				}
				$iva_ttm_company_color = $iva_ttm_company_color ? 'color: ' . $iva_ttm_company_color . ';' : '';
				$ttm_company_color 	   = ( $iva_ttm_company_color ) ? ' style="' . $iva_ttm_company_color . '"' : '' ;

				if ( get_post_meta( $ttm_sh_id, 'iva_ttm_spltitle_color', true ) ) {
					$iva_ttm_spltitle_color 	= get_post_meta( $ttm_sh_id, 'iva_ttm_spltitle_color', true );
				} elseif ( get_option( 'iva_ttm_spltitle_color' ) ) {
					$iva_ttm_spltitle_color 	= get_option( 'iva_ttm_spltitle_color' ) ? get_option( 'iva_ttm_spltitle_color' ) : '';
				}
				$iva_ttm_spltitle_color = $iva_ttm_spltitle_color ? 'color: ' . $iva_ttm_spltitle_color . ';' : '';
				$ttm_spltitle_color 	= ( $iva_ttm_spltitle_color ) ? ' style="' . $iva_ttm_spltitle_color . '"' : '' ;

				if ( get_post_meta( $ttm_sh_id, 'iva_ttm_blockquote_color', true ) ) {
					$iva_ttm_blockquote_color 	= get_post_meta( $ttm_sh_id, 'iva_ttm_blockquote_color', true );
				} elseif ( get_option( 'iva_ttm_blockquote_color' ) ) {
					$iva_ttm_blockquote_color 	= get_option( 'iva_ttm_blockquote_color' ) ? get_option( 'iva_ttm_blockquote_color' ) : '';
				}
				$iva_ttm_blockquote_color = $iva_ttm_blockquote_color ? 'color: ' . $iva_ttm_blockquote_color . ';' : '';
				$ttm_blockquote_color_css = ( $iva_ttm_blockquote_color ) ? ' style="' . $iva_ttm_blockquote_color . '"' : '' ;

				// Style 'list'
				if ( 'list' === $iva_ttm_style || 'carousel' === $iva_ttm_style || 'fade' === $iva_ttm_style ) {
					$out .= '<div class="at-adv-ttm-' . $iva_ttm_layouts . '">';
					if ( 'v1-a' === $iva_ttm_layouts || 'v1-b' === $iva_ttm_layouts || 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
						if ( 'v1-b' === $iva_ttm_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
						if ( 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
							$out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left fa-fw"></i>';
						}
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						if ( 'v1-c' === $iva_ttm_layouts ) {
						   	$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v2-a' === $iva_ttm_layouts ) {
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						$out .= '<div class="author">';
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id );
						$out .= ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
						$out .= '</div>';
					}
					if ( 'v2-b' === $iva_ttm_layouts ) {
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						$out .= '<div class="author with-image">';
						$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					    $out .= '</div>';
					}
					if ( 'v3-a' === $iva_ttm_layouts || 'v3-b' === $iva_ttm_layouts ) {
					    $out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left v3-a"></i>';
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-right v3-a"></i>';
					    if ( 'v3-b' === $iva_ttm_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v4-a' === $iva_ttm_layouts || 'v4-b' === $iva_ttm_layouts ) {
					    $out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left v3-a"></i>';
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-right v3-a"></i>';
					    if ( 'v4-b' === $iva_ttm_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v5-a' === $iva_ttm_layouts || 'v5-b' === $iva_ttm_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    if ( 'v5-b' === $iva_ttm_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v6-a' === $iva_ttm_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v6-b' === $iva_ttm_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v7' === $iva_ttm_layouts ) {
						$out .= '<div class="at-adv-ttm-content">';
						if ( '' != $special_title ) {
							$out .= '<h3 ' . $ttm_spltitle_color . '><i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left v7"></i>';
							$out .= $special_title;
							$out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-right v7"></i></h3>';
						}
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id );
					    $out .= ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					    $out .= '</div>';
					    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
					}
					if ( 'v8-a' === $iva_ttm_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v8-b' === $iva_ttm_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					$out .= '</div>';
					if ( 'fade' === $iva_ttm_style ) {
						$out .= '</li>';
					}
				}

				// Style 'grid'
				if ( 'grid' === $iva_ttm_style ) {
					$out .= '<div class="at-adv-ttm-' . $iva_ttm_g_layouts . '">';
					if ( 'v1-a' === $iva_ttm_g_layouts || 'v1-b' === $iva_ttm_g_layouts || 'v1-c' === $iva_ttm_g_layouts || 'v1-d' === $iva_ttm_g_layouts ) {
						if ( 'v1-b' === $iva_ttm_g_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
						if ( 'v1-c' === $iva_ttm_g_layouts || 'v1-d' === $iva_ttm_g_layouts ) {
							$out .= '<i class="fa fa-quote-left fa-fw"></i>';
						}
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						if ( 'v1-c' === $iva_ttm_g_layouts ) {
						   	$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v2-a' === $iva_ttm_g_layouts ) {
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						$out .= '<div class="author">';
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id );
						$out .= ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
						$out .= '</div>';
					}
					if ( 'v2-b' === $iva_ttm_g_layouts ) {
						$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
						$out .= '<div class="author with-image">';
						$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						$out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
						$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					    $out .= '</div>';
					}
					if ( 'v3-a' === $iva_ttm_g_layouts || 'v3-b' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    if ( 'v3-b' === $iva_ttm_g_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v4-a' === $iva_ttm_g_layouts || 'v4-b' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    if ( 'v4-b' === $iva_ttm_g_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v5-a' === $iva_ttm_g_layouts || 'v5-b' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    if ( 'v5-b' === $iva_ttm_g_layouts ) {
							$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
						}
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v6-a' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v6-b' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v8-a' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					if ( 'v8-b' === $iva_ttm_g_layouts ) {
					    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
					    $out .= ttm_client_title( $iva_ttm_title, $client_title, $ttm_sh_id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $ttm_sh_id );
					    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
						$after .= '</a>';
					    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $ttm_sh_id );
					    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
					}
					$out .= '</div>';
					if ( 'grid' === $iva_ttm_style ) {
						$out .= '</div>';
					}
					if ( $column_index == $columns ) {
						$column_index = 0;
					}
				}// End if().
				endwhile;
			// Style 'list'
			if ( 'list' === $iva_ttm_style ) {
				$out .= '</div>';
				if ( 'true' == $iva_ttm_pagination || 'on' == $iva_ttm_pagination ) {
					if ( function_exists( 'iva_ttm_pagination' ) ) {
						ob_start();
						$out .= iva_ttm_pagination();
						$out .= ob_get_contents();
						ob_end_clean();
					}
				}
			}
			// Style 'Grid'
			if ( 'grid' === $iva_ttm_style ) {
				$out .= '</div>';
			}
		endif;
		// Style 'fade'
		if ( 'fade' === $iva_ttm_style ) {
			$out .= '</ul></div>';
		}
		// Style 'carousel'
		if ( 'carousel' === $iva_ttm_style ) {
			$out .= '</div>';
			wp_enqueue_script( 'iva-owl-carousel' );
		}
		wp_reset_query();

		return $out;
	}
	//End Testimonials List Function
	add_shortcode( 'iva_testimonial_pro', 'iva_multiple_testimonials' );
}// End if().

function iva_ttm_fade_script() {
	wp_print_scripts( 'iva-ttm-frontend-script' );
}
