<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
global $post;

//
$args = array(
	'post_type' => 'iva_testimonial',
	'posts_per_page'=> -1,
);
$iva_ttm_post_ids = array();
$iva_ttm_post_query = get_posts( $args );
foreach ( $iva_ttm_post_query as $key => $entry ) {
	$iva_ttm_post_ids[ $entry->ID ] = $entry->post_title;
}


$this->meta_box[] = array(
	'id'		=> 'Shortcode-meta-box',
	'title'		=> esc_html__( 'Shortcode Information', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_shortcode' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(
		// Testimonial Types
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Testimonial Types', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose the Type of the Testimonial you wish to use.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_type',
			'std'		=> 'fade',
			'type'		=> 'layout',
			'options'	=> array(
				'carousel'	=> IVA_TTM_CPT_URI . 'assets/images/carousel-layout.png',
				'grid'		=> IVA_TTM_CPT_URI . 'assets/images/grid-layout.png',
				'list'		=> IVA_TTM_CPT_URI . 'assets/images/list-layout.png',
				'fade'		=> IVA_TTM_CPT_URI . 'assets/images/fade-layout.png',
			),
		),
		// Layouts
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Layouts', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose the Layout you wish to use for the Testimonials to display.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_layouts',
			'std'		=> '',
			'type'		=> 'layout_select',
			'class'		=> 'showtestimonial carousel fade list',
			'options'	=> array(
				'default-ttm'	=> 'Choose one..',
				'v1-a'  => 'Layout 1-a',
				'v1-b'  => 'Layout 1-b',
				'v1-c'  => 'Layout 1-c',
				'v1-d'  => 'Layout 1-d',
				'v2-a'  => 'Layout 2-a',
				'v2-b'  => 'Layout 2-b',
				'v3-a'  => 'Layout 3-a',
				'v3-b'  => 'Layout 3-b',
				'v4-a'  => 'Layout 4-a',
				'v4-b'  => 'Layout 4-b',
				'v5-a'  => 'Layout 5-a',
				'v5-b'  => 'Layout 5-b',
				'v6-a'  => 'Layout 6-a',
				'v6-b'  => 'Layout 6-b',
				'v7'  	=> 'Layout 7',
				'v8-a'  => 'Layout 8-a',
				'v8-b'  => 'Layout 8-b',
			),
		),
		array(
			'name'		=> esc_html__( 'Layouts', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose the Layout you wish to use for the Testimonials to display.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_g_layouts',
			'std'		=> '',
			'type'		=> 'layout_select',
			'class'		=> 'showtestimonial grid',
			'options'	=> array(
				'default-ttm'		=> 'Choose one..',
				'v1-a'  => 'Layout 1-a',
				'v1-b'  => 'Layout 1-b',
				'v1-c'  => 'Layout 1-c',
				'v1-d'  => 'Layout 1-d',
				'v2-a'  => 'Layout 2-a',
				'v2-b'  => 'Layout 2-b',
				'v3-a'  => 'Layout 3-a',
				'v3-b'  => 'Layout 3-b',
				'v4-a'  => 'Layout 4-a',
				'v4-b'  => 'Layout 4-b',
				'v5-a'  => 'Layout 5-a',
				'v5-b'  => 'Layout 5-b',
				'v6-a'  => 'Layout 6-a',
				'v6-b'  => 'Layout 6-b',
				'v8-a'  => 'Layout 8-a',
				'v8-b'  => 'Layout 8-b',
			),
		),
		// Testimonial Columns
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Testimonial Columns', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose the no. of columns you wish to display for Testimonials.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_columns',
			'std'		=> '2columns',
			'class'		=> 'showtestimonial grid',
			'type'		=> 'select',
			'inputsize'	=> '',
			'options'	=> array(
							'2' 	=> '2 Columns',
							'3'		=> '3 Columns',
						),
		),
		// Carousel Limit
		// -----------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Display Items', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Number of Testimonials Items to display for Carousel.', 'iva_testimonial_pro' ),
			'std'	=> '',
			'class'	=> 'showtestimonial carousel',
			'id'	=> 'iva_ttm_itemslimit',
			'type'	=> 'text',
		),
		// Speed
		// -----------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Speed', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Speed of the Testimonials. ( Default Speed: 5000, for eg: 1000ms = 1sec )', 'iva_testimonial_pro' ),
			'std'	=> '',
			'id'	=> 'iva_ttm_speed',
			'class'	=> 'showtestimonial carousel fade',
			'type'	=> 'text',
		),
		// Choose Dropdown
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Select ID/Categories','iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose any Category from dropdown in which the selected categories will hold the posts to display.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_choose',
			'type'		=> 'select',
			'std'		=> '',
			'options'	=> array(
								'postid'	 => 'Post ID',
								'categories' => 'Categories',
							),
		),
		// Select Categories
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Categories', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Hold Ctrl Key for selecting multiple categories. For Mac hold Command Key.categories', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_categories',
			'std'		=> '',
			'class'		=> 'ttm_options categories',
			'type'		=> 'getterms',
			'options'	=> 'iva_testimonial_cat',
		),
		// Select Testimonial Id\'s
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Testimonial(s)', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Hold Ctrl Key for selecting multiple testimonials. For Mac hold Command Key.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_posts',
			'std'		=> '',
			'class'		=> 'ttm_options postid',
			'type'		=> 'multiselect',
			'options'	=> $iva_ttm_post_ids,
		),
	),
);
$this->meta_box[] = array(
	'id'		=> 'Shortcode-meta-boxx',
	'title'		=> esc_html__( 'Shortcode Generator', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_shortcode' ),
	'context'	=> 'side',
	'priority'	=> 'low',
	'fields'	=> array(
		// Shortcode Generator
		// -----------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Shortcode', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'To display multiple testimonials, add this shortcode to any post or page.', 'iva_testimonial_pro' ),
			'id'	=> 'shortcode_gen',
			'std'	=> '',
			'class'	=> 'ttm-edit-shortcode',
			'type'	=> 'shortcode_gen',
		),
	),
);
$this->meta_box[] = array(
	'id'		=> 'settings-meta-box',
	'title'		=> esc_html__( 'Display Settings', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_shortcode' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(
		// Client Picture
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Client Picture', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_clientpic',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Title
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Title', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_title',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Content
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Content / Feedback','iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_content',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Client Role
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Role:', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_clientjob',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Company Name
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Company Name', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_cmpnyname',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Company Website
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Company Website', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_cmpnyurl',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
		// Ratings
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Ratings', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_clientratings',
			'std'		=> 'on',
			'type'		=> 'radio',
			'options' 	=> array(
								'on' 	=> 'ON',
								'off' 	=> 'OFF',
							),
		),
	),
);

// Styling
$this->meta_box[] = array(
	'id'		=> 'styling-meta-box',
	'title'		=> esc_html__( 'Styling Options', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_shortcode' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(
		// Font Size
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Font Size', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Enter the Font Size in pixels. (Eg: 20px)', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_fontsize',
			'std'		=> '',
			'type'		=> 'text',
		),
		// Content Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Content Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Testimonial Text.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_content_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Title Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Title Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Testimonial Title.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_title_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Role Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Role Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Client\'s Role.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_job_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Client Company Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Client Company Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Client\'s Company.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_company_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// BG Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'BG Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose BG Color for the Testimonial Layouts 6-a,6-b,8-a and 8-b.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_bg_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Blockquote Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Blockquote Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Blockquote Color for the Testimonial Layouts 1-c and 1-d.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_blockquote_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Ratings Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Ratings Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Ratings Color for the Testimonials.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_ratings_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Special Title Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Special Title Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Special Title Color for the Testimonial Layouts 7.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_spltitle_color',
			'std'		=> '',
			'type'		=> 'color',
		),
	),
);

// Testimonial Settings
$this->meta_box[] = array(
	'id'		=> 'settings-meta-boxx',
	'title'		=> esc_html__( 'Testimonial Settings', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_shortcode' ),
	'context'	=> 'side',
	'priority'	=> 'low',
	'fields'	=> array(
		// Limit
		// -----------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Limit', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter the limit you wish to display if multiple testimonials/category is selected.', 'iva_testimonial_pro' ),
			'std'	=> '',
			'id'	=> 'iva_ttm_limit',
			'type'	=> 'text',
		),
		// Pagination
		// -----------------------------------------------------------
		array(
			'name'	=> esc_html__( 'Pagination', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Check this if you wish to enable the Pagination.', 'iva_testimonial_pro' ),
			'std'	=> 'off',
			'id'	=> 'iva_ttm_pagination',
			'type'	=> 'checkbox',
		),
		// OrderBy
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'OrderBy', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Select the Orderby ID, Title, Date or Menu Order (Default: Date)', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_orderby',
			'std'		=> 'menu_order',
			'type'		=> 'select',
			'inputsize'	=> '',
			'options'	=> array(
								'' 			 => 'Choose Options',
								'ID' 		 => 'ID',
								'title'		 => 'Title',
								'date' 		 => 'Date',
								'menu_order' => 'Menu Order',
							),
		),
		// Order
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Order', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Select the display order of Testimonials. (Default: Descending)', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_order',
			'std'		=> 'DESC',
			'type'		=> 'select',
			'inputsize'	=> '',
			'options'	=> array(
								'ASC' 	=> 'Ascending',
								'DESC'	=> 'Descending',
							),
		),
	),
);
