<?php
/**
 * Plugin Name: Advanced Testimonial Manager Pro
 * Plugin URI: http://www.aivahthemes.com
 * Description: Displays Testimonials with different styles using shortcode, widget, and vc addon.
 * Version: 1.0
 * Author: Aivahthemes
 * Author URI: http://www.aivahthemes.com
 */
if ( ! class_exists( 'Iva_Testimonial_Plugin' ) ) {

	class Iva_Testimonial_Plugin {
		public function __construct() {

			define( 'IVA_TTM_CPT_URI', plugin_dir_url( __FILE__ ) );
			define( 'IVA_TTM_CPT_DIR', plugin_dir_path( __FILE__ ) );

			$this->iva_post_type();
			$this->iva_custom_meta();
			$this->iva_require_files();
			$this->iva_themesupport();
		}

		/**
		 * Load custom post types register files
		 */
		function iva_post_type() {
		    require_once( IVA_TTM_CPT_DIR . '/post-type/iva-testimonial.php' );
		    require_once( IVA_TTM_CPT_DIR . '/post-type/iva-shortcode.php' );
		}

		/**
		 * Load custom post types helper class
		 */
		function iva_custom_meta() {
		    require_once( IVA_TTM_CPT_DIR . '/iva-ttm-metabox.php' );
		    require_once( IVA_TTM_CPT_DIR . '/iva-ttm-sc-meta.php' );
		    require_once( IVA_TTM_CPT_DIR . '/iva-ttm-meta-helper.php' );
		}

		/***
		 * Add Theme Supports
		 */
		function iva_themesupport() {
			// Add Theme Support for post thumbnails
			add_theme_support( 'post-thumbnails', array( 'iva_testimonial' ) );

			if ( ! isset( $content_width ) ) {
				$content_width = 900;
			}
		}

		/**
		 * Load required files for  testimonial functions,
		 *  Widgets,
		 *  Shortcodes,
		 *  VC Addon
		 */
		function iva_require_files() {
			require_once( 'iva-ttm-functions.php' );
			require_once( 'iva-ttm-sc-multiple.php' );
			require_once( 'iva-ttm-sc-single.php' );
			require_once( 'iva-ttm-form.php' );
			require_once( 'iva-ttm-widget.php' );
			require_once( 'iva-ttm-wg-testimonial.php' );
			require_once( 'iva-ttm-wg-single.php' );
			require_once( 'iva-ttm-vc-addon.php' );
			require_once( 'iva-ttm-vc-addon-single.php' );
			require_once( 'iva-ttm-update-file.php' ); // manual update file
		}
	}
}// End if().

$iva_testimonial_plugin = new Iva_Testimonial_Plugin();

add_action('plugins_loaded', 'iva_testimonials_plugin_load_textdomain' );
function iva_testimonials_plugin_load_textdomain() {
	load_plugin_textdomain( 'iva_testimonial_pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

$iva_ttm_db_version  = '1.0.0'; // Initial Plugin Version

register_activation_hook( __FILE__, 'iva_ttm_install' );

// Action function for above hook
function iva_ttm_install() {

	global $wpdb,$iva_ttm_db_version;
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	$installed_version 	  = get_option( 'iva_ttm_version' ) ? get_option( 'iva_ttm_version' ) : $iva_ttm_db_version;
	$iva_ttm_plugin_data  = iva_ttm_plugin_data();
	$update_version 	  = $iva_ttm_plugin_data['Version'];
}

/**
 * Function iva_ttm_plugin_data()
 * Fetching plugin data
 */
function iva_ttm_plugin_data() {
	global $wpdb;
	$iva_ttm_plugin_data = get_plugin_data( __FILE__ );
	return $iva_ttm_plugin_data;
}

if ( ! function_exists( 'iva_ttm_get_attachment_id_from_src' ) ) {
	function iva_ttm_get_attachment_id_from_src( $image_src ) {
		global $wpdb;
		$id = $wpdb->get_var( "SELECT ID FROM {$wpdb->posts} WHERE guid='$image_src'" );
		return $id;
	}
}


/**
 * Theme Frontend Scripts and Styles
 */
if ( ! function_exists( 'iva_ttm_frontend_scripts' ) ) {
	function iva_ttm_frontend_scripts() {
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'jquery-ui-core' );
		$iva_ttm_ratings_color 	= get_option( 'iva_ttm_ratings_color' ) ? get_option( 'iva_ttm_ratings_color' ) : '';
		//AJAX URL
		$data['ajaxurl'] = esc_url( admin_url( 'admin-ajax.php' ) );
		$data['ratings_color'] 	= $iva_ttm_ratings_color;

		//Pass data to javascript
		$params = array(
			'l10n_print_after' 	=> 'iva_ttm_panel = ' . json_encode( $data ) . ';',
		);

		wp_localize_script( 'jquery', 'iva_ttm_panel', $params );

		wp_enqueue_script( 'iva-ttm-frontend-script', IVA_TTM_CPT_URI . 'assets/js/frontend-script.js',  array( 'jquery' ), '', true );
		wp_enqueue_script( 'iva-ttm-form', IVA_TTM_CPT_URI . 'assets/js/form.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'iva-ttm-owl-carousel', IVA_TTM_CPT_URI . 'assets/js/owl.carousel.js', 'jquery', '', '' );
		wp_enqueue_style( 'iva-ttm-atmpro_icon' , IVA_TTM_CPT_URI . 'assets/fontello/css/atmpro_icon.css', false,false,'all' );
		wp_enqueue_style( 'iva-ttm-owl-style', IVA_TTM_CPT_URI . 'assets/css/owl.carousel.css', array(), '1', 'all' );
		wp_enqueue_style( 'iva-ttm-owl-theme', IVA_TTM_CPT_URI . 'assets/css/owl.theme.css', array(), '1', 'all' );
		wp_enqueue_style( 'iva-ttm-frontend' , IVA_TTM_CPT_URI . 'assets/css/iva-ttm-frontend.css', array(),false,'all' );
		wp_enqueue_style( 'iva-ttm-fontawesome' , IVA_TTM_CPT_URI . 'assets/fontawesome/css/font-awesome.css', array(),false,'all' );
	}
	add_action( 'wp_enqueue_scripts', 'iva_ttm_frontend_scripts' );
}

/**
 * Function iva_ttm_admin_enqueue_scripts
 *
 */
if ( ! function_exists( 'iva_ttm_admin_enqueue_scripts' ) ) {
	function iva_ttm_admin_enqueue_scripts() {

		// Scripts
		wp_enqueue_media();
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script( 'iva-ttm-script', IVA_TTM_CPT_URI . 'assets/js/backend-script.js', 'jquery','','in_footer' );

		// Styles
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'iva-ttm-admin', IVA_TTM_CPT_URI . 'assets/css/iva-ttm-admin.css', false,false,'all' );
		wp_enqueue_script( 'iva-ttm-pro', IVA_TTM_CPT_URI . 'assets/js/iva-testimonials-pro.js', array( 'jquery' ), '', true );
		wp_enqueue_style( 'iva-ttm-atmpro_icon' , IVA_TTM_CPT_URI . 'assets/fontello/css/atmpro_icon.css', false,false,'all' );
		// Modal
		wp_enqueue_style( 'iva-modal-component' , IVA_TTM_CPT_URI . 'assets/css/component.css', false,false,'all' );
		wp_enqueue_script( 'iva-classie', IVA_TTM_CPT_URI . 'assets/js/classie.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'iva-modalEffects',IVA_TTM_CPT_URI . 'assets/js/modalEffects.js', array( 'jquery' ), '', true );
		// Upload
		wp_enqueue_script( 'media-upload' );
		wp_enqueue_script( 'iva-ttm-upload',IVA_TTM_CPT_URI . 'assets/js/iva_ttm_upload.js', array( 'jquery' ), '', true );
	}
	add_action( 'admin_enqueue_scripts', 'iva_ttm_admin_enqueue_scripts' );
}

// Testimonial Settings
add_action( 'admin_menu' , 'iva_ttm_settings' );
function iva_ttm_settings() {
	add_submenu_page( 'edit.php?post_type=iva_testimonial', 'My Custom Submenu Page', 'Settings', 'manage_options', 'iva_testimonial_settings', 'iva_testimonial_settings' );
}

/**
 * Function iva_testimonial_settings()
 * Fetching plugin data
 */
function iva_testimonial_settings() {
	global $wpdb;

	$iva_styles = array(
		'carousel'	=> IVA_TTM_CPT_URI . 'assets/images/carousel-layout.png',
		'grid'		=> IVA_TTM_CPT_URI . 'assets/images/grid-layout.png',
		'list'		=> IVA_TTM_CPT_URI . 'assets/images/list-layout.png',
		'fade'		=> IVA_TTM_CPT_URI . 'assets/images/fade-layout.png',
		'masonry'	=> IVA_TTM_CPT_URI . 'assets/images/grid-layout.png',
	);

	$iva_input_fontsize = array(
		'9px' => '9px',
		'10px'=> '10px',
		'11px'=> '11px',
		'12px'=> '12px',
		'13px'=> '13px',
		'14px'=> '14px',
		'15px'=> '15px',
		'16px'=> '16px',
		'17px'=> '17px',
		'18px'=> '18px',
		'19px'=> '19px',
		'20px'=> '20px',
		'21px'=> '21px',
		'22px'=> '22px',
		'23px'=> '23px',
		'24px'=> '24px',
		'25px'=> '25px',
		'26px'=> '26px',
		'27px'=> '27px',
		'28px'=> '28px',
		'29px'=> '29px',
		'30px'=> '23px',
		'31px'=> '31px',
		'32px'=> '32px',
		'33px'=> '33px',
		'34px'=> '34px',
		'35px'=> '35px',
		'36px'=> '36px',
	);

	$iva_input_fontweight = array(
		'bold'	=> 'bold',
		'normal'=> 'normal',
	);

	$iva_input_fontfamily = array(
		'Georgia, serif'	=> 'Georgia',
		"Palatino Linotype, Book Antiqua, Palatino, serif"	=> 'Palatino Linotype',
		"Times New Roman, Times, serif"	=> 'Times New Roman',
		"Arial, Helvetica, sans-serif"	=> 'Arial',
		"Arial Black, Gadget, sans-serif"	=> 'Arial Black',
		"Comic Sans MS, cursive, sans-serif"	=> 'Comic Sans MS',
		"Impact, Charcoal, sans-serif"	=> 'Impact',
		"Lucida Sans Unicode, Lucida Grande, sans-serif"	=> 'Lucida Sans Unicode',
		"Tahoma, Geneva, sans-serif"	=> 'Tahoma',
		"Trebuchet MS, Helvetica, sans-serif"	=> 'Trebuchet MS',
		"Verdana, Geneva, sans-serif"	=> 'Verdana',
		"Courier New, Courier, monospace"	   => 'Courier New',
		"Lucida Console, Monaco, monospace"	=> 'Lucida Console',
	);

	$iva_input_borderradius = array(
		'border-none' => 'border-none',
		'5px'		  => '5px',
		'10px'		  => '10px',
		'50px'		  => '50px',
	);

	$iva_input_notificationemail = array(
		'enable'	=> 'Enable',
		'disable'	=> 'Disable',
	);

	$iva_input_emailto = array(
		'admin'	=> 'admin',
	);

	$iva_ttm_extracss 	= get_option( 'iva_ttm_extracss' ) ? stripslashes( get_option( 'iva_ttm_extracss' ) ) : '';

	$iva_ttm_plugin_data  = iva_ttm_plugin_data();

	echo '<div class="ttm-mainwrap">';
	echo '<div class="testimonial-title main-heading">';
	echo '<div class="testimonial-desc">
			<div class="ttm_icon green testimonial-logo"><span class="ivaIcon"></span></div>
				<h1>' . esc_attr( $iva_ttm_plugin_data['Name'] ) . ' - <span class="iva_ttm_ver">' . esc_attr( $iva_ttm_plugin_data['Version'] ) . '</h1>
				<div class="about-text">' . esc_html__( 'A premium multi-use WordPress Plugin used to showcase Testimonials on any of your Website.', 'iva_testimonial_pro' ) . '</div>';
	echo '</div>';  // testimonial-desc
	echo '<div class="testimonial-manual-update">';
	echo '<a id="iva_ttm_update_plugin" class="button blue-button alignright button-hero md-trigger" data-modal="iva_ttm_update_plugin_dialog">' . esc_html__( 'Manual Update Plugin', 'iva_testimonial_pro' ) . '</a>';
	echo '</div>';
	echo '</div>';// testimonial-title main-heading

	echo '<div id="settings_success_msg"></div>';
	echo '<div class="general-input clearfix">';

	echo '<form method="post" id="iva_ttm_settings_form" class="iva_ttm_settings_form" name="iva_ttm_settings_form" action="#">';
	$iva_ttm_setting_nonce = wp_create_nonce( 'iva-ttm-settings' );
	echo '<input type="hidden" name="iva-ttm-settings" id="iva-ttm-settings" value="', esc_attr( $iva_ttm_setting_nonce ), '" />';

	// Add Settings Row
	$iva_ttm_opt_client_name 	= get_option( 'iva_ttm_opt_client_name' ) ? get_option( 'iva_ttm_opt_client_name' ) : '';
	$iva_ttm_opt_client_pic 	= get_option( 'iva_ttm_opt_client_pic' ) ? get_option( 'iva_ttm_opt_client_pic' ) : '';
	$iva_ttm_opt_client_job 	= get_option( 'iva_ttm_opt_client_job' ) ? get_option( 'iva_ttm_opt_client_job' ) : '';
	$iva_ttm_opt_grav_email 	= get_option( 'iva_ttm_opt_grav_email' ) ? get_option( 'iva_ttm_opt_grav_email' ) : '';
	$iva_ttm_opt_client_email	= get_option( 'iva_ttm_opt_client_email' ) ? get_option( 'iva_ttm_opt_client_email' ) : '';
	$iva_ttm_opt_cmpny_name 	= get_option( 'iva_ttm_opt_cmpny_name' ) ? get_option( 'iva_ttm_opt_cmpny_name' ) : '';
	$iva_ttm_opt_cmpny_url 		= get_option( 'iva_ttm_opt_cmpny_url' ) ? get_option( 'iva_ttm_opt_cmpny_url' ) : '';
	$iva_ttm_opt_ratings 		= get_option( 'iva_ttm_opt_ratings' ) ? get_option( 'iva_ttm_opt_ratings' ) : '';
	$iva_ttm_opt_client_desc	= get_option( 'iva_ttm_opt_client_desc' ) ? get_option( 'iva_ttm_opt_client_desc' ) : '';
	$iva_ttm_opt_captcha		= get_option( 'iva_ttm_opt_captcha' ) ? get_option( 'iva_ttm_opt_captcha' ) : '';

	//
	$iva_ttm_req_client_name 	= get_option( 'iva_ttm_req_client_name' ) ? get_option( 'iva_ttm_req_client_name' ) : 'on';
	$iva_ttm_req_client_pic 	= get_option( 'iva_ttm_req_client_pic' ) ? get_option( 'iva_ttm_req_client_pic' ) : '';
	$iva_ttm_req_gravatar 		= get_option( 'iva_ttm_req_gravatar' ) ? get_option( 'iva_ttm_req_gravatar' ) : '';
	$iva_ttm_req_upload_pic 	= get_option( 'iva_ttm_req_upload_pic' ) ? get_option( 'iva_ttm_req_upload_pic' ) : '';
	$iva_ttm_req_client_job 	= get_option( 'iva_ttm_req_client_job' ) ? get_option( 'iva_ttm_req_client_job' ) : '';
	$iva_ttm_req_cmpny_name 	= get_option( 'iva_ttm_req_cmpny_name' ) ? get_option( 'iva_ttm_req_cmpny_name' ) : 'on';
	$iva_ttm_req_cmpny_url 		= get_option( 'iva_ttm_req_cmpny_url' ) ? get_option( 'iva_ttm_req_cmpny_url' ) : 'on';
	$iva_ttm_req_ratings 		= get_option( 'iva_ttm_req_ratings' ) ? get_option( 'iva_ttm_req_ratings' ) : '';
	$iva_ttm_req_client_desc 	= get_option( 'iva_ttm_req_client_desc' ) ? get_option( 'iva_ttm_req_client_desc' ) : 'on';

	// Labels Text
	$iva_ttm_client_name_txt 	= get_option( 'iva_ttm_client_name_txt' ) ? get_option( 'iva_ttm_client_name_txt' ) : '';
	$iva_ttm_client_pic_txt 	= get_option( 'iva_ttm_client_pic_txt' ) ? get_option( 'iva_ttm_client_pic_txt' ) : '';
	$iva_ttm_grav_email_txt 	= get_option( 'iva_ttm_grav_email_txt' ) ? get_option( 'iva_ttm_grav_email_txt' ) : '';
	$iva_ttm_client_job_txt 	= get_option( 'iva_ttm_client_job_txt' ) ? get_option( 'iva_ttm_client_job_txt' ) : '';
	$iva_ttm_cmpny_name_txt 	= get_option( 'iva_ttm_cmpny_name_txt' ) ? get_option( 'iva_ttm_cmpny_name_txt' ) : '';
	$iva_ttm_cmpny_url_txt 		= get_option( 'iva_ttm_cmpny_url_txt' ) ? get_option( 'iva_ttm_cmpny_url_txt' ) : '';
	$iva_ttm_ratings_txt 		= get_option( 'iva_ttm_ratings_txt' ) ? get_option( 'iva_ttm_ratings_txt' ) : '';
	$iva_ttm_client_desc_txt	= get_option( 'iva_ttm_client_desc_txt' ) ? get_option( 'iva_ttm_client_desc_txt' ) : '';

	// Color Options
	$iva_testimonial_slug 		= get_option( 'iva_testimonial_slug' ) ? get_option( 'iva_testimonial_slug' ) : '';
	$iva_ttm_fontsize			= get_option( 'iva_ttm_fontsize' ) ? get_option( 'iva_ttm_fontsize' ) : '';
	$iva_ttm_content_color 		= get_option( 'iva_ttm_content_color' ) ? get_option( 'iva_ttm_content_color' ) : '';
	$iva_ttm_title_color 		= get_option( 'iva_ttm_title_color' ) ? get_option( 'iva_ttm_title_color' ) : '';
	$iva_ttm_job_color 			= get_option( 'iva_ttm_job_color' ) ? get_option( 'iva_ttm_job_color' ) : '';
	$iva_ttm_company_color 		= get_option( 'iva_ttm_company_color' ) ? get_option( 'iva_ttm_company_color' ) : '';
	$iva_ttm_bg_color 			= get_option( 'iva_ttm_bg_color' ) ? get_option( 'iva_ttm_bg_color' ) : '';
	$iva_ttm_blockquote_color 	= get_option( 'iva_ttm_blockquote_color' ) ? get_option( 'iva_ttm_blockquote_color' ) : '';
	$iva_ttm_spltitle_color 	= get_option( 'iva_ttm_spltitle_color' ) ? get_option( 'iva_ttm_spltitle_color' ) : '';
	$iva_ttm_ratings_color 		= get_option( 'iva_ttm_ratings_color' ) ? get_option( 'iva_ttm_ratings_color' ) : '';
	$iva_ttm_upload_image 		= get_option( 'iva_ttm_upload_image' ) ? get_option( 'iva_ttm_upload_image' ) : '';

	// Form Inputs Style
	$iva_ttm_input_fontcolor 	= get_option( 'iva_ttm_input_fontcolor' ) ? get_option( 'iva_ttm_input_fontcolor' ) : '';
	$iva_ttm_input_bordercolor	= get_option( 'iva_ttm_input_bordercolor' ) ? get_option( 'iva_ttm_input_bordercolor' ) : '';
	$iva_ttm_input_bgcolor		= get_option( 'iva_ttm_input_bgcolor' ) ? get_option( 'iva_ttm_input_bgcolor' ) : '';
	$iva_ttm_input_fontsize		= get_option( 'iva_ttm_input_fontsize' ) ? get_option( 'iva_ttm_input_fontsize' ) : '';
	$iva_ttm_input_fontfamily	= get_option( 'iva_ttm_input_fontfamily' ) ? get_option( 'iva_ttm_input_fontfamily' ) : '';
	$iva_ttm_input_fontweight	= get_option( 'iva_ttm_input_fontweight' ) ? get_option( 'iva_ttm_input_fontweight' ) : '';
	$iva_ttm_input_borderradius	= get_option( 'iva_ttm_input_borderradius' ) ? get_option( 'iva_ttm_input_borderradius' ) : '';

	// Button Settings
	$iva_ttm_button_text			= get_option( 'iva_ttm_button_text' ) ? get_option( 'iva_ttm_button_text' ) : esc_html__('Submit','iva_testimonial_pro');
	$iva_ttm_button_fontcolor		= get_option( 'iva_ttm_button_fontcolor' ) ? get_option( 'iva_ttm_button_fontcolor' ) : '';
	$iva_ttm_button_bordercolor		= get_option( 'iva_ttm_button_bordercolor' ) ? get_option( 'iva_ttm_button_bordercolor' ) : '';
	$iva_ttm_button_bgcolor			= get_option( 'iva_ttm_button_bgcolor' ) ? get_option( 'iva_ttm_button_bgcolor' ) : '';
	$iva_ttm_button_hover_fontcolor = get_option( 'iva_ttm_button_hover_fontcolor' ) ? get_option( 'iva_ttm_button_hover_fontcolor' ) : '';
	$iva_ttm_button_hover_bordercolor = get_option( 'iva_ttm_button_hover_bordercolor' ) ? get_option( 'iva_ttm_button_hover_bordercolor' ) : '';
	$iva_ttm_button_hover_bgcolor	= get_option( 'iva_ttm_button_hover_bgcolor' ) ? get_option( 'iva_ttm_button_hover_bgcolor' ) : '';
	$iva_ttm_btn_fontsize	= get_option( 'iva_ttm_btn_fontsize' ) ? get_option( 'iva_ttm_btn_fontsize' ) : '';
	$iva_ttm_btn_fontfamily	= get_option( 'iva_ttm_btn_fontfamily' ) ? get_option( 'iva_ttm_btn_fontfamily' ) : '';
	$iva_ttm_btn_fontweight	= get_option( 'iva_ttm_btn_fontweight' ) ? get_option( 'iva_ttm_btn_fontweight' ) : '';
	$iva_ttm_btn_borderradius	= get_option( 'iva_ttm_btn_borderradius' ) ? get_option( 'iva_ttm_btn_borderradius' ) : '';

	// Message Settings
	$iva_ttm_smsg_fontcolor		= get_option( 'iva_ttm_smsg_fontcolor' ) ? get_option( 'iva_ttm_smsg_fontcolor' ) : '';
	$iva_ttm_smsg_fontsize		= get_option( 'iva_ttm_smsg_fontsize' ) ? get_option( 'iva_ttm_smsg_fontsize' ) : '';
	$iva_ttm_smsg_fontweight	= get_option( 'iva_ttm_smsg_fontweight' ) ? get_option( 'iva_ttm_smsg_fontweight' ) : '';
	$iva_ttm_smsg_bgcolor		= get_option( 'iva_ttm_smsg_bgcolor' ) ? get_option( 'iva_ttm_smsg_bgcolor' ) : '';
	$iva_ttm_smsg_bordercolor	= get_option( 'iva_ttm_smsg_bordercolor' ) ? get_option( 'iva_ttm_smsg_bordercolor' ) : '';
	$iva_ttm_smsg_fontfamily	= get_option( 'iva_ttm_smsg_fontfamily' ) ? get_option( 'iva_ttm_smsg_fontfamily' ) : '';

	// Notification Email Settings
	$iva_ttm_notificationemail	= get_option( 'iva_ttm_notificationemail' ) ? get_option( 'iva_ttm_notificationemail' ) : '';
	$iva_ttm_emailto			= get_option( 'iva_ttm_emailto' ) ? get_option( 'iva_ttm_emailto' ) : '';
	$iva_ttm_emailsubject		= get_option( 'iva_ttm_emailsubject' ) ? get_option( 'iva_ttm_emailsubject' ) : '';
	$iva_ttm_emailid			= get_option( 'iva_ttm_emailid' ) ? get_option( 'iva_ttm_emailid' ) : '';
	$iva_ttm_emailmessage		= get_option( 'iva_ttm_emailmessage' ) ? get_option( 'iva_ttm_emailmessage' ) : '';
	$iva_ttm_headersmsg			= get_option( 'iva_ttm_headersmsg' ) ? get_option( 'iva_ttm_headersmsg' ) : '';

	//
	$title_enabled = $title_req_enabled = $pic_enabled = $pic_req_enabled = $uploadpic_req_enabled = $gravtar_enabled = $gravtar_req_enabled = $job_enabled = $job_req_enabled = $company_enabled = $company_req_enabled = $company_url_enabled = $company_url_req_enabled = $rating_enabled = $rating_req_enabled = $number_req_enabled = $cusotm_req_enabled = $desc_enabled = $desc_req_enabled = $captcha_enabled = '';

	// Client Title
	if ( 'on' == $iva_ttm_opt_client_name ) { $title_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_client_name ) { $title_req_enabled = 'checked=\"checked\"'; }

	// Client Pic
	if ( 'on' == $iva_ttm_opt_client_pic ) { $pic_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_client_pic ) { $pic_req_enabled = 'checked=\"checked\"'; }

	if ( 'on' == $iva_ttm_opt_grav_email ) { $gravtar_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_gravatar ) { $gravtar_req_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_upload_pic ) { $uploadpic_req_enabled = 'checked=\"checked\"'; }

	// Role
	if ( 'on' == $iva_ttm_opt_client_job ) { $job_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_client_job ) { $job_req_enabled = 'checked=\"checked\"'; }

	// Company name
	if ( 'on' == $iva_ttm_opt_cmpny_name ) { $company_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_cmpny_name ) { $company_req_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_opt_cmpny_url ) { $company_url_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_cmpny_url ) { $company_url_req_enabled = 'checked=\"checked\"'; }

	// Ratings
	if ( 'on' == $iva_ttm_opt_ratings ) { $rating_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_ratings ) { $rating_req_enabled = 'checked=\"checked\"'; }

	// Client Description
	if ( 'on' == $iva_ttm_opt_client_desc ) { $desc_enabled = 'checked=\"checked\"'; }
	if ( 'on' == $iva_ttm_req_client_desc ) { $desc_req_enabled = 'checked=\"checked\"'; }

	// Captcha
	if ( 'on' == $iva_ttm_opt_captcha ) { $captcha_enabled = 'checked=\"checked\"'; }

	echo '<div class="testimonial-title sub-heading"><div class="ttm_icon blue"><span class="ivaIcon "><i class="atmpro_settings"></i></span></div><h3 class="iva_ttm_subheading">' . esc_html__( 'Testimonial Settings on the Frontend', 'iva_testimonial_pro' ) . '</h3>';

	echo '<div class="iva_ttm_settings_row">';

	// Testimonial Slug
	echo '<div class="iva-ttm-title">' . esc_html__( 'Testimonial Slug', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_testimonial_slug" name="iva_testimonial_slug" id="iva_testimonial_slug" value="' . esc_attr( $iva_testimonial_slug ) . '"><p><label for="iva_testimonial_slug">' . esc_html__( 'Enter Slug for the Testimonial.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Font Size
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Size', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_fontsize" name="iva_ttm_fontsize" id="iva_ttm_fontsize" value="' . esc_attr( $iva_ttm_fontsize ) . '"><p><label for="iva_ttm_fontsize">' . esc_html__( 'Enter Font Size for the Testimonial.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Content Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Content Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_content_color wpcolorpicker" name="iva_ttm_content_color" id="iva_ttm_content_color" value="' . esc_attr( $iva_ttm_content_color ) . '"><p><label for="iva_ttm_content_color">' . esc_html__( 'Choose Color for the Testimonial Text.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Title Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Title Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_title_color wpcolorpicker" name="iva_ttm_title_color" id="iva_ttm_title_color" value="' . esc_attr( $iva_ttm_title_color ) . '"><p><label for="iva_ttm_title_color">' . esc_html__( 'Choose Color for the Testimonial Title.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Role Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Role Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_job_color wpcolorpicker" name="iva_ttm_job_color" id="iva_ttm_job_color" value="' . esc_attr( $iva_ttm_job_color ) . '"><p><label for="iva_ttm_job_color">' . esc_html__( 'Choose Color for the Client\'s Role.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Client Company Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Client Company Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_company_color wpcolorpicker" name="iva_ttm_company_color" id="iva_ttm_company_color" value="' . esc_attr( $iva_ttm_company_color ) . '"><p><label for="iva_ttm_company_color">' . esc_html__( 'Choose Color for the Client\'s Company.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Background Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'BG Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_bg_color wpcolorpicker" name="iva_ttm_bg_color" id="iva_ttm_bg_color" value="' . esc_attr( $iva_ttm_bg_color ) . '"><p><label for="iva_ttm_bg_color">' . esc_html__( 'Choose BG Color for the Testimonial Layouts 6-a,6-b,8-a and 8-b.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Blockquote Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Blockquote Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_blockquote_color wpcolorpicker" name="iva_ttm_blockquote_color" id="iva_ttm_blockquote_color" value="' . esc_attr( $iva_ttm_blockquote_color ) . '"><p><label for="iva_ttm_blockquote_color">' . esc_html__( 'Choose Blockquote Color for the Testimonial Layouts 1-c and 1-d.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Ratings Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Ratings Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_ratings_color wpcolorpicker" name="iva_ttm_ratings_color" id="iva_ttm_ratings_color" value="' . esc_attr( $iva_ttm_ratings_color ) . '"><p><label for="at-ttm-ratings">' . esc_html__( 'Choose Ratings Color for the Testimonials.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Special Title Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Special Title Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_spltitle_color wpcolorpicker" name="iva_ttm_spltitle_color" id="iva_ttm_spltitle_color" value="' . esc_attr( $iva_ttm_spltitle_color ) . '"><p><label for="iva_ttm_spltitle_color">' . esc_html__( 'Choose Special Title Color for the Testimonial Layouts 7.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Upload Default Image
	echo '<div class="iva-ttm-title">' . esc_html__( 'Upload Default Image', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input name="iva_ttm_upload_image" id="iva_open_hidden_image"  type="hidden" class="iva_oc_upload_image" value="' . esc_attr( $iva_ttm_upload_image ) . '" />';
	echo '<input name="iva_open_image" id="iva_open_image" class="iva_oc_upload_btn button blue-button" type="button" value="' . esc_html__( 'Upload Image','iva_testimonial_pro' ) . '" />';

	echo '<a href="#" class="iva_oc_image_remove button red-button">remove</a>';
	echo '<div id="iva_oc_preview_image-iva_open_image" class="iva-oc-screenshot">';
	if ( $iva_ttm_upload_image != '' ) {
		$image_attributes = wp_get_attachment_image_src( iva_ttm_get_attachment_id_from_src( $iva_ttm_upload_image ) );
		if ( $image_attributes != '' ) {
			echo '<img src="' . $image_attributes[0] . '"  class="iva_oc_preview_image" alt="" />';
		} else {
			echo '<img src="' . $iva_ttm_upload_image . '"  class="iva_oc_preview_image" alt="" />';
		}
	}
	echo '</div></div></div></div>';

	echo '<div class="testimonial-title sub-heading"><div class="ttm_icon blue"><span class="ivaIcon "><i class="atmpro_settings"></i></span></div><h3 class="iva_ttm_subheading">' . esc_html__( 'Form Settings', 'iva_testimonial_pro' ) . '</h3>';

	// Title text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Client Title Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_client_name_txt" name="iva_ttm_client_name_txt" id="iva_client_name_txt" value="' . esc_attr( $iva_ttm_client_name_txt ) . '">';
	echo '</div>';

	// Name
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_client_name" id="iva_ttm_opt_client_name"  name="iva_ttm_opt_client_name"  ' . esc_attr( $title_enabled ) . '><label for="iva_ttm_opt_client_name">' . esc_html__( 'Check this if you wish to disable Client Title for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';

	echo '<input type="checkbox" class="iva_ttm_req_client_name" id="iva_ttm_req_client_name"  name="iva_ttm_req_client_name"  ' . esc_attr( $title_req_enabled ) . '><label for="iva_ttm_req_client_name">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label>';
	echo '</div></div><hr>';

	// Picture Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Check this if you wish to use Image Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_client_pic_txt" name="iva_ttm_client_pic_txt" id="iva_ttm_client_pic_txt" value="' . esc_attr( $iva_ttm_client_pic_txt ) . '">';
	echo '</div>';

	// Client Pic
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_client_pic" id="iva_ttm_opt_client_pic"  name="iva_ttm_opt_client_pic" ' . esc_attr( $pic_enabled ) . '><label for="iva_ttm_opt_client_pic">' . esc_html__( 'Check this if you wish to disable Client Picture for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';
	echo '</div></div><hr>';

	// Email Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Email ID Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_grav_email_txt" name="iva_ttm_grav_email_txt" id="iva_ttm_grav_email_txt" value="' . esc_attr( $iva_ttm_grav_email_txt ) . '">';
	echo '</div>';

	// Email
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_grav_email" id="iva_ttm_opt_grav_email"  name="iva_ttm_opt_grav_email" ' . esc_attr( $gravtar_enabled ) . '><label for="iva_ttm_opt_grav_email">' . esc_html__( 'Check this if you wish to disable Email Option for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';
	echo '<input type="checkbox" class="iva_ttm_req_gravatar" id="iva_ttm_req_gravatar"  name="iva_ttm_req_gravatar" ' . esc_attr( $gravtar_req_enabled ) . '><label for="iva_ttm_req_gravatar">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label></div>';
	echo '</div><hr>';

	// Role Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Role Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">
	<input type="text" class="iva_ttm_client_job_txt" name="iva_ttm_client_job_txt" id="iva_ttm_client_job_txt" value="' . esc_attr( $iva_ttm_client_job_txt ) . '">';
	echo '</div>';

	// Role
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_client_job" id="iva_ttm_opt_client_job"  name="iva_ttm_opt_client_job" ' . esc_attr( $job_enabled ) . '><label for="iva_ttm_opt_client_job">' . esc_html__( 'Check this if you wish to disable Client Role for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';

	echo '<input type="checkbox" class="iva_ttm_req_client_job" id="iva_ttm_req_client_job"  name="iva_ttm_req_client_job" ' . esc_attr( $job_req_enabled ) . '><label for="iva_ttm_req_client_job">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label></div></div><hr>';

	// Company Name Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Company Name Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">
	<input type="text" class="iva_ttm_cmpny_name_txt" name="iva_ttm_cmpny_name_txt" id="iva_ttm_cmpny_name_txt" value="' . esc_attr( $iva_ttm_cmpny_name_txt ) . '">';
	echo '</div>';

	// Company Name
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_cmpny_name" id="iva_ttm_opt_cmpny_name"  name="iva_ttm_opt_cmpny_name" ' . esc_attr( $company_enabled ) . '><label for="iva_ttm_opt_cmpny_name">' . esc_html__( 'Check this if you wish to disable Company Name for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';
	echo '<input type="checkbox" class="iva_ttm_req_cmpny_name" id="iva_ttm_req_cmpny_name"  name="iva_ttm_req_cmpny_name" ' . esc_attr( $company_req_enabled ) . '><label for="iva_ttm_req_cmpny_name">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label>';
	echo '</div></div><hr>';

	// Company Url Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Company Website Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">
	<input type="text" class="iva_ttm_cmpny_url_txt" name="iva_ttm_cmpny_url_txt" id="iva_ttm_cmpny_url_txt" value="' . esc_attr( $iva_ttm_cmpny_url_txt ) . '">';
	echo '</div>';

	// Company Url
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_cmpny_url" id="iva_ttm_opt_cmpny_url"  name="iva_ttm_opt_cmpny_url" ' . esc_attr( $company_url_enabled ) . '><label for="iva_ttm_opt_cmpny_url">' . esc_html__( 'Check this if you wish to disable Company Website for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';
	echo '<input type="checkbox" class="iva_ttm_req_cmpny_url" id="iva_ttm_req_cmpny_url"  name="iva_ttm_req_cmpny_url" ' . esc_attr( $company_url_req_enabled ) . '><label for="iva_ttm_req_cmpny_url">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label>';
	echo '</div></div><hr>';

	// Description Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Description Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">
	<input type="text" class="iva_ttm_client_desc_txt" name="iva_ttm_client_desc_txt" id="iva_ttm_client_desc_txt" value="' . esc_attr( $iva_ttm_client_desc_txt ) . '">';
	echo '</div>';

	// Description
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_client_desc" id="iva_ttm_opt_client_desc"  name="iva_ttm_opt_client_desc" ' . esc_attr( $desc_enabled ) . '><label for="iva_ttm_opt_client_desc">' . esc_html__( 'Check this if you wish to disable Description for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';

	// Description
	echo '<input type="checkbox" class="iva_ttm_req_client_desc" id="iva_ttm_req_client_desc"  name="iva_ttm_req_client_desc" ' . esc_attr( $desc_req_enabled ) . '><label for="iva_ttm_req_client_desc">' . esc_html__( 'Check this if this field is mandatory.', 'iva_testimonial_pro' ) . '</label></div></div><hr>';

	// Captcha
	echo '<div class="iva-ttm-title">' . esc_html__( 'Captcha', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm_hd_checkbox"><div class="ivattm-input-details">';
	echo '<input type="checkbox" class="iva_ttm_opt_captcha" id="iva_ttm_opt_captcha"  name="iva_ttm_opt_captcha" ' . esc_attr( $captcha_enabled ) . '><label for="iva_ttm_opt_captcha">' . esc_html__( 'Check this if you wish to disable Captcha for the Testimonial on frontend.', 'iva_testimonial_pro' ) . '</label><br >';
	echo '</div>';
	echo '</div>';

	echo '</div>';//.testimonial-title sub-heading

	// Form Inputs Style
	echo '<div class="testimonial-title sub-heading"><div class="ttm_icon blue"><span class="ivaIcon "><i class="atmpro_styles"></i></span></div><h3 class="iva_ttm_subheading">' . esc_html__( 'Form Inputs Style', 'iva_testimonial_pro' ) . '</h3>';

	// Inputs Font Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_input_fontcolor wpcolorpicker" name="iva_ttm_input_fontcolor" id="iva_ttm_input_fontcolor" value="' . esc_attr( $iva_ttm_input_fontcolor ) . '"><p><label for="iva_ttm_input_fontcolor">' . esc_html__( 'Choose Inputs Font Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Border Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Border Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_input_bordercolor wpcolorpicker" name="iva_ttm_input_bordercolor" id="iva_ttm_input_bordercolor" value="' . esc_attr( $iva_ttm_input_bordercolor ) . '"><p><label for="iva_ttm_input_bordercolor">' . esc_html__( 'Choose Inputs Border Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Background Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Background Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_input_bgcolor wpcolorpicker" name="iva_ttm_input_bgcolor" id="iva_ttm_input_bgcolor" value="' . esc_attr( $iva_ttm_input_bgcolor ) . '"><p><label for="iva_ttm_input_bgcolor">' . esc_html__( 'Choose Inputs Background Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Font Size
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Size', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_input_fontsize" id="iva_ttm_input_fontsize" class="iva_ttm_input_fontsize">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontsize as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_input_fontsize == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_input_fontsize">' . esc_html__( 'Choose Inputs Font Size in pixels for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Font Family
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Family', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_input_fontfamily" id="iva_ttm_input_fontfamily" class="iva_ttm_input_fontfamily">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontfamily as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_input_fontfamily == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_input_fontfamily">' . esc_html__( 'Choose Inputs Font Family for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Font Weight
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Weight', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_input_fontweight" id="iva_ttm_input_fontweight" class="iva_ttm_input_fontweight">';
	echo '<option value="">'. esc_html__( 'Choose Style' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontweight as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_input_fontweight == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_input_fontweight">' . esc_html__( 'Choose Inputs Font Weight for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Inputs Border Radius
	echo '<div class="iva-ttm-title">' . esc_html__( 'Border Radius', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_input_borderradius" id="iva_ttm_input_borderradius" class="iva_ttm_input_borderradius">';
	echo '<option value="">'. esc_html__( 'Choose Border' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_borderradius as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_input_borderradius == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_input_borderradius">' . esc_html__( 'Choose Inputs Border Radius for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Settings
	echo '<h3 class="iva_ttm_subheading">' . esc_html__( 'Button Settings', 'iva_testimonial_pro' ) . '</h3>';

	// Button Text
	echo '<div class="iva-ttm-title">' . esc_html__( 'Button Text', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_text" name="iva_ttm_button_text" id="iva_ttm_button_text" value="' . esc_attr( $iva_ttm_button_text ) . '"><p><label for="iva_ttm_button_text">' . esc_html__( 'Choose Button Font Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Font Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_fontcolor wpcolorpicker" name="iva_ttm_button_fontcolor" id="iva_ttm_button_fontcolor" value="' . esc_attr( $iva_ttm_button_fontcolor ) . '"><p><label for="iva_ttm_button_fontcolor">' . esc_html__( 'Choose Button Font Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Border Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Border Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_bordercolor wpcolorpicker" name="iva_ttm_button_bordercolor" id="iva_ttm_button_bordercolor" value="' . esc_attr( $iva_ttm_button_bordercolor ) . '"><p><label for="iva_ttm_button_bordercolor">' . esc_html__( 'Choose Button Border Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Background Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Background Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_bgcolor wpcolorpicker" name="iva_ttm_button_bgcolor" id="iva_ttm_button_bgcolor" value="' . esc_attr( $iva_ttm_button_bgcolor ) . '"><p><label for="iva_ttm_button_bgcolor">' . esc_html__( 'Choose Button Background Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Hover Font Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Hover Font Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_hover_fontcolor wpcolorpicker" name="iva_ttm_button_hover_fontcolor" id="iva_ttm_button_hover_fontcolor" value="' . esc_attr( $iva_ttm_button_hover_fontcolor ) . '"><p><label for="iva_ttm_button_hover_fontcolor">' . esc_html__( 'Choose Button Hover Font Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Hover Border Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Hover Border Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_hover_bordercolor wpcolorpicker" name="iva_ttm_button_hover_bordercolor" id="iva_ttm_button_hover_bordercolor" value="' . esc_attr( $iva_ttm_button_hover_bordercolor ) . '"><p><label for="iva_ttm_button_hover_bordercolor">' . esc_html__( 'Choose Button Hover Border Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Hover Background Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Hover Background Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_button_hover_bgcolor wpcolorpicker" name="iva_ttm_button_hover_bgcolor" id="iva_ttm_button_hover_bgcolor" value="' . esc_attr( $iva_ttm_button_hover_bgcolor ) . '"><p><label for="iva_ttm_button_hover_bgcolor">' . esc_html__( 'Choose Button Hover Background Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Font Size (px)
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Size', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_btn_fontsize" id="iva_ttm_btn_fontsize" class="iva_ttm_btn_fontsize">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontsize as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_btn_fontsize == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_btn_fontsize">' . esc_html__( 'Choose Button Font Size for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Font Family
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Family', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_btn_fontfamily" id="iva_ttm_btn_fontfamily" class="iva_ttm_btn_fontfamily">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontfamily as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_btn_fontfamily == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_btn_fontfamily">' . esc_html__( 'Choose Button Font Family for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Font Weight
	echo '<div class="iva-ttm-title">' . esc_html__( 'Font Weight', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_btn_fontweight" id="iva_ttm_btn_fontweight" class="iva_ttm_btn_fontweight">';
	echo '<option value="">'. esc_html__( 'Choose Style' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontweight as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_btn_fontweight == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_btn_fontweight">' . esc_html__( 'Choose Button Font Weight for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Button Border Radius
	echo '<div class="iva-ttm-title">' . esc_html__( 'Border Radius', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_btn_borderradius" id="iva_ttm_btn_borderradius" class="iva_ttm_btn_borderradius">';
	echo '<option value="">'. esc_html__( 'Choose Border' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_borderradius as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_btn_borderradius == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_btn_borderradius">' . esc_html__( 'Choose Button Border Radius for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Messages Style
	echo '<h3 class="iva_ttm_subheading">' . esc_html__( 'Messages Style', 'iva_testimonial_pro' ) . '</h3>';

	// Success Message Font Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Font Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_smsg_fontcolor wpcolorpicker" name="iva_ttm_smsg_fontcolor" id="iva_ttm_smsg_fontcolor" value="' . esc_attr( $iva_ttm_smsg_fontcolor ) . '"><p><label for="iva_ttm_smsg_fontcolor">' . esc_html__( 'Choose Success Message Font Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Success Message Background Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Background Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_smsg_bgcolor wpcolorpicker" name="iva_ttm_smsg_bgcolor" id="iva_ttm_smsg_bgcolor" value="' . esc_attr( $iva_ttm_smsg_bgcolor ) . '"><p><label for="iva_ttm_smsg_bgcolor">' . esc_html__( 'Choose Success Message Background Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Success Message Border Color
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Border Color', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_smsg_bordercolor wpcolorpicker" name="iva_ttm_smsg_bordercolor" id="iva_ttm_smsg_bordercolor" value="' . esc_attr( $iva_ttm_smsg_bordercolor ) . '"><p><label for="iva_ttm_smsg_bordercolor">' . esc_html__( 'Choose Success Message Border Color for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Success Message Font Size (px)
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Font Size (px)', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_smsg_fontsize" id="iva_ttm_smsg_fontsize" class="iva_ttm_smsg_fontsize">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontsize as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_smsg_fontsize == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_smsg_fontsize">' . esc_html__( 'Choose Success Message Font Size in pixels for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Success Message Font Family
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Font Family', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_smsg_fontfamily" id="iva_ttm_smsg_fontfamily" class="iva_ttm_smsg_fontfamily">';
	echo '<option value="">'. esc_html__( 'Choose Font' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontfamily as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_smsg_fontfamily == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_smsg_fontfamily">' . esc_html__( 'Choose Success Message Font Family for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	// Success Message Font Weight
	echo '<div class="iva-ttm-title">' . esc_html__( 'Success Message Font Weight', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_smsg_fontweight" id="iva_ttm_smsg_fontweight" class="iva_ttm_smsg_fontweight">';
	echo '<option value="">'. esc_html__( 'Choose Style' ,'iva_testimonial_pro' ) . '</option>';
	foreach ( $iva_input_fontweight as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_smsg_fontweight == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p><label for="iva_ttm_smsg_fontweight">' . esc_html__( 'Choose Success Message Font Weight for the Testimonial Form.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr>';

	echo '</div>';//.testimonial-title sub-heading

	// Notification Email
	echo '<div class="testimonial-title sub-heading"><div class="ttm_icon blue"><span class="ivaIcon "><i class="atmpro_mail"></i></span></div><h3 class="iva_ttm_subheading">' . esc_html__( 'Notification Email', 'iva_testimonial_pro' ) . '</h3>';

	// Notification Email
	echo '<div class="iva-ttm-title">' . esc_html__( 'Notification Email', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_notificationemail" id="iva_ttm_notificationemail" class="iva_ttm_notificationemail">';
	foreach ( $iva_input_notificationemail as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_notificationemail == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p class="ivattm-desc"><label for="iva_ttm_notificationemail">' . esc_html__( 'Enable/Disable Notification Email.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr class="enable">';

	// Send Email To
	echo '<div class="iva-ttm-title enable">' . esc_html__( 'Send Email To', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<select name="iva_ttm_emailto" id="iva_ttm_emailto" class="iva_ttm_emailto enable">';
	foreach ( $iva_input_emailto as $key => $value ) {
		$selected = '';
		if ( $iva_ttm_emailto == $value ) {
			$selected = "selected= 'selected'";
		}
		echo '<option ' . esc_attr( $selected ) . ' value="' . esc_attr( $value ) . '"><span>' . esc_attr( $value ) . '</span></option>';
	}
	echo '</select>';
	echo '<p class="ivattm-desc enable"><label for="iva_ttm_emailto">' . esc_html__( 'Sends email to admin.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr class="enable">';

	// Admin Email ID
	echo '<div class="iva-ttm-title enable">' . esc_html__( 'Admin Email ID', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<input type="text" class="iva_ttm_emailid enable" name="iva_ttm_emailid" id="iva_ttm_emailid" value="' . esc_attr( $iva_ttm_emailid ) . '"><p class="ivattm-desc enable"><label for="iva_ttm_emailid">' . esc_html__( 'Enter Admin Email ID.', 'iva_testimonial_pro' ) . '</label></p>';
	echo '</div><hr class="enable">';

	// Notification Email Subject
	echo '<div class="iva-ttm-title enable">' . esc_html__( 'Notification Email Subject', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<textarea class="iva_ttm_emailsubject enable" name="iva_ttm_emailsubject" id="iva_ttm_emailsubject" cols="100" rows="6">' . esc_attr( $iva_ttm_emailsubject ) . '</textarea>';
	echo '</div><hr class="enable">';

	// Notification Email Message
	echo '<div class="iva-ttm-title enable">' . esc_html__( 'Notification Email Message', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<textarea class="iva_ttm_emailmessage enable" name="iva_ttm_emailmessage" id="iva_ttm_emailmessage" cols="100" rows="6">' . esc_attr( $iva_ttm_emailmessage ) . '</textarea>';
	echo '</div><hr class="enable">';

	// Notification Headers Message
	echo '<div class="iva-ttm-title enable">' . esc_html__( 'Notification Headers Message', 'iva_testimonial_pro' ) . '</div>';
	echo '<div class="ivattm-input-details">';
	echo '<textarea class="iva_ttm_headersmsg enable" name="iva_ttm_headersmsg" id="iva_ttm_headersmsg" cols="100" rows="6">' . esc_attr( $iva_ttm_headersmsg ) . '</textarea>';
	echo '</div><hr class="enable">';

	echo '</div>';//.testimonial-title sub-heading

	// Custom CSS
	echo '<div class="testimonial-title sub-heading"><div class="ttm_icon blue"><span class="ivaIcon "><i class="atmpro_view"></i></span></div><h3 class="iva_ttm_subheading">' . esc_html__( 'Custom CSS', 'iva_testimonial_pro' ) . '</h3><label for="iva_ttm_opt_client_desc">' . esc_html__( 'Input any Custom CSS you want to use.', 'iva_testimonial_pro' ) . '</label>';

	echo '<textarea class="iva_ttm_extracss" name="iva_ttm_extracss" id="iva_ttm_extracss" cols="50" rows="8">' . esc_attr( $iva_ttm_extracss ) . '</textarea>';

	$iva_ttm_setting_nonce = wp_create_nonce( 'iva-ttm-settings' );
	echo '<input type="hidden" name="iva-ttm-settings" id="iva-ttm-settings" value="', esc_attr( $iva_ttm_setting_nonce ), '" />';

	echo '</div>';//.testimonial-title sub-heading
	echo '<a data_tm_url = "' . esc_url( admin_url( 'admin.php?page=ttm-settings' ) ) . '" class="update_ttm_settings button button-hero blue-button">' . esc_html__( 'Save All Changes','iva_testimonial_pro' ) . '</a>';
	echo '</form>';
	echo '</div>'; //general-input

	// Manual Update Plugin Dialog Form
	echo '<div id="iva_ttm_update_plugin_dialog" class="iva_ttm_update_plugin_dialog md-modal md-effect-1">';

	echo '<div class="md-content">';
	echo '<div>';
	echo '<h3>' . esc_html__( 'Update Plugin', 'iva_testimonial_pro' ) . '</h3>';
	echo '<p>' . esc_html__( 'Select a file provided within the package "adv-ttm-pro.zip" If you update the plugin the files will be overwriten.', 'iva_testimonial_pro' ) . '</p>';
	echo '<p>' . esc_html__( 'Choose the update file:', 'iva_testimonial_pro' ) . '</p>';
	echo '<form action="' . esc_url( 'admin-ajax.php' ) . '" enctype="multipart/form-data" method="post">';
	echo '<input type="hidden" name="action" value="iva_ttm_ajax_action">';
	echo '<p><input type="file" name="iva_ttm_update_file" class="input_update_slider"></p>';
	echo '<p><input type="submit" class="button green-button button-hero subbtn" value="' . esc_html__( 'Update Now', 'iva_testimonial_pro' ) . '"></p>';
	echo '</form>';
	echo '<p><a class="button red-button md-close">' . esc_html__( 'Close', 'iva_testimonial_pro' ) . '</a></p>';
	echo '</div>';
	echo '</div>';//md-content
	echo '</div>';//iva_ttm_update_plugin_dialog
	echo '<div class="md-overlay"></div>';
}

/**
 * function iva_ttm_update_settings()
 * updates settings.
 */
add_action( 'wp_ajax_iva_ttm_update_settings', 'iva_ttm_update_settings' );
add_action( 'wp_ajax_nopriv_iva_ttm_update_settings', 'iva_ttm_update_settings' );
function iva_ttm_update_settings() {

	global $wpdb;
	check_ajax_referer( 'iva-ttm-settings', 'setting_nonce' );

	$postform = isset( $_POST['data'] ) ? $_POST['data'] : '';

	/**
	 * function parse_str
	 * @param 'str' inpput string
	 * @param 'arr' If the second parameter arr is present, variables are stored in this variable as array elements instead.
	 * @return No value is returned.
	 */
	parse_str( $postform, $formdata );

	$error = $iva_ttm_extracss = $iva_ttm_opt_client_name = $iva_ttm_req_client_name = $iva_ttm_req_client_name = $iva_ttm_client_name_txt = $iva_ttm_client_pic_txt = $iva_ttm_req_client_pic = $iva_ttm_opt_grav_email = $iva_ttm_grav_email_txt = $iva_ttm_req_gravatar = $iva_ttm_req_upload_pic = $iva_ttm_client_job_txt = $iva_ttm_opt_client_job = $iva_ttm_req_client_job = $iva_ttm_client_email_txt = $iva_ttm_client_email_txt = $iva_ttm_req_client_email = $iva_ttm_client_url_txt = $iva_ttm_opt_client_url = $iva_ttm_req_client_url = $iva_ttm_cmpny_name_txt = $iva_ttm_opt_cmpny_name = $iva_ttm_req_cmpny_name = $iva_ttm_cmpny_url_txt = $iva_ttm_opt_cmpny_url = $iva_ttm_req_cmpny_url = $iva_ttm_ratings_txt = $iva_ttm_opt_ratings = $iva_ttm_req_ratings = $iva_ttm_client_desc_txt = $iva_testimonial_slug = $iva_ttm_fontsize = $iva_ttm_content_color = $iva_ttm_title_color = $iva_ttm_job_color = $iva_ttm_company_color = $iva_ttm_bg_color = $iva_ttm_blockquote_color = $iva_ttm_ratings_color = $iva_ttm_spltitle_color = $iva_ttm_upload_image = $iva_ttm_input_fontcolor = $iva_ttm_input_bordercolor = $iva_ttm_input_bgcolor = $iva_ttm_button_fontcolor = $iva_ttm_button_bordercolor = $iva_ttm_button_bgcolor = $iva_ttm_button_hover_fontcolor = $iva_ttm_button_hover_bordercolor = $iva_ttm_button_hover_bgcolor = $iva_ttm_button_text = $iva_ttm_smsg_fontcolor = $iva_ttm_input_fontsize = $iva_ttm_input_fontfamily = $iva_ttm_input_fontweight = $iva_ttm_input_borderradius = $iva_ttm_smsg_fontsize = $iva_ttm_smsg_fontweight = $iva_ttm_smsg_bgcolor = $iva_ttm_smsg_bordercolor = $iva_ttm_smsg_fontfamily = $iva_ttm_btn_fontsize = $iva_ttm_btn_fontfamily = $iva_ttm_btn_fontweight = $iva_ttm_btn_borderradius = $iva_ttm_notificationemail = $iva_ttm_emailto = $iva_ttm_emailsubject = $iva_ttm_emailid = $iva_ttm_emailmessage = $iva_ttm_headersmsg = '';

	if ( isset( $formdata['iva_ttm_extracss'] ) && '' != $formdata['iva_ttm_extracss'] ) {
		$iva_ttm_extracss = $formdata['iva_ttm_extracss'];
	} else {
		$iva_ttm_extracss = '';
	}
	if ( isset( $formdata['iva_ttm_opt_client_name'] ) && '' != $formdata['iva_ttm_opt_client_name'] ) {
		$iva_ttm_opt_client_name = $formdata['iva_ttm_opt_client_name'];
	} else {
		$iva_ttm_opt_client_name = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_client_name'] ) && '' != $formdata['iva_ttm_req_client_name'] ) {
		$iva_ttm_req_client_name = $formdata['iva_ttm_req_client_name'];
	} else {
		$iva_ttm_req_client_name = 'off';
	}
	if ( isset( $formdata['iva_ttm_client_name_txt'] ) && '' != $formdata['iva_ttm_client_name_txt'] ) {
		$iva_ttm_client_name_txt = $formdata['iva_ttm_client_name_txt'];
	}
	if ( isset( $formdata['iva_ttm_client_pic_txt'] ) && '' != $formdata['iva_ttm_client_pic_txt'] ) {
		$iva_ttm_client_pic_txt = $formdata['iva_ttm_client_pic_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_client_pic'] ) && '' != $formdata['iva_ttm_opt_client_pic'] ) {
		$iva_ttm_opt_client_pic = $formdata['iva_ttm_opt_client_pic'];
	} else {
		$iva_ttm_opt_client_pic = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_client_pic'] ) && '' != $formdata['iva_ttm_req_client_pic'] ) {
		$iva_ttm_req_client_pic = $formdata['iva_ttm_req_client_pic'];
	} else {
		$iva_ttm_req_client_pic = 'off';
	}
	if ( isset( $formdata['iva_ttm_grav_email_txt'] ) && '' != $formdata['iva_ttm_grav_email_txt'] ) {
		$iva_ttm_grav_email_txt = $formdata['iva_ttm_grav_email_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_grav_email'] ) && '' != $formdata['iva_ttm_opt_grav_email'] ) {
		$iva_ttm_opt_grav_email = $formdata['iva_ttm_opt_grav_email'];
	} else {
		$iva_ttm_opt_grav_email = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_gravatar'] ) && '' != $formdata['iva_ttm_req_gravatar'] ) {
		$iva_ttm_req_gravatar = $formdata['iva_ttm_req_gravatar'];
	} else {
		$iva_ttm_req_gravatar = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_upload_pic'] ) && '' != $formdata['iva_ttm_req_upload_pic'] ) {
		$iva_ttm_req_upload_pic = $formdata['iva_ttm_req_upload_pic'];
	} else {
		$iva_ttm_req_upload_pic = 'off';
	}
	if ( isset( $formdata['iva_ttm_client_job_txt'] ) && '' != $formdata['iva_ttm_client_job_txt'] ) {
		$iva_ttm_client_job_txt = $formdata['iva_ttm_client_job_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_client_job'] ) && '' != $formdata['iva_ttm_opt_client_job'] ) {
		$iva_ttm_opt_client_job = $formdata['iva_ttm_opt_client_job'];
	} else {
		$iva_ttm_opt_client_job = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_client_job'] ) && '' != $formdata['iva_ttm_req_client_job'] ) {
		$iva_ttm_req_client_job = $formdata['iva_ttm_req_client_job'];
	} else {
		$iva_ttm_req_client_job = 'off';
	}
	if ( isset( $formdata['iva_ttm_client_email_txt'] ) && '' != $formdata['iva_ttm_client_email_txt'] ) {
		$iva_ttm_client_email_txt = $formdata['iva_ttm_client_email_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_client_email'] ) && '' != $formdata['iva_ttm_opt_client_email'] ) {
		$iva_ttm_opt_client_email = $formdata['iva_ttm_opt_client_email'];
	} else {
		$iva_ttm_opt_client_email = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_client_email'] ) && '' != $formdata['iva_ttm_req_client_email'] ) {
		$iva_ttm_req_client_email = $formdata['iva_ttm_req_client_email'];
	} else {
		$iva_ttm_req_client_email = 'off';
	}
	if ( isset( $formdata['iva_ttm_cmpny_name_txt'] ) && '' != $formdata['iva_ttm_cmpny_name_txt'] ) {
		$iva_ttm_cmpny_name_txt = $formdata['iva_ttm_cmpny_name_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_cmpny_name'] ) && '' != $formdata['iva_ttm_opt_cmpny_name'] ) {
		$iva_ttm_opt_cmpny_name = $formdata['iva_ttm_opt_cmpny_name'];
	} else {
		$iva_ttm_opt_cmpny_name = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_cmpny_name'] ) && '' != $formdata['iva_ttm_req_cmpny_name'] ) {
		$iva_ttm_req_cmpny_name = $formdata['iva_ttm_req_cmpny_name'];
	} else {
		$iva_ttm_req_cmpny_name = 'off';
	}
	if ( isset( $formdata['iva_ttm_cmpny_url_txt'] ) && '' != $formdata['iva_ttm_cmpny_url_txt'] ) {
		$iva_ttm_cmpny_url_txt = $formdata['iva_ttm_cmpny_url_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_cmpny_url'] ) && '' != $formdata['iva_ttm_opt_cmpny_url'] ) {
		$iva_ttm_opt_cmpny_url = $formdata['iva_ttm_opt_cmpny_url'];
	} else {
		$iva_ttm_opt_cmpny_url = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_cmpny_url'] ) && '' != $formdata['iva_ttm_req_cmpny_url'] ) {
		$iva_ttm_req_cmpny_url = $formdata['iva_ttm_req_cmpny_url'];
	} else {
		$iva_ttm_req_cmpny_url = 'off';
	}
	if ( isset( $formdata['iva_ttm_ratings_txt'] ) && '' != $formdata['iva_ttm_ratings_txt'] ) {
		$iva_ttm_ratings_txt = $formdata['iva_ttm_ratings_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_ratings'] ) && '' != $formdata['iva_ttm_opt_ratings'] ) {
		$iva_ttm_opt_ratings = $formdata['iva_ttm_opt_ratings'];
	} else {
		$iva_ttm_opt_ratings = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_ratings'] ) && '' != $formdata['iva_ttm_req_ratings'] ) {
		$iva_ttm_req_ratings = $formdata['iva_ttm_req_ratings'];
	} else {
		$iva_ttm_req_ratings = 'off';
	}
	if ( isset( $formdata['iva_ttm_client_desc_txt'] ) && '' != $formdata['iva_ttm_client_desc_txt'] ) {
		$iva_ttm_client_desc_txt = $formdata['iva_ttm_client_desc_txt'];
	}
	if ( isset( $formdata['iva_ttm_opt_client_desc'] ) && '' != $formdata['iva_ttm_opt_client_desc'] ) {
		$iva_ttm_opt_client_desc = $formdata['iva_ttm_opt_client_desc'];
	} else {
		$iva_ttm_opt_client_desc = 'off';
	}
	if ( isset( $formdata['iva_ttm_req_client_desc'] ) && '' != $formdata['iva_ttm_req_client_desc'] ) {
		$iva_ttm_req_client_desc = $formdata['iva_ttm_req_client_desc'];
	} else {
		$iva_ttm_req_client_desc = 'off';
	}
	if ( isset( $formdata['iva_ttm_opt_captcha'] ) && '' != $formdata['iva_ttm_opt_captcha'] ) {
		$iva_ttm_opt_captcha = $formdata['iva_ttm_opt_captcha'];
	} else {
		$iva_ttm_opt_captcha = 'off';
	}
	if ( isset( $formdata['iva_testimonial_slug'] ) && '' != $formdata['iva_testimonial_slug'] ) {
		$iva_testimonial_slug = $formdata['iva_testimonial_slug'];
	}
	if ( isset( $formdata['iva_ttm_fontsize'] ) && '' != $formdata['iva_ttm_fontsize'] ) {
		$iva_ttm_fontsize = $formdata['iva_ttm_fontsize'];
	}
	if ( isset( $formdata['iva_ttm_content_color'] ) && '' != $formdata['iva_ttm_content_color'] ) {
		$iva_ttm_content_color = $formdata['iva_ttm_content_color'];
	}
	if ( isset( $formdata['iva_ttm_title_color'] ) && '' != $formdata['iva_ttm_title_color'] ) {
		$iva_ttm_title_color = $formdata['iva_ttm_title_color'];
	}
	if ( isset( $formdata['iva_ttm_job_color'] ) && '' != $formdata['iva_ttm_job_color'] ) {
		$iva_ttm_job_color = $formdata['iva_ttm_job_color'];
	}
	if ( isset( $formdata['iva_ttm_company_color'] ) && '' != $formdata['iva_ttm_company_color'] ) {
		$iva_ttm_company_color = $formdata['iva_ttm_company_color'];
	}
	if ( isset( $formdata['iva_ttm_bg_color'] ) && '' != $formdata['iva_ttm_bg_color'] ) {
		$iva_ttm_bg_color = $formdata['iva_ttm_bg_color'];
	}
	if ( isset( $formdata['iva_ttm_blockquote_color'] ) && '' != $formdata['iva_ttm_blockquote_color'] ) {
		$iva_ttm_blockquote_color = $formdata['iva_ttm_blockquote_color'];
	}
	if ( isset( $formdata['iva_ttm_spltitle_color'] ) && '' != $formdata['iva_ttm_spltitle_color'] ) {
		$iva_ttm_spltitle_color = $formdata['iva_ttm_spltitle_color'];
	}
	if ( isset( $formdata['iva_ttm_ratings_color'] ) && '' != $formdata['iva_ttm_ratings_color'] ) {
		$iva_ttm_ratings_color = $formdata['iva_ttm_ratings_color'];
	}
	if ( isset( $formdata['iva_ttm_upload_image'] ) && '' != $formdata['iva_ttm_upload_image'] ) {
		$iva_ttm_upload_image = $formdata['iva_ttm_upload_image'];
	}
	if ( isset( $formdata['iva_ttm_input_fontcolor'] ) && '' != $formdata['iva_ttm_input_fontcolor'] ) {
		$iva_ttm_input_fontcolor = $formdata['iva_ttm_input_fontcolor'];
	}
	if ( isset( $formdata['iva_ttm_input_bordercolor'] ) && '' != $formdata['iva_ttm_input_bordercolor'] ) {
		$iva_ttm_input_bordercolor = $formdata['iva_ttm_input_bordercolor'];
	}
	if ( isset( $formdata['iva_ttm_input_bgcolor'] ) && '' != $formdata['iva_ttm_input_bgcolor'] ) {
		$iva_ttm_input_bgcolor = $formdata['iva_ttm_input_bgcolor'];
	}
	if ( isset( $formdata['iva_ttm_button_fontcolor'] ) && '' != $formdata['iva_ttm_button_fontcolor'] ) {
		$iva_ttm_button_fontcolor = $formdata['iva_ttm_button_fontcolor'];
	}
	if ( isset( $formdata['iva_ttm_button_bordercolor'] ) && '' != $formdata['iva_ttm_button_bordercolor'] ) {
		$iva_ttm_button_bordercolor = $formdata['iva_ttm_button_bordercolor'];
	}
	if ( isset( $formdata['iva_ttm_button_bgcolor'] ) && '' != $formdata['iva_ttm_button_bgcolor'] ) {
		$iva_ttm_button_bgcolor = $formdata['iva_ttm_button_bgcolor'];
	}
	if ( isset( $formdata['iva_ttm_button_hover_fontcolor'] ) && '' != $formdata['iva_ttm_button_hover_fontcolor'] ) {
		$iva_ttm_button_hover_fontcolor = $formdata['iva_ttm_button_hover_fontcolor'];
	}
	if ( isset( $formdata['iva_ttm_button_hover_bordercolor'] ) && '' != $formdata['iva_ttm_button_hover_bordercolor'] ) {
		$iva_ttm_button_hover_bordercolor = $formdata['iva_ttm_button_hover_bordercolor'];
	}
	if ( isset( $formdata['iva_ttm_button_hover_bgcolor'] ) && '' != $formdata['iva_ttm_button_hover_bgcolor'] ) {
		$iva_ttm_button_hover_bgcolor = $formdata['iva_ttm_button_hover_bgcolor'];
	}
	if ( isset( $formdata['iva_ttm_button_text'] ) && '' != $formdata['iva_ttm_button_text'] ) {
		$iva_ttm_button_text = $formdata['iva_ttm_button_text'];
	}
	if ( isset( $formdata['iva_ttm_smsg_fontcolor'] ) && '' != $formdata['iva_ttm_smsg_fontcolor'] ) {
		$iva_ttm_smsg_fontcolor = $formdata['iva_ttm_smsg_fontcolor'];
	}
	if ( isset( $formdata['iva_ttm_input_fontsize'] ) && '' != $formdata['iva_ttm_input_fontsize'] ) {
		$iva_ttm_input_fontsize = $formdata['iva_ttm_input_fontsize'];
	}
	if ( isset( $formdata['iva_ttm_input_fontfamily'] ) && '' != $formdata['iva_ttm_input_fontfamily'] ) {
		$iva_ttm_input_fontfamily = $formdata['iva_ttm_input_fontfamily'];
	}
	if ( isset( $formdata['iva_ttm_input_fontweight'] ) && '' != $formdata['iva_ttm_input_fontweight'] ) {
		$iva_ttm_input_fontweight = $formdata['iva_ttm_input_fontweight'];
	}
	if ( isset( $formdata['iva_ttm_input_borderradius'] ) && '' != $formdata['iva_ttm_input_borderradius'] ) {
		$iva_ttm_input_borderradius = $formdata['iva_ttm_input_borderradius'];
	}
	if ( isset( $formdata['iva_ttm_smsg_fontsize'] ) && '' != $formdata['iva_ttm_smsg_fontsize'] ) {
		$iva_ttm_smsg_fontsize = $formdata['iva_ttm_smsg_fontsize'];
	}
	if ( isset( $formdata['iva_ttm_smsg_fontweight'] ) && '' != $formdata['iva_ttm_smsg_fontweight'] ) {
		$iva_ttm_smsg_fontweight = $formdata['iva_ttm_smsg_fontweight'];
	}
	if ( isset( $formdata['iva_ttm_smsg_bgcolor'] ) && '' != $formdata['iva_ttm_smsg_bgcolor'] ) {
		$iva_ttm_smsg_bgcolor = $formdata['iva_ttm_smsg_bgcolor'];
	}
	if ( isset( $formdata['iva_ttm_smsg_bordercolor'] ) && '' != $formdata['iva_ttm_smsg_bordercolor'] ) {
		$iva_ttm_smsg_bordercolor = $formdata['iva_ttm_smsg_bordercolor'];
	}
	if ( isset( $formdata['iva_ttm_smsg_fontfamily'] ) && '' != $formdata['iva_ttm_smsg_fontfamily'] ) {
		$iva_ttm_smsg_fontfamily = $formdata['iva_ttm_smsg_fontfamily'];
	}
	if ( isset( $formdata['iva_ttm_btn_fontsize'] ) && '' != $formdata['iva_ttm_btn_fontsize'] ) {
		$iva_ttm_btn_fontsize = $formdata['iva_ttm_btn_fontsize'];
	}
	if ( isset( $formdata['iva_ttm_btn_fontfamily'] ) && '' != $formdata['iva_ttm_btn_fontfamily'] ) {
		$iva_ttm_btn_fontfamily = $formdata['iva_ttm_btn_fontfamily'];
	}
	if ( isset( $formdata['iva_ttm_btn_fontweight'] ) && '' != $formdata['iva_ttm_btn_fontweight'] ) {
		$iva_ttm_btn_fontweight = $formdata['iva_ttm_btn_fontweight'];
	}
	if ( isset( $formdata['iva_ttm_btn_borderradius'] ) && '' != $formdata['iva_ttm_btn_borderradius'] ) {
		$iva_ttm_btn_borderradius = $formdata['iva_ttm_btn_borderradius'];
	}
	if ( isset( $formdata['iva_ttm_notificationemail'] ) && '' != $formdata['iva_ttm_notificationemail'] ) {
		$iva_ttm_notificationemail = $formdata['iva_ttm_notificationemail'];
	}
	if ( isset( $formdata['iva_ttm_emailto'] ) && '' != $formdata['iva_ttm_emailto'] ) {
		$iva_ttm_emailto = $formdata['iva_ttm_emailto'];
	}
	if ( isset( $formdata['iva_ttm_emailsubject'] ) && '' != $formdata['iva_ttm_emailsubject'] ) {
		$iva_ttm_emailsubject = $formdata['iva_ttm_emailsubject'];
	}
	if ( isset( $formdata['iva_ttm_emailid'] ) && '' != $formdata['iva_ttm_emailid'] ) {
		$iva_ttm_emailid = $formdata['iva_ttm_emailid'];
	}
	if ( isset( $formdata['iva_ttm_emailmessage'] ) && '' != $formdata['iva_ttm_emailmessage'] ) {
		$iva_ttm_emailmessage = $formdata['iva_ttm_emailmessage'];
	}
	if ( isset( $formdata['iva_ttm_headersmsg'] ) && '' != $formdata['iva_ttm_headersmsg'] ) {
		$iva_ttm_headersmsg = $formdata['iva_ttm_headersmsg'];
	}


	$iva_testimonial_settings = array(
		'iva_ttm_extracss'	  		=> $iva_ttm_extracss,
		'iva_ttm_client_name_txt'	=> $iva_ttm_client_name_txt,
		'iva_ttm_opt_client_name'	=> $iva_ttm_opt_client_name,
		'iva_ttm_req_client_name'	=> $iva_ttm_req_client_name,
		'iva_ttm_client_pic_txt'	=> $iva_ttm_client_pic_txt,
		'iva_ttm_opt_client_pic'	=> $iva_ttm_opt_client_pic,
		'iva_ttm_req_client_pic'	=> $iva_ttm_req_client_pic,
		'iva_ttm_opt_grav_email'	=> $iva_ttm_opt_grav_email,
		'iva_ttm_grav_email_txt'	=> $iva_ttm_grav_email_txt,
		'iva_ttm_req_gravatar'		=> $iva_ttm_req_gravatar,
		'iva_ttm_req_upload_pic'	=> $iva_ttm_req_upload_pic,
		'iva_ttm_client_job_txt'	=> $iva_ttm_client_job_txt,
		'iva_ttm_opt_client_job'	=> $iva_ttm_opt_client_job,
		'iva_ttm_req_client_job'	=> $iva_ttm_req_client_job,
		'iva_ttm_client_email_txt'	=> $iva_ttm_client_email_txt,
		'iva_ttm_opt_client_email'	=> $iva_ttm_opt_client_email,
		'iva_ttm_req_client_email'	=> $iva_ttm_req_client_email,
		'iva_ttm_cmpny_name_txt'	=> $iva_ttm_cmpny_name_txt,
		'iva_ttm_opt_cmpny_name'	=> $iva_ttm_opt_cmpny_name,
		'iva_ttm_req_cmpny_name'	=> $iva_ttm_req_cmpny_name,
		'iva_ttm_cmpny_url_txt'		=> $iva_ttm_cmpny_url_txt,
		'iva_ttm_opt_cmpny_url'		=> $iva_ttm_opt_cmpny_url,
		'iva_ttm_req_cmpny_url'		=> $iva_ttm_req_cmpny_url,
		'iva_ttm_ratings_txt'		=> $iva_ttm_ratings_txt,
		'iva_ttm_opt_ratings'		=> $iva_ttm_opt_ratings,
		'iva_ttm_req_ratings'		=> $iva_ttm_req_ratings,
		'iva_ttm_client_desc_txt'	=> $iva_ttm_client_desc_txt,
		'iva_ttm_opt_client_desc'	=> $iva_ttm_opt_client_desc,
		'iva_ttm_req_client_desc'	=> $iva_ttm_req_client_desc,
		'iva_ttm_opt_captcha'		=> $iva_ttm_opt_captcha,
		'iva_testimonial_slug'		=> $iva_testimonial_slug,
		'iva_ttm_fontsize'			=> $iva_ttm_fontsize,
		'iva_ttm_content_color'		=> $iva_ttm_content_color,
		'iva_ttm_title_color'		=> $iva_ttm_title_color,
		'iva_ttm_job_color'			=> $iva_ttm_job_color,
		'iva_ttm_company_color'		=> $iva_ttm_company_color,
		'iva_ttm_bg_color'			=> $iva_ttm_bg_color,
		'iva_ttm_blockquote_color'	=> $iva_ttm_blockquote_color,
		'iva_ttm_spltitle_color'	=> $iva_ttm_spltitle_color,
		'iva_ttm_ratings_color'		=> $iva_ttm_ratings_color,
		'iva_ttm_input_fontcolor'	=> $iva_ttm_input_fontcolor,
		'iva_ttm_input_bordercolor'	=> $iva_ttm_input_bordercolor,
		'iva_ttm_input_bgcolor'		=> $iva_ttm_input_bgcolor,
		'iva_ttm_button_fontcolor'	=> $iva_ttm_button_fontcolor,
		'iva_ttm_button_bordercolor'=> $iva_ttm_button_bordercolor,
		'iva_ttm_button_bgcolor'	=> $iva_ttm_button_bgcolor,
		'iva_ttm_button_hover_fontcolor' => $iva_ttm_button_hover_fontcolor,
		'iva_ttm_button_hover_bordercolor' => $iva_ttm_button_hover_bordercolor,
		'iva_ttm_button_hover_bgcolor' => $iva_ttm_button_hover_bgcolor,
		'iva_ttm_button_text'		 => $iva_ttm_button_text,
		'iva_ttm_smsg_fontcolor'	=> $iva_ttm_smsg_fontcolor,
		'iva_ttm_input_fontsize'	=> $iva_ttm_input_fontsize,
		'iva_ttm_input_fontfamily'	=> $iva_ttm_input_fontfamily,
		'iva_ttm_input_fontweight'	=> $iva_ttm_input_fontweight,
		'iva_ttm_input_borderradius' => $iva_ttm_input_borderradius,
		'iva_ttm_smsg_fontsize'		=> $iva_ttm_smsg_fontsize,
		'iva_ttm_smsg_fontweight'	=> $iva_ttm_smsg_fontweight,
		'iva_ttm_smsg_bgcolor'		=> $iva_ttm_smsg_bgcolor,
		'iva_ttm_smsg_bordercolor'	=> $iva_ttm_smsg_bordercolor,
		'iva_ttm_smsg_fontfamily'	=> $iva_ttm_smsg_fontfamily,
		'iva_ttm_btn_fontsize'		=> $iva_ttm_btn_fontsize,
		'iva_ttm_btn_fontfamily'	=> $iva_ttm_btn_fontfamily,
		'iva_ttm_btn_fontweight'	=> $iva_ttm_btn_fontweight,
		'iva_ttm_btn_borderradius'	=> $iva_ttm_btn_borderradius,
		'iva_ttm_notificationemail'	=> $iva_ttm_notificationemail,
		'iva_ttm_emailto'			=> $iva_ttm_emailto,
		'iva_ttm_emailsubject'		=> $iva_ttm_emailsubject,
		'iva_ttm_emailmessage'		=> $iva_ttm_emailmessage,
		'iva_ttm_headersmsg'		=> $iva_ttm_headersmsg,
		'iva_ttm_emailid'			=> $iva_ttm_emailid,
	);

	foreach ( $iva_testimonial_settings as $key => $value ) {
		if ( isset( $value ) ) {
			update_option( $key, $value );
		}
	}
	update_option( 'iva_ttm_upload_image', $iva_ttm_upload_image );

	$response = '<div id="iva_ttm_msg" class="updated notice success is-dismissible clearfix"><p>' . esc_html__( 'Settings updated successfully!', 'iva_testimonial_pro' ) . '</p><button class="notice-dismiss" type="button"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
	echo wp_kses_post( $response );
	wp_die();
}

//
if ( ! function_exists( 'iva_ttm_get_attachment_id_from_src' ) ) {
	function iva_ttm_get_attachment_id_from_src( $image_src ) {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE guid = %s", $image_src ) );
		return $id;
	}
}

// iva_ttm_resize function
if ( ! function_exists( 'iva_ttm_resize' ) ) {
	function iva_ttm_resize( $ivapostid = null, $src = null, $width, $height, $class = null, $alt = null ) {
		$title = $ivapostid ? get_the_title( $ivapostid ) :'';

		if ( $class ) {
			$class = ' class="' . $class . '"';
		}
		if ( $alt ) {
			$alt_txt = ' alt="' . $alt . '"';
		} else {
		    $alt_txt = ' alt="' . $title . '"';
		}
		if ( '' == $src ) {
			$imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $ivapostid ), 'full', false, '' );
			$src = $imagesrc[0];
		}
		$out = '';
		$image = iva_ttm_aq_resize( $src, $width, $height, true );
		if ( '' != $image ) {
			$out .= '<img  ' . $class . ' ' . $alt_txt . ' src="' . $image . '">';
		}
		return  $out;
	}
}
// iva_ttm_aq_resize function
if ( ! function_exists( 'iva_ttm_aq_resize' ) ) {
	function iva_ttm_aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

		//define upload path & dir
		$upload_info = wp_upload_dir();
		$upload_dir = $upload_info['basedir'];
		$upload_url = $upload_info['baseurl'];

		$http_prefix = "http://";
		$https_prefix = "https://";

		 /* if the $url scheme differs from $upload_url scheme, make them match
		if the schemes differe, images don't show up. */
		if ( ! strncmp( $url, $https_prefix, strlen( $https_prefix ) ) ) {
 			$upload_url = str_replace( $http_prefix, $https_prefix,$upload_url );
		} elseif ( ! strncmp( $url, $http_prefix, strlen( $http_prefix ) ) ) {
			$upload_url = str_replace( $https_prefix, $http_prefix, $upload_url );
		}

		//check if $img_url is local
		if ( strpos( $url, $upload_url ) === false ) {
			return false;
		}

		//define path of image
		$rel_path = str_replace( $upload_url, '', $url );
		$img_path = $upload_dir . $rel_path;

		//check if img path exists, and is an image indeed
		if ( ! file_exists( $img_path ) or ! getimagesize( $img_path ) ) {
			return false;
		}

		//get image info
		$info = pathinfo( $img_path );
		$ext = @$info['extension'];
		list( $orig_w,$orig_h ) = @getimagesize( $img_path );

		//get image size after cropping
		$dims = image_resize_dimensions( $orig_w, $orig_h, $width, $height, $crop );
		$dst_w = $dims[4];
		$dst_h = $dims[5];

		//use this to check if cropped image already exists, so we can return that instead
		$suffix = "{$dst_w}x{$dst_h}";
		$dst_rel_path = str_replace( '.' . $ext, '', $rel_path );
		$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

		if ( ! $dst_h ) {
			//can't resize, so return original url
			$img_url = $url;
			$dst_w = $orig_w;
			$dst_h = $orig_h;
		} elseif ( file_exists( $destfilename ) && getimagesize( $destfilename ) ) {
			//else check if cache exists
			$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
		} else {
			// else, we resize the image and return the new resized image url
			// Note: This pre-3.5 fallback check will edited out in subsequent version
			$editor = wp_get_image_editor( $img_path );
			if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) ) {
				return false;
			}

			$resized_file = $editor->save();

			if ( ! is_wp_error( $resized_file ) ) {
				$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path'] );
				$img_url = $upload_url . $resized_rel_path;
			} else {
				return false;
			}
		}

		//returns output
		if ( $single ) {
			//str return
			$image = $img_url;
		} else {
			//array return
			$image = array(
				0 => $img_url,
				1 => $dst_w,
				2 => $dst_h,
			);
		}
		return $image;
	}
}

//Add custom links to row actions in WordPress
add_filter( 'post_row_actions', 'iva_ttm_post_id', 10, 1 );
function iva_ttm_post_id( $actions ) {
	global $post;
	if ( 'page' != $post->post_type || 'post' != $post->post_type ) {
		$actions['itemid'] = 'ID: ' . $post->ID;
	}
	return $actions;
}

// P A G I N A T I O N
//--------------------------------------------------------
if ( ! function_exists( 'iva_ttm_pagination' ) ) {
	function iva_ttm_pagination( $pages = '', $range = 2 ) {
		$showitems = ( $range * 2 ) + 1;

		global $wp_query;

		if ( get_query_var( 'paged' ) ) {
			$paged = get_query_var( 'paged' );
		} elseif ( get_query_var( 'page' ) ) {
			$paged = get_query_var( 'page' );
		} else {
			$paged = 1;
		}

		if ( empty( $paged ) ) {
			$paged = 1;
		}
		if ( '' == $pages ) {
			$pages = $wp_query->max_num_pages;
			if ( ! $pages ) {
				$pages = 1;
			}
		}
		$out = '';
		if ( 1 != $pages ) {
			$out .= '<div class="pagination">';
			$out .= '<span class="pages extend">';
			$out .= 'Page ' . $paged . ' of ' . $pages;
			$out .= '</span>';

			if ( $paged > 2 && $paged > $range + 1 && $showitems < $pages ) {
				$out .= "<a href='" . get_pagenum_link( 1 ) . "'>&laquo;</a>";
			}
			if ( $paged > 1 && $showitems < $pages ) {
				$out .= "<a href='" . get_pagenum_link( $paged - 1 ) . "'>&lsaquo;</a>";
			}
			for ( $i = 1; $i <= $pages; $i++ ) {
				if ( 1 != $pages && ( ! ($i >= $paged + $range + 1 || $i <= $paged -$range -1) || $pages <= $showitems ) ) {
					$out .= ( $paged == $i )? "<span class='current'>" . $i . "</span>":"<a href='" . get_pagenum_link( $i ) . "' class='inactive' >" . $i . "</a>";
				}
			}
			if ( $paged < $pages && $showitems < $pages ) {
				$out .= "<a href='" . get_pagenum_link( $paged + 1 ) . "'>&rsaquo;</a>";
			}
			if ( $paged < $pages -1 &&  $paged + $range - 1 < $pages && $showitems < $pages ) {
				$out .= "<a href='" . get_pagenum_link( $pages ) . "'>&raquo;</a>";
			}
				$out .= "</div>\n";
		}
		return $out;
	}
}
// Custom CSS
function iva_ttm_style() {
	$iva_ttm_extracss = get_option( 'iva_ttm_extracss' ) ? stripslashes( get_option( 'iva_ttm_extracss' ) ) : '';
	if ( '' != $iva_ttm_extracss ) {
		echo '<style type="text/css">';
		echo wp_kses_post( $iva_ttm_extracss );
		echo '</style>';
	}
}
add_action( 'wp_head', 'iva_ttm_style', 100 );

//------------------------------------------------------------------
function ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $postid ) {
	global $post;
	$out = '';
	if ( '' != $client_gravatar_image && 'on' == $iva_ttm_clientpic ) {
		$iva_ttm_layouts = get_post_meta( $postid, 'iva_ttm_layouts', true );
		$iva_ttm_g_layouts = get_post_meta( $postid, 'iva_ttm_g_layouts', true );
		if ( 'v6-a' == $iva_ttm_layouts || 'v7' == $iva_ttm_layouts || 'v6-a' == $iva_ttm_g_layouts || 'v7' == $iva_ttm_g_layouts ) {
			$out .= '<div class="at-adv-ttm-image">';
			$out .= $client_gravatar_image;
			$out .= '</div>';
		}
		if ( 'v1-b' === $iva_ttm_layouts || 'v1-c' === $iva_ttm_layouts || 'v2-b' === $iva_ttm_layouts || 'v3-b' === $iva_ttm_layouts || 'v4-b' === $iva_ttm_layouts || 'v5-b' === $iva_ttm_layouts || 'v8-a' === $iva_ttm_layouts ) {
			$out .= $client_gravatar_image;
		}
		if ( 'v1-b' === $iva_ttm_g_layouts || 'v1-c' === $iva_ttm_g_layouts || 'v2-b' === $iva_ttm_g_layouts || 'v3-b' === $iva_ttm_g_layouts || 'v4-b' === $iva_ttm_g_layouts || 'v5-b' === $iva_ttm_g_layouts || 'v8-a' === $iva_ttm_g_layouts ) {
			$out .= $client_gravatar_image;
		}
	}
	return $out;
}
function ttm_content( $iva_ttm_content, $testimonial_content, $postid ) {
	global $post;

	$out = $iva_ttm_content_color = $iva_ttm_bg_color = $iva_ttm_fontsize = '';
	if ( get_post_meta( $postid, 'iva_ttm_content_color', true ) ) {
		$iva_ttm_content_color 	= get_post_meta( $postid, 'iva_ttm_content_color', true );
	} elseif ( get_option( 'iva_ttm_content_color' ) ) {
		$iva_ttm_content_color 	= get_option( 'iva_ttm_content_color' ) ? get_option( 'iva_ttm_content_color' ) : '';
	}
	$ttm_content_color 		= $iva_ttm_content_color ? 'color: ' . $iva_ttm_content_color . ';' : '';

	if ( get_post_meta( $postid, 'iva_ttm_fontsize', true ) ) {
		$iva_ttm_fontsize 	= get_post_meta( $postid, 'iva_ttm_fontsize', true );
	} elseif ( get_option( 'iva_ttm_fontsize' ) ) {
		$iva_ttm_fontsize 	= get_option( 'iva_ttm_fontsize' ) ? get_option( 'iva_ttm_fontsize' ) : '';
	}
	$ttm_fontsize  = $iva_ttm_fontsize ? 'font-size:' . $iva_ttm_fontsize . ';' : '';

	if ( get_post_meta( $postid, 'iva_ttm_bg_color', true ) ) {
		$iva_ttm_bg_color 	= get_post_meta( $postid, 'iva_ttm_bg_color', true );
	} elseif ( get_option( 'iva_ttm_bg_color' ) ) {
		$iva_ttm_bg_color 	= get_option( 'iva_ttm_bg_color' ) ? get_option( 'iva_ttm_bg_color' ) : '';
	}
	$ttm_bg_color 			= $iva_ttm_bg_color ? 'background-color: ' . $iva_ttm_bg_color . '!important;' : '';
	$ttm_bg_color_css	    = ( $iva_ttm_bg_color || $iva_ttm_content_color || $iva_ttm_fontsize ) ? ' style="' . $ttm_bg_color . $ttm_content_color . $ttm_fontsize . '"' : '' ;
	$ttm_content_color_css	= ( $iva_ttm_content_color || $iva_ttm_fontsize ) ? ' style="' . $ttm_content_color . $ttm_fontsize . '"' : '' ;

	if ( 'on' == $iva_ttm_content && '' != $testimonial_content ) {
		$iva_ttm_layouts = get_post_meta( $postid, 'iva_ttm_layouts', true );
		$iva_ttm_g_layouts = get_post_meta( $postid, 'iva_ttm_g_layouts', true );
		if ( 'v8-a' === $iva_ttm_layouts || 'v8-b' === $iva_ttm_layouts ||'v8-a' === $iva_ttm_g_layouts || 'v8-b' === $iva_ttm_g_layouts ) {
			$out .= '<p ' . $ttm_bg_color_css . '>' . $testimonial_content . '<span class="arrow" ' . $ttm_bg_color_css . '></span></p>';
		} elseif ( 'v6-a' === $iva_ttm_layouts || 'v6-b' === $iva_ttm_layouts ) {
			$out .= '<p ' . $ttm_bg_color_css . '>' . $testimonial_content . '</p>';
		} else {
			$out .= '<p ' . $ttm_content_color_css . '>' . $testimonial_content . '</p>';
		}
	}
	return $out;
}
function ttm_client_title( $iva_ttm_title, $client_title, $postid ) {
	$out = $iva_ttm_title_color = '';
	if ( get_post_meta( $postid, 'iva_ttm_title_color', true ) ) {
		$iva_ttm_title_color 	= get_post_meta( $postid, 'iva_ttm_title_color', true );
	} elseif ( get_option( 'iva_ttm_title_color' ) ) {
		$iva_ttm_title_color 	= get_option( 'iva_ttm_title_color' ) ? get_option( 'iva_ttm_title_color' ) : '';
	}
	$iva_ttm_title_color = $iva_ttm_title_color ? 'color: ' . $iva_ttm_title_color . ';' : '';
	$ttm_title_color 	 = ( $iva_ttm_title_color ) ? ' style="' . $iva_ttm_title_color . '"' : '' ;
	if ( 'on' == $iva_ttm_title ) {
		$out .= '<span class="name" ' . $ttm_title_color . '>';
		$out .= $client_title;
		$out .= '</span>';
	}
	return $out;
}
function ttm_client_job( $iva_ttm_clientjob, $client_job, $postid ) {
	$out = $iva_ttm_job_color = '';
	if ( get_post_meta( $postid, 'iva_ttm_job_color', true ) ) {
		$iva_ttm_job_color 	= get_post_meta( $postid, 'iva_ttm_job_color', true );
	} elseif ( get_option( 'iva_ttm_job_color' ) ) {
		$iva_ttm_job_color 	= get_option( 'iva_ttm_job_color' ) ? get_option( 'iva_ttm_job_color' ) : '';
	}
	$iva_ttm_job_color = $iva_ttm_job_color ? 'color: ' . $iva_ttm_job_color . ';' : '';
	$ttm_job_color 	   = ( $iva_ttm_job_color ) ? ' style="' . $iva_ttm_job_color . '"' : '' ;
	if ( 'on' == $iva_ttm_clientjob ) {
		$out .= '<span class="caption" ' . $ttm_job_color . '>';
		$out .= $client_job;
		$out .= '</span>';
	}
	return $out;
}
function ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $post ) {
	$out = '';
	if ( '' != $company_url && 'on' == $iva_ttm_cmpnyname && 'on' == $iva_ttm_cmpnyurl ) {
		$out .= '<span class="company">';
		$out .= $before . $company_name . $after;
		$out .= '</span>';
	} elseif ( 'on' == $iva_ttm_cmpnyname ) {
		$out .= '<span class="company">';
		$out .= $company_name;
		$out .= '</span>';
	}
	return $out;
}
function ttm_client_ratings( $client_ratings, $iva_ttm_clientratings ) {
	$out = '';
	if ( '' != $client_ratings && 'on' == $iva_ttm_clientratings ) {
	    $out .= '<div class="at-ttm-ratings" data-rated=' . $client_ratings . '>';
		$out .= '<i class="star_1 atmpro_star"></i>';
		$out .= '<i class="star_2 atmpro_star"></i>';
		$out .= '<i class="star_3 atmpro_star"></i>';
		$out .= '<i class="star_4 atmpro_star"></i>';
		$out .= '<i class="star_5 atmpro_star"></i>';
	    $out .= '</div>';//.at-ttm-ratings
	}
	return $out;
}

// Function that outputs the contents of the dashboard widget
function iva_ttm_dashboard_widget( $post, $callback_args ) {
	$iva_ttm_count_posts = wp_count_posts( 'iva_testimonial' );
	$out = $result_text = '';

	if ( wp_count_posts( 'iva_testimonial' )->pending > 1 ) {
		$result_text = esc_html__( 'There are', 'iva_testimonial_pro' ) .' <b><a href="' . admin_url( 'edit.php?post_status=pending&post_type=iva_testimonial' ) . '" style="color:#d64e07;" >' . wp_count_posts( 'iva_testimonial' )->pending . ' ' . esc_html__( 'pending', 'iva_testimonial_pro' ) . ' </a></b> ' . esc_html__( 'testimonials.', 'iva_testimonial_pro' );
	} elseif ( wp_count_posts( 'iva_testimonial' )->pending == 1 ) {
		$result_text = esc_html__( 'There is', 'iva_testimonial_pro' ) . ' <b><a href="' . admin_url( 'edit.php?post_status=pending&post_type=iva_testimonial' ) . '" style="color:#d64e07;" >' . wp_count_posts( 'iva_testimonial' )->pending . ' ' . esc_html__( 'pending', 'iva_testimonial_pro' ) . '</a></b> ' . esc_html__( 'testimonial.', 'iva_testimonial_pro' );
	} else {
		$result_text = esc_html__( 'No pending testimonials found.', 'iva_testimonial_pro' );
	}
	$out .= $result_text;

	$args = array(
			'post_type' 		=> 'iva_testimonial',
			'post_status' 		=> 'pending',
			'posts_per_page' 	=> 3,
			'suppress_filters' 	=> true,
		);

	$iva_ttm_query = new WP_Query( $args );
	if ( $iva_ttm_query->have_posts() ) {
		$i = 0;
		while ( $i < $iva_ttm_query->post_count ) {
			$post = $iva_ttm_query->posts;
			$thumbnailsrc = $company_name = $company_url = $client_job = $after = $before = '';

			// if has post thumbnail
			if ( has_post_thumbnail( $post[ $i ]->ID ) ) {
				$thumbnailsrc = iva_ttm_resize( $post[ $i ]->ID, '', '70', '70', 'imageborder', '' );
			}
			$company_url 	= get_post_meta( $post[ $i ]->ID, 'company_url', true );
			$company_name 	= get_post_meta( $post[ $i ]->ID, 'company_name', true );
			$client_job 	= get_post_meta( $post[ $i ]->ID, 'client_job', true );
			if ( $company_url) {
				$after = '<a href="' . esc_url( $company_url ) . '" target="_blank" >';
				$before = '</a>';
			}

			$content = $post[ $i ]->post_content;
			$out .= '<div class="iva_ttm_pending_testimonial">';
			$out .= '<div class="iva_ttm_pending_img">' . $thumbnailsrc . '</div>';
			$out .= '<div class="iva_ttm_pending_title"><strong>' . get_the_title( $post[ $i ]->ID ) . '</strong></div>';
			$out .= '<div class="iva_ttm_pending_text">' . substr( $content, 0, 100 ) . '</div>';
			$out .= '<div class="iva_ttm_pending_details">' . $after . $company_name. $before;
			if ( $company_name && $client_job ) {
				$out .= '/';
			}
			if ( $client_job ) {
				$out .= $client_job;
			}
			$out .= '</div>';
			$out .= '<div class="iva_ttm_pending_status">' . get_post_meta( $post[ $i ]->ID, 'post_status', true ) . '<span class="iva_ttm_pending_date">' . $post[ $i ]->post_date . '</span></div>';
			$out .= '<a class="iva_ttm_pending_edit" href="' . admin_url( 'post.php?post=' . $post[ $i ]->ID . '&action=edit' ) . '">' . esc_html__( 'Edit', 'iva_testimonial_pro' ) . '</a>';
			$out .= '</div>';
			$i++;
		}
	}

	$out .= '<div id="iva_ttm_pending_link"><a href="' . admin_url( 'edit.php?post_status=pending&post_type=iva_testimonial&order_by=date&order=DESC' ) . '">' . esc_html__( 'View all pending testimonials.', 'iva_testimonial_pro' ) . '</a></div>';
	$out .= '<div id="iva_ttm_status_list">';
	$out .= '<span><a href="' . admin_url( 'edit.php?post_status=publish&post_type=iva_testimonial' ) . '">' . esc_html__( 'Published', 'iva_testimonial_pro' ) . '</a> ( ' . $iva_ttm_count_posts->publish . ' )</span>';
	$out .= '<span><a href="' . admin_url( 'edit.php?post_status=pending&post_type=iva_testimonial' ) . '">' . esc_html__( 'Pending', 'iva_testimonial_pro' ) .'</a> ( ' . $iva_ttm_count_posts->pending . ' )</span>';
	$out .= '<span><a href="' . admin_url( 'edit.php?post_status=draft&post_type=iva_testimonial' ) . '">' . esc_html__( 'Draft', 'iva_testimonial_pro' ) . '</a> ( ' . $iva_ttm_count_posts->draft . ' )</span>';
	$out .= '</div>';
	echo $out;
}
// Function used in the action hook
function iva_ttm_add_dashboard_widget() {
	wp_add_dashboard_widget( 'dashboard_widget', 'Pending Testimonials', 'iva_ttm_dashboard_widget' );
}

// Register the new dashboard widget with the 'wp_dashboard_setup' action
add_action( 'wp_dashboard_setup', 'iva_ttm_add_dashboard_widget' );

add_filter( 'rwmb_meta_boxes', 'your_prefix_meta_boxes' );
function your_prefix_meta_boxes( $meta_boxes ) {
    $meta_boxes[] = array(
        'title'      => __( 'Test Meta Box', 'textdomain' ),
        'post_types' => 'post',
        'fields'     => array(
            array(
                'id'   => 'name',
                'name' => __( 'Name', 'textdomain' ),
                'type' => 'text',
            ),
            array(
                'id'      => 'gender',
                'name'    => __( 'Gender', 'textdomain' ),
                'type'    => 'radio',
                'options' => array(
                    'm' => __( 'Male', 'textdomain' ),
                    'f' => __( 'Female', 'textdomain' ),
                ),
            ),
            array(
                'id'   => 'email',
                'name' => __( 'Email', 'textdomain' ),
                'type' => 'email',
            ),
            array(
                'id'   => 'bio',
                'name' => __( 'Biography', 'textdomain' ),
                'type' => 'textarea',
            ),
        ),
    );
    return $meta_boxes;
}
