<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
if ( ! function_exists( 'iva_single_tesimonial' ) ) {
	function iva_single_tesimonial( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'id'				=> '',
			'name'				=> '',
			'iva_ttm_title' 	=> 'on',
			'iva_ttm_clientpic' => 'on',
			'iva_ttm_gravatar'	=> 'on',
			'iva_ttm_content' 	=> 'on',
			'iva_ttm_clientjob' => 'on',
			'iva_ttm_cmpnyname' => 'on',
			'iva_ttm_cmpnyurl' 	=> 'on',
			'iva_ttm_clientratings'	=> 'on',
		), $atts ) );
		global $post;
		$out = $before = $after = '';

		if ( $id ) {
			$ttm_post = get_post( $id );
		}

		$client_image_option  = get_post_meta( $id, 'client_image_option', true );
		$client_job			  = get_post_meta( $id, 'client_job', true );
		$company_name		  = get_post_meta( $id, 'company_name', true );
		$company_url		  = get_post_meta( $id, 'company_url', true );
		$client_ratings		  = get_post_meta( $id, 'client_ratings', true );
		$special_title		  = get_post_meta( $id, 'special_title', true );
		$testimonial_content  = $ttm_post->post_content;
		$client_title 		  = $ttm_post->post_title;

		// Styling Options 
		$iva_ttm_fontsize  			= get_post_meta( $id, 'iva_ttm_fontsize', true );
		$iva_ttm_content_color  	= get_post_meta( $id, 'iva_ttm_content_color', true );
		$iva_ttm_title_color  		= get_post_meta( $id, 'iva_ttm_title_color', true );
		$iva_ttm_job_color  		= get_post_meta( $id, 'iva_ttm_job_color', true );
		$iva_ttm_bg_color  			= get_post_meta( $id, 'iva_ttm_bg_color', true );
		$iva_ttm_ratings_color  	= get_post_meta( $id, 'iva_ttm_ratings_color', true );
		$iva_ttm_layouts		  	= get_post_meta( $id, 'iva_ttm_layouts', true ) ? get_post_meta( $id, 'iva_ttm_layouts', true ) : 'v1-a';

		$iva_ttm_upload_image = get_option( 'iva_ttm_upload_image' ) ? get_option( 'iva_ttm_upload_image' ) : '';
		$testimonial_email = get_post_meta( $post->ID, 'gravatar_email', true );

		if ( has_post_thumbnail( $id ) ) {
			$client_gravatar_image = iva_ttm_resize( $id, '', '', '', 'imageborder', '' );
		} elseif ( ! empty( $testimonial_email ) ) {
			$client_gravatar_image = get_avatar( $testimonial_email, 70 );
		} else {
			if ( ! empty( $iva_ttm_upload_image ) ) {
				$client_gravatar_image = '<img src="' . $iva_ttm_upload_image . '" alt="img" class="imageborder"/>';
			} else {
				$client_gravatar_image = '<img src="' . IVA_TTM_CPT_URI . 'assets/images/image-1.png" alt="img"/>';
			}
		}
		if ( '' == $iva_ttm_layouts ) {
			$iva_ttm_layouts = get_post_meta( $id, 'iva_ttm_layouts', true ) ? get_post_meta( $id, 'iva_ttm_layouts', true ) : 'v1-a';
		}
		$iva_ttm_company_color = get_option( 'iva_ttm_company_color' ) ? get_option( 'iva_ttm_company_color' ) : '';
		$iva_ttm_company_color = $iva_ttm_company_color ? 'color: ' . $iva_ttm_company_color . ';' : '';
		$ttm_company_color 	   = ( $iva_ttm_company_color ) ? ' style="' . $iva_ttm_company_color . '"' : '' ;

		$iva_ttm_spltitle_color = get_option( 'iva_ttm_spltitle_color' ) ? get_option( 'iva_ttm_spltitle_color' ) : '';
		$iva_ttm_spltitle_color = $iva_ttm_spltitle_color ? 'color: ' . $iva_ttm_spltitle_color . ';' : '';
		$ttm_spltitle_color 	= ( $iva_ttm_spltitle_color ) ? ' style="' . $iva_ttm_spltitle_color . '"' : '' ;

		$iva_ttm_blockquote_color = get_option( 'iva_ttm_blockquote_color' ) ? get_option( 'iva_ttm_blockquote_color' ) : '';
		$iva_ttm_blockquote_color = $iva_ttm_blockquote_color ? 'color: ' . $iva_ttm_blockquote_color . ';' : '';
		$ttm_blockquote_color_css = ( $iva_ttm_blockquote_color ) ? ' style="' . $iva_ttm_blockquote_color . '"' : '' ;

		$out .= '<div class="at-adv-ttm-' . $iva_ttm_layouts . '">';
		if ( 'v1-a' === $iva_ttm_layouts || 'v1-b' === $iva_ttm_layouts || 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
			if ( 'v1-b' === $iva_ttm_layouts ) {
				$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			}
			if ( 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
				$out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left fa-fw"></i>';
			}
			$out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
			if ( 'v1-c' === $iva_ttm_layouts ) {
			   	$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			}
			$out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
			$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v2-a' === $iva_ttm_layouts ) {
			$out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
			$out .= '<div class="author">';
			$out .= ttm_client_title( $iva_ttm_title, $client_title, $id );
			$out .= ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
			$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			$out .= '</div>';
		}
		if ( 'v2-b' === $iva_ttm_layouts ) {
			$out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
			$out .= '<div class="author with-image">';
			$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			$out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
			$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		    $out .= '</div>';
		}
		if ( 'v3-a' === $iva_ttm_layouts || 'v3-b' === $iva_ttm_layouts ) {
			$out .= '<i class="fa fa-quote-left v3-a"></i>';
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
			$out .= '<i class="fa fa-quote-right v3-a"></i>';
		    if ( 'v3-b' === $iva_ttm_layouts ) {
				$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			}
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v4-a' === $iva_ttm_layouts || 'v4-b' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    if ( 'v4-b' === $iva_ttm_layouts ) {
				$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			}
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v5-a' === $iva_ttm_layouts || 'v5-b' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    if ( 'v5-b' === $iva_ttm_layouts ) {
				$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
			}
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v6-a' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v6-b' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v7' === $iva_ttm_layouts ) {
			$out .= '<div class="at-adv-ttm-content">';
			$out .= '<h3 ' . $ttm_spltitle_color . '>' . $special_title . '</h3>';
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id );
		    $out .= ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		    $out .= '</div>';
		    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
		}
		if ( 'v8-a' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $id );
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		if ( 'v8-b' === $iva_ttm_layouts ) {
		    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $id );
		    $out .= ttm_client_title( $iva_ttm_title, $client_title, $id ) . ttm_client_job( $iva_ttm_clientjob, $client_job, $id );
		    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
			$after .= '</a>';
		    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after, $id );
		    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
		}
		$out .= '</div>';

		return $out;
	}
	//End Testimonials List Function
	add_shortcode( 'single_testimonial', 'iva_single_tesimonial' );
}
function iva_single_fade_script() {
	wp_print_scripts( 'iva-frontend-script' );
}
