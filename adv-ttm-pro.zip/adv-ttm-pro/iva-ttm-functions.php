<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
function iva_ttm_sui_process_image( $file, $post_id, $caption ) {
	require_once( ABSPATH . "wp-admin" . '/includes/image.php' );
	require_once( ABSPATH . "wp-admin" . '/includes/file.php' );
	require_once( ABSPATH . "wp-admin" . '/includes/media.php' );

	if ( isset( $file ) ) {

		$attachment_id = media_handle_upload( $file, $post_id );
		update_post_meta( $post_id, '_thumbnail_id', $attachment_id );
		set_post_thumbnail( $post_id, $attachment_id );

		$attachment_data = array(
			'ID' 			=> $attachment_id,
			'post_excerpt' 	=> $caption,
		);

		wp_update_post( $attachment_data );
		$image_url = wp_get_attachment_url( $attachment_id );
		update_post_meta( $post_id,'client_photo', $image_url );
	}
	return $attachment_id;
}
/**
 * function iva_ttm_form_insert
 * function that inserts appointment form data into database and sends mail to admin email,user email
 * @param 'str' inpput string
 * @param 'arr' If the second parameter arr is present, variables are stored in this variable as array elements instead.
 * @return No value is returned.
 */
add_action( 'wp_ajax_iva_ttm_form_insert', 'iva_ttm_form_insert' );
add_action( 'wp_ajax_nopriv_iva_ttm_form_insert', 'iva_ttm_form_insert' );
function iva_ttm_form_insert() {
	check_ajax_referer( 'iva-ttm-form', 'form_nonce' );
	$postform = isset( $_POST['data'] ) ? $_POST['data'] : '';

	/**
	 * function parse_str
	 * @param 'str' inpput string
	 * @param 'arr' If the second parameter arr is present, variables are stored in this variable as array elements instead.
	 * @return No value is returned.
	 **/
	parse_str( $postform, $formdata );

	$iva_client_title = $iva_client_image_option = $iva_gravatar_email = $iva_client_photo = $iva_client_job = $iva_client_email = $iva_client_url = $iva_company_name = $iva_company_url = $iva_client_ratings = '';
	$post  = ( ! empty( $_POST ) ) ? true : false;

	$iva_client_title			= isset( $formdata['client_title'] ) ? $formdata['client_title'] : '';
	$iva_client_image_option	= isset( $formdata['client_image_option'] ) ? $formdata['client_image_option'] : '';
	$iva_gravatar_email			= isset( $formdata['gravatar_email'] ) ? $formdata['gravatar_email'] : '';
	$iva_client_job				= isset( $formdata['client_job'] ) ? $formdata['client_job'] : '';
	$iva_company_name			= isset( $formdata['company_name'] ) ? $formdata['company_name'] : '';
	$iva_company_url			= isset( $formdata['company_url'] ) ? $formdata['company_url'] : '';
	$iva_client_ratings 		= isset( $formdata['client_ratings'] ) ? $formdata['client_ratings'] : '';
	$iva_ttm_status				= isset( $formdata['client_status'] ) ? $formdata['client_status'] : '';
	$iva_ttm_desc				= isset( $formdata['client_desc'] ) ? $formdata['client_desc'] : '';
	$iva_thnq_message			= isset( $formdata['ttm_message'] ) ? $formdata['ttm_message'] : '';

	$iva_ttm_smsg_fontcolor		= get_option( 'iva_ttm_smsg_fontcolor' ) ? get_option( 'iva_ttm_smsg_fontcolor' ) : '';
	$iva_ttm_smsg_fontcolor 	= $iva_ttm_smsg_fontcolor ? 'color:' . $iva_ttm_smsg_fontcolor . ';' : '';

	$iva_ttm_smsg_fontsize		= get_option( 'iva_ttm_smsg_fontsize' ) ? get_option( 'iva_ttm_smsg_fontsize' ) : '';
	$iva_ttm_smsg_fontsize 		= $iva_ttm_smsg_fontsize ? 'font-size:' . $iva_ttm_smsg_fontsize . ';' : '';

	$iva_ttm_smsg_fontfamily	= get_option( 'iva_ttm_smsg_fontfamily' ) ? get_option( 'iva_ttm_smsg_fontfamily' ) : '';
	$iva_ttm_smsg_fontfamily 	= $iva_ttm_smsg_fontfamily ? 'font-family:' . $iva_ttm_smsg_fontfamily . ';' : '';

	$iva_ttm_smsg_fontweight	= get_option( 'iva_ttm_smsg_fontweight' ) ? get_option( 'iva_ttm_smsg_fontweight' ) : '';
	$iva_ttm_smsg_fontweight 	= $iva_ttm_smsg_fontweight ? 'font-weight:' . $iva_ttm_smsg_fontweight . ';' : '';

	$iva_ttm_smsg_bgcolor		= get_option( 'iva_ttm_smsg_bgcolor' ) ? get_option( 'iva_ttm_smsg_bgcolor' ) : '';
	$iva_ttm_smsg_bgcolor 		= $iva_ttm_smsg_bgcolor ? 'background-color:' . $iva_ttm_smsg_bgcolor . ';' : '';

	$iva_ttm_smsg_bordercolor	= get_option( 'iva_ttm_smsg_bordercolor' ) ? get_option( 'iva_ttm_smsg_bordercolor' ) : '';
	$iva_ttm_smsg_bordercolor 	= $iva_ttm_smsg_bordercolor ? 'border-color:' . $iva_ttm_smsg_bordercolor . ';' : '';

	// Success message
	$iva_ttm_message 	= $iva_thnq_message ? $iva_thnq_message : esc_html__( 'Thank you! Your testimonial is submitted.', 'iva_testimonial_pro' );
	/**
	* If error occurs display it, otherwise send the email
	*/
	if ( $iva_client_title ) {
		/**
		* Prepare and store testimonial post data and update its meta data
		*/
		$ttm_data = array(
			'post_title' 	=> $formdata['client_title'],
			'post_content' 	=> $iva_ttm_desc,
			'post_type'  	=> 'iva_testimonial',
			'post_status'	=> 'pending',
		);

		// Inserts post
		$ttm_data_id = wp_insert_post( $ttm_data );

		$ttm_fields = array(
						'client_image_option',
						'client_job',
						'company_name',
						'company_url',
						'client_ratings',
						'client_status',
				   	);

		foreach ( $ttm_fields as $ttm_field ) {
			if ( isset( $formdata[ $ttm_field ] ) ) {
			  	update_post_meta( $ttm_data_id, $ttm_field, $formdata[ $ttm_field ] );
			}
		}
		update_post_meta( $ttm_data_id, 'gravatar_email', $formdata['gravatar_email'] );
		// Image
		if ( isset( $_FILES['client_photo']['name'] ) && $_FILES['client_photo']['name'] != "" ) {
			iva_ttm_sui_process_image( 'client_photo', $ttm_data_id, $iva_client_title );
		}

		/**
		 * Headers
		 */
		$iva_ttm_headersmsg 	= get_option( 'iva_ttm_headersmsg' ) ? get_option( 'iva_ttm_headersmsg' ) : get_option( 'blogname' );
		$iva_ttm_emailto		= get_option( 'iva_ttm_emailto' ) ? get_option( 'iva_ttm_emailto' ) : '';
		$iva_ttm_emailid		= get_option( 'iva_ttm_emailid' ) ? get_option( 'iva_ttm_emailid' ) : '';
		$iva_ttm_emailsubject	= get_option( 'iva_ttm_emailsubject' ) ? get_option( 'iva_ttm_emailsubject' ) : '';
		$iva_ttm_emailmessage	= get_option( 'iva_ttm_emailmessage' ) ? get_option( 'iva_ttm_emailmessage' ) : '';

		$iva_ttm_headersmsg 	= 'From: ' . $iva_ttm_headersmsg . ' < ' .$iva_ttm_emailid. '>' . "\r\n\\";

		/**
		 * Sends mail to admin mail
		 */
		wp_mail( $iva_ttm_emailid,$iva_ttm_emailsubject, $iva_ttm_emailmessage,$iva_ttm_headersmsg );

		$response = '<div id="iva_ttm_msg" style="' . $iva_ttm_smsg_fontcolor . $iva_ttm_smsg_bgcolor . $iva_ttm_smsg_fontsize . $iva_ttm_smsg_fontfamily . $iva_ttm_smsg_fontweight . $iva_ttm_smsg_bordercolor . '" class="iva_message_box success iva-box-solid iva-box-normal clearfix"><div class="iva_message_box_content">' . $iva_ttm_message . '</div></div>';
	} else {
		/**
		 * If error occurs in validation
		 */
		$response = '<div id="iva_ttm_msg" style="' . $iva_ttm_smsg_fontcolor . $iva_ttm_smsg_bgcolor . $iva_ttm_smsg_fontsize . $iva_ttm_smsg_fontfamily . $iva_ttm_smsg_fontweight . $iva_ttm_smsg_bordercolor . '" class="iva_message_box error iva-box-solid iva-box-normal clearfix"><div class="iva_message_box_content">' . esc_html__( 'error', 'iva_testimonial_pro' ) . '</div></div>';
	}
	echo wp_kses_post( $response );

	wp_die();
}
