<?php
function iva_testimonials_submit_form() {
	register_widget( 'IVA_testimonials_submit_form' );
}
add_action( 'widgets_init', 'iva_testimonials_submit_form' );

class IVA_testimonials_submit_form extends WP_Widget {
	function __construct() {

		$widget_ops = array(
			'classname'		=> 'testimonial_sub',
			'description'	=> esc_html__( 'Testimonials Submit Form', 'iva_testimonial_pro' ),
		);

		$control_ops = array(
			'id_base' => 'testimonial_sub_form',
		);

		parent::__construct( 'testimonial_sub_form', esc_html__( 'Testimonials Form', 'iva_testimonial_pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );
		echo wp_kses_post( $before_widget );

		$ttm_thankyou_msg 	= isset( $instance['ttm_thankyou_msg'] ) ? $instance['ttm_thankyou_msg'] : esc_html__( 'Thank You', 'iva_testimonial_pro' );
		$title		  		= isset( $instance['title'] ) ? $instance['title'] : '';
		$ttm_extra_class     = isset( $instance['ttm_extra_class'] ) ? $instance['ttm_extra_class'] : '';

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title ) . esc_attr( $title ) . wp_kses_post( $after_title );
		}

		function iva_ttm_wg_random_string( $length ) {
			$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			$size = strlen( $chars );
			$str = '';
			for ( $i = 0; $i < $length; $i++ ) {
				$str .= $chars[ rand( 0, $size - 1 ) ];
			}
			return $str;
		}

		$captcha = iva_ttm_wg_random_string( 6 );

		$ctitle_reqd_mark = $grav_email_reqd_mark = $client_job_reqd_mark = $cmpny_name_reqd_mark = $cmpny_url_reqd_mark = $client_desc_reqd_mark = '';

		//
		$iva_ttm_client_name_txt	= get_option( 'iva_ttm_client_name_txt' ) ? get_option( 'iva_ttm_client_name_txt' ) : esc_html__( 'Name', 'iva_testimonial_pro' );
		$iva_ttm_grav_email_txt		= get_option( 'iva_ttm_grav_email_txt' ) ? get_option( 'iva_ttm_grav_email_txt' ): esc_html__( 'Email ID', 'iva_testimonial_pro' );
		$iva_ttm_upload_pic_txt		= get_option( 'iva_ttm_upload_pic_txt' ) ? get_option( 'iva_ttm_upload_pic_txt' ) : esc_html__( 'Upload Photo:', 'iva_testimonial_pro' );
		$iva_ttm_client_job_txt		= get_option( 'iva_ttm_client_job_txt' ) ? get_option( 'iva_ttm_client_job_txt' ) : esc_html__( 'Role', 'iva_testimonial_pro' );
		$iva_ttm_cmpny_name_txt		= get_option( 'iva_ttm_cmpny_name_txt' ) ? get_option( 'iva_ttm_cmpny_name_txt' ) : esc_html__( 'Company', 'iva_testimonial_pro' );
		$iva_ttm_cmpny_url_txt		= get_option( 'iva_ttm_cmpny_url_txt' ) ? get_option( 'iva_ttm_cmpny_url_txt' ) : esc_html__( 'Website', 'iva_testimonial_pro' );
		$iva_ttm_client_desc_txt	= get_option( 'iva_ttm_client_desc_txt' ) ? get_option( 'iva_ttm_client_desc_txt' ) : esc_html__( 'Feedback', 'iva_testimonial_pro' );
		$iva_ttm_client_pic_txt		= get_option( 'iva_ttm_client_pic_txt' ) ? get_option( 'iva_ttm_client_pic_txt' ) : esc_html__( 'Check this if you wish to use Image.', 'iva_testimonial_pro' );

		//
		$iva_ttm_opt_client_name	= get_option( 'iva_ttm_opt_client_name' ) ? get_option( 'iva_ttm_opt_client_name' ) : '';
		$iva_ttm_opt_grav_email		= get_option( 'iva_ttm_opt_grav_email' ) ? get_option( 'iva_ttm_opt_grav_email' ) : '';
		$iva_ttm_opt_client_pic		= get_option( 'iva_ttm_opt_client_pic' ) ? get_option( 'iva_ttm_opt_client_pic' ) : '';
		$iva_ttm_opt_client_job		= get_option( 'iva_ttm_opt_client_job' ) ? get_option( 'iva_ttm_opt_client_job' ) : '';
		$iva_ttm_opt_cmpny_name		= get_option( 'iva_ttm_opt_cmpny_name' ) ? get_option( 'iva_ttm_opt_cmpny_name' ) : '';
		$iva_ttm_opt_cmpny_url		= get_option( 'iva_ttm_opt_cmpny_url' ) ? get_option( 'iva_ttm_opt_cmpny_url' ) : '';
		$iva_ttm_opt_client_desc	= get_option( 'iva_ttm_opt_client_desc' ) ? get_option( 'iva_ttm_opt_client_desc' ) : '';
		$iva_ttm_opt_captcha		= get_option( 'iva_ttm_opt_captcha' ) ? get_option( 'iva_ttm_opt_captcha' ) : '';

		//
		$iva_ttm_req_client_name	= get_option( 'iva_ttm_req_client_name' ) ? get_option( 'iva_ttm_req_client_name' ) : 'on';
		$iva_ttm_req_client_pic		= get_option( 'iva_ttm_req_client_pic' ) ? get_option( 'iva_ttm_req_client_pic' ) : '';
		$iva_ttm_req_gravatar		= get_option( 'iva_ttm_req_gravatar' ) ? get_option( 'iva_ttm_req_gravatar' ) : '';
		$iva_ttm_req_upload_pic		= get_option( 'iva_ttm_req_upload_pic' ) ? get_option( 'iva_ttm_req_upload_pic' ) : 'on';
		$iva_ttm_req_client_job		= get_option( 'iva_ttm_req_client_job' ) ? get_option( 'iva_ttm_req_client_job' ) : '';
		$iva_ttm_req_cmpny_name		= get_option( 'iva_ttm_req_cmpny_name' ) ? get_option( 'iva_ttm_req_cmpny_name' ) : 'on';
		$iva_ttm_req_cmpny_url		= get_option( 'iva_ttm_req_cmpny_url' ) ? get_option( 'iva_ttm_req_cmpny_url' ) : '';
		$iva_ttm_req_client_desc	= get_option( 'iva_ttm_req_client_desc' ) ? get_option( 'iva_ttm_req_client_desc' ) : 'on';

		// Form Inputs Style
		$iva_ttm_input_fontcolor	= get_option( 'iva_ttm_input_fontcolor' ) ? get_option( 'iva_ttm_input_fontcolor' ) : '';
		$iva_ttm_input_fontcolor 	= $iva_ttm_input_fontcolor ? 'color:' . $iva_ttm_input_fontcolor . ';' : '';
	
		$iva_ttm_input_fontsize		= get_option( 'iva_ttm_input_fontsize' ) ? get_option( 'iva_ttm_input_fontsize' ) : '';
		$iva_ttm_input_fontsize 	= $iva_ttm_input_fontsize ? 'font-size:' . $iva_ttm_input_fontsize . ';' : '';
	
		$iva_ttm_input_fontfamily	= get_option( 'iva_ttm_input_fontfamily' ) ? get_option( 'iva_ttm_input_fontfamily' ) : '';
		$iva_ttm_input_fontfamily 	= $iva_ttm_input_fontfamily ? 'font-family:' . $iva_ttm_input_fontfamily . ';' : '';
	
		$iva_ttm_input_fontweight	= get_option( 'iva_ttm_input_fontweight' ) ? get_option( 'iva_ttm_input_fontweight' ) : '';
		$iva_ttm_input_fontweight 	= $iva_ttm_input_fontweight ? 'font-weight:' . $iva_ttm_input_fontweight . ';' : '';
	
		$iva_ttm_input_borderradius	= get_option( 'iva_ttm_input_borderradius' ) ? get_option( 'iva_ttm_input_borderradius' ) : '';
		$iva_ttm_input_borderradius = $iva_ttm_input_borderradius ? 'border-radius:' . $iva_ttm_input_borderradius . ';' : '';
	
		$iva_ttm_input_bordercolor	= get_option( 'iva_ttm_input_bordercolor' ) ? get_option( 'iva_ttm_input_bordercolor' ) : '';
		$iva_ttm_input_bordercolor  = $iva_ttm_input_bordercolor ? 'border-color:' . $iva_ttm_input_bordercolor . ';':'';
	
		$iva_ttm_input_bgcolor		= get_option( 'iva_ttm_input_bgcolor' ) ? get_option( 'iva_ttm_input_bgcolor' ) : '';
		$iva_ttm_input_bgcolor 		= $iva_ttm_input_bgcolor ? 'background-color:' . $iva_ttm_input_bgcolor . ';':'';
	
		// Button Settings
		$iva_ttm_button_text			= get_option( 'iva_ttm_button_text' ) ? get_option( 'iva_ttm_button_text' ) : esc_html__( 'Submit', 'iva_testimonial_pro' );
		$iva_ttm_button_fontcolor		= get_option( 'iva_ttm_button_fontcolor' ) ? get_option( 'iva_ttm_button_fontcolor' ) : '';
		$iva_ttm_button_fontcolor 		= $iva_ttm_button_fontcolor ? 'color:' . $iva_ttm_button_fontcolor . ';' : '';
		$iva_ttm_button_bordercolor		= get_option( 'iva_ttm_button_bordercolor' ) ? get_option( 'iva_ttm_button_bordercolor' ) : '';
		$iva_ttm_button_bordercolor  	= $iva_ttm_button_bordercolor ? 'border-color:' . $iva_ttm_button_bordercolor . ';':'';
		$iva_ttm_button_bgcolor			= get_option( 'iva_ttm_button_bgcolor' ) ? get_option( 'iva_ttm_button_bgcolor' ) : '';
		$iva_ttm_button_bgcolor 		= $iva_ttm_button_bgcolor ? 'background-color:' . $iva_ttm_button_bgcolor . ';':'';
		$iva_ttm_button_hover_fontcolor = get_option( 'iva_ttm_button_hover_fontcolor' ) ? get_option( 'iva_ttm_button_hover_fontcolor' ) : '';
		$iva_ttm_button_hover_bordercolor = get_option( 'iva_ttm_button_hover_bordercolor' ) ? get_option( 'iva_ttm_button_hover_bordercolor' ) : '';
		$iva_ttm_button_hover_bgcolor	= get_option( 'iva_ttm_button_hover_bgcolor' ) ? get_option( 'iva_ttm_button_hover_bgcolor' ) : '';
		$iva_ttm_btn_fontsize			= get_option( 'iva_ttm_btn_fontsize' ) ? get_option( 'iva_ttm_btn_fontsize' ) : '';
		$iva_ttm_btn_fontsize  			= $iva_ttm_btn_fontsize ? 'font-size:' . $iva_ttm_btn_fontsize . ';':'';
		$iva_ttm_btn_fontfamily			= get_option( 'iva_ttm_btn_fontfamily' ) ? get_option( 'iva_ttm_btn_fontfamily' ) : '';
		$iva_ttm_btn_fontfamily  		= $iva_ttm_btn_fontfamily ? 'font-family:' . $iva_ttm_btn_fontfamily . ';':'';
		$iva_ttm_btn_fontweight			= get_option( 'iva_ttm_btn_fontweight' ) ? get_option( 'iva_ttm_btn_fontweight' ) : '';
		$iva_ttm_btn_fontweight  		= $iva_ttm_btn_fontweight ? 'font-weight:' . $iva_ttm_btn_fontweight . ';':'';
		$iva_ttm_btn_borderradius		= get_option( 'iva_ttm_btn_borderradius' ) ? get_option( 'iva_ttm_btn_borderradius' ) : '';
		$iva_ttm_btn_borderradius  		= $iva_ttm_btn_borderradius ? 'border-radius:' . $iva_ttm_btn_borderradius . ';':'';

		$ctitle_reqd 		= 'data-req=false';
		$cpic_reqd 			= 'data-req=false';
		$grav_email_reqd 	= 'data-req=false';
		$upload_pic_reqd 	= 'data-req=false';
		$client_job_reqd 	= 'data-req=false';
		$cmpny_name_reqd 	= 'data-req=false';
		$cmpny_url_reqd 	= 'data-req=false';
		$client_desc_reqd 	= 'data-req=false';

		$c_value1 = rand( 5,10 );
		$c_value2 = rand( 1,5 );
		$operators = array(
					    '+',
					    '-',
				    );
		$captcha_operator = $operators[ rand( 0,1 ) ];
		switch ( $captcha_operator ) {
		    case '+':
		        $result = $c_value2 + $c_value1;
		        break;
		    case '-':
		        $result = $c_value1 - $c_value2;
		        break;
		}

		// Form
		echo '<div class="iva_ttm_section ' . esc_attr( $ttm_extra_class ) . '">';

		echo '<div class="iva_ttm_wg_form">';
		echo '<form name="iva_ttm_form" id="iva_ttm_wg_form" method="post" action="#" enctype="multipart/form-data">';
		$iva_ttm_form_nonce = wp_create_nonce( 'iva-ttm-form' );
		echo '<input type="hidden" name="iva_ttm_form" id="iva-ttm-form" value="' . esc_attr( $iva_ttm_form_nonce ) . '" />';
		echo '<div id="iva_ttm_wg_formstatus"></div>';
		// Title
		if ( 'on' != $iva_ttm_opt_client_name ) {
			if ( 'on' == $iva_ttm_req_client_name ) {
				$ctitle_reqd = 'data-req=true';
 				$ctitle_reqd_mark = ' * ';
			}
			echo '<p><span class="iva_client_title">';
			echo '<input type="text" ' . esc_attr( $ctitle_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_name_txt . $ctitle_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_title" name="client_title" value="" class="client_title">';
			echo '</span></p>';
		}

		// Email ID
		if ( 'on' != $iva_ttm_opt_grav_email ) {
			if ( 'on' == $iva_ttm_req_gravatar ) {
				$grav_email_reqd = 'data-req=true';
				$grav_email_reqd_mark = ' * ';
			}
			echo '<p><span class="widget_iva_gravatar_email">';
			echo '<input type="text" ' . esc_attr( $grav_email_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_grav_email_txt . $grav_email_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="gravatar_email" name="gravatar_email" value="" class="gravatar_email" />';
			echo '</span></p>';
		}
		// Role
		if ( 'on' != $iva_ttm_opt_client_job ) {
			if ( 'on' == $iva_ttm_req_client_job ) {
				$client_job_reqd = 'data-req=true';
				$client_job_reqd_mark = ' * ';
			}
			echo '<p><span class="iva_client_job">';
			echo '<input type="text" ' . esc_attr( $client_job_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_job_txt . $client_job_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_job" name="client_job" value="" class="client_job">';
			echo '</span></p>';
		}
		// Company Name
		if ( 'on' != $iva_ttm_opt_cmpny_name ) {
			if ( 'on' == $iva_ttm_req_cmpny_name ) {
				$cmpny_name_reqd = 'data-req=true';
				$cmpny_name_reqd_mark = ' * ';
			}
			echo '<p><span class="iva_company_name">';
			echo '<input type="text" ' . esc_attr( $cmpny_name_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_cmpny_name_txt . $cmpny_name_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="company_name" name="company_name" value="" class="company_name">';
			echo '</span></p>';
		}
		// Company Website
		if ( 'on' != $iva_ttm_opt_cmpny_url ) {
			if ( 'on' == $iva_ttm_req_cmpny_url ) {
				$cmpny_url_reqd = 'data-req=true';
				$cmpny_url_reqd_mark = ' * ';
			}
			echo '<p><span class="iva_company_url">';
			echo '<input type="text" ' . esc_attr( $cmpny_url_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_cmpny_url_txt . $cmpny_url_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="company_url" name="company_url" value="" class="company_url">';
			echo '</span></p>';
		}
		 // feedback
		if ( 'on' != $iva_ttm_opt_client_desc ) {
			if ( 'on' == $iva_ttm_req_client_desc ) {
				$client_desc_reqd = 'data-req=true';
				$client_desc_reqd_mark = ' * ';
			}
			echo '<p><span class="iva_client_desc">';
			echo '<textarea ' . esc_attr( $client_desc_reqd ) . ' placeholder="' . esc_attr( $iva_ttm_client_desc_txt . $client_desc_reqd_mark ) . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" id="client_desc" name="client_desc" class="client_desc" rows="5" cols="15" /></textarea>';
			echo '</span></p>';
		}
		// Picture
		if ( 'on' != $iva_ttm_opt_client_pic ) {
			if ( 'on' == $iva_ttm_req_client_pic ) { $cpic_reqd = 'data-req=true'; }
			echo '<p><span class="iva_client_image_option">';
			echo '<input type="checkbox" ' . esc_attr( $cpic_reqd ) . ' id="widget_client_image_option" name="client_image_option"><label for="widget_client_image_option" class="ivabh-desc">' . esc_attr( $iva_ttm_client_pic_txt ) . '</label>';
			echo '</span></p>';
			//Upload Image
			if ( 'on' == $iva_ttm_req_upload_pic ) { $upload_pic_reqd = 'data-req=true'; }
			echo '<p><span class="widget_iva_client_photo">';
			echo '<input class="inputText ttm-browser" ' . esc_attr( $upload_pic_reqd ) . ' type="file" placeholder="' . esc_attr( $iva_ttm_upload_pic_txt ) . '" name="client_photo" multiple="" id="client_photo" />';
			echo '</span></p>';
		}
		// Captcha
		if ( 'on' != $iva_ttm_opt_captcha ) {
			echo '<p class="iva_captcha">';
			echo '<input name="captcha_result" id="captcha_result" placeholder="' . esc_attr( $c_value1 ) . ' ' . esc_attr( $captcha_operator ) . ' ' . esc_attr( $c_value2 ) . ' = ' . '" style="' . $iva_ttm_input_fontcolor . $iva_ttm_input_bordercolor . $iva_ttm_input_bgcolor . $iva_ttm_input_fontsize . $iva_ttm_input_fontfamily . $iva_ttm_input_fontweight . $iva_ttm_input_borderradius . '" class="captcha_result" type="text" size="2" />';
			echo '<input name="captcha_val" id="captcha_val" type="hidden" value=' . esc_attr( $result ) . ' >';
			echo '</p>';
		}
		// Ratings
		echo '<p class="at-ttm-ratings-ch">';
		echo '<a class="star_1" data-rated="1"><i class="atmpro_star"></i></a>';
		echo '<a class="star_2" data-rated="2"><i class="atmpro_star"></i></a>';
		echo '<a class="star_3" data-rated="3"><i class="atmpro_star"></i></a>';
		echo '<a class="star_4" data-rated="4"><i class="atmpro_star"></i></a>';
		echo '<a class="star_5" data-rated="5"><i class="atmpro_star"></i></a>';
		echo '</p>';//.ratings_choice
		echo '<input type="hidden" name="client_ratings" id="client_ratings">';

		echo '<input  type="hidden"  id="ttm_message" name="ttm_message" value="' . esc_attr( $ttm_thankyou_msg ) . '"/>';

		// Status
		echo '<input type="hidden" name="client_status" id="client_status" value="accepted" />';

		// Submit Button
		echo '<div class="iva_subbtn">';
		echo '<a href="#" id="iva_ttm_wg_submit" class="ttm-btn medium iva_submit" style="' . $iva_ttm_button_fontcolor . $iva_ttm_button_bordercolor . $iva_ttm_button_bgcolor . $iva_ttm_btn_fontsize . $iva_ttm_btn_fontfamily . $iva_ttm_btn_fontweight . $iva_ttm_btn_borderradius . '"/><span>' . esc_attr( $iva_ttm_button_text ) . '</span></a>';
		echo '</div>';
		echo '</form>';
		echo '</div>';
		echo '</div>';
		echo wp_kses_post( $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['ttm_thankyou_msg'] = strip_tags( $new_instance['ttm_thankyou_msg'] );
		$instance['ttm_extra_class'] = strip_tags( $new_instance['ttm_extra_class'] );
		return $instance;
	}

	function form( $instance ) {
		$instance 			= wp_parse_args( (array) $instance, array( 'title' => '', 'ttm_thankyou_msg' => '', 'ttm_extra_class' => '' ) );
		$title 				= $instance['title'];
		$ttm_thankyou_msg 	= $instance['ttm_thankyou_msg'];
		$ttm_extra_class 	= $instance['ttm_extra_class'];

		// Title
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title:', 'iva_testimonial_pro' ) . '</label>';
		echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '">';
		echo '</p>';

		// Thank You Message
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'ttm_thankyou_msg' ) ) . '">' . esc_html__( 'Thank you Message:', 'iva_testimonial_pro' ) . '</label>';
		echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'ttm_thankyou_msg' ) ) . '" name="' . esc_attr( $this->get_field_name( 'ttm_thankyou_msg' ) ) . '" type="text" value="' . esc_attr( $ttm_thankyou_msg ) . '" />';
		echo '</p>';

		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'ttm_extra_class' ) ) . '">' . esc_html__( 'Extra Class:', 'iva_testimonial_pro' ) . '</label>';
		echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'ttm_extra_class' ) ) . '" name="' . esc_attr( $this->get_field_name( 'ttm_extra_class' ) ) . '" type="text" value="' . esc_attr( $ttm_extra_class ) . '">';
		echo '</p>';
	}
}
