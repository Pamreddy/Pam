<?php
// custom_post_type = iva_shortcode
if ( ! function_exists( 'iva_tmp_shortcode' ) ) {
	function iva_tmp_shortcode() {
		$labels = array(
			'name'				 => esc_html__( 'Shortcode Pro', 'iva_testimonial_pro' ),
			'singular_name'		 => esc_html__( 'Shortcode', 'iva_testimonial_pro' ),
			'add_new'			 => esc_html__( 'Add New', 'iva_testimonial_pro' ),
			'add_new_item'		 => esc_html__( 'Add Shortcode', 'iva_testimonial_pro' ),
			'edit_item'			 => esc_html__( 'Edit Shortcode', 'iva_testimonial_pro' ),
			'new_item'			 => esc_html__( 'New Item', 'iva_testimonial_pro' ),
			'view_item'			 => esc_html__( 'View Shortcode Item', 'iva_testimonial_pro' ),
			'search_items'		 => esc_html__( 'Search Shortcode Item', 'iva_testimonial_pro' ),
			'not_found'			 => esc_html__( 'Nothing found', 'iva_testimonial_pro' ),
			'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'iva_testimonial_pro' ),
			'parent_item_colon'	 => '',
			'all_items' 		 => esc_html__( 'Shortcodes' ,'iva_testimonial_pro' ),
		);

		$iva_shortcode_slug = get_option( 'iva_shortcode_slug' ) ? get_option( 'iva_shortcode_slug' ) : 'iva_shortcode';

		$args = array(
			'labels'			  => $labels,
			'public'			  => false,
			'exclude_from_search' => false,
			'show_ui'			  => true,
			'capability_type'	  => 'post',
			'hierarchical'		  => false,
			'rewrite'			  => array( 'slug' => $iva_shortcode_slug, 'with_front' => true ),
			'query_var'			  => false,
			'menu_icon'			  => IVA_TTM_CPT_URI . 'assets/images/testimonial-icon.png',
			'supports'			  => array( 'title', 'revisions', ),
			'show_in_menu' 		  => 'edit.php?post_type=iva_testimonial',
		);
		register_post_type( 'iva_shortcode', $args );
	}
	add_action( 'init', 'iva_tmp_shortcode' );
}

// Custom Post Type Columns
if ( ! function_exists( 'iva_ttm_shortcode_columns' ) ) {
	function iva_ttm_shortcode_columns( $columns ) {
		$columns = array(
			'cb'       		=> '<input type="checkbox" />',
			'title'       	=> esc_html__( 'Title', 'iva_testimonial_pro' ),
			'tmp_shortcode' => esc_html__( 'Shortcode', 'iva_testimonial_pro' ),
			'date'       	=> esc_html__( 'Date', 'iva_testimonial_pro' ),
		  );
		return $columns;
	}
	add_filter( 'manage_edit-iva_shortcode_columns', 'iva_ttm_shortcode_columns' );
}

// Manage Custom Post Type Columns
if ( ! function_exists( 'iva_ttm_manage_shortcode_columns' ) ) {
	function iva_ttm_manage_shortcode_columns( $name ) {

		global $wpdb, $wp_query,$post;

		switch ( $name ) {
			case 'tmp_shortcode':
				$iva_ttm_style 		= get_post_meta( $post->ID, 'iva_ttm_type', true );
				$iva_ttm_postid 	= get_post_meta( $post->ID, 'iva_ttm_posts', true );
				$iva_ttm_cats 		= get_post_meta( $post->ID, 'iva_ttm_categories', true );
				$iva_ttm_columns 	= get_post_meta( $post->ID, 'iva_ttm_columns', true );

				if ( ! empty( $iva_ttm_cats ) ) { $iva_ttm_cats 	= implode( ',',$iva_ttm_cats ); }
				if ( ! empty( $iva_ttm_postid ) ) {	$iva_ttm_postid = implode( ',',$iva_ttm_postid ); }

				$iva_ttm_choose = get_post_meta( $post->ID, 'iva_ttm_choose', true );

				$iva_ttm_sh_args = '';

				if ( $iva_ttm_choose == 'postid' ) {
					$iva_ttm_sh_args = ' postid="' . $iva_ttm_postid . '"';
				} elseif ( $iva_ttm_choose == 'categories' ) {
					$iva_ttm_sh_args = ' cat="' . $iva_ttm_cats . '" ';
				}
				$columns = '';
				if ( $iva_ttm_style == 'grid' ) {
					$columns = 'columns="' . $iva_ttm_columns . '"';
				}
				if ( ! empty( $post->post_name ) ) {
					$iva_ttm_shortcode = '[iva_testimonial_pro name="' . $post->post_name . '" style="' . $iva_ttm_style . '"' . $iva_ttm_sh_args . '' . $columns . ']';
				} else {
					$iva_ttm_shortcode = '';
				}
				echo $iva_ttm_shortcode;
				break;
		}
	}
	add_action( 'manage_posts_custom_column', 'iva_ttm_manage_shortcode_columns', 10, 2 );
}
