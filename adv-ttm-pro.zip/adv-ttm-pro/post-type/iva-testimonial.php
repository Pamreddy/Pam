<?php
/*
 * function iva_testimonial_pro
 * post_type = iva_testimonial
 * taxonomy = iva_testimonial_cat
 */
if ( ! function_exists( 'iva_testimonial_pro' ) ) {
	function iva_testimonial_pro() {
		$labels = array(
			'name'				 => esc_html__( 'Testimonials Pro', 'iva_testimonial_pro' ),
			'singular_name'		 => esc_html__( 'Testimonial', 'iva_testimonial_pro' ),
			'add_new'			 => esc_html__( 'Add New', 'iva_testimonial_pro' ),
			'add_new_item'		 => esc_html__( 'Add Testimonial', 'iva_testimonial_pro' ),
			'edit_item'			 => esc_html__( 'Edit Testimonial', 'iva_testimonial_pro' ),
			'new_item'			 => esc_html__( 'New Item', 'iva_testimonial_pro' ),
			'view_item'			 => esc_html__( 'View Testimonial Item', 'iva_testimonial_pro' ),
			'search_items'		 => esc_html__( 'Search Testimonial Item', 'iva_testimonial_pro' ),
			'not_found'			 => esc_html__( 'Nothing found', 'iva_testimonial_pro' ),
			'not_found_in_trash' => esc_html__( 'Nothing found in Trash', 'iva_testimonial_pro' ),
			'parent_item_colon'	 => '',
			'all_items' 		 => esc_html__( 'Testimonials', 'iva_testimonial_pro' ),
		);

		$iva_testimonial_slug = get_option( 'iva_testimonial_slug' ) ? get_option( 'iva_testimonial_slug' ) : 'iva_testimonial';

		$args = array(
			'labels'			  => $labels,
			'public'			  => false,
			'exclude_from_search' => false,
			'show_ui'			  => true,
			'capability_type'	  => 'post',
			'hierarchical'		  => false,
			'rewrite'			  => array( 'slug' => $iva_testimonial_slug, 'with_front' => true ),
			'query_var'			  => false,
			'menu_icon'			  => 'dashicons-format-quote',
			'supports'			  => array( 'page-attributes', 'title', 'iva_testimonial_cat', 'editor', 'thumbnail' ),
		);
		register_post_type( 'iva_testimonial', $args );
	}
	add_action( 'init', 'iva_testimonial_pro' );
}
register_taxonomy( 'iva_testimonial_cat', array( 'iva_testimonial' ), array(
	'hierarchical'	=> true,
	'labels' 		=> array(
			'name' 				=> esc_html__( 'Categories', 'iva_testimonial_pro' ),
			'singular_name' 	=> esc_html__( 'Testimonials', 'iva_testimonial_pro' ),
			'search_items' 		=> esc_html__( 'Search Testimonials', 'iva_testimonial_pro' ),
			'all_items' 		=> esc_html__( 'All Testimonials', 'iva_testimonial_pro' ),
			'parent_item' 		=> esc_html__( 'Parent Testimonials', 'iva_testimonial_pro' ),
			'parent_item_colon' => esc_html__( 'Parent Testimonials:', 'iva_testimonial_pro' ),
			'edit_item' 		=> esc_html__( 'Edit Testimonials', 'iva_testimonial_pro' ),
			'update_item' 		=> esc_html__( 'Update Testimonials', 'iva_testimonial_pro' ),
			'add_new_item' 		=> esc_html__( 'Add Testimonial Category', 'iva_testimonial_pro' ),
			'new_item_name' 	=> esc_html__( 'New Testimonials ', 'iva_testimonial_pro' ),
			'menu_name' 		=> esc_html__( 'Categories', 'iva_testimonial_pro' ),
	),
	'show_ui'			=> true,
	'query_var'			=> true,
	'rewrite'			=> false,
) );
// Custom Post Type Columns
if ( ! function_exists( 'iva_ttm_columns' ) ) {
	function iva_ttm_columns( $columns ) {
		$columns = array(
			'cb'       		=> '<input type="checkbox" />',
			'client_image'	=> esc_html__( 'Client Picture', 'iva_testimonial_pro' ),
			'title'       	=> esc_html__( 'Name', 'iva_testimonial_pro' ),
			'position'      => esc_html__( 'Position', 'iva_testimonial_pro' ),
			'company'       => esc_html__( 'Company', 'iva_testimonial_pro' ),
			'rating'       	=> esc_html__( 'Rating', 'iva_testimonial_pro' ),
			'author'       	=> esc_html__( 'Author', 'iva_testimonial_pro' ),
			'ttm_category'	=> esc_html__( 'Categories', 'iva_testimonial_pro' ),
			'date'       	=> esc_html__( 'Date', 'iva_testimonial_pro' ),
			'shortcode' 	=> esc_html__( 'Shortcode', 'iva_testimonial_pro' ),
		);
		return $columns;
	}
	add_filter( 'manage_edit-iva_testimonial_columns', 'iva_ttm_columns' );
}

// Manage Custom Post Type Columns
if ( ! function_exists( 'iva_ttm_manage_columns' ) ) {
	function iva_ttm_manage_columns( $name ) {
		global $wpdb, $wp_query,$post;
		switch ( $name ) {
			case 'client_image':
				if ( has_post_thumbnail() ) {
					$width = (int) 70;
					$height = (int) 70;
					echo iva_ttm_resize( get_the_ID(),'', $width, $height, '', '' );
				} else {
					$gravatar_email = get_post_meta( get_the_ID(), 'gravatar_email', true );
					echo get_avatar( $gravatar_email, 70 );
				}
	      		break;
			case 'position':
				echo get_post_meta( get_the_ID(), 'client_job', true );
				break;
			case 'company':
				echo get_post_meta( get_the_ID(), 'company_name', true );
				break;
			case 'rating':
				echo get_post_meta( get_the_ID(), 'client_ratings', true );
				break;
			case 'ttm_category':
				$terms = get_the_terms( $post->ID, 'iva_testimonial_cat' );
				if ( ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						$post_terms[] = esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, '', 'edit' ) );
					}
					echo esc_html( implode( ', ', $post_terms ) );
				} else {
					echo '<em>' . esc_html__( 'No terms', 'iva_testimonial_pro' ) . '</em>';
				}
				break;
			case 'shortcode':
				echo get_post_meta( get_the_ID(), 'iva_tmp_shortcode', true );
				break;
		}
	}
	add_action( 'manage_posts_custom_column', 'iva_ttm_manage_columns', 10, 2 );
}
