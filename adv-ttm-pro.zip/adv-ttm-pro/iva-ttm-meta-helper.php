<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
// CUSTOM META BOXES
//--------------------------------------------------------
if ( ! class_exists( 'Iva_Ttm_Customfields' ) ) {
	class Iva_Ttm_Customfields {

		function __construct( $meta_box ) {
			$this->_meta_box = $meta_box;
			add_action( 'admin_menu',array( &$this, 'metabox' ) );
			add_action( 'save_post',array( &$this, 'savemeta' ), 10, 2 );
		}

		// Add meta box
		function metabox() {
			foreach ( $this->_meta_box['page'] as $page ) {
				add_meta_box( $this->_meta_box['id'], $this->_meta_box['title'], array( &$this, 'show_metabox' ), $page, $this->_meta_box['context'], $this->_meta_box['priority'] );
			}
		}

		// Callback function to show fields in meta box
		function show_metabox() {

			global $page_layout, $post,$meta_box;

			// Use nonce for verification
			echo '<input type="hidden" name="page_page_layout_nonce" value="', wp_create_nonce( basename( __FILE__ ) ), '" />';

			// M E T A B O X   W R A P
			//--------------------------------------------------------
			echo '<div class="iva_meta_options">';

			foreach ( $this->_meta_box['fields'] as $field ) {

				// get current post meta data
				$meta = get_post_meta( $post->ID, $field['id'], true );

				//Default Meta Array Value if empty
				if ( '' === $meta ) { $meta = $field['std']; }

				if ( ! isset( $field['class'] ) ) { $field['class'] = ''; }
				if ( ! isset( $field['desc'] ) ) { $field['desc'] = ''; }

				// M E T A B O X   O P T I O N S
				//--------------------------------------------------------
				echo '<div class="iva_options_box ' . $field['class'] . '">',
					'<div class="iva_label"><label>', $field['name'],'</label>',
				(( 'checkbox' !== $field['type'] ) ? '<p class="desc">' . $field['desc'] . '</p>' : ''),
					'</div>',
					'<div class="iva_inputs">';
				switch ( $field['type'] ) {
					case 'text':
						echo '<input type="text" class="select300" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" size="25" />';
						break;
					// case 'email':
					// 	echo '<input type="text" class="select300" name="', $field['id'], '" id="', $field['id'], '" value="', $meta ? $meta : $field['std'], '" size="25" />';
					// 	echo '<span id="error" style="display:none;color:red;">Wrong Email</span>';
					// 	break;
					case 'color':
						echo '<div class="meta_page_selectwrap"><input class="color"  name="' . $field['id'] . '" id="' . $field['id'] . '" type="text" value="', $meta ? $meta : $field['std'], '"  />';
						echo '<div id="' . $field['id'] . '_color" class="wpcolorSelector"><div></div></div></div>';
						break;
					case 'textarea':
						echo '<textarea name="', $field['id'], '" id="', $field['id'], '" cols="60" rows="4">', $meta ? $meta : $field['std'], '</textarea>';
						break;
					case 'posttextarea':
						echo '<textarea name="', $field['id'], '" id="', $field['id'], '" cols="30" rows="4">', $meta ? $meta : '[single_testimonial id="' . $post->ID . '"]', '</textarea>';
						break;
					case 'shortcode_gen':
						$iva_ttm_style 		= get_post_meta( $post->ID, 'iva_ttm_type', true );
						$iva_ttm_postid 	= get_post_meta( $post->ID, 'iva_ttm_posts', true );
						$iva_ttm_cats 		= get_post_meta( $post->ID, 'iva_ttm_categories', true );
						$iva_ttm_columns 	= get_post_meta( $post->ID, 'iva_ttm_columns', true );

						if ( ! empty( $iva_ttm_cats ) ) { $iva_ttm_cats 	= implode( ',',$iva_ttm_cats ); }
						if ( ! empty( $iva_ttm_postid ) ) {	$iva_ttm_postid = implode( ',',$iva_ttm_postid ); }

						$iva_ttm_choose = get_post_meta( $post->ID, 'iva_ttm_choose', true );

						$iva_ttm_sh_args = $columns = '';

						if ( 'postid' === $iva_ttm_choose ) {
							$iva_ttm_sh_args = ' postid="' . $iva_ttm_postid . '"';
						} elseif ( 'categories' === $iva_ttm_choose ) {
							$iva_ttm_sh_args = ' cat="' . $iva_ttm_cats . '" ';
						}
						if ( 'grid' === $iva_ttm_style ) {
							$columns = ' columns="' . $iva_ttm_columns . '"';
						}
						if ( ! empty( $post->post_name ) ) {
							$iva_ttm_shortcode = '[iva_testimonial_pro name="' . $post->post_name . '" style="' . $iva_ttm_style . '"' . $iva_ttm_sh_args . '' . $columns . ']';
						} else {
							$iva_ttm_shortcode = '';
						}
						echo '<textarea name="' . $field['id'] . '" id="' . $field['id'] . '" cols="30" rows="4">' . $iva_ttm_shortcode . '</textarea>';
						break;
					case 'select':
						echo '<div class="select_wrapper select300 ', $field['class'], '"><select class="select select300" name="', $field['id'], '" id="', $field['id'], '">';
						foreach ( $field['options'] as $key => $value ) {
							echo '<option value="' . $key . '"', $meta == $key ? ' selected="selected"' : '', '>', $value, '</option>';
						}
						echo '</select></div>';
						break;
					case 'layout_select':
						echo '<div class="select_wrapper select300 ', $field['class'], '"><select class="select" name="', $field['id'], '" id="', $field['id'], '">';
						foreach ( $field['options'] as $key => $value ) {
							$img = IVA_TTM_CPT_URI . 'assets/images/' . $key . '.jpg';
							echo '<option  data-img="' . $img . '" value="' . $key . '"', $meta == $key ? ' selected="selected"' : '', '>', $value, '</option>';
						}
						echo '</select>';
						echo '<div id="iva_demo_preview_pic" class="select-screens">';
						
						echo '</div>';
				
						echo '</div>';
						echo '<img id="iva_demo_img" class="iva_demo_img" src="" alt="" >';
						break;
					case 'multiselect':
						echo '<div class="multi_select_wrapper">';
						$count = count( $field['options'] );
						if ( $count > 0 ) {
							echo '<select multiple="multiple" class="select300" name="', $field['id'], '[]" id="', $field['id'], '[]">';
							foreach ( $field['options'] as $key => $value ) {
								echo '<option value="' . $key . '"',  ( is_array( $meta ) && in_array( $key, $meta ) ) ? ' selected="selected"' : '', '>', $value, '</option>';
							}
							echo '</select>';
						} else {
							echo '<strong>' . esc_html__( 'No Posts IN Categories', 'iva_testimonial_pro' ) . '</strong>';
						}
						echo '</div>';
						break;
					case 'radio':
						$select_value = get_post_meta( $post->ID, $field['id'], true ) ?  get_post_meta( $post->ID, $field['id'], true ) : 'on';
						echo '<div class="radio_field_options">';
						foreach ( $field['options'] as $key => $option ) {
							$checked = '';
							if ( '' !== $select_value ) {
								if ( $select_value == $key ) {
									$checked = ' checked';
								}
							} else {
								if ( $field['std'] == $key ) { $checked = ' checked'; }
							}
							echo '<span class="iva_radio_field"><input class="iva-input iva-radio" type="radio" name="' . $field['id'] . '" id="' . $field['id'] . $key . '" value="' . $key . '" ' . $checked . ' /><label class="iva_radio_field_label" for="' . $field['id'] . $key . '">' . $option . '</label><br /></span>';
						}
						echo '</div>';
						break;
					case 'upload':
						echo '<input name="' . $field['id'] . '" id="' . $field['id'] . '"  type="hidden" class="iva_ttm_upload_image" value="' . stripslashes( get_post_meta( $post->ID, $field['id'], true ) ) . '" />';
						echo '<input name="' . $field['id'] . '" id="' . $field['id'] . '" class="iva_ttm_upload_image_button button button-primary button-large clearfix" type="button" value="Choose Image" />';
						echo '<div id="iva_ttm_imagepreview-' . $field['id'] . '" class="iva-ttm-screenshot">';
						if ( get_post_meta( $post->ID, $field['id'], true ) ) {
							$iva_img 			= get_post_meta( $post->ID, $field['id'], true );
							$image_attributes 	= wp_get_attachment_image_src( iva_ttm_get_attachment_id_from_src( $iva_img ) );
							if ( '' !== $image_attributes[0] ) {
								echo '<img src="' . esc_url( $image_attributes[0] ) . '"  class="custom_preview_image" alt="" />';
								echo '<a href="#" class="iva_ttm_image_remove button button-primary">x</a>';
							} else {
								echo '<img src="' . esc_url( $iva_img ) . '"  class="custom_preview_image" alt="" />';
								echo '<a href="#" class="iva_ttm_image_remove button button-primary">x</a>';
							}
						}
						echo '</div>';
						break;
					case 'getterms':
						$iva_ttm_cats = $iva_post_ids = array();
						$iva_ttm_cat_query = get_terms( $field['options'], 'orderby=name&hide_empty=0' );
						foreach ( $iva_ttm_cat_query as $iva_testimonial ) {
							$iva_ttm_cats[ $iva_testimonial->slug ] = $iva_testimonial->name;
						}
						echo '<div class="multi_select_wrapper select300">';
							$count = count( $iva_ttm_cats );
						if ( $count > 0 ) {
							echo '<select multiple="multiple" class="select300"  name="', $field['id'], '[]" id="', $field['id'], '[]">';
							foreach ( $iva_ttm_cats as $key => $value ) {
								echo '<option value="' . $key . '"',  ( is_array( $meta ) && in_array( $key, $meta ) ) ? ' selected="selected"' : '', '>', $value, '</option>';
							}
							echo '</select>';
						} else {
							echo '<strong>' . esc_html__( 'No Posts IN Categories', 'iva_testimonial_pro' ) . '</strong>';
						}
						echo '</div>';
						break;
					case 'layout':
						$i = 0;
						$select_value = $meta;
						foreach ( $field['options'] as $key => $value ) {
								$i++;
							$checked = '';
							$selected = '';
							if ( $select_value != '' ) {
								if ( $select_value == $key ) {
									$checked = ' checked';
									$selected = 'iva-radio-option-selected';
								}
							} else {
								if ( $meta == $key ) {
									$checked = ' checked';
									$selected = 'iva-radio-option-selected';
								} elseif ( $i == 1  && ! isset( $select_value ) ) {
									$checked = ' checked';
									$selected = 'iva-radio-option-selected';
								} elseif ( $i == 1  && $meta == '' ) {
									$checked = ' checked';
									$selected = 'iva-radio-option-selected';
								} else { $checked = 'checked'; }
							}
							echo '<div class="layout"><input value="'.$key.'"  class="checkbox iva-radio-img-radio" type="radio" id="'. $field['id'].$i.'" name="'. $field['id'].'"'.$checked.' />';
							echo '<img src="'.esc_url( $value ).'" alt="" class="iva-radio-option '. $selected .'" onClick="document.getElementById(\''. $field['id'].$i.'\').checked = true;" /><span class="label">'.$key.'</span></div>';
						}
						break;
					case 'checkbox':
						$meta != '' ? 'on' : 'off';
						echo '<input  type="checkbox" name="', $field['id'], '" id="', $field['id'], '"', $meta == 'on' ? ' checked="checked"' : '', ' />
						<label for="',$field['id'],'">',$field['desc'],'</label>';
						break;
					case 'background':
						$bg_color = '';
						if ( is_array( $meta ) ) {
							if ( ! empty( $meta ) ) {
								$bg_image 		= $meta['0']['image'];
								$bg_color		= $meta['0']['color'];
								$bg_repeat 		= $meta['0']['repeat'];
								$bg_position 	= $meta['0']['position'];
								$bg_attachement = $meta['0']['attachement'];
							}
						} else {
							$bg_image 		= $meta;
						}
						// Position Properties Array
						$positionarray = array(
							'left top'		=> 'Left Top',
							'left center'	=> 'Left Center',
							'left bottom'	=> 'Left Bottom',
							'right top' 	=> 'Right Top',
							'right center' 	=> 'Right Center',
							'right bottom'	=> 'Right Bottom',
							'center top'	=> 'Center Top',
							'center center'	=> 'Center Center',
							'center bottom'	=> 'Center Bottom',
						);
						// Repeat Properties Array
						$repeatarray = array( 'repeat' => 'Repeat', 'no-repeat' => 'No-Repeat', 'repeat-x' => 'Repeat-X', 'repeat-y' => 'Repeat-Y' );
						// Attachment Properties Array
						$attacharray = array( 'scroll' => 'Scroll', 'fixed' => 'Fixed' );

						echo '<div class="section section-background">';

						//Upload Field
						echo '<div class="iva-background-upload clearfix">';
						echo '<input type="text"  name="'.$field['id'].'_image" id="'.$field['id'].'_image" class="iva_ttm_upload_image" value="'.$bg_image.'" />';
						echo '<input type="button" name="'.$field['id'].'_image" class="iva_ttm_upload_image_button button button-primary button-large" value="' . esc_html__( 'Choose Image', 'iva_testimonial_pro' ) . '" />';
						echo '<div id="iva_ttm_imagepreview-'.$field['id'].'_image" class="iva-ttm-screenshot">';
						if ( $bg_image != '' ) {
							$image_attributes = wp_get_attachment_image_src( iva_ttm_get_attachment_id_from_src( $bg_image ) );
							if ( $image_attributes[0] != '' ) {
								echo '<img src="'.esc_url( $image_attributes[0] ).'"  class="custom_preview_image" alt="" />';
								echo '<a href="#" class="iva_ttm_image_remove button button-primary">x</a>';
							} else {
								echo '<img src="'.esc_url( $bg_image ).'"  class="custom_preview_image" alt="" />';
								echo '<a href="#" class="iva_ttm_image_remove button button-primary">x</a>';
							}
						}
						echo '</div></div>';

						//Color Input
						echo '<div class="iva-background-color">';
						echo '<input class="color"  name="'. $field['id'].'_color" id="'. $field['id'].'_color" type="text" value="'.$bg_color.'">';
						echo '<div id="'.$field['id'].'_color" class="wpcolorSelector"><div></div></div>';
						echo '</div>';

						// Background Repeat Options Input
						echo '<div class="iva-background-repeat">';
						echo '<div class="select_wrapper">';
						echo '<select class="select" name="'. $field['id'].'_repeat" id="'. $field['id'].'_repeat">';
						foreach ( $repeatarray as $key => $value ) {
							$selected = ($key == $bg_repeat) ? ' selected="selected"' : '';
							echo'<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
						}
						echo '</select>';
						echo '</div></div>';

						//Background Position Options Input
						echo '<div class="iva-background-position"><div class="select_wrapper">';
						echo '<select class="select" name="'. $field['id'].'_position" id="'. $field['id'].'_position">';
						foreach ( $positionarray as $key => $value ) {
							$selected = ($key == $bg_position) ? ' selected="selected"' : '';
							echo'<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
						}
						echo '</select>';
						echo '</div></div>';

						//Background Attachment Options Input
						echo '<div class="iva-background-attachment"><div class="select_wrapper">';
						echo '<select class="select" name="'. $field['id'].'_attachement" id="'. $field['id'].'_attachement">';
						foreach ( $attacharray as $key => $value ) {
							$selected = ($key == $bg_attachement) ? ' selected="selected"' : '';
							echo'<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
						}
						echo '</select>';
						echo '</div></div>';

						echo '</div>';
						break;
					case 'multicheckbox':
						foreach ( $field['options'] as $key => $value ) {
						    echo '<div><input  type="checkbox"  ' , (isset( $meta[$key] ) == $key ) ? ' checked="checked"' : '','  name="',$field['id'],'[',$key,']','"    value="',$key,'" id="',$value,'"  /> ';
						    echo '<label for="',$value,'">',$value,'</label></div>';
						}
						break;
				}
				echo '</div>';
				echo '</div>';
			}
			echo '</div>';
		}
		// E N D  - SHOW METABOX

		// S A V E   M E T A   D A T A
		//--------------------------------------------------------
		function savemeta( $post_id, $post ) {

			/* Verify the nonce before proceeding. */
			if ( ! isset( $_POST['page_page_layout_nonce'] ) || ! wp_verify_nonce( $_POST['page_page_layout_nonce'], basename( __FILE__ ) ) )
				return $post_id;
		/* Get the post type object. */
			$post_type = get_post_type_object( $post->post_type );

			/* Check if the current user has permission to edit the post. */
			if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) )
				return $post_id;

			// Is the user allowed to edit the post or page?
			foreach ( $this->_meta_box['fields'] as $field ) {
				$field_type = $field['type'] ;
							if( isset( $_POST['gravatar_email'])  ) {
							if( is_email( $_POST['gravatar_email'] ) ) {
							    // Valid email address
							} else {
							    // Invalid email address
							    echo 'error message';
							   die();
							}
							}
				if ( $field_type === 'background' ) {
					if ( isset( $field['id'] ) && $field['id'] != '' ) {
						$bg_props = array();
						$bg_props[] = array(
							'image' 		=> isset( $_POST[$field['id'] . '_image'] ) ? $_POST[$field['id'] . '_image'] : '',
							'color' 		=> isset( $_POST[$field['id'] . '_color'] ) ? $_POST[$field['id'] . '_color'] : '',
							'repeat'		=> isset( $_POST[$field['id'] . '_repeat'] ) ? $_POST[$field['id'] . '_repeat'] : '',
							'position'		=> isset( $_POST[$field['id'] . '_position'] ) ? $_POST[$field['id'] . '_position'] : '',
							'attachement'	=> isset( $_POST[$field['id'] . '_attachement'] ) ? $_POST[$field['id'] . '_attachement'] : '',
						);

						if ( get_post_meta( $post_id, $field['id'],true ) == '' ) {
							add_post_meta( $post_id, $field['id'], $bg_props, true );
						} elseif ( $bg_props != get_post_meta( $post_id, $field['id'], true ) ) {
							update_post_meta( $post_id, $field['id'], $bg_props );
						}
					}
				} else {
					$old = get_post_meta( $post_id, $field['id'], true );
					$new = isset( $_POST[$field['id']] ) ? $_POST[$field['id']] : '';
					if ( $field['type'] == 'dateformat' ) {
							$new = strtotime( $new );
					}
					if ( $new && $new != $old ) {
						update_post_meta( $post_id, $field['id'], $new );
					} elseif ( '' == $new && $old ) {
						delete_post_meta( $post_id, $field['id'], $old );
					}
				}
			}
		}

		// function get_custom_options - fetch pages/posts/cats
		//--------------------------------------------------------
		function get_custom_options( $type ) {
			switch ( $type ) {
				case 'page':
					$entries = get_pages( 'title_li=&orderby=name' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[$entry->ID] = $entry->post_title;
					}
					break;
				case 'cat':
					$entries = get_categories( 'title_li=&orderby=name&hide_empty=0' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[$entry->term_id] = $entry->name;
					}
					break;
				case 'post':
					$entries = get_posts( 'orderby=title&numberposts=-1&order=ASC' );
					foreach ( $entries as $key => $entry ) {
						$iva_objects[$entry->ID] = $entry->post_title;
					}
					break;
				default:
					$iva_objects = false;
			}
			return $iva_objects;
		}
	}
}
foreach ( $this->meta_box as $meta_box ) {
	$iva_ttm_customfields = new Iva_Ttm_Customfields( $meta_box );
}
