<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
if ( ! class_exists( 'iva_single_ttm_addon' ) ) {
	class iva_single_ttm_addon {
		// constructor
		function __construct() {
			add_action( 'init', array( $this, 'iva_single_testimonial_init' ) );
			add_shortcode( 'iva_single_ttm_addon', array( $this, 'iva_testimonial_single_shortcode' ) );
		}

		// initialize the mapping function
		function iva_single_testimonial_init() {
			if ( function_exists( 'vc_map' ) ) {

				$iva_ttm_layouts = array(
					'Choose One..' => '',
					'Layout 1-a'  => 'v1-a',
					'Layout 1-b'  => 'v1-b',
					'Layout 1-c'  => 'v1-c',
					'Layout 1-d'  => 'v1-d',
					'Layout 2-a'  => 'v2-a',
					'Layout 2-b'  => 'v2-b',
					'Layout 3-a'  => 'v3-a',
					'Layout 3-b'  => 'v3-b',
					'Layout 4-a'  => 'v4-a',
					'Layout 4-b'  => 'v4-b',
					'Layout 5-a'  => 'v5-a',
					'Layout 5-b'  => 'v5-b',
					'Layout 6-a'  => 'v6-a',
					'Layout 6-b'  => 'v6-b',
					'Layout 7'    => 'v7',
					'Layout 8-a'  => 'v8-a',
					'Layout 8-b'  => 'v8-b',
				);

				$iva_ttm_post_ids = array();
				$args = array(
					'post_type' => 'iva_testimonial',
					'posts_per_page' => -1,
				);
				$iva_ttm_post_query = get_posts( $args );
				foreach ( $iva_ttm_post_query as $key => $entry ) {
					$iva_ttm_post_ids[ $entry->post_title ] = $entry->ID;
				}

				vc_map(
					array(
					   'name' 		 => esc_html__( 'Single Testimonial', 'iva_testimonial_pro' ),
					   'base' 		 => 'iva_single_ttm_addon',
					   'class' 		 => '',
					   'icon' 		 => '',
					   'category' 	 => 'Aivah VC Addons',
					   'description' => esc_html__( 'Single Testimonial Shortcode', 'iva_testimonial_pro' ),
					   'params' 	 => array(
					   		array(
								'type' 			=> 'dropdown',
								'heading'  	 	=> esc_html__( 'Layouts:', 'iva_testimonial_pro' ),
								'param_name' 	=> 'iva_ttm_layouts',
								'value' 	 	=> $iva_ttm_layouts,
								'description' 	=> esc_html__( 'Select the Layout which you wish to display for Testimonials.', 'iva_testimonial_pro' ),
							),
							array(
								'type' 			=> 'dropdown',
								'heading'  	 	=> esc_html__( 'Select Testimonial:', 'iva_testimonial_pro' ),
								'param_name' 	=> 'id',
								'value' 	 	=> $iva_ttm_post_ids,
								'description' 	=> esc_html__( 'Select the testimonial which you wish to display in Testimonial Shortcode Page.', 'iva_testimonial_pro' ),
							),
							array(
								'type' 		  => 'css_editor',
								'heading'     => esc_html__( 'css', 'iva_testimonial_pro' ),
								'param_name'  => 'css',
								'group' 	  => esc_html__( 'Design', 'iva_testimonial_pro' ),
							),
						),
					)
				);
			}
		}

		function iva_testimonial_single_shortcode( $args ) {
			// Attributes
			$args = shortcode_atts(
				array(
					'id'				=> '',
					'css'				=> '',
					'name'				=> '',
					'iva_ttm_title' 	=> 'on',
					'iva_ttm_clientpic' => 'on',
					'iva_ttm_gravatar'	=> 'on',
					'iva_ttm_content' 	=> 'on',
					'iva_ttm_clientjob' => 'on',
					'iva_ttm_cmpnyname' => 'on',
					'iva_ttm_cmpnyurl' 	=> 'on',
					'iva_ttm_clientratings'	=> 'on',
					'iva_ttm_layouts'	=> '',
				),
				$args
			);

			// Define Variables
			$id	= (int) $args['id'];
			$css = $args['css'];
			$name = $args['name'];
			$iva_ttm_title = $args['iva_ttm_title'];
			$iva_ttm_clientpic = $args['iva_ttm_clientpic'];
			$iva_ttm_gravatar = $args['iva_ttm_gravatar'];
			$iva_ttm_content = $args['iva_ttm_content'];
			$iva_ttm_clientjob = $args['iva_ttm_clientjob'];
			$iva_ttm_cmpnyname = $args['iva_ttm_cmpnyname'];
			$iva_ttm_cmpnyurl = $args['iva_ttm_cmpnyurl'];
			$iva_ttm_clientratings = $args['iva_ttm_clientratings'];
			$iva_ttm_layouts = $args['iva_ttm_layouts'];

			global $post;

			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ) );

			if ( $id ) {
				$ttm_post = get_post( $id );
			}

			$out = $before = $after = $ttm_sh_id = '';

			// Shortcode Query
			$iva_sh_args = array(
			  'name' 		=> $name,
			  'post_type' 	=> 'iva_shortcode',
			  'post_status' => 'publish',
			  'showposts' 	=> 1,
			);

			$iva_sh_post = get_posts( $iva_sh_args );

			if ( $iva_sh_post ) {
				$ttm_sh_id = $iva_sh_post[0]->ID;
			}

			$client_image_option  = get_post_meta( $id, 'client_image_option', true );
			$client_job			  = get_post_meta( $id, 'client_job', true );
			$company_name		  = get_post_meta( $id, 'company_name', true );
			$company_url		  = get_post_meta( $id, 'company_url', true );
			$client_ratings		  = get_post_meta( $id, 'client_ratings', true );
			$special_title		  = get_post_meta( $id, 'special_title', true );
			$testimonial_content  = $ttm_post->post_content;
			$client_title 		  = $ttm_post->post_title;

			$iva_ttm_upload_image = get_option( 'iva_ttm_upload_image' ) ? get_option( 'iva_ttm_upload_image' ) : '';
			$testimonial_email = get_post_meta( $post->ID, 'gravatar_email', true );

			if ( has_post_thumbnail( $id ) ) {
				$client_gravatar_image = iva_ttm_resize( $id, '', '', '', 'imageborder', '' );
			} elseif ( ! empty( $testimonial_email ) ) {
				$client_gravatar_image = get_avatar( $testimonial_email, 70 );
			} else {
				if ( ! empty( $iva_ttm_upload_image ) ) {
					$client_gravatar_image = '<img src="' . $iva_ttm_upload_image . '" alt="img" class="imageborder"/>';
				} else {
					$client_gravatar_image = '<img src="' . IVA_TTM_CPT_URI . 'assets/images/image-1.png" alt="img"/>';
				}
			}

			$iva_ttm_company_color  = get_option( 'iva_ttm_company_color' ) ? get_option( 'iva_ttm_company_color' ) : '';
			$iva_ttm_text_color 	= $iva_ttm_company_color ? 'color: ' . $iva_ttm_company_color . ';' : '';
			$ttm_company_color 		= ( $iva_ttm_company_color ) ? ' style="' . $iva_ttm_company_color . '"' : '' ;

			$iva_ttm_spltitle_color = get_option( 'iva_ttm_spltitle_color' ) ? get_option( 'iva_ttm_spltitle_color' ) : '';
			$iva_ttm_spltitle_color = $iva_ttm_spltitle_color ? 'color: ' . $iva_ttm_spltitle_color . ';' : '';
			$ttm_spltitle_color 	= ( $iva_ttm_spltitle_color ) ? ' style="' . $iva_ttm_spltitle_color . '"' : '' ;

			$iva_ttm_blockquote_color = get_option( 'iva_ttm_blockquote_color' ) ? get_option( 'iva_ttm_blockquote_color' ) : '';
			$iva_ttm_blockquote_color = $iva_ttm_blockquote_color ? 'color: ' . $iva_ttm_blockquote_color . ';' : '';
			$ttm_blockquote_color_css = ( $iva_ttm_blockquote_color ) ? ' style="' . $iva_ttm_blockquote_color . '"' : '' ;

			if ( $css_class != '' ) { $out .= '<div class="' . esc_attr( $css_class ) . '">'; }
			$out .= '<div class="at-adv-ttm-' . $iva_ttm_layouts . '">';
			if ( 'v1-a' === $iva_ttm_layouts || 'v1-b' === $iva_ttm_layouts || 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
				if ( 'v1-b' === $iva_ttm_layouts ) {
					$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				}
				if ( 'v1-c' === $iva_ttm_layouts || 'v1-d' === $iva_ttm_layouts ) {
					$out .= '<i ' . $ttm_blockquote_color_css . ' class="fa fa-quote-left fa-fw"></i>';
				}
				$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
				if ( 'v1-c' === $iva_ttm_layouts ) {
				   	$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				}
				$out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
				$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v2-a' === $iva_ttm_layouts ) {
				$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
				$out .= '<div class="author">';
				$out .= ttm_client_title( $iva_ttm_title, $client_title );
				$out .= ttm_client_job( $iva_ttm_clientjob, $client_job );
				$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
				$out .= '</div>';
			}
			if ( 'v2-b' === $iva_ttm_layouts ) {
				$out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
				$out .= '<div class="author with-image">';
				$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				$out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
				$before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			    $out .= '</div>';
			}
			if ( 'v3-a' === $iva_ttm_layouts || 'v3-b' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    if ( 'v3-b' === $iva_ttm_layouts ) {
					$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				}
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v4-a' === $iva_ttm_layouts || 'v4-b' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    if ( 'v4-b' === $iva_ttm_layouts ) {
					$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				}
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v5-a' === $iva_ttm_layouts || 'v5-b' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    if ( 'v5-b' === $iva_ttm_layouts ) {
					$out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
				}
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v6-a' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v6-b' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v7' === $iva_ttm_layouts ) {
				$out .= '<div class="at-adv-ttm-content">';
				$out .= '<h3 ' . $ttm_spltitle_color . '>' . $special_title . '</h3>';
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    $out .= ttm_client_title( $iva_ttm_title, $client_title );
			    $out .= ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			    $out .= '</div>';
			    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
			}
			if ( 'v8-a' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    $out .= ttm_image( $client_gravatar_image, $iva_ttm_clientpic, $ttm_sh_id );
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( 'v8-b' === $iva_ttm_layouts ) {
			    $out .= ttm_content( $iva_ttm_content, $testimonial_content, $ttm_sh_id );
			    $out .= ttm_client_title( $iva_ttm_title, $client_title ) . ttm_client_job( $iva_ttm_clientjob, $client_job );
			    $before .= '<a href="' . esc_url( $company_url ) . '" target="_blank" ' . $ttm_company_color . '>';
				$after .= '</a>';
			    $out .= ttm_client_company( $company_url, $iva_ttm_cmpnyname, $iva_ttm_cmpnyurl, $company_name, $before, $after );
			    $out .= ttm_client_ratings( $client_ratings, $iva_ttm_clientratings );
			}
			if ( $css_class != '' ) { $out .= '</div>'; }
			return $out;
		}
	}
}
if ( class_exists( 'iva_single_ttm_addon' ) ) {
	$iva_single_ttm_addon = new iva_single_ttm_addon;
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_iva_single_ttm_addon extends WPBakeryShortCode {
	}
}
