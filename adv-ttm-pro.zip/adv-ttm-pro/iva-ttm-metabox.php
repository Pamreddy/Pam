<?php
/**
 * Advanced Testimonial Manager Pro
 * @author aivahthemes
 * @package adv-ttm-pro
 * @since 1.0
 */
/* Testimonial Meta box setup function. */
global $post;
$this->meta_box[] = array(
	'id'		=> 'Testimonial-meta-box',
	'title'		=> esc_html__( 'Testimonial Information', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_testimonial' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(

		// Email ID
		array(
			'name'	=> esc_html__( 'Email ID', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter your gravatar email address you wish to display for the picture, leave empty if you wish to use featured image.', 'iva_testimonial_pro' ),
			'id'	=> 'gravatar_email',
			'class'	=> 'testimonialoption gravatar',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Client Role
		array(
			'name'	=> esc_html__( 'Role', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter role (designation) of the client.', 'iva_testimonial_pro' ),
			'id'	=> 'client_job',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Company Name
		array(
			'name'	=> esc_html__( 'Company Name', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter company name of the client.', 'iva_testimonial_pro' ),
			'id'	=> 'company_name',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Company Website
		array(
			'name'	=> esc_html__( 'Company Website', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter company website of the client, excluding any protocols ( without http:// ).', 'iva_testimonial_pro' ),
			'id'	=> 'company_url',
			'std'	=> '',
			'type'	=> 'text',
		),
		// Ratings
		array(
			'name'	=> esc_html__( 'Rating','iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Choose ratings for the testimonial.', 'iva_testimonial_pro' ),
			'id'	=> 'client_ratings',
			'std'	=> '',
			'type'	=> 'select',
			'options' => array(
				'1'	=> '1 Star',
				'2'	=> '2 Stars',
				'3'	=> '3 Stars',
				'4' => '4 Stars',
				'5' => '5 Stars',
			),
		),
		// Special Title for Layout7
		array(
			'name'	=> esc_html__( 'Special Title for Layout 7', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'Enter Special Title, This displays only for Layout 7 Testimonial', 'iva_testimonial_pro' ),
			'id'	=> 'special_title',
			'std'	=> '',
			'type'	=> 'text',
		),
	),
);

$this->meta_box[] = array(
	'id'		=> 'Testimonial-meta-boxx',
	'title'		=> esc_html__( 'Shortcode Generator', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_testimonial' ),
	'context'	=> 'side',
	'priority'	=> 'low',
	'fields'	=> array(
		// Shortcode
		array(
			'name'	=> esc_html__( 'Shortcode', 'iva_testimonial_pro' ),
			'desc'	=> esc_html__( 'To display this testimonial add this shortcode to any post or page.', 'iva_testimonial_pro' ),
			'id'	=> 'iva_tmp_shortcode',
			'std'	=> '',
			'type'	=> 'posttextarea',
		),
	),
);

// Styling
$this->meta_box[] = array(
	'id'		=> 'styling-meta-box',
	'title'		=> esc_html__( 'Styling Options For This Testimonial', 'iva_testimonial_pro' ),
	'page'		=> array( 'iva_testimonial' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(
		// Layouts
		//-------------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Layouts', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose the Layout you wish to use for the Testimonials to display.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_layouts',
			'std'		=> '',
			'class'		=> 'ttm',
			'type'		=> 'layout_select',
			'options'	=> array(
				'default-ttm'	=> 'Choose one..',
				'v1-a'  => 'Layout 1-a',
				'v1-b'  => 'Layout 1-b',
				'v1-c'  => 'Layout 1-c',
				'v1-d'  => 'Layout 1-d',
				'v2-a'  => 'Layout 2-a',
				'v2-b'  => 'Layout 2-b',
				'v3-a'  => 'Layout 3-a',
				'v3-b'  => 'Layout 3-b',
				'v4-a'  => 'Layout 4-a',
				'v4-b'  => 'Layout 4-b',
				'v5-a'  => 'Layout 5-a',
				'v5-b'  => 'Layout 5-b',
				'v6-a'  => 'Layout 6-a',
				'v6-b'  => 'Layout 6-b',
				'v7'  	=> 'Layout 7',
				'v8-a'  => 'Layout 8-a',
				'v8-b'  => 'Layout 8-b',
			),
		),
		// Font Size
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Font Size', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Enter the Font Size for content in pixels. (Eg: 20px)', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_fontsize',
			'std'		=> '',
			'type'		=> 'text',
		),
		// Content Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Content Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Testimonial Text.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_content_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Title Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Title Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Testimonial Title.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_title_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Role Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Role Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Client\'s Role.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_job_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Client Company Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Client Company Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Color for the Client\'s Company.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_company_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// BG Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'BG Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose BG Color for the Testimonial Layouts 6-a,6-b,8-a and 8-b.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_bg_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Blockquote Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Blockquote Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Blockquote Color for the Testimonial Layouts 1-c and 1-d.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_blockquote_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Ratings Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Ratings Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Ratings Color for the Testimonials.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_ratings_color',
			'std'		=> '',
			'type'		=> 'color',
		),
		// Special Title Color
		// -----------------------------------------------------------
		array(
			'name'		=> esc_html__( 'Special Title Color', 'iva_testimonial_pro' ),
			'desc'		=> esc_html__( 'Choose Special Title Color for the Testimonial Layouts 7.', 'iva_testimonial_pro' ),
			'id'		=> 'iva_ttm_spltitle_color',
			'std'		=> '',
			'type'		=> 'color',
		),
	),
);
