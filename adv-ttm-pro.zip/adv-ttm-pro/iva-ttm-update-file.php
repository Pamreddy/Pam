<?php
/**
 * Class IvaTtmZip
 */
if ( ! class_exists( 'IvaTtmZip' ) ) {
	class IvaTtmZip {
		private $zip;
		public static function is_zip_exists() {
			$exists = class_exists( 'ZipArchive' );
			return $exists;
		}
		public function extract( $src, $dest ) {
			$zip = new ZipArchive;
			if ( $zip->open( $src ) === true ) {
				$zip->extractTo( $dest );
				$zip->close();
				return true;
			}
			return false;
		}
	}
}

/**
 * function iva_ttm_throw_error
 * throws error message
 */
if ( ! function_exists( 'iva_ttm_throw_error' ) ) {
	function iva_ttm_throw_error( $message ) {
		throw new Exception( $message );
	}
}

/**
 * function iva_ttm_check_create_dir
 * checks directory exist or not
 * if not it creates directory
 */
if ( ! function_exists( 'iva_ttm_check_create_dir' ) ) {
	function iva_ttm_check_create_dir( $dir ) {
		if ( ! is_dir( $dir ) ) {
			mkdir( $dir );
		}
		if ( ! is_dir( $dir ) ) {
			return "Could not create directory: $dir";
		}
	}
}

/**
 * function iva_ttm_copy_dir
 * copys directory
 */
if ( ! function_exists( 'iva_ttm_copy_dir' ) ) {
	function iva_ttm_copy_dir( $path, $dest ) {

		if ( is_dir( $path ) ) {
			wp_mkdir_p( $dest );
			$objects = scandir( $path );
			if ( count( $objects ) > 0 ) {
				foreach ( $objects as $file ) {
					if ( '.' === $file || '..' === $file ) {
						continue;
					}

					// go on
					if ( is_dir( $path . '/' . $file ) ) {
						iva_ttm_copy_dir( $path . '/' . $file, $dest . '/' . $file );
					} else {
						copy( $path . '/' . $file, $dest . '/' . $file );
					}
				}
			}
			return true;
		} elseif ( is_file( $path ) ) {
			return copy( $path, $dest );
		} else {
			return false;
		}
	}
}

/**
 * function iva_ttm_delete_dir
 * deletes directory
 */
if ( ! function_exists( 'iva_ttm_delete_dir' ) ) {
	function iva_ttm_delete_dir( $str ) {
		if ( is_file( $str ) ) {
			return unlink( $str );
		} elseif ( is_dir( $str ) ) {
			$scan = glob( rtrim( $str,'/' ) . '/*' );
			if ( ! empty( $scan ) ) {
				foreach ( $scan as $index => $path ) {
					iva_ttm_delete_dir( $path );
				}
			}
			return rmdir( $str );
		}
	}
}

/**
 * function iva_ttm_update_plugin
 * Updates the plugin
 */
add_action( 'wp_ajax_iva_ttm_ajax_action', 'iva_ttm_update_plugin' );
add_action( 'wp_ajax_nopriv_iva_ttm_ajax_action', 'iva_ttm_update_plugin' );
function iva_ttm_update_plugin() {

	// Creates Zip Class Object
	$iva_ttm_zip = new IvaTtmZip();

	try {
		if ( function_exists( 'unzip_file' ) === false ) {
			if ( IvaTtmZip::is_zip_exists() === false ) {
				iva_ttm_throw_error( 'The ZipArchive php extension not exists, can\'t extract the update file. Please turn it on in php ini.' );
			}
		}
		echo esc_html__( 'Update in progress...', 'iva_testimonial_pro' );

		// If update files empty returns error
		if ( empty( $_FILES ) ) {
			iva_ttm_throw_error( esc_html__( 'Update file not found.', 'iva_testimonial_pro' ) );
		}

		// Current Plugin main file path
		$iva_ttm_main_file 			= IVA_TTM_CPT_DIR . '/adv-ttm-pro/';

		// Update file path info
		$iva_ttm_file_name 			= $_FILES['iva_ttm_update_file']['name'];
		$iva_ttm_file_temp_path 	= $_FILES['iva_ttm_update_file']['tmp_name'];
		$iva_ttm_file_type 			= $_FILES['iva_ttm_update_file']['type'];

		// Current Plugin path
		$iva_ttm_plugin_path 		= dirname( $iva_ttm_main_file ) . '/';

		// Current Plugin temporary path
		$iva_ttm_plugin_temp_path 	= $iva_ttm_plugin_path . 'temp/';

		// Current Plugin path info
		$iva_ttm_plugin_file_info		= pathinfo( $iva_ttm_main_file );
		$iva_ttm_plugin_file_basename 	= $iva_ttm_plugin_file_info['basename'];
		$iva_ttm_plugin_file_name 		= str_replace( '.php','',$iva_ttm_plugin_file_basename );

		// checks uploaded file is not empty
		if ( empty( $iva_ttm_file_name ) ) {
			iva_ttm_throw_error( esc_html__( 'You have not selected a file to upload. Please select a file.', 'iva_testimonial_pro' ) );
		}

		// Checks uploaded file is zip file or not
		$iva_ttm_upload_file_ext = pathinfo( $iva_ttm_file_name, PATHINFO_EXTENSION );
		if ( 'zip' !== $iva_ttm_upload_file_ext ) {
			iva_ttm_throw_error( esc_html__( 'Uploaded file is not a zip file. Select zip file and upload.', 'iva_testimonial_pro' ) );
		}

		// Checks temporary folder is exist or not
		if ( file_exists( $iva_ttm_file_temp_path ) === false ) {
			iva_ttm_throw_error( esc_html__( 'Cannot find the updated files.', 'iva_testimonial_pro' ) );
		}

		// Crates temporary folder
		iva_ttm_check_create_dir( $iva_ttm_plugin_temp_path );

		// Copys the zip file.
		$iva_ttm_zip_filepath = $iva_ttm_plugin_temp_path . $iva_ttm_file_name;

		// Moves the zip file.
		$iva_ttm_success = move_uploaded_file( $iva_ttm_file_temp_path, $iva_ttm_zip_filepath );

		// If success
		if ( false === $iva_ttm_success ) {
			iva_ttm_throw_error( 'Can\'t move the updated files here: {$iva_ttm_zip_filepath}.' );
		}

		if ( function_exists( 'unzip_file' ) === true ) {
			WP_Filesystem();
			$response = unzip_file( $iva_ttm_zip_filepath, $iva_ttm_plugin_temp_path );
		} else {
			$iva_ttm_zip->extract( $iva_ttm_zip_filepath, $iva_ttm_plugin_temp_path );
		}

		// Scans update file and returns all files
		$iva_ttm_tmp_dir_files = scandir( $iva_ttm_plugin_temp_path );

		$iva_ttm_extracted_files 	= array();
		foreach ( $iva_ttm_tmp_dir_files as $file ) {

			if ( '.' === $file || '..' === $file ) {
				continue;
			}

			// Uploaded file path
			$filepath = $iva_ttm_plugin_temp_path . $file;

			// If update file is directory then returns extracted folder
			if ( is_dir( $filepath ) ) {
				$iva_ttm_extracted_files[] = $file;
			}
		}

		// Gets extracted folder
		$iva_ttm_extracted_folder = $iva_ttm_extracted_files;

		if ( empty( $iva_ttm_extracted_folder ) ) {
			iva_ttm_throw_error( esc_html__( 'The updated folder is not extracted.', 'iva_testimonial_pro' ) );
		}
		if ( count( $iva_ttm_extracted_folder ) > 1 ) {
			iva_ttm_throw_error( esc_html__( 'Extracted folders are more than 1. Please check the updated file.', 'iva_testimonial_pro' ) );
		}

		// Gets update folder
		$iva_ttm_uploaded_folder = $iva_ttm_extracted_folder[0];
		if ( empty( $iva_ttm_uploaded_folder ) ) {
			iva_ttm_throw_error( esc_html__( 'Wrong updated folder.', 'iva_testimonial_pro' ) );
		}

		// Checks if update folder is match the main plugin filename
		if ( $iva_ttm_uploaded_folder !== $iva_ttm_plugin_file_name ) {
			iva_ttm_throw_error( esc_html__( 'The updated folder do not match the current plugin folder. Please check the updated file.', 'iva_testimonial_pro' ) );
		}

		// Update file path
		$iva_ttm_update_file_path  = $iva_ttm_plugin_temp_path . $iva_ttm_uploaded_folder . '/';

		//check some file in folder to validate it's the real one:
		$iva_ttm_check_filepath = $iva_ttm_update_file_path . $iva_ttm_uploaded_folder . '.php';

		if ( file_exists( $iva_ttm_check_filepath ) === false ) {
			// delete the update file from temporary path
			iva_ttm_delete_dir( $iva_ttm_plugin_temp_path );

			//iva_ttm_throw_error("The file: $iva_ttm_uploaded_folder.php not found in update folder.");
			iva_ttm_throw_error( esc_html__( 'Wrong updated folder.', 'iva_testimonial_pro' ) );
		}

		// Copy update files to destination folder
		iva_ttm_copy_dir( $iva_ttm_update_file_path, $iva_ttm_plugin_path );

		// delete the update file from temporary path
		iva_ttm_delete_dir( $iva_ttm_plugin_temp_path );

		echo 'Plugin Updated Successfully and redirecting...';
		echo '<script>location.href="' . admin_url( 'edit.php?post_type=iva_testimonial&page=iva_testimonial_settings' ) . '"</script>';

	} catch ( Exception $e ) {
		$iva_ttm_message  = $e->getMessage();
		$iva_ttm_message .= '<br>' . esc_html__( 'Please update the plugin manually via the ftp.', 'iva_testimonial_pro' );
		echo '<div style="color:#ff0000;font-size:20px;"><b>' . esc_html__( 'Update Error:', 'iva_testimonial_pro' ) . '</b>' . esc_attr( $iva_ttm_message ) . '</div><br>';
		echo '<a href="' . admin_url( 'edit.php?post_type=iva_testimonial&page=iva_testimonial_settings' ) . '">' . esc_html__( 'Go Back.', 'iva_testimonial_pro' ) . '</a>';
		exit();
	}
}
