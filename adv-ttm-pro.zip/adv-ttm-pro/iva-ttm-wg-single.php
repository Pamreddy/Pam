<?php
function iva_single_testimonial_widget() {
	register_widget( 'IVA_single_testimonial_widget' );
}
add_action( 'widgets_init', 'iva_single_testimonial_widget' );

class IVA_single_testimonial_widget extends WP_Widget {
	function __construct() {

		$widget_ops = array(
			'classname'		=> 'testimonial_wg',
			'description'	=> esc_html__( 'Single Testimonial Widget.', 'iva_testimonial_pro' ),
		);

		$control_ops = array(
			'width'   => '',
			'height'  => '',
			'id_base' => 'ttm_single_widget',
		);

		parent::__construct( 'ttm_single_widget', esc_html__( 'Single Testimonial', 'iva_testimonial_pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );
		echo wp_kses_post( $before_widget );

		$title		 = isset( $instance['title'] ) ? $instance['title'] : '';
		$ttm_posts 	 = isset( $instance['ttm_posts'] ) ? $instance['ttm_posts'] : '';
		$ttm_layouts = isset( $instance['ttm_layouts'] ) ? $instance['ttm_layouts'] : '';
		$ttm_single_widget = '[single_testimonial id=' . $ttm_posts . ' iva_ttm_layouts=' . $ttm_layouts . ' ]';
		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title ) . esc_attr( $title ) . wp_kses_post( $after_title );
		}
		echo do_shortcode( $ttm_single_widget );
		echo wp_kses_post( $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] 		 = strip_tags( $new_instance['title'] );
		$instance['ttm_posts'] 	 = strip_tags( $new_instance['ttm_posts'] );
		$instance['ttm_layouts'] = strip_tags( $new_instance['ttm_layouts'] );
		return $instance;
	}
	function form( $instance ) {
		$layouts = array(
			''		=> 'Choose one..',
			'v1-a'  => 'Layout 1-a',
			'v1-b'  => 'Layout 1-b',
			'v1-c'  => 'Layout 1-c',
			'v1-d'  => 'Layout 1-d',
			'v2-a'  => 'Layout 2-a',
			'v2-b'  => 'Layout 2-b',
			'v3-a'  => 'Layout 3-a',
			'v3-b'  => 'Layout 3-b',
			'v4-a'  => 'Layout 4-a',
			'v4-b'  => 'Layout 4-b',
			'v5-a'  => 'Layout 5-a',
			'v5-b'  => 'Layout 5-b',
			'v6-a'  => 'Layout 6-a',
			'v6-b'  => 'Layout 6-b',
			'v7'  	=> 'Layout 7',
			'v8-a'  => 'Layout 8-a',
			'v8-b'  => 'Layout 8-b',
		);
		$iva_ttm_post_ids = array();
		$args = array(
			'post_type' => 'iva_testimonial',
		);
		$iva_ttm_post_query = get_posts( $args );
		foreach ( $iva_ttm_post_query as $testimonial ) {
			$iva_ttm_post_ids[ $testimonial->ID ] = $testimonial->post_title;
			$testimonial_ids[] = $testimonial->ID;
		}
		$instance 	= wp_parse_args( (array) $instance, array( 'title' => '', 'ttm_posts' => '', 'ttm_layouts' => '' ) );
		$title 		 = $instance['title'];
		$ttm_posts 	 = $instance['ttm_posts'];
		$ttm_layouts = $instance['ttm_layouts'];

		// Title
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title:', 'iva_testimonial_pro' ) . '</label>';
		echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '">';
		echo '</p>';

		// Layouts
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'ttm_layouts' ) ) . '">' . esc_html__( 'Layouts:', 'iva_testimonial_pro' ) . '</label>';
		echo '<select name="' . esc_attr( $this->get_field_name( 'ttm_layouts' ) ) . '" id="' . esc_attr( $this->get_field_id( 'ttm_layouts' ) ) . '" class="widefat">';
		foreach ( $layouts as $key => $value ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $instance['ttm_layouts'], $key ) . '>' . esc_html( $value ) . '</option>';
		}
		echo '</select>';
		echo '</p>';

		// Posts
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'ttm_posts' ) ) . '">' . esc_html__( 'Testimonial Posts:', 'iva_testimonial_pro' ) . '</label>';
		echo '<select name="' . esc_attr( $this->get_field_name( 'ttm_posts' ) ) . '" id="' . esc_attr( $this->get_field_id( 'ttm_posts' ) ) . '" class="widefat">';
		foreach ( $iva_ttm_post_ids as $key => $value ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $instance['ttm_posts'], $key ) . '>' . esc_html( $value ) . '</option>';
		}
		echo '</select>';
		echo '</p>';
	}
}
