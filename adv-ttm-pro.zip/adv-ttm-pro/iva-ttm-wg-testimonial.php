<?php
function iva_testimonials_widget() {
	register_widget( 'IVA_Testimonials_Widget' );
}
add_action( 'widgets_init', 'iva_testimonials_widget' );

class IVA_Testimonials_Widget extends WP_Widget {
	function __construct() {

		$widget_ops = array(
			'classname'		=> 'testimonial_wg',
			'description'	=> esc_html__( 'Testimonials Pro Widget.', 'iva_testimonial_pro' ),
		);

		$control_ops = array(
			'width'   => 400,
			'height'  => 350,
			'id_base' => 'testimonial_widget',
		);

		parent::__construct( 'testimonial_widget', esc_html__( 'Testimonials Pro', 'iva_testimonial_pro' ), $widget_ops, $control_ops );
	}

	function widget( $args, $instance ) {

		extract( $args );
		echo wp_kses_post( $before_widget );

		$ttm_shortcode 	= isset( $instance['ttm_shortcode'] ) ? $instance['ttm_shortcode'] : '';
		$title		  	= isset( $instance['title'] ) ? $instance['title'] : '';

		if ( ! empty( $title ) ) {
			echo wp_kses_post( $before_title ) . esc_attr( $title ) . wp_kses_post( $after_title );
		}
		$shortcode_gen	= get_post_meta( $ttm_shortcode, 'shortcode_gen', true );
		echo do_shortcode( $shortcode_gen );
		echo wp_kses_post( $after_widget );
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] 			= strip_tags( $new_instance['title'] );
		$instance['ttm_shortcode'] 	= strip_tags( $new_instance['ttm_shortcode'] );
		return $instance;
	}
	function form( $instance ) {
		$iva_ttm_shortcode = array();
		$args = array(
			'posts_per_page' => -1,
			'post_type' 	 => 'iva_shortcode',
		);
		$testimonial_array = get_posts( $args );
		foreach ( $testimonial_array as $testimonial ) {
			$iva_ttm_shortcode[ $testimonial->ID ] = $testimonial->post_title;
			$testimonial_ids[] = $testimonial->ID;
		}
		$instance 		= wp_parse_args( (array) $instance, array( 'title' => '', 'ttm_shortcode' => '' ) );
		$title 			= $instance['title'];
		$ttm_shortcode 	= $instance['ttm_shortcode'];
		// Title
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">' . esc_html__( 'Title:', 'iva_testimonial_pro' ) . '</label>';
		echo '<input class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '">';
		echo '</p>';

		// Shortcodes
		echo '<p>';
		echo '<label for="' . esc_attr( $this->get_field_id( 'ttm_shortcode' ) ) . '">' . esc_html__( 'Shortcodes:', 'iva_testimonial_pro' ) . '</label>';
		echo '<select name="' . esc_attr( $this->get_field_name( 'ttm_shortcode' ) ) . '" id="' . esc_attr( $this->get_field_id( 'ttm_shortcode' ) ) . '" class="widefat">';
		foreach ( $iva_ttm_shortcode as $key => $value ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $instance['ttm_shortcode'], $key ) . '>' . esc_html( $value ) . '</option>';
		}
		echo '</select>';
		echo '</p>';
	}
}
